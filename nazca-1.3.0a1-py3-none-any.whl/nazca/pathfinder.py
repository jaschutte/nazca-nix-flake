"""
Pathfinder functionality to trace a netlist through a layout.

@authors: Jerom Baas, Ronald Broeke, Stefan van Ieperen.

Copyright (c) 2019-2023 Bright Photonics B.V.
"""
from typing import Any, List, Optional
from copy import copy, deepcopy
from dataclasses import dataclass
# TODO look into making find_optical connections more readable

import nazca as nd
import nazca.compact_models as cm


@dataclass
class Segment:
    """Class for storing the info a single path segment"""

    # TODO: reduce numnber of parameters? Is all this info really needed?
    #       e.g." pin_in can be the instance pin, so no need to explicitly add the instance
    pin_in: nd.Node  # start pin in Cell of a compact model connection
    pin_out: nd.Node  # end pin in Cell of a compact model connection
    connection: Any  # the compact model (reference) between pin_in and pin_out
    position_in: Any  # position of the input pin relative to the top cell
    position_out: Any  # position of the output pin relative to the top cell
    instance: nd.Instance  # instance in which the connection was found
    label: str # instance label


class Logger:
    """
    Class for logging outputs of the pathfinder.

    Args:
        filename (str): Name of the logfile to write to.
        logging_level (int): Level of logging. At 0 no logfile is created. At 1 a logfile is created with different
            pins traversed. At 2, the act of moving up and down the hierarchy is also logged.
        depth (int): Attribute used to manage indentations in the logging file that correspond to hierarchical depth.
        modeltype (str): Path signal type.
    """

    def __init__(
        self,
        filename="trace.log",
        logging_level=0,
        depth=0,
        modeltype='dis',
    ):
        self.filename = filename
        self.logging_level = logging_level
        self.depth = depth
        self.modeltype = modeltype
        self.logfile = None

        if self.logging_level > 0:
            self.logfile = open(filename, "w")
        elif self.logging_level == -1:
            self.logfile = open(filename, "w")

    def close(self):
        """Close the pathfinder log file if one was opened."""
        if self.logfile is not None and not self.logfile.closed:
            self.logfile.close()

    def __del__(self):
        self.close()

    def log(
        self,
        pin,
        status,
        modelinfo=None,
        sigtype=None,
        instance_params=None,
        value=0,
        instance_stack=None,
        from_pin=None,
        endpoint=None,
        connected_pins=None,
        paths_dict=None,
    ):
        """
        Outputs message to logging file if logging_level > 0. Outputs more detailed message if logging level > 1.
        The message depends on the status passed to the log function.

        Possible statuses:

            logging level 1:
                'start',
                'cm_connection',
                'pin_connection',
                'loop',
                'end_of_path',
                'end_of_path_splitting_node',
                'endpoint',
                'backtracking',
                'backtracked',
                'end_of_tracking'.
            logging level 2:
                'drill_down',
                'drill_up',
                'no_pin_connection',
                'no_cm_connection',
                'reverse'.

        Args:
            pin (node): current pin at the time of logging.
            status (str): string that determines what kind of message is logged.
            modelinfo (ModelInfo): ModelInfo object containing the compact model information.
                                    Used only if status is 'cm_connection' or 'backtracked'.
            sigtype (str): type of compact model connection found. Used only if status is 'cm_connection' or 'backtracked'.
            instance_params (dict): instance parameters for the compact model connection found.
                                    Used only if status is 'cm_connection' or 'backtracked'.
            value (float | str): value of compact model connection found. Used only if status is 'cm_connection' or 'backtracked'.
            from_pin (node): pin that the connection came from. Used only if status is 'backtracked'.
            instance_stack (list): Instance stack of instances traversed. Used for hierarchy in backtracking.
            endpoint (nd.Pin, nd.Cell or nd.Instance): Used for status 'endpoint', to specify which specific
                                                        user-provided endpoint was reached.
            connected_pins (list): List of connected pins. This is used to output the list of connections when status is
                                   'end_of_path_splitting_node' so that debugging is easier.
            paths_dict (dict): dictionary of final paths
        """
        if self.logging_level > 0:
            if status == "start":
                self.depth = 0
                self.logfile.write(f"Start of tracking paths...\n")
                self.depth = 1
                try:
                    # check if pin has an instance
                    instance_name = pin.cnode.instance.name
                    # if pin has an instance, slightly change output message
                    self.logfile.write(
                        f"{self.depth * '  '}Starting path tracking at pin '{pin.basename}' in instance '{instance_name}' of "
                        f"cell '{pin.cnode.cell.cell_name}'.\n"
                    )
                except AttributeError:
                    self.logfile.write(
                        f"{self.depth*'  '}Starting path tracking at pin '{pin.name}' in cell "
                        f"'{pin.cnode.cell.cell_name}'.\n"
                    )
            elif status == "cm_connection":
                try:
                    # check if pin has an instance
                    instance_name = pin.cnode.instance.name
                    # if pin has an instance, slightly change output message
                    if modelinfo is not None:
                        self.logfile.write(
                            f"{self.depth * '  '}Found compact model connection to pin '{pin.basename}' in instance '{instance_name}' "
                            f"of cell '{pin.cnode.cell.cell_name}' with '{sigtype}' model {modelinfo}\n"
                            f"{self.depth*'  '}and instance parameters {instance_params}\n"
                            f"{self.depth*'  '}(model not evaluated during initial pathfinding. Can be evaluated using solve().)\n"
                        )
                    else:
                        self.logfile.write(
                            f"{self.depth * '  '}Found compact model connection to pin '{pin.basename}' in instance '{instance_name}' "
                            f"of cell '{pin.cnode.cell.cell_name}' with value '{sigtype}' = {value}.\n"
                        )
                    if self.logging_level > 1:
                        self.logfile.write(
                            f"{self.depth * '  '}------------------------------------------------------"
                            f"-----------------\n"
                        )
                        self.logfile.write(
                            f"{self.depth * '  '}Looking for pin connections to pin '{pin.basename}' "
                            f"in instance '{instance_name}' of cell '{pin.cnode.cell.cell_name}'...\n"
                        )
                except AttributeError:
                    if modelinfo is not None:
                        self.logfile.write(
                            f"{self.depth*'  '}Found compact model connection to pin '{pin.name}' in cell "
                            f"'{pin.cnode.cell.cell_name}' with '{sigtype}' model {modelinfo}\n"
                            f"{self.depth*'  '}and instance parameters {instance_params}\n"
                            f"{self.depth*'  '}(model not evaluated during initial pathfinding. Can be evaluated using solve().)\n"
                        )
                    else:
                        self.logfile.write(
                            f"{self.depth*'  '}Found compact model connection to pin '{pin.name}' in cell "
                            f"'{pin.cnode.cell.cell_name}' with value '{sigtype}' = {value}.\n"
                        )
                    if self.logging_level > 1:
                        self.logfile.write(
                            f"{self.depth * '  '}------------------------------------------------------"
                            f"-----------------\n"
                        )
                        self.logfile.write(
                            f"{self.depth * '  '}Looking for pin connections to pin '{pin.name}' in "
                            f"cell '{pin.cnode.cell.cell_name}'...\n"
                        )
            elif status == "pin_connection":
                try:
                    # check if pin has an instance
                    instance_name = pin.cnode.instance.name
                    # if pin has an instance, slightly change output message
                    self.logfile.write(
                        f"{self.depth*'  '}Found pin-pin connection to pin '{pin.basename}' in instance '{instance_name}' of "
                        f"cell '{pin.cnode.cell.cell_name}'.\n"
                    )
                    if self.logging_level > 1:
                        self.logfile.write(
                            f"{self.depth * '  '}------------------------------------------------------"
                            f"-----------------\n"
                        )
                        self.logfile.write(
                            f"{self.depth * '  '}Looking for compact model connections to pin '{pin.basename}' "
                            f"in instance '{instance_name}' of cell '{pin.cnode.cell.cell_name}'...\n"
                        )
                except AttributeError:
                    self.logfile.write(
                        f"{self.depth * '  '}Found pin-pin connection to pin '{pin.name}' in cell "
                        f"'{pin.cnode.cell.cell_name}'.\n"
                    )
                    if self.logging_level > 1:
                        self.logfile.write(
                            f"{self.depth * '  '}------------------------------------------------------"
                            f"-----------------\n"
                        )
                        self.logfile.write(
                            f"{self.depth * '  '}Looking for compact model connections to pin '{pin.name}' "
                            f"in cell '{pin.cnode.cell.cell_name}'...\n"
                        )
            elif status == "loop":
                self.depth = 1
                try:
                    # check if pin has an instance
                    instance_name = pin.cnode.instance.name
                    # if pin has an instance, slightly change output message
                    self.logfile.write(
                        f"{self.depth * '  '}Detected loop at pin '{pin.basename}' in instance '{instance_name}' of cell "
                        f"'{pin.cnode.cell.cell_name}'.\n\n"
                    )
                except AttributeError:
                    self.logfile.write(
                        f"{self.depth*'  '}Detected loop at pin '{pin.name}' in cell "
                        f"'{pin.cnode.cell.cell_name}'.\n\n"
                    )
            elif status == "end_of_path":
                self.depth = 1
                try:
                    # check if pin has an instance
                    instance_name = pin.cnode.instance.name
                    # if pin has an instance, slightly change output message
                    self.logfile.write(
                        f"{self.depth * '  '}Reached end of path at pin '{pin.basename}' in instance '{instance_name}' of "
                        f"cell '{pin.cnode.cell.cell_name}'.\n\n"
                    )
                except AttributeError:
                    self.logfile.write(
                        f"{self.depth*'  '}Reached end of path at pin '{pin.name}' in cell "
                        f"'{pin.cnode.cell.cell_name}'.\n\n"
                    )
            elif status == "end_of_path_splitting_node":
                self.depth = 1
                try:
                    # check if pin has an instance
                    instance_name = pin.cnode.instance.name
                    # if pin has an instance, slightly change output message
                    self.logfile.write(
                        f"{self.depth * '  '}Splitting nodes: connections to:\n"
                    )
                    for connection in connected_pins:
                        self.logfile.write(
                            f"{self.depth * '  '}\t- pin '{connection.basename}' in instance '{connection.cnode.instance.name}' of "
                            f"cell '{connection.cnode.cell.cell_name}'\n"
                        )
                    self.logfile.write(
                        f"{self.depth * '  '}Terminated path at pin '{pin.basename}' in instance '{instance_name}' of "
                        f"cell '{pin.cnode.cell.cell_name}'.\n\n"
                    )
                except AttributeError:
                    self.logfile.write(
                        f"{self.depth * '  '}Splitting nodes: connections to:\n"
                    )
                    for connection in connected_pins:
                        self.logfile.write(
                            f"{self.depth * '  '}\t- pin '{connection.basename}' in instance '{connection.cnode.instance.name}' of "
                            f"cell '{connection.cnode.cell.cell_name}'\n"
                        )
                    self.logfile.write(
                        f"{self.depth*'  '}Terminated path at pin '{pin.name}' in cell "
                        f"'{pin.cnode.cell.cell_name}'.\n\n"
                    )
            elif status == "endpoint":
                self.depth = 1
                # figure out if endpoint is pin, cell or instance
                if isinstance(endpoint, nd.Node):
                    self.logfile.write(
                        f"{self.depth * '  '}Reached endpoint: pin is endpoint pin.\n"
                    )
                    try:
                        # check if pin has an instance
                        instance_name = endpoint.cnode.instance.name
                        # if pin has an instance, slightly change output message
                        self.logfile.write(
                            f"{self.depth * '  '}Reached end of path at pin '{endpoint.basename}' "
                            f"in instance '{instance_name}' of cell '{endpoint.cnode.cell.cell_name}'.\n\n"
                        )
                    except AttributeError:
                        self.logfile.write(
                            f"{self.depth * '  '}Reached end of path at pin '{endpoint.name}' in cell "
                            f"'{endpoint.cnode.cell.cell_name}'.\n\n"
                        )
                elif isinstance(endpoint, nd.Cell):
                    self.logfile.write(
                        f"{self.depth * '  '}Reached endpoint: pin "
                        f"in cell '{endpoint.cell_name}'.\n"
                    )
                    try:
                        # check if pin has an instance
                        instance_name = pin.cnode.instance.name
                        # if pin has an instance, slightly change output message
                        self.logfile.write(
                            f"{self.depth * '  '}Reached end of path at pin '{pin.basename}' in instance '{instance_name}' of "
                            f"cell '{pin.cnode.cell.cell_name}'.\n\n"
                        )
                    except AttributeError:
                        self.logfile.write(
                            f"{self.depth * '  '}Reached end of path at pin '{pin.name}' in cell "
                            f"'{pin.cnode.cell.cell_name}'.\n\n"
                        )
                elif isinstance(endpoint, nd.Instance):
                    self.logfile.write(
                        f"{self.depth * '  '}Reached endpoint: pin in {endpoint}.\n"
                    )
                    try:
                        # check if pin has an instance
                        instance_name = pin.cnode.instance.name
                        # if pin has an instance, slightly change output message
                        self.logfile.write(
                            f"{self.depth * '  '}Reached end of path at pin '{pin.basename}' in instance '{instance_name}' of "
                            f"cell '{pin.cnode.cell.cell_name}'.\n\n"
                        )
                    except AttributeError:
                        self.logfile.write(
                            f"{self.depth * '  '}Reached end of path at pin '{pin.name}' in cell "
                            f"'{pin.cnode.cell.cell_name}'.\n\n"
                        )
            elif status == "backtracking":
                self.depth = 0
                self.logfile.write(f"{self.depth*'  '}Backtracking...\n")
            elif status == "backtracked":
                if self.logging_level > 1:
                    self.depth = len(instance_stack) + 1
                else:
                    self.depth = 1
                try:
                    # check if pin has an instance
                    instance_name = pin.cnode.instance.name
                    # if pin has an instance, slightly change output message
                    if modelinfo is not None:
                        self.logfile.write(
                            f"{self.depth*'  '}Backtracked to pin '{pin.basename}' in instance '{instance_name}' of cell "
                            f"'{pin.cnode.cell.cell_name}'. Connection from pin '{from_pin.name}' in cell "
                            f"'{from_pin.cnode.cell.cell_name}' has '{sigtype}' compact model {modelinfo}\n"
                            f"{self.depth*'  '}and instance parameters {instance_params}\n"
                            f"{self.depth*'  '}(model not evaluated during initial pathfinding. Can be evaluated using solve().)\n"
                        )
                    else:
                        self.logfile.write(
                            f"{self.depth*'  '}Backtracked to pin '{pin.basename}' in instance '{instance_name}' of cell "
                            f"'{pin.cnode.cell.cell_name}'. Connection from pin '{from_pin.name}' in cell "
                            f"'{from_pin.cnode.cell.cell_name}' has value '{sigtype}' = {value}.\n"
                        )
                except AttributeError:
                    if modelinfo is not None:
                        self.logfile.write(
                            f"{self.depth*'  '}Backtracked to pin '{pin.name}' in cell "
                            f"'{pin.cnode.cell.cell_name}'. Connection from pin '{from_pin.name}' in cell "
                            f"'{from_pin.cnode.cell.cell_name}' has '{sigtype}' compact model {modelinfo}\n"
                            f"{self.depth*'  '}and instance parameters {instance_params}\n"
                            f"{self.depth*'  '}(model not evaluated during initial pathfinding. Can be evaluated using solve().)\n"
                        )
                    else:
                        self.logfile.write(
                            f"{self.depth*'  '}Backtracked to pin '{pin.name}' in cell "
                            f"'{pin.cnode.cell.cell_name}'. Connection from pin '{from_pin.name}' in cell "
                            f"'{from_pin.cnode.cell.cell_name}' has value '{sigtype}' = {value}.\n"
                        )
            elif status == "end_of_tracking":
                self.depth = 0
                self.logfile.write(
                    f"\n\nTracking done...\n\nFound {len(pin)} paths with the following endpins:\n"
                )
                for i, p in enumerate(pin):
                    if len(paths_dict[i]) > 0:
                        position_out = tuple(float(val) for val in paths_dict[i][-1].position_out) # convert to regular floats
                        try:
                            instance_name = p.cnode.instance.name
                            self.logfile.write(
                                f"{i+1}. Pin '{p.basename}' in instance '{instance_name}' of cell '{p.cnode.cell.cell_name}' at"
                                f" {position_out}.\n"
                            )
                        except AttributeError:
                            self.logfile.write(
                                f"{i + 1}. Pin '{p.name}' in cell '{p.cnode.cell.cell_name}' at"
                                f" {position_out}.\n"
                            )

        if self.logging_level > 1:
            if status == "drill_up":
                self.depth -= 1
                try:
                    # check if pin has an instance
                    instance_name = pin.cnode.instance.name
                    # if pin has an instance, slightly change output message
                    self.logfile.write(
                        f"{self.depth*'  '}Move up to pin '{pin.basename}' in instance '{instance_name}' of "
                        f"cell '{pin.cnode.cell.cell_name}'.\n"
                    )
                except AttributeError:
                    self.logfile.write(
                        f"{self.depth * '  '}Move up to pin '{pin.name}' in cell "
                        f"'{pin.cnode.cell.cell_name}'.\n"
                    )
            elif status == "drill_down":
                self.depth += 1
                try:
                    # check if pin has an instance
                    instance_name = pin.cnode.instance.name
                    # if pin has an instance, slightly change output message
                    self.logfile.write(
                        f"{self.depth * '  '}Move down to pin '{pin.basename}' in instance '{instance_name}' of "
                        f"cell '{pin.cnode.cell.cell_name}'.\n"
                    )
                except AttributeError:
                    self.logfile.write(
                        f"{self.depth * '  '}Move down to pin '{pin.name}' in cell "
                        f"'{pin.cnode.cell.cell_name}'.\n"
                    )
            elif status == "no_cm_connection":
                self.logfile.write(
                    f"{self.depth * '  '}No compact model connection of type '{self.modeltype}' found...\n"
                )
            elif status == "no_pin_connection":
                self.logfile.write(f"{self.depth * '  '}No connected pins found...\n")
            elif status == "reverse":
                self.logfile.write(f"{self.depth * '  '}Reversed tracking. Drilling down first...\n")


class Paths:
    """Perform pathfinding, i.e. finding connectivity in a layout.

    The Paths class creates an object that contains information on the different paths from a starting pin.

    Attributes:
        endpins (list): A list containing the endpins of the different paths.
        segments (dict): A dictionary containing the raw output data from the pathfinder.
        endpins_dict (dict): A dictionary containing the endpins and their positional information.
        number_of_paths (float): The number of different paths found by the pathfinder.
        startpin (node): The starting pin from which the paths were traced.
        lengths (list): A list containing the lengths of the different paths.
    """

    def __init__(
        self,
        startpin,
        endpoints=None,
        logfilename="trace.log",
        logging_level=0,
        reverse=False,
        allow_splitting_nodes=False,
        modeltype="dis",
        instance_stack=None,
        show=False,
        show_layer_number=2000,
        show_width=7,
    ):
        """
        Initializes the paths by finding the endpins and paths from a startpin using the
        _findpaths() function, calculating their lengths and the number of paths.

        Args:
            startpin (Node): Startpoint for the pathfinding algorithm.
            logfilename (str): Name of the logfile.
            endpoints (list): Optional List of pins, cells and/or instances where the pathfinder
                will terminate the paths
            logging_level (int): Level of logging. At 0 no logfile is created. At 1 a logfile
                is created with different pins traversed. At 2, the act of moving up and down
                the hierarchy is also logged.
            reverse (bool): If true, pathfinder will start tracking in the reverse direction.
                The default direction is to look for compact model connections at the start. If reverse
                is true, the pathfinder will look for pin2pin connections first.
            allow_splitting_nodes (bool): If true, the pathfinder will handle a splitting path in
                pin2pin connections. By default, this is false: If this happens, the pathfinder
                will terminate the path and raise an error.
            modeltype (str): Type of compact model connections to look for.
            instance_stack (list): Optional instance stack that a user can provide. This allows
                the pathfinder to break out of the starting level.
            show (bool): Show path in the cell. default=False.
        Returns:
            None
        """

        if startpin is None:
            msg = "You must specify a start pin to trace paths from."
            raise RuntimeError(msg)

        # find the paths
        endpoint_pins, endpoint_cells = self._endpoint_pin(endpoints)
        endpins, paths_dict = self._findpaths(
            startpin=startpin,
            endpoints=endpoint_pins,
            endpoint_cells=endpoint_cells,
            logfilename=logfilename,
            logging_level=logging_level,
            reverse=reverse,
            allow_splitting_nodes=allow_splitting_nodes,
            modeltype=modeltype,
            instance_stack=instance_stack,
        )

        self.endpins = endpins
        self.segments = paths_dict
        self.endpins_dict = self._generate_endpins_dictionary(paths_dict, startpin, instance_stack)
        # self.lengths = self._get_lengths(self.segments)
        self.number_of_paths = len(self.segments)
        self.startpin = startpin
        self.pathlayers = set()  # keep track of layers added by pathfinder to allow pathfinder to reuse them.
        self.label2params = self._get_label2params_mapping(topcell=startpin.cnode.cell)  # map instance labels to params
        self.parameter_defaults = deepcopy(self.label2params)
        if show:
            self.show(layer_number=show_layer_number, width=show_width)

    def set_parameters(
            self,
            parameters: dict,
            label: Optional[str]=None,
            cm_id: Optional[str]=None
    ) -> None:
        """Set instance <parameters> for any instance object corresponding to <label> or for any instance object of a
        cell with compact model identifier <cm_id>.

        The parameters are added to the stored parameters for this label in self.label2params.

        Args:
            parameters (dict): {parameter_name: value} instance parameters.
            label (str): label string of the instance for which parameters are to be added
            cm_id (str): Optional cm_id of the cell for which parameters are to be added. This can be used
                instead of label. If a label is provided, the cm_id is ignored.

        Returns:
            None
        """
        if label is None and cm_id is None:
            raise TypeError('You must provide either a label or an cm_id argument')

        matching_labels = []
        for full_label, info in self.label2params.items():
            if label is not None:
                if len(label) > len(full_label):
                    # if we do not perform this check, full_label[-len(label):] might give an index out of range error.
                    continue
                if label == full_label[-len(label):]:
                    matching_labels.append(full_label)
                    for name, value in parameters.items():
                        info['pcell_data'][name] = value
            elif cm_id is not None:
                if cm_id == info['cm_id']:
                    matching_labels.append(full_label)
                    for name, value in parameters.items():
                        info['pcell_data'][name] = value

        if not matching_labels:
            if label is not None:
                msg = f'Failed to set parameters: No instances found for label {label}. ' \
                      f'hint: Make sure to call update_label_hierarchy() before calling this function.'
            elif cm_id is not None:
                msg = f'Failed to set parameters: No instances found for Cell cm_id {cm_id}.'
            nd.compact_model_logger(msg, 'error')

    def reset_parameters(self) -> None:
        """Reset the parameters to the initial state.

        This function resets any parameters that have been changed by set_parameter back to their initial value
        """
        self.label2params = deepcopy(self.parameter_defaults)

    def solve(
        self,
        params: dict=None,
        solve_method: str="sum",
        input_power: float=None,
    ) -> dict:
        """Solve the paths.

        This function first evaluates all the different path segments using their compact models. Then, depending on the
        solve method, it will either sum (solve_method "sum") or multiply the segments of a path (solve_method "product"),
        or return the raw segments (solve_method "None")


        Args:
            params (dict): Dictionary containing simulation parameters
            solve_method (str): Method to evaluate the resulting paths. Potential options are "sum" to sum the segments
                of the paths, "product" to multiply the segments of the paths and "None" to return a list of paths, each
                containing a list of evaluated segments.
        Returns:
            list: list of resulting path segments.
        """
        allowed_solve_methods = ["sum", "product", "None"]
        if solve_method not in allowed_solve_methods:
            nd.main_logger(f"Solve method {solve_method} not supported. Supported solve methods: {allowed_solve_methods}")

        if params is None:
            params = {}

        startpin = self.startpin.basename
        result = {startpin: {}}
        for i, path in self.segments.items():
            endpin = self.endpins[i].basename

            if input_power is None:
                if solve_method == "sum":
                    input_power = 0.0
                elif solve_method == "product":
                    input_power = 1.0
                else:
                    input_power = None
            power = input_power

            evaluated_path = []
            for segment in path:
                # evaluate segment model
                if isinstance(segment.connection, cm.ModelInfo):
                    if segment.connection.nonlinear and solve_method == "None":
                        msg = f"Nonlinear model {cm.ModelInfo} cannot be evaluated for solve_method 'None'. Use " \
                              f"solve_method 'sum' or 'product' instead."
                        raise ValueError(msg)
                    elif segment.connection.nonlinear:
                        _params = {**params, "P_in": power}
                    else:
                        _params = params

                    label_key = segment.label

                    # Extra check: if label_key not in label2params, add it during traversal.
                    if label_key not in self.label2params:
                        if segment.instance is not None:
                            self.label2params[label_key] = {
                                "pcell_data": deepcopy(segment.instance.pcell_data),
                                "cm_id": segment.pin_in.cnode.cell.cm_id,
                            }
                        else:
                            # Fallback: use empty pcell_data if no instance
                            self.label2params[label_key] = {
                                "pcell_data": {},
                                "cm_id": segment.pin_in.cnode.cell.cm_id,
                            }

                    instance_params = self.label2params[label_key]["pcell_data"]
                    cm_result = cm.evaluate_compact_model(
                        compact_model=segment.connection,
                        cell=segment.pin_in.cnode.cell,
                        parameters=_params,
                        instance_parameters=instance_params,
                    )
                    connection_value = cm.parse_cm_result(
                        pin_in=segment.pin_in.basename,
                        pin_out=segment.pin_out.basename,
                        compact_model=segment.connection,
                        result=cm_result,
                    )
                else:
                    # flat value without compact model
                    connection_value = segment.connection
                evaluated_path.append(connection_value)
                if solve_method == "sum":
                    power += connection_value
                if solve_method == "product":
                    power *= connection_value

            if solve_method == "sum":
                solved_path = input_power + sum(evaluated_path)
            elif solve_method == "product":
                product = 1
                for val in evaluated_path:
                    product *= val
                solved_path = input_power * product
            else:
                solved_path = evaluated_path

            result[startpin].setdefault(endpin, []).append(solved_path)

        # sort result dictionary alphabetically for readability
        result[startpin] = {k: result[startpin][k] for k in sorted(result[startpin])}

        for endpin, solved_paths in result[startpin].items():
            if len(solved_paths) == 1:
                result[startpin][endpin] = solved_paths[0]
            else:
                msg = f"Paths.solve(): Multiple paths found from '{startpin}' to '{endpin}'. The pathtracer simulation " \
                      f"may not be accurate, as the pathtracer does not take phase into account"
                nd.compact_model_logger(msg, "warning")

        return result

    @staticmethod
    def get_pin_coordinate_up_instance_stack(pin, instance_stack):
        """Get the xy coordinates of the pin by going up the instance stack
        Args:
            pin (nd.Pin): pin for which the xy coordinates have to be calculated
            instance_stack (list): List of instances above the pin
        Returns:
            Tuple: x and y position of the pin coordinate relative to the top cell.
        """
        flipstate = False
        pointer = nd.Pointer(0, 0, 0)
        for instance in instance_stack:
            move = copy(instance.cnode.pointer)
            if flipstate:
                move.flip()
            pointer.move_ptr(move)
            flipstate = not flipstate if instance.cnode.flip else flipstate

        move = copy(pin.pointer)
        if flipstate:
            move.flip()
        pointer.move_ptr(move)

        return pointer.xy()

    def show_paths(
        self,
        layer_number=2000,
        width=5.0,
        paths2cell=None,
    ):
        """Visualize paths in the layout via a polyline.

        Args:
            layer_number (int): layer number for path 1.
            width (float): width of the lines drawn between the nodes of a path.
            paths2cell (nd.Cell): Cell to which to add the paths. Default is the active cell.

        Returns:
            None
        """
        if paths2cell is not None:
            nd.cfg.cells.append(paths2cell)
            nd.cfg.patchcell = True

        points_dict = {}
        for i, segments in self.segments.items():
            if len(segments) == 0:
                points_dict[i] = []
                continue
            # for each path, create a new layer for visualization
            layername = f"path{layer_number+i}"
            if layername not in nd.cfg.reuse_pathlayers:
                layer = nd.add_layer(name=layername, layer=layer_number+i, datatype=0)
                nd.cfg.reuse_pathlayers.add(layername)
            else:
                layer = nd.get_layer(layername)
            points = []
            for segment in segments:
                # do not add polyline points if position did not change
                if not points or segment.position_in != points[-1]:
                    points.append(segment.position_in)
            # do not add polyline points if position did not change
            if points[-1] != segments[-1].position_out:
                points.append(segments[-1].position_out)

            points_filtered = []
            for j, point in enumerate(points):
                if j == 0:
                    points_filtered.append(point)
                elif point != points_filtered[-1]:
                    points_filtered.append(point)

            # place polyline that visualizes the paths
            nd.Polyline(points_filtered, layer=layer, width=width, pathtype=1).put(0, 0, 0)

            # place pins that visualize the startpin and endpin of each path.
            nd.show_pin(pin=points[0], radius=2 * width, width=1 * width, layer=layer)
            nd.show_pin(pin=points[-1], radius=1.5 * width, width=1.5 * width, layer=layer)

            # update dictionary of the positions. Can be used for debugging purposes and pytests.
            points_dict[i] = points

        if paths2cell is not None:
            nd.cfg.cells.pop()
            nd.cfg.patchcell = False

        return points_dict
    show = show_paths

    def get_pathlengths(
        self,
        params: dict = None,
    ) -> list[float]:
        """
        Get the lengths of all the paths stored in a paths dictionary

        Args:
            params (dict): Optional parameters to pass to compact models
        Returns:
            lengths (list): A list of all the pathlengths.
        """

        if params is None:
            params = {}

        # Use solve with 'sum' method to get path lengths
        result = self.solve(params=params, solve_method="sum")

        # Extract lengths from the result dictionary
        startpin = self.startpin.basename
        selected_result = result[startpin]
        lengths = []
        for endpin in sorted(selected_result.keys()):
            value = selected_result[endpin]
            # If multiple paths to same endpoint, take first or handle appropriately
            if isinstance(value, list):
                lengths.extend(value)
            else:
                lengths.append(value)

        return lengths

    @staticmethod
    def _get_label2params_mapping(topcell):
        """Construct a mapping between hierarchical instance labels and compact model parameters

        Args:
            topcell (nd.Cell): Topcell of the paths
        Returns:
            dict: Mapping between labels and parameters
        """
        label2params = {}

        for params in nd.cell_iter(topcell=topcell, revisit=True):
            if params.cell is topcell:
                continue
            if not params.cell_open:
                continue
            if params.cell.auxiliary: continue
            if 'bbox' in params.cell.cell_name: continue
            if 'icon' in params.cell.cell_name: continue
            if 'stub' in params.cell.cell_name: continue

            unique_label = ''
            for i, node in enumerate(params.branch):
                if i > 0:
                    unique_label += f'{node.instance.label}/'
            # cutoff the trailing forward slash of the label
            unique_label = unique_label[:-1]

            if unique_label not in label2params:
                label2params[unique_label] = {
                    'pcell_data': deepcopy(params.branch[-1].instance.pcell_data),
                    'cm_id': params.cell.cm_id,
                }
            else:
                if label2params[unique_label]['pcell_data'] != params.branch[-1].instance.pcell_data:
                    msg = f'Update_label_hierarchy: different pcell_data for the same label'
                    nd.compact_model_logger(msg, 'error')

        return label2params

    def _findpaths(
        self,
        startpin,
        endpoints=None,
        endpoint_cells=None,
        logfilename="trace.log",
        logging_level=0,
        reverse=False,
        allow_splitting_nodes=False,
        modeltype="dis",
        instance_stack=None,
    ):
        """Function to find the paths originating from a certain Node <startpin>.

        The tracing follows the following algorithm:
        Step 1: Look for a compact model connections inside a cell and move to a connection.
        For example, if the start pin is pin a0 of a straight section step 1 will yield the
        b0 pin of that same straight section and the length from a0 to b0.
        Step 2: Look for pin2pin connections from a pin. This step yields pins connected
        to the pin found in step 1.

        If in step 1 multiple compact model connections are found, the state for those connections is
        stored as loose ends. When the end of the current path is reached, the algorithm will
        backtrack to one of the loose ends and continue tracking from there. Tracking continues
        until all paths have reached an endpoint.

        Args:
            startpin (Node): Startpoint for the pathfinding algorithm.
            logfilename (str): Name of the logfile.
            endpoints (list): Optional List of pins, cells and/or instances where the pathfinder
                will terminate the paths
            logging_level (int): Level of logging. At 0 no logfile is created. At 1 a logfile
                is created with different pins traversed. At 2, the act of moving up and down the
                hierarchy is also logged.
            reverse (bool): If true, pathfinder will start tracking in the reverse direction.
                The default direction is to look for compact model connections at the start. If reverse
                is true, the pathfinder will look for an instance pin2pin connections first.
            allow_splitting_nodes (bool): If true, the pathfinder will handle a splitting path in
                pin2pin connections. By default, this is False: If this happens, the pathfinder
                will terminate the path and raise an error
            modeltype (str): (=sigtype) Type of in-cell pin2pin connections to look for.
            instance_stack (list): Optional instance stack that a user can provide. This allows the
                pathfinder to break out of the starting level.

        Returns:
            list, list: endpins, paths; where endpins is a list of the endpins (Nodes) of all paths
                that were found, and paths is a list of all paths dicts that were found. Each path
                entry contains a list of [pin, length] where pin is the next pin and length is the
                compact model between that pin and the previous pin.
        """
        # initialize logger
        logger = Logger(filename=logfilename, logging_level=logging_level, modeltype=modeltype)

        # define parameters for tracking of paths
        # instance_stack stores hierarchical information, which is used to look for pin connections up in the hierarchy
        if instance_stack is None:
            instance_stack = []
            current_pin = startpin
        else:
            instance_stack = instance_stack.copy()
            try:
                current_pin = startpin.up
            except AttributeError:
                current_pin = startpin

        # visited pins stores all pins previously visited, which is used for detecting looped paths
        visited_pins = []
        visited_pins.append((tuple(instance_stack), current_pin))
        # loose end stores the tracking state of all but one connection when multiple connections are found.
        loose_ends = []
        # boolean for decision-making:
        backtracking = False

        if not reverse:
            find_compact_model_connections = True
            find_geometrical_connections = False
        else:
            find_compact_model_connections = False
            find_geometrical_connections = True

        tracking = True

        # endpins stores the endpins of all paths traced, this is an output
        endpins = []

        # variables for output
        path_id = 0
        pinlist = []
        paths_dict = {}

        # before tracking, check if startpin is an endpin
        endpoint_reached, endpoint = self._is_endpoint(
            current_pin, endpoints, endpoint_cells, instance_stack, logger
        )
        if endpoint_reached:
            # End of path. Stop performing path tracking of this path
            tracking = False

            # end of path, but we need to go up the instance stack in some way before output
            _, current_pin, instance_stack = self._find_connected_pins(current_pin, instance_stack, logger=logger, just_drill_up=True)
            # update logger and output lists
            logger.log(current_pin, endpoint=endpoint, status="endpoint")

            # if the endpoint is a pin, add that pin to endpins and paths_dict instead of the current pin
            if isinstance(endpoint, nd.Node):
                endpins.append(endpoint)
            else:
                endpins.append(current_pin)
            paths_dict[path_id] = pinlist

        for instance in instance_stack:
            # Cell2Instance mapping for the instance nodes.
            instance.C2I_nodemap = {node.up: node for node in instance.pin.values()}

        logger.log(current_pin, status="start")

        # if reversing, we need to drill down to ensure that any pin2pin connection is found
        if reverse:
            logger.log(current_pin, status="reverse")
            current_pin, _, instance_stack, _ = self._find_cm_connections(
                current_pin,
                instance_stack,
                logger=logger,
            )

        while tracking:
            # if end of path is reached and there are still loose ends, track paths from one of the stored loose ends
            if backtracking:
                # obtain state of one of the loose ends
                (
                    current_pin,
                    instance_stack,
                    visited_pins,
                    pinlist,
                    find_compact_model_connections,
                    find_geometrical_connections,
                ) = loose_ends.pop()
                connection_model = pinlist[-1].connection
                if logging_level > 0: # then print the connection model info to log
                    if isinstance(connection_model, cm.ModelInfo): # connection has a model, print its info but do not evaluate
                        logger.log(
                            current_pin, status="backtracked", modelinfo=connection_model, sigtype=sigtype,
                            instance_params=pinlist[-1].instance.pcell_data, value=None,
                            instance_stack=instance_stack, from_pin=pinlist[-1].pin_in,
                        )
                    else: # connection value is just a number, print it
                        logger.log(
                            current_pin, status="backtracked", sigtype=sigtype, value=connection_model,
                            instance_stack=instance_stack, from_pin=pinlist[-1].pin_in,
                        )
                # stop backtracking and start tracking from the current pin
                backtracking = False

                # check if the pin backtracked to is actually an endpin:
                endpoint_reached, endpoint = self._is_endpoint(
                    current_pin, endpoints, endpoint_cells, instance_stack, logger
                )
                if endpoint_reached:
                    # End of path. Stop performing path tracking of this path
                    find_compact_model_connections = False
                    find_geometrical_connections = False
                    # end of path, but we need to go up the instance stack in before output
                    _, current_pin, instance_stack = self._find_connected_pins(
                        current_pin, instance_stack, logger=logger, just_drill_up=True
                    )
                    # update logger and output lists
                    logger.log(current_pin, endpoint=endpoint, status="endpoint")

                    # if the endpoint is a pin, add that pin to endpins and paths_dict instead of the current pin
                    if isinstance(endpoint, nd.Node):
                        endpins.append(endpoint)
                    else:
                        endpins.append(current_pin)

                    paths_dict[path_id] = pinlist
                    path_id += 1

                    # check if there are any loose ends to track
                    if not loose_ends:  # no loose ends, stop tracking
                        break
                    else: # loose ends, start backtracking
                        backtracking = True
                        logger.log(current_pin, status="backtracking")
                    # set current pin to None as we are currently not tracking from a pin
                    current_pin = None

            if find_compact_model_connections:
                # STEP 1: Find pin2pin compact models inside the cells.
                (
                    segment_start,
                    cm_connections,
                    instance_stack,
                    drilled_pins,
                ) = self._find_cm_connections(
                    current_pin,
                    instance_stack,
                    logger=logger,
                    modeltype=modeltype,
                )
                # deal with possible endpoints during drilling down 
                for drilled_pin, drilled_instance_stack in drilled_pins:
                    endpoint_reached, endpoint = self._is_endpoint(
                        drilled_pin, endpoints, endpoint_cells, drilled_instance_stack, logger
                    )
                # TODO the if endpoint_reached logic can be refactored, used multiple times identically.
                if endpoint_reached:
                    find_compact_model_connections = False
                    find_geometrical_connections = False
                    _, current_pin, instance_stack = self._find_connected_pins(
                        drilled_pin, drilled_instance_stack, logger=logger, just_drill_up=True
                    )
                    logger.log(current_pin, endpoint=endpoint, status="endpoint")
                    if isinstance(endpoint, nd.Node):
                        endpins.append(endpoint)
                    else:
                        endpins.append(current_pin)
                    paths_dict[path_id] = pinlist
                    path_id += 1

                    if not loose_ends:
                        break
                    backtracking = True
                    logger.log(current_pin, status="backtracking")
                    current_pin = None
                    continue
                
                # deal with possibility of no compact model
                if cm_connections is None:
                    # End of path. Stop performing path tracking of this path
                    find_compact_model_connections = False
                    find_geometrical_connections = False

                    # update logger and output lists
                    logger.log(current_pin, status="no_cm_connection")
                    logger.log(current_pin, status="end_of_path")
                    endpins.append(current_pin)
                    paths_dict[path_id] = pinlist
                    path_id += 1
                    # check if there are any loose ends to track
                    if not loose_ends:  # no loose ends, stop tracking
                        break
                    else:  # loose ends, start backtracking
                        backtracking = True
                        logger.log(current_pin, status="backtracking")
                    # set current pin to None as we are currently not tracking from a pin
                    current_pin = None

                # found compact model connection(s), start tracking from (one of) the compact model
                else:
                    # flow control: need to perform step 1 next
                    find_compact_model_connections = False
                    find_geometrical_connections = True

                    # move to new pin, update loose ends
                    (
                        current_pin,
                        connection_model,
                        direction,
                        posrel,
                        sigtype,
                    ) = cm_connections.pop()
                    if logging_level > 0: # then print the connection model info to log
                        if isinstance(connection_model, cm.ModelInfo): # connection has a model, print its info but do not evaluate
                            logger.log(
                                current_pin,
                                status="cm_connection",
                                modelinfo=connection_model,
                                sigtype=sigtype,
                                instance_params=current_pin.cnode.cell.pcell_data,
                                value=None,
                            )
                        else: # connection value is just a number, print it
                            logger.log(current_pin, status="cm_connection", sigtype=sigtype, value=connection_model)

                    # update the pinlist for this path
                    pinlist_copy = pinlist.copy()
                    position_in = self.get_pin_coordinate_up_instance_stack(segment_start, instance_stack)
                    position_out = self.get_pin_coordinate_up_instance_stack(current_pin, instance_stack)
                    if instance_stack:
                        instance = instance_stack[-1]
                        label = ""
                        for instance in instance_stack:
                            label += f"{instance.label}/"
                        label = label[:-1]  # remove trailing slash
                    else:
                        instance = None
                        label = ""

                    pinlist.append(
                        Segment(
                            segment_start,
                            current_pin,
                            connection_model,
                            position_in,
                            position_out,
                            instance,
                            label
                        )
                    )

                    # store remaining connections as loose ends that will be visited after path end is reached
                    for _ in cm_connections:
                        (
                            cm_connection,
                            connection_model,
                            direction,
                            posrel,
                            sigtype,
                        ) = _

                        _pinlist_copy = pinlist_copy.copy()
                        position_in = self.get_pin_coordinate_up_instance_stack(segment_start, instance_stack)
                        position_out = self.get_pin_coordinate_up_instance_stack(cm_connection, instance_stack)
                        if instance_stack:
                            instance = instance_stack[-1]
                            label = ""
                            for instance in instance_stack:
                                label += f"{instance.label}/"
                            label = label[:-1]  # remove trailing slash
                        else:
                            instance = None
                            label = ""

                        _pinlist_copy.append(
                            Segment(
                                segment_start,
                                cm_connection,
                                connection_model,
                                position_in,
                                position_out,
                                instance,
                                label
                            )
                        )
                        loose_ends.append(
                            [
                                cm_connection,
                                instance_stack.copy(),
                                visited_pins.copy(),
                                _pinlist_copy,
                                find_compact_model_connections,
                                find_geometrical_connections,
                            ]
                        )

                # If a current pin was found, perform checks:
                if current_pin is not None:
                    # Check if current pin was already visisted.
                    # generate a unique pin_id to differentiate between pins in different
                    # instances of the same cell
                    pin_id = (tuple(instance_stack), current_pin)
                    if pin_id in visited_pins:
                        # End of path. Stop performing path tracking of this path
                        find_compact_model_connections = False
                        find_geometrical_connections = False
                        # path is a loop, drill up from current pin
                        _, current_pin, instance_stack = self._find_connected_pins(
                            current_pin, instance_stack, logger=logger, just_drill_up=True
                        )

                        # update logger and output lists
                        logger.log(current_pin, status="loop")
                        endpins.append(current_pin)
                        paths_dict[path_id] = pinlist
                        path_id += 1
                        # check if there are any loose ends to track
                        if not loose_ends: # no loose ends, stop tracking
                            break
                        else: # loose ends, start backtracking
                            backtracking = True
                            logger.log(current_pin, status="backtracking")
                        # set current pin to None as we are currently not tracking from a pin
                        current_pin = None
                    # if no loop, store the current pin for the sake of future loop detection
                    else:
                        visited_pins.append((tuple(instance_stack), current_pin))

                    # check if current pin is at an endpoint
                    #if current_pin is not None:
                    endpoint_reached, endpoint = self._is_endpoint(
                        current_pin, endpoints, endpoint_cells, instance_stack, logger
                    )
                    if endpoint_reached:
                        # End of path. Stop performing path tracking of this path
                        find_compact_model_connections = False
                        find_geometrical_connections = False
                        # end of path, but we need to go up the instance stack in some way before output
                        _, current_pin, instance_stack = self._find_connected_pins(
                            current_pin, instance_stack, logger=logger, just_drill_up=True
                        )
                        # update logger and output lists
                        logger.log(current_pin, endpoint=endpoint, status="endpoint")

                        # if the endpoint is a pin, add that pin to endpins and paths_dict
                        if isinstance(endpoint, nd.Node):
                            endpins.append(endpoint)
                        else:
                            endpins.append(current_pin)
                        paths_dict[path_id] = pinlist
                        path_id += 1

                        # check if there are any loose ends to track
                        if not loose_ends: # no loose ends, stop tracking
                            break
                        else:  # loose ends, start backtracking
                            backtracking = True
                            logger.log(current_pin, status="backtracking")
                        # set current pin to None as we are currently not tracking from a pin
                        current_pin = None

            if find_geometrical_connections:
                # STEP 2: Find pin connections from current_pin
                (
                    connected_pins,
                    upper_output_pin,
                    instance_stack,
                ) = self._find_connected_pins(
                    current_pin, instance_stack, logger=logger
                )
                if reverse:
                    reverse = False
                # Found no connected pins
                if connected_pins is None:
                    # End of path. Stop performing path tracking of this path
                    find_compact_model_connections = False
                    find_geometrical_connections = False
                    # end of path, but we need to go up the instance stack in some way before output
                    _, current_pin, instance_stack = self._find_connected_pins(
                        current_pin, instance_stack, logger=logger, just_drill_up=True
                    )
                    # update logger and output lists
                    logger.log(current_pin, status="end_of_path")
                    endpins.append(current_pin)
                    paths_dict[path_id] = pinlist
                    path_id += 1

                    # check if there are any loose ends to track
                    if not loose_ends: # no loose ends, stop tracking
                        break
                    else:  # loose ends, start backtracking
                        backtracking = True
                        logger.log(current_pin, status="backtracking")
                    # set current pin to None as we are currently not tracking from a pin
                    current_pin = None

                # Found connections
                else:
                    # flow control: need to perform step 1 next
                    find_compact_model_connections = True
                    find_geometrical_connections = False
                    # move to new pin.
                    connected_pin_1 = connected_pins.pop()

                    if not instance_stack:
                        # store the previous pin. We want to return this pin in the case of splitting nodes
                        # update current pin with the connected pin that we found.
                        current_pin = connected_pin_1
                        logger.log(current_pin, status="pin_connection")
                    # if we are not at the top level, try to go to the top level first
                    else:
                        try:
                            _, current_pin, instance_stack = self._find_connected_pins(
                                connected_pin_1, instance_stack, logger=logger, just_drill_up=True
                            )
                            logger.log(current_pin, status="pin_connection")
                        except Exception:
                            current_pin = connected_pin_1
                            logger.log(current_pin, status="pin_connection")
                    if connected_pins:
                        # store other connected pins as loose ends, if splitting nodes are allowed
                        if allow_splitting_nodes:
                            nd.main_logger(
                                f"Splitting node at pin '{current_pin.basename}' in instance '{current_pin.cnode.instance.name}' of "
                                f"cell '{current_pin.cnode.cell.cell_name}', allow_splitting_nodes is set to True.",
                                'warning'
                            )
                            for connected_pin in connected_pins:
                                pinlist_copy = pinlist.copy()
                                # store the loose ends
                                loose_ends.append(
                                    [
                                        connected_pin,
                                        instance_stack.copy(),
                                        visited_pins.copy(),
                                        pinlist_copy,
                                        find_compact_model_connections,
                                        find_geometrical_connections,
                                    ]
                                )
                        # if splitting nodes are not allowed (which is the default setting), we need to terminate this
                        # path and raise an error
                        else:
                            nd.main_logger(
                                f"Splitting node at pin '{current_pin.basename}' in instance '{current_pin.cnode.instance.name}' of "
                                f"cell '{current_pin.cnode.cell.cell_name}'. Terminated path.",
                                'error'
                            )
                            find_compact_model_connections = False
                            find_geometrical_connections = False
                            # terminate path, but we need to go up the instance stack in some way before output
                            _, current_pin, instance_stack = self._find_connected_pins(
                                current_pin, instance_stack, logger=logger, just_drill_up=True
                            )
                            # update logger and output lists
                            logger.log(current_pin, status="end_of_path_splitting_node", connected_pins=connected_pins)
                            endpins.append(current_pin)
                            paths_dict[path_id] = pinlist
                            path_id += 1

                            # check if there are any loose ends to track
                            if not loose_ends:  # no loose ends, stop tracking
                                break
                            else:  # loose ends, start backtracking
                                backtracking = True
                                logger.log(current_pin, status="backtracking")
                            # set current pin to None as we are currently not tracking from a pin
                            current_pin = None
                    pin_id = (tuple(instance_stack), current_pin)

                    # check if new current pin is at an endpoint or already visited.
                    #TODO this can be refactored together with the same code in 
                    # find_compact_model_connections part and probably backtracking
                    if current_pin is not None:
                        # Check if current pin was already visisted.
                        # generate a unique pin_id to differentiate between pins in different
                        # instances of the same cell
                        pin_id = (tuple(instance_stack), current_pin)
                        if pin_id in visited_pins:
                            # End of path. Stop performing path tracking of this path
                            find_compact_model_connections = False
                            find_geometrical_connections = False
                            # path is a loop, drill up from current pin
                            _, current_pin, instance_stack = self._find_connected_pins(
                                current_pin, instance_stack, logger=logger, just_drill_up=True
                            )

                            # update logger and output lists
                            logger.log(current_pin, status="loop")
                            endpins.append(current_pin)
                            paths_dict[path_id] = pinlist
                            path_id += 1
                            # check if there are any loose ends to track
                            if not loose_ends: # no loose ends, stop tracking
                                break
                            else: # loose ends, start backtracking
                                backtracking = True
                                logger.log(current_pin, status="backtracking")
                            # set current pin to None as we are currently not tracking from a pin
                            current_pin = None
                        # if no loop, store the current pin for the sake of future loop detection
                        else:
                            visited_pins.append((tuple(instance_stack), current_pin))

                        #check for endpoint
                        endpoint_reached, endpoint = self._is_endpoint(
                            current_pin, endpoints, endpoint_cells, instance_stack, logger
                        )
                        if endpoint_reached:
                            # End of path. Stop performing path tracking of this path
                            find_compact_model_connections = False
                            find_geometrical_connections = False
                            # end of path, but we need to go up the instance stack in some way before output
                            _, current_pin, instance_stack = self._find_connected_pins(
                                current_pin, instance_stack, logger=logger, just_drill_up=True
                            )
                            # update logger and output lists
                            logger.log(current_pin, endpoint=endpoint, status="endpoint")

                            # if the endpoint is a pin, add that pin to endpins and paths_dict
                            if isinstance(endpoint, nd.Node):
                                endpins.append(endpoint)
                            else:
                                endpins.append(current_pin)
                            paths_dict[path_id] = pinlist
                            path_id += 1

                            # check if there are any loose ends to track
                            if not loose_ends: # no loose ends, stop tracking
                                break
                            else:  # loose ends, start backtracking
                                backtracking = True
                                logger.log(current_pin, status="backtracking")
                            # set current pin to None as we are currently not tracking from a pin
                            current_pin = None

        logger.log(pin=endpins, status="end_of_tracking", paths_dict=paths_dict)
        logger.close()

        # return the endpins that were found during the tracking
        return endpins, paths_dict

    def _generate_endpins_dictionary(
            self,
            paths_dict,
            startpin,
            instance_stack=None,
    ):
        """Function to generate a endpins.

        Function to generate an endpins dictionary that contains the endpins and their position
        at the highest hierarchical level.

        Args:
            paths_dict (dict): Dictionary of the paths, obtained from self._findpaths().
            startpin (nd.Pin): Startpin from which tracking is performed.
            instance_stack (list): List of instances above the startpin.

        Returns:
            dict: endpins dictionary containing a dictionary of the endpin and position for each path.
        """
        endpins_dict = {}

        if instance_stack is None:
            instance_stack = []
        for i, segments in paths_dict.items():
            # if paths were found, use the segments to obtain each endpin and position
            if len(segments) > 0:
                endpins_dict[i] = {
                    'endpin': segments[-1].pin_out,
                    'position': segments[-1].position_out
                }
            # if no paths were found (termination on startpin), extract the position of the startpin.
            else:
                endpins_dict[i] = {
                    'endpin': startpin,
                    'position': self.get_pin_coordinate_up_instance_stack(startpin, instance_stack)
                }
        return endpins_dict
    
    @staticmethod
    def _should_drill(pin1, pin2, require_same_position=False):
        """Return whether node is a valid drilling/parent candidate for pin.
        
        Args:
            pin1 (Node): Pin from which to move.
            pin2 (Node): Candidate pin to move to.
            require_same_position (bool): Whether drill candidate must be at the same position as pin1.

        A drill candidate must have a physical width (not None and not 0).
        Optionally, for drilling up and down, the candidate must be colocated with pin.
        """
        # this should flag that there is a node without a width.
        width = getattr(pin2, "width", None)
        if width is None:
            return False
        
        if pin2.cnode.cell.auxiliary:
            return False
        
        if require_same_position and (pin1.x != pin2.x or pin1.y != pin2.y):
            return False
        
        return True

    def _drill_up_instance_stack(self, pin):
        """Drill one layer up in the instance stack.

        Args:
            pin (Node): Pin from which to move up.

        Returns:
            Node, list, list:
             - pin: original pin
             - parent_pins: list of pins that are parent nodes
             - adjacent_pins: list of pins that are connected but not at same location
        """
        adjacent_pins = []
        parent_pins = []
        # look at all pins connected to this pin
        for node, _ in pin.nb_geo:
            # if node is in a different instance with the same parent, it is a connected node
            if (
                node.cnode.instance is not pin.cnode.instance
                and node.cnode.parent_cnode is pin.cnode.parent_cnode
                and self._should_drill(pin, node, require_same_position=False)
            ):
                adjacent_pins.append(node)
            # otherwise, it is possible that the node is a parent node.
            elif (
                pin.cnode.parent_cnode is node.cnode
                and self._should_drill(pin, node, require_same_position=True)
            ):
                parent_pins.append(node)

        return pin, parent_pins, adjacent_pins
         
    def _drill_down_instance_stack(self, pin, instance_stack):
        """Drill one layer down in the instance stack.

        Args:
            pin (Node): Pin from which to move down.
            instance_stack (list): List of instances above the input pin.

        Returns:
            Node, list, bool: 
                - drill_pin: updated pin
                - instance_stack: updated instance stack
                - bool: whether drilling succeeded.
        """
        drill_pin = None
        for nb, _ in pin.nb_geo:
            if (
                nb.cnode.instance is not None
                and self._should_drill(pin, nb, require_same_position=True)
            ):
                drill_pin = nb
                break  # assume max one instance below can be connected

        if drill_pin is None:
            return pin, instance_stack, False

        instance_stack.append(drill_pin.cnode.instance)
        return drill_pin, instance_stack, True

    def _find_cm_connections(
        self,
        start,
        instance_stack=None,
        logger=None,
        flip=1,
        modeltype="dis",
    ):
        """Drill down from a node in the cell hierarchy until a valid edge is found or max depth is reached.

        This function finds if node <start> has a compact model connection to another pin.
        If not, it is checked if node is connected to an instance to, if so,
        drill down into it.
        When drilling down this function creates a "C2I_nodemap" attribute (cell2instance)
        in every Instance it passes to find the way back up from a Cell to the Instance along
        the celltree path it came from.

        Args:
            start (Node): a higher level Node from which you want to go down
            instance_stack (list): list of instances above the pin
            logger (Logger): pathfinder logger
            flip (int): when the instance is flipped, the direction of the cm connection needs to be flipped as well.  
            modeltype (str): modeltype of compact model connections

        Returns:
            Node, list, list:
                - start_segment (Node): start Node of an optical connection,
                - nb_cm (list): list of connections
                - instance_stack (list): list of Instances traversed,
        """
        if instance_stack is None:
            instance_stack = []
        drilled_pins = []

        if start.cnode.instance is not None:  # instance pin start
            current_pin = start
            instance = start.cnode.instance
            instance_stack.append(instance)
            if instance.cnode.flip:
                flip *= -1
        else:  # cell pin start
            current_pin = start

        # drill down until a signal edge is found or the bottom is reached:
        while True:
            next_nodes_cm = []  # store signal connections.

            # First check wether current node has a cm connection.
            if current_pin.cnode.instance is not None:  # pin resides in an instance
                # Cell2Instance mapping for the instance nodes.
                instance.C2I_nodemap = {
                    node.up: node for node in instance.pin.values()
                }
                # go to corresponding cell node of current_pin before drilling down
                cell_node = current_pin.up
            else:
                cell_node = current_pin

            drilled_pins.append((current_pin, instance_stack.copy()))
            if cell_node is not current_pin:
                drilled_pins.append((cell_node, instance_stack.copy()))

            # Find (and store) all cm connections of cell_node, if any:
            # TODO add Cell.flag to the cell to see if it we want to take this specific cm into account
            for nb, L, direction, sigtype, extra_out in cell_node.path_nb_iter(
                sigtype=modeltype,
            ):
                # find xya position of the compact model nodes for visualisation
                if nb is None:
                    x, y, a = 0, 0, 0  # termination
                else:
                    x, y, a = nd.diff(cell_node, nb)
                posrel = nd.Pointer(x, y, a)
                if flip == -1:
                    posrel.flip()
                next_nodes_cm.append(
                    (nb, L, direction, posrel.xya(), sigtype)
                )
            if len(next_nodes_cm) > 0:
                if logger is not None:
                    logger.log(cell_node, status="drill_down")
                break  # found cm link, leave while loop

            # If no cm connection was found, drill down, if possible.
            # Do not drill down in auxiliary cells and ignore non-physical helper pins.
            current_pin, instance_stack, drilled_down = self._drill_down_instance_stack(
                cell_node,
                instance_stack,
            )

            if not drilled_down:
                break  # bottom reached, leave while loop
            else:
                instance = current_pin.cnode.instance
                if instance.cnode.flip:
                    flip *= -1
                if logger is not None:
                    logger.log(current_pin, status="drill_down")

        start_segment = cell_node
        if len(next_nodes_cm) == 0:
            return [None] * 3 + [drilled_pins]
        else:
            return start_segment, next_nodes_cm, instance_stack, drilled_pins

    def _find_connected_pins(
        self,
        pin,
        instance_stack,
        logger=None,
        just_drill_up=False,
    ):
        """Look for pin-to-pin connections to the input pin.

        Args:
            pin (Node): pin to find pin-to-pin connections for.
            instance_stack (list): List of parent instances/cells of the input pin
            logger (Logger): Logger object used for logging purposes
            just_drill_up (bool): If True, only drill up the instance stack and do not look for adjacent pins. For moving to top hierarchical level

        Returns:
           list, Node, list:
               - all pins connected to the input pin. If no connected pins are found this returns None.
               - the pin at the top hierarchical level that corresponds to the input pin. 
               - list of parent instances/cells of the output pins. If no connected pins are found,
                 returns the initial instance stack.
        """

        # save the instance stack. If no connect pins are found, we need to output the old instance stack
        old_instance_stack = instance_stack.copy()

        # while there are instances in the instance stack, go up in hierarchy and look for pin connections
        # continue trying to go up in hierarchy until the instance_stack is empty
        while instance_stack:
            # consider the next instance:
            instance = instance_stack[-1]
            if pin in instance.C2I_nodemap:
                pin = instance.C2I_nodemap[pin]
            # if the top level is the instance of a cell, it's not possible to find a pin one level up for the
            # last entry of the instance stack
            else:
                break
            # update the instance stack
            pin, parent_pins, adjacent_pins = self._drill_up_instance_stack(
                pin
            )
            # if we find a connected pin, return that connected pin and an updated instance stack
            if adjacent_pins and not just_drill_up:
                instance_stack.pop()
                if logger is not None:
                    logger.log(pin, status="drill_up")
                return adjacent_pins, pin, instance_stack

            # if we don't find a connected pin but do find a parent node,
            # move to the parent node 
            elif parent_pins:
                pin = parent_pins[0]
                instance_stack.pop()
                if logger is not None:  
                    logger.log(pin, status="drill_up")

                # if instance stack is empty, that means there is no pin to pin connection.
                if instance_stack == []:
                    if logger is not None:
                        logger.log(pin, status="no_pin_connection")
                    # return None for adjacent pins and the old instance stack.
                    adjacent_pins = None
                    if not just_drill_up:
                        instance_stack = old_instance_stack
                    return adjacent_pins, pin, instance_stack
                
        if logger is not None:
            logger.log(pin, status="no_pin_connection")
        # return None for adjacent pins and the old instance stack.
        adjacent_pins = None
        if not just_drill_up:
            instance_stack = old_instance_stack
        return adjacent_pins, pin, instance_stack

    @staticmethod
    def _endpoint_pin(endpoints):
        """
        Function to dig down from the endpoint to all the related pins to make a list
         of all endpoint pins at all levels

        Args:
            endpoints (list): list of endpoints, which can be pins, cells, or instances.
        Returns:
            list:
             -endpoints_pin: list of all endpoint pins at all levels
        """
        endpoint_pins = []
        endpoint_cells = []
        if endpoints:
            if isinstance(endpoints, (str, nd.Node, nd.Cell, nd.Instance)):
                endpoints = [endpoints]
            for endpoint in endpoints:
                if isinstance(endpoint, nd.Node):
                    endpoint_pins.append(endpoint)
                elif isinstance(endpoint, nd.Cell):
                    endpoint_cells.append(endpoint)
                elif isinstance(endpoint, str):
                    endpoint_cells.append(endpoint)
                elif isinstance(endpoint, nd.Instance):
                    endpoint_pins.extend(endpoint.pin.values())
                else:
                    msg = f"Provided endpoint {endpoint} is not a pin, cell or instance."
                    raise TypeError(msg)
        return endpoint_pins, endpoint_cells
        
    def _is_endpoint(
        self,
        pin,
        endpoints,
        endpoint_cells=None,
        input_instance_stack=None,
        logger=None,
    ):
        """
        Function to check if a pin is an endpoint. A pin is an endpoint if it or its parent
        pins is the same as one of the endpoints, or is in a cell that is the same as one of
        the endpoints, or if it is in an instance that is the same as one of the endpoints.

        First, this functions drills all the way down the hierarchy, while storing all
        instances traversed. Then, this drills all the way up through all the instances
        traversed (and possible instances provided as input_instance_stack), checking at
        each corresponding pin whether it is an endpoint. If an endpoint is encountered,
        this function returns True. If no endpoint is encountered in any of the instances,
        this function returns False.

        Args:
            pin (Node): pin to check for
            endpoints (list): list of endpoints, which can be pins, cells, or instances.
            input_instance_stack (list): list containing a history of traversed instances
            logger: Logger object used for logging purposes
            #TODO: add 3th layer of logging for checking for endpoints.
        Returns:
            bool, Node:
               - True, endpoint: if the pin is an endpoint, return True and the endpoint
               - False, None: if the pin is not an endpoint, return False and None
        """
        # TODO consider refactoring
        if endpoints is not None and pin in endpoints:
            return True, pin

        if endpoints is not None and input_instance_stack:
            for endpoint in endpoints:
                if (
                    endpoint.cnode.instance in input_instance_stack
                    and endpoint.up is pin
                ):
                    return True, endpoint

        if endpoints is not None:
            for endpoint in endpoints:
                if endpoint is pin:
                    return True, endpoint
                # drill down in endpoint to see if any endpoint_pins is current_pin
                _, _, _, endpoint_pins = self._find_cm_connections(
                    endpoint, logger=None
                )
                instance_end_pins = [
                    item for item in endpoint_pins 
                    if 'instance' in str(item[0])
                ]
                instance_stack = input_instance_stack.copy()
                parent_pins, _, _ = self._find_connected_pins(
                    pin, instance_stack, logger = None
                )
                if not parent_pins:
                    parent_pins = []
                current_pins_all = [
                    item for item in parent_pins +[pin]
                    if 'instance' in str(item)
                ]
                if any(pin is endpoint_pin for endpoint_pin, _ in instance_end_pins for pin in current_pins_all):
                    return True, endpoint
        current_pin = pin
        instance_stack = [] if input_instance_stack is None else input_instance_stack.copy()
        if not endpoint_cells:
            return False, None

        
        while True:
            cell = current_pin.cnode.cell
            for endpoint_cell in endpoint_cells:
                endpoint_name = endpoint_cell.cell_name if isinstance(endpoint_cell, nd.Cell) else endpoint_cell
                if cell is endpoint_cell or cell.cell_name == endpoint_name:
                    for instance in reversed(instance_stack):
                        if instance.cell is cell and current_pin in instance.C2I_nodemap:
                            return True, instance.C2I_nodemap[current_pin]
                    return True, current_pin

            if not instance_stack:
                return False, None
            instance = instance_stack[-1]
            if current_pin not in instance.C2I_nodemap:
                return False, None
            current_pin = instance.C2I_nodemap[current_pin]
            instance_stack.pop()
            if logger is not None:
                logger.log(current_pin, status="drill_up")