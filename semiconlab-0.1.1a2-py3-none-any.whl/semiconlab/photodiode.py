#
# (c) 2024 Xaveer Leijtens
#
# Photodiode template
#
import nazca as nd
import nazca.geometries as geom
from nazca.cellcache_util import cellcache
from nazca.clipper import grow_polygons

import semiconlab as sl

__all__ = ["pd"]

GAP = 2  # There should be 2µm gap between the fingers for manufacturing.


@cellcache("comb", ["nfinger", "width", "length"])
def comb(nfinger: int = 3, width: float = 2.5, length: float = 10.0) -> nd.Cell:
    """Create a metal structure with fingers to be paired with the same structure to
    create an interdigitated electrode. The width, depth and total number of fingers can
    be specified."""
    length = length + width / 2
    with nd.Cell() as C:
        grow = 0.5  # structure will grow 2x and srhink 1x
        pitch = 2 * (GAP + width)
        polygons = []
        x0, y0 = length / 2, 0
        for n in range(nfinger):
            polygons.append(
                geom.rectangle(
                    length - 2 * grow,
                    width - 2 * grow,
                    position=5,
                    shift=(x0, y0 + n * pitch),
                )
            )
        polygons.append(
            geom.rectangle(
                width - 2 * grow,
                (nfinger - 1) * pitch + width - 2 * grow,
                position=5,
                shift=(0, (nfinger - 1) * pitch / 2),
            )
        )
        electrode = grow_polygons(polygons, 2 * grow, 0.01)
        electrode = grow_polygons(electrode, -grow, 0.005)
        for p in electrode:
            nd.Polygon(points=p, layer="Metal").put()
        nd.Polygon(geom.rectangle(width, width / 2, 6), layer="Metal").put()
        nd.Pin("a0").put(0, -width / 2, -90)
        nd.Pin("b0").put(0, -width / 2, -90)
    return C


@cellcache("pn_contact", ["nfinger", "width", "length"])
def pn_contact(nfinger: int = 3, width: float = 2.5, length: float = 10.0) -> nd.Cell:
    """Create n-contact and p-contact."""
    with nd.Cell() as C:
        pitch = 2 * (GAP + width)
        if length <= 0:  # Two staight lines
            s1 = nd.strt(
                length=nfinger * pitch,
                width=width,
                layer="Metal",
            ).put()
            nd.strt(
                length=nfinger * pitch,
                width=width,
                layer="Metal",
            ).put(0, length + width + GAP)
        else:
            m = comb(nfinger=nfinger, width=width, length=length)
            m.put(0, 0)
            s1 = nd.strt(length=GAP, width=width, layer="Metal").put()
            m.put(pitch / 2, -(length + width + GAP), flip=True)
            nd.strt(length=2 * GAP + width, width=width, layer="Metal").put()
        nd.Pin("c0", width=width, xs="Metal").put()
        nd.Pin("c1", width=width, xs="Metal").put(s1.pin["b0"])
        nd.put_stub(["c0", "c1"])
        C.default_pins("c0", "c1")
    return C


@cellcache("pd", ["nfinger", "width", "length"])
def pd(nfinger: int = 3, length: float = 10.0, width: float = 2.5) -> nd.Cell:
    """This compoment defines the contacts on the n-doped mesa top layer. This in turn
    defines the size of the detector mesa. It has one optical input pin (a0) and two
    electrical pins (c0 and c1)

    Args:
        nfinger (int): number of interdigitated fingers (default 3)
        width (float): width of the metal tracks (default 2.5)
        length (float): length of each finger (default 10)

    Returns:
        Cell: nazca cell
    """
    mesalength = nfinger * 2 * (width + GAP) + GAP
    mesawidth = 3 * GAP + 2 * width + length
    with nd.Cell() as C:
        # Detector mesa
        for lay, growtup, *_ in nd.layeriter("WG"):
            (_a1, grow), (_a2, _b2), _c1, _c2 = growtup
            g = 2 * grow
            # print(f"{lay=}, {grow=}")
            nd.Polygon(
                geom.rectangle(mesalength + grow / 2, mesawidth + g, position=2),
                layer=lay,
            ).put(-grow / 2)
        # Metal
        pn = pn_contact(nfinger, width, length).put(
            mesalength, (mesawidth - width) / 2 - GAP, 180
        )
        C.autobbox = True

        # Put pins so we can connect to the PD
        nd.Pin(name="a0", xs="WG").put(0, 0, 180)
        # Electrical contact
        pn.raise_pins()
        # default from a0 to c0
        C.default_pins("a0", "c0")
    return C


if __name__ == "__main__":
    sl.wg.strt().put()
    pd1 = pd(nfinger=3, length=3).put()

    sl.wg.strt().put(100)
    pd1 = pd(nfinger=3, length=0).put()

    sl.metal.bend(width=2.5, radius=20, angle=45).put(pd1.pin["c0"])
    sl.metal.bend(width=2.5, radius=20, angle=-45).put(pd1.pin["c1"])

    comb().put(500)
    pn_contact(width=2.5, length=0).put(300, 0)
    pn_contact(width=2.5, length=10).put(300, 10)

    nd.export_gds()
