"""
Amplitude models for gensol testing

"""
import numpy as np


def mmi2x2(wl, dwidth=0):
    """
    Example model for 2x2 mmi featuring parabolic transmission and linear imbalance/phase error

    """
    # parabolic transmission centered at wl_c, offset by width variation
    offset = dwidth/10
    wl_c = 1.55 + offset

    # set transmission at +- dwl to T_dwl dB
    T_0 = -3.1
    T_dwl = -3.5
    dwl = 0.02
    dropoff = (T_0-T_dwl) /(dwl) ** 2
    A = -dropoff * (wl - wl_c) ** 2 + T_0

    # generate linear imbalance between channels of +-imb for at +- dwl
    imb = 0.1  # dB
    imb_c = 0.05
    imbalance = imb/dwl * (wl-wl_c) + imb_c

    # generate linear phase error between channels of +-dph for at +- dwl
    dph = 3  # deg
    dph = dph * 2 * np.pi / 360  # convert to radians
    dphase = dph/dwl * (wl-wl_c)

    amplitude_bar  = 10 ** ((A-imbalance/2)/10)
    amplitude_cross = 10 ** ((A+imbalance/2)/10)

    bar = np.sqrt(amplitude_bar) * np.exp(0j)
    cross = np.sqrt(amplitude_cross) * np.exp(0.5j * np.pi + dphase * 1.0j)

    result = {
        'a0': {'b0': bar, 'b1': cross},
        'a1': {'b0': cross, 'b1': bar},
    }

    return result


def phase_shifter(wl, length, voltage=0):
    """
    Example amplitude model of a phase shifter with a Vpi = 0.5 Vmm. 
    Assuming zero loss.

    Args:
        wl (float): simulation wavelength in [um].
        length (float): length of the phase shifter in [um].
        voltage (float): voltage applied to the phase shifter in [V].

    Returns:
        dict: dictionary with compact model result
    """

    Neff = 3.2  # for a more elaborate model, this would be a call to an index model
    Vpi = 0.5 / (length * 1e-3)
    optlen = Neff * length
    dphase = np.pi * voltage/Vpi * 1j
    value = 1.0 * np.exp(2j * np.pi * optlen / wl + dphase)

    result = {
        'a0': {'b0': value},
    }
    return result


def xs_transition():
    """
    Mock up model for this transition, assuming no loss and no phase difference.
    """
    value = 1.0 * np.exp(0j)

    result = {
        'a0': {'b0': value},
    }
    return result


class DummyIndex:
    def __init(self):
        pass

    def Neff(self, width=3.0, radius=0.0, wl=1.55, pol=0, mode=0):
        if radius == 0:
            return 3.5 - 0.5 * pol - 0.1 * mode - 0.5 / (1 + width ** 2) + 0.5 / wl ** 2.0
        else:
            return 3.5 - 0.5 * pol - 0.1 * mode - 0.5 / (1 + width ** 2) + 1.0 / (0.2 * radius) + 0.5 / wl ** 2.0


index = DummyIndex()

def strt(length, width, wl, pol=0):
    pol = int(pol)
    optlen = index.Neff(width=width, wl=wl, pol=pol, mode=0) * length
    connection_value = 1.0 * np.exp(2.0j * np.pi * optlen / wl)
    result = {
        'a0': {'b0': connection_value}
    }
    return result


def arc(width, width2, radius, angle, wl, pol=0):
    """Optical path length model for an arc bend.
    """
    pol = int(pol)
    length = abs(radius * angle * np.pi/180)

    n1 = index.Neff(width=width, wl=wl, pol=pol, mode=0)
    if width2 != width:
        n2 = index.Neff(width=width2, wl=wl, pol=0, mode=0)
    else:
        n2 = n1

    optlen = 0.5 * (n1 + n2) * length

    connection_value = 1.0 * np.exp(2.0j * np.pi * optlen / wl)
    result = {
        'a0': {'b0': connection_value}
    }
    return result


def soa(P_in, wl, length, current=0.0, unprocessed=False):
    """Simplified nonlinear SOA gain model

    This gain model takes saturation into account.
    The model uses a small signal gain and a saturation power that depend on the current.

    Args:
        P_in (float): input power in [dB] or [dBm].
        wl (float): simulation wavelength in [um].
        length (float): length of the SOA in [um].
        current (float): current applied to SOA in [mA].
        unprocessed (bool): optional argument that indicates this component has not been analyzed yet.
    """
    if unprocessed:
        result = {
            "a0": {"b0": 0} # do not transmit anything
        }

    else:
        Neff = 3.2  # for a more elaborate model, this would be a call to an index model
        optlen = Neff * length
        phase = 1.0 * np.exp(2j * np.pi * optlen / wl)

        P_in = 10 ** (P_in/10)

        P_sat = 0.08 * current
        P_sat = 10 ** (P_sat/10)

        g0 = np.exp(6.5 - 12.5 * 0.57 ** (current/15.0))

        if g0 < 1.0:
            gain = g0
        else:
            gain = g0 * (1 + P_in / P_sat) / (1 + g0 * P_in / P_sat)


        result = {
            "a0": {"b0": np.sqrt(gain) * phase}
        }

    return result
