# -----------------------------------------------------------------------
#
# Nazca is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or (at
# your option) any later version.
#
# Nazca is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with Nazca.  If not, see <http://www.gnu.org/licenses/>.
# -----------------------------------------------------------------------
#
# @author: Mike Machielsen
# Bright Photonics B.V. (c) 2025,
# @email: info@brightphotonics.eu
#

import yaml
import numpy as np


_YAMLDumperBase = getattr(yaml, "CSafeDumper", yaml.SafeDumper)

# Get faster C-accelerated yaml loader, if available.
yloader = getattr(yaml, "CSafeLoader", yaml.SafeLoader)


class NazcaYAMLDumper(_YAMLDumperBase):
    """Custom YAML dumper for Nazca that handles tuples and numpy types.

    Example usage:

    with open(filename, "w") as f:
        yaml.dump(netlist, f, Dumper=NazcaYAMLDumper, default_flow_style=False, sort_keys=False)

    """

    pass


def represent_tuple(dumper, data):
    """Convert tuples to lists for YAML serialization."""
    return dumper.represent_list(list(data))


def represent_numpy_float(dumper, data):
    """Convert numpy floats to Python floats for YAML serialization."""
    return dumper.represent_float(float(data))


def represent_numpy_int(dumper, data):
    """Convert numpy integers to Python integers for YAML serialization."""
    return dumper.represent_int(int(data))


def represent_numpy_array(dumper, data):
    """Convert numpy arrays to lists for YAML serialization."""
    return dumper.represent_list(data.tolist())


# Register the custom representers
NazcaYAMLDumper.add_representer(tuple, represent_tuple)
NazcaYAMLDumper.add_representer(np.float64, represent_numpy_float)
NazcaYAMLDumper.add_representer(np.float32, represent_numpy_float)
NazcaYAMLDumper.add_representer(np.int64, represent_numpy_int)
NazcaYAMLDumper.add_representer(np.int32, represent_numpy_int)
NazcaYAMLDumper.add_representer(np.ndarray, represent_numpy_array)
