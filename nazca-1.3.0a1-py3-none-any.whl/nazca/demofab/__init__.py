# -----------------------------------------------------------------------
# This file is part of Nazca.
#
# Nazca is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or (at
# your option) any later version.
#
# Nazca is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with Nazca.  If not, see <http://www.gnu.org/licenses/>.
# -----------------------------------------------------------------------
#
# @Authors: Katarzyna Lawniczuk, Ronald Broeke
# @email: nazca@brightphotonics.eu
# 2024(c)

"""
DEMO PDK initialization.

An example on how to initialize foundry specific technology settings.
DEMO PDK is for Nazca tutorials and PIC design training.

Note:
    Any resemblence of technology details in the DEMO PDK with an actual foundry
    is purely coincidental.
"""


print()
print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
print("Nazca Design - demofab PDK")
print("by Bright Photonics")
print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
print()

from importlib.metadata import version, PackageNotFoundError
try:
    __version__ = version("demofab")
except PackageNotFoundError:
    # Not an installed nazca package, but a git source tree
    from ._version import get_version
    __version__ = get_version()

technology = f"demofab_{__version__}"

import nazca as nd
with nd.Technology(technology):
    from .pdk_10_materials import *
    from .pdk_15_xsections import *
    from .pdk_20_technology import *
    from .pdk_30_BB_library import *
    from .pdk_40_project_templates import *
    from .pdk_50_api import *

