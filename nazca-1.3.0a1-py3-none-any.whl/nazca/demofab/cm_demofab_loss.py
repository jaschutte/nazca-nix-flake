"""
Example of loss compact models for demofab

"""
import numpy as np

def mmi1x2(wl=1.55, dwidth=0):
    """
    Example model for 1x2 mmi featuring parabolic transmission
    """
    # parabolic transmission centered at wl_c, offset by width variation
    offset = dwidth/10
    wl_c = 1.55 + offset

    # set transmission at +- dwl to T_dwl dB
    T_0 = -3.1
    T_dwl = -3.5
    dwl = 0.02
    dropoff = (T_0-T_dwl) /(dwl) ** 2
    A = -dropoff * (wl - wl_c) ** 2 + T_0

    result = {
        'a0': {'b0': A, 'b1': A},
    }

    return result


def mmi2x2(wl=1.55, dwidth=0):
    """
    Example model for 2x2 mmi featuring parabolic transmission and linear imbalance

    """
    # parabolic transmission centered at wl_c, offset by width variation
    offset = dwidth/10
    wl_c = 1.55 + offset

    # set transmission at +- dwl to T_dwl dB
    T_0 = -3.1
    T_dwl = -3.5
    dwl = 0.02
    dropoff = (T_0-T_dwl) /(dwl) ** 2
    A = -dropoff * (wl - wl_c) ** 2 + T_0

    # generate linear imbalance between channels of +-imb for at +- dwl
    imb = 0.1  # dB
    imb_c = 0.05
    imbalance = imb/dwl * (wl-wl_c) + imb_c

    loss_bar  = A-imbalance/2
    loss_cross = A+imbalance/2

    result = {
        'a0': {'b0': loss_bar, 'b1': loss_cross},
        'a1': {'b0': loss_cross, 'b1': loss_bar},
    }

    return result


def phase_shifter(length, propagation_loss=3.5e-4):
    """
    Example model for phase shifter loss

    Args:
        length (float): length of the phase shifter in [um].

    Returns:
        dict: dictionary with compact model result
    """
    loss = propagation_loss * length

    result = {
        'a0': {'b0': loss},
    }
    return result


def xs_transition():
    """
    Mock up model for this transition
    """
    loss = 0.5 # dB

    result = {
        'a0': {'b0': -loss},
    }
    return result


def strt(length, propagation_loss=3.5e-4):
    loss = propagation_loss * length
    
    result = {
        'a0': {'b0': -loss}
    }
    return result


def arc(radius, angle, propagation_loss=3.5e-4):
    """Optical path length model for an arc bend.
    """
    length = abs(radius * angle * np.pi/180)
    loss = propagation_loss * length

    result = {
        'a0': {'b0': -loss}
    }
    return result


def soa(P_in, current=0.0):
    """Simplified nonlinear SOA gain model

    This gain model takes saturation into account.
    The model uses a small signal gain and a saturation power that depend on the current.

    Args:
        P_in (float): input power in [dB] or [dBm].
        current (float): current applied to SOA in [mA].
    """
    P_in = 10 ** (P_in/10)

    P_sat = 0.08 * current
    P_sat = 10 ** (P_sat/10)

    g0 = np.exp(6.5 - 12.5 * 0.57 ** (current/15.0))

    if g0 < 1.0:
        gain = g0
    else:
        gain = g0 * (1 + P_in / P_sat) / (1 + g0 * P_in / P_sat)


    result = {
        "a0": {"b0": 10 * np.log10(gain)}
    }

    return result


if __name__ == "__main__":
    import numpy as np
    import matplotlib.pyplot as plt
    input_powers = np.linspace(-30, 20, 1000)
    currents = np.linspace(0.0, 250, 50)

    fig, ax = plt.subplots()
    for i, current in enumerate(currents):
        gain = []
        for input_power in input_powers:
            gain.append(soa(P_in=input_power, current=current)["a0"]["b0"])
        ax.plot(input_powers, gain, label=f"I = {round(current, 1)} mA")
    ax.legend()
    ax.set_xlabel("Input power [dBm]")
    ax.set_ylabel("Gain [dB]")
    ax.grid()
    plt.show()
