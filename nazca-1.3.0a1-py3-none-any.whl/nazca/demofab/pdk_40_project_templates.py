# -----------------------------------------------------------------------
# This file is part of Nazca.
#
# Nazca is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or (at
# your option) any later version.
#
# Nazca is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with Nazca.  If not, see <http://www.gnu.org/licenses/>.
# -----------------------------------------------------------------------
#
# @Authors: Katarzyna Lawniczuk, Ronald Broeke
# @email: nazca@brightphotonics.eu
# 2017(c)

"""
**DEMO PDK project definition.**

This module is intended to define the cell templates of a technology,
e.g. the cells for an MPW.
It may contains cells that define **optical or electrical IO** functionality of
the die with the external world, e.g. fiber-coupling or wire-bonding.
"""

import nazca as nd
from nazca import Cell
from nazca.demopackager.unit_cell import UnitCell
from nazca.demopackager.unit_cell import apply_coating as nd_apply_coating
import nazca.bb_util as bbu
from . import technology

DIE_WIDTH = 5000
DIE_HEIGHT = 5000
DICELANE_WIDTH = 100
UC_ORIGIN = (50, 50)
COATING_WIDTH = 150


pinlines: dict = {
    "io": nd.PinLine(
        balance=0.5,
        length=None,
        N=16,
        dN=1,
        pitch=127,
        N0=0,
        flip=False,
        prefix="io",
        reverse=True,
        angle=0,
        symbol_cell=None,
        symbol_shape="arrow_full",
        symbol_scale=1.0,
        symbol_layer="package_pin",
        text_move=[0, 0, -90],
        text_height=0.5,
        text_show=False,
        text_arr=None,
        text_layer="package_pin_text",
        text_align="cc",
        annotation=True,
        annotation_move=[-0.35, 0, 0],
        annotation_layer="bb_pin_text",
        instantiate=False,
        pintype=None,
        zfill=2,
        cellname="pinline_ssc",
    ),
    "dc": nd.PinLine(
        balance=0.5,
        length=None,
        N=20,
        dN=1,
        pitch=200,
        N0=0,
        flip=False,
        prefix="dc",
        reverse=True,
        angle=0,
        symbol_cell=None,
        symbol_shape="arrow_full",
        symbol_scale=1.0,
        symbol_layer="package_pin",
        text_move=[-0.4, 0, 0],
        text_height=0.15,
        text_show=True,
        text_arr=None,
        text_layer="package_pin_text",
        text_align="cc",
        annotation=True,
        annotation_move=[-0.35, 0, 0],
        annotation_layer="bb_pin_text",
        instantiate=False,
        pintype=None,
        zfill=2,
        cellname="pinline_dc",
    ),
    "rf": nd.PinLine(
        balance=0.5,
        length=None,
        N=4,
        dN=1,
        pitch=500,
        N0=0,
        flip=False,
        prefix="rf",
        reverse=True,
        angle=0,
        symbol_cell=None,
        symbol_shape="arrow_full",
        symbol_scale=1.0,
        symbol_layer="package_pin",
        text_move=[0, 0, -90],
        text_height=0.5,
        text_show=False,
        text_arr=None,
        text_layer="package_pin_text",
        text_align="cc",
        annotation=True,
        annotation_move=[-0.35, 0, 0],
        annotation_layer="bb_pin_text",
        instantiate=False,
        pintype=None,
        zfill=2,
        cellname="pinline_rf",
    ),
}


@bbu.technology(technology)
def unitcell(
    die_width: float = DIE_WIDTH,
    die_height: float = DIE_HEIGHT,
) -> Cell:
    """Create a unitcell for demofab.

    Args:
        die_width (float): nominal horizontal die size in [um].
        die_height (float): nominal vertical die size in [um].
        cellname (str): name of the unit cell.

    Returns:
        nd.Cell: unitcell
    """
    uc = UnitCell(
        nominal_die_width=die_width,
        nominal_die_height=die_height,
        dicelane_width=DICELANE_WIDTH,
        origin=UC_ORIGIN,
    )
    die = uc.cell()
    return die

# Make apply_coating available in the demofab namespace
@bbu.technology(technology)
def apply_coating(
    cell: Cell,
    west_coating: str,
    east_coating: str,
) -> Cell:
    """Apply coating to the unit cell.

    Args:
        cell (Cell): The unit cell to apply coating to.
        west_coating (str): Coating type for the west facet. Options: 'AR', 'HR', 'NO', 'DC'.
        east_coating (str): Coating type for the east facet. Options: 'AR', 'HR', 'NO', 'DC'.

    Returns:
        Cell: The cell with coating applied.
    """
    # In order for the foundry to differentiate between no coating, and no preference,
    # the foundry has layers for both. Use those instead of specifying coating=None.
    coating2layer = {
        "AR": "Coating_AR",
        "HR": "Coating_HR",
        "NO": "Coating_NO",
        "DC": "Coating_DC",
    }
    coat_w = coating2layer.get(west_coating)
    coat_e = coating2layer.get(east_coating)
    for coat in (coat_w, coat_e):
        if coat is None:
            nd.main_logger(
                f"Coating {coat} not available\n"
                """Available coating options: AR | HR | NO | DC
AR: Anti-reflection
HR: High-reflection
NO: No coating (facets as-cleaved)
DC: User has no coating preferences""",
                "warning",
            )

    return nd_apply_coating(
        cell=cell,
        west_coating={"layer": coat_w, "overspray": COATING_WIDTH},
        east_coating={"layer": coat_e, "overspray": COATING_WIDTH},
    )

@bbu.technology(technology)
@nd.cellcache(name="MPW_CELL_DEMOFAB")
def cell_template(die_width: float = DIE_WIDTH, die_height: float = DIE_HEIGHT) -> Cell:
    """Create an MPW cell for demofab.

    Args:
        die_width (float): nominal horizontal die size in [um].
        die_height (float): nominal vertical die size in [um].

    Returns:
        nd.Cell: MPW template cell
    """

    with nd.Cell() as C:
        # Foundry MPW template
        uc = unitcell(die_width, die_height)
        die = uc.put(0).raise_pins()

        # Apply die overlays
        apply_coating(uc, west_coating="AR", east_coating="AR").put(0)

        # Add pins to the cell
        pinlines["dc"].cell(prefix="dcN").put(uc.pin["des_tc"].xyclone(0, -50, 180)).raise_pins()
        pinlines["dc"].cell(prefix="dcS").put(uc.pin["des_bc"].xyclone(0, 50, 0)).raise_pins()
        pinlines["rf"].cell(prefix="rfW").put(uc.pin["des_lc"].xyclone(50, 0, -90)).raise_pins()
        pinlines["io"].cell(prefix="ioE").put(uc.pin["nom_rc"].xyclone(0, 0, 90)).raise_pins()
        # pinlines["io"].cell(prefix="iowgE", N0=8, N=8, balance=0.0, reverse=True).put(uc.pin['nom_rc'].xyclone(0, -7.5*127, 90)).raise_pins()
    return C


if __name__ == "__main__":
    nd.export_gds(cell_template(), filename="cell_template.gds")
