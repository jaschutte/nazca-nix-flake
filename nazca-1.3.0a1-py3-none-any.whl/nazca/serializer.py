"""
Serialization of objects to JSON format.

Either define a specific (de)serialization path for an object type,
otherwise check if pickling is needed for serialization and do so.
"""

from __future__ import annotations

import pickle
import base64
from typing import Any
import math
import numpy as np
import nazca as nd
from nazca.compact_models import CompactModelLibrary, compact_model_library


# TODO can we also automate the cases where the attribute is a pointer to an entire class? We could check for the
#      presence of a to_json() method for this class. We would then serialize it such that the serialized dictionary
#      also contains a string reference to the corresponding deserialization function in this file, and use that
#      during the deserialization.
#      For example, one could format the result as:
#         my_serialized_class = ('deserialize_my_class', {<serialized class>})
#     where deserialize_my_class is a function in this file that deserialized using the serialized json {<serialized class>}
#
# RB: A class can be pickled for de(serialization), see PinLine() in if _name__... below.


def _lookup_in_namespace(namespace: Any, name: str):
    """Lookup a callable by name inside a namespace (dict, module, or object)."""
    if isinstance(namespace, dict):
        obj = namespace.get(name)
        if callable(obj):
            return obj
        cls = namespace.get("PDKClient")
        if cls is not None:
            cand = getattr(cls, name, None)
            if callable(cand):
                return cand
        return None
    # module or object
    obj = getattr(namespace, name, None)
    if callable(obj):
        return obj
    cls = getattr(namespace, "PDKClient", None)
    if cls is not None:
        cand = getattr(cls, name, None)
        if callable(cand):
            return cand
    return None


def _find_api_for_callable(func: Any, name: str | None = None) -> str | None:
    """Return the api key from nd.cfg.apis that owns this callable, if any."""
    if name is None:
        name = getattr(func, "__name__", None)
    if not name:
        return None
    for api_key, namespace in nd.cfg.apis.items():
        # exact identity match for module-level function
        if isinstance(namespace, dict):
            if namespace.get(name) is func:
                return api_key
            cls = namespace.get("PDKClient")
            if cls is not None and getattr(cls, name, None) is func:
                return api_key
        else:
            if getattr(namespace, name, None) is func:
                return api_key
            cls = getattr(namespace, "PDKClient", None)
            if cls is not None and getattr(cls, name, None) is func:
                return api_key
    return None


def _resolve_function_from_apis(name: str, api: str | None = None):
    """Resolve a function by name using the API registry in nd.cfg.apis."""
    apis = nd.cfg.apis

    # Prefer specific API when provided
    if api:
        namespace = apis.get(api)
        if namespace is not None:
            cand = _lookup_in_namespace(namespace, name)
            if callable(cand):
                return cand
        return None

    # Otherwise search all registered APIs
    for _, namespace in apis.items():
        cand = _lookup_in_namespace(namespace, name)
        if callable(cand):
            return cand
    return None


def serialize_attribute(attr: Any) -> Any:
    """Automatically serialize an object attribute if it is a Callable.

    It is possible that the attribute of an object points to a function.
    We cannot transfer this function over the server, so we have to serialize it.

    Args:
        attr (Any): attribute of an object that is being serialized

    Returns:
        dict: the serialized attribute.
    """
    if callable(attr):
        name = getattr(attr, "__name__", None)
        api = _find_api_for_callable(attr, name)
        # Return a structured 'token'
        token = {"__type__": "function", "name": name}
        if api:
            token["api"] = api
        return token
    return attr


def deserialize_attribute(attr: Any) -> Any:
    """Automatically deserialize an object attribute which may be a Callable.

    It is possible that on the server side the object's attribute points to a function on the server side.
    In that case, we need to insert the pointer towards the endpoint
    function on the client side. This function automatically handles this case.

    It requires that there is an endpoint function on the client side (api) with the same name as the original
    function on the server side.

    Args:
        attr: serialized attribute.

    Returns:
        Any: deserialized attribute
    """
    if isinstance(attr, dict) and attr.get("__type__") == "function":
        name = attr.get("name")
        api = attr.get("api")
        if not name:
            return attr
        func = _resolve_function_from_apis(name=name, api=api)
        if callable(func):
            return func
        nd.main_logger(level="error", msg=f"Cannot resolve function '{name}' in API '{api or '*'}'.")
        raise AttributeError(f"Unresolved function token: {attr!r}")
    return attr


directly_serializable_types = (int, float, str, bool, type(None))
def is_directly_serializable(data: Any) -> bool:
    """Checks if the data is of a type that can be directly serialized.

    In case of list and dict it recursively checks if all elements are directly serializable.

    Args:
        data: data to check for serializability

    Returns:
        bool: True if the data is directly serializable, False otherwise
    """
    if isinstance(data, directly_serializable_types):
        return True
    elif isinstance(data, (list, tuple)):
        return all(is_directly_serializable(item) for item in data)
    elif isinstance(data, dict):
        # TODO: Does this handle tuple type keys correctly, like (int, int) or (str, str)?
        return all(isinstance(key, (int, float, str)) and is_directly_serializable(value) for key, value in data.items())
    return False


# properties to include in serialization, to be stored in the Layer class as a classvar or similar.
layer_properties_to_copy = [
    "name",
    "tech",
    # "ID",
    "layer",
    "datatype",
    "description",
    "origin",
]
def layer_serialize(layer: nd.Layer) -> dict:
    """Serializate Xsection objects

    Args:
        xs (nd.Xsection): Xsection object to serialize

    Returns:
        dict: serialized xsection object
    """
    layer_info = {}
    for attr in layer_properties_to_copy:
        layer_info[attr] = serialize_attribute(getattr(layer, attr))
    return layer_info


def layer_deserialize(layer_info: dict) -> nd.Layer:
    """Deserialize Xsection objects.

    Args:
        layer_info (dict): Dictionary containing serialized xsection object.

    Returns:
        nd.Layer: deserialized xsection object
    """
    LAY = nd.add_layer(layer_info.pop("name"), tech=layer_info.pop("tech"))
    for attr_name, attr_value in layer_info.items():
        setattr(LAY, attr_name, deserialize_attribute(attr_value))
    return LAY


# attributes to include in serialization
# TODO: store this list in xsection itself as a classvar.
xsection_properties_to_copy = [
    "name",
    "tech",
    # "ID",
    "doc",
    "width",
    "radius",
    "os",
    "taper",
    "stub",
    "_pinstyle",
    "minimum_radius",
    "minimum_width",
    "drc_width",
    "drc_angle",
    "drc_pin2pin",
    "symmetry",
    "description",
    "origin",
]

def xsection_serialize(xs: nd.XSID) -> dict:
    """Serializate Xsection objects

    Args:
        xs (nd.Xsection): Xsection object to serialize

    Returns:
        dict: serialized xsection object
    """
    xs_info = {}
    for attr in xsection_properties_to_copy:
        xs_info[attr] = serialize_attribute(getattr(xs, attr))
    return xs_info


def xsection_deserialize(xs_info: dict) -> nd.XSID:
    """Deserialize Xsection objects.

    Args:
        xs_info (dict): Dictionary containing serialized xsection object.

    Returns:
        nd.XSID: deserialized xsection object
    """
    XS = nd.add_xsection(xs_info.pop("name"), tech=xs_info.pop("tech"))
    for attr_name, attr_value in xs_info.items():
        setattr(XS, attr_name, deserialize_attribute(attr_value))

    # Deserialize pinstyle
    if XS.pinstyle is not None:
        XS.pinstyle = tuple(XS.pinstyle)
    # Deserialize drc_pin2pin
    if XS.drc_pin2pin:
        XS.drc_pin2pin = [tuple(drc) for drc in XS.drc_pin2pin]
    return XS


def compact_models_serialize(compact_models: dict) -> dict:
    """Serialize compact models.

    Args:
        compact_models (dict): Dictionary containing compact models
    Returns:
        dict: Serialized compact models
    """
    return compact_models


def compact_models_deserialize(compact_models):
    """Deserialize the compact models from the server

    During deserialization, these compact models will be stored in Nazca's compact_model_library.
    Existing models will not be overwritten.

    Args:
        compact_models (dict): Dictionary containing the compact models from the server
    Returns:
        None
    """
    for technology, sigtype_info in compact_models.get("technologies", {}).items():
        for sigtype, cell_info in sigtype_info.get("sigtypes", {}).items():
            for cellname, info in cell_info.get("cells", {}).items():
                model_info = info.get("model")
                instance_models = info.get("instance_models")

                # insert technology in api field, so that the api endpoint for model evaluation is accessible
                model_info["api"] = technology

                compact_model_library._add_model(
                    tech=technology,
                    sigtype=sigtype,
                    cellname=cellname,
                    model_info=model_info,
                    instance_models=instance_models,
                )


def deserialize_interconnect(interconnect_info: dict) -> nd.interconnects.Interconnect:
    """Deserialize the interconnect information

    Args:
        interconnect_info (dict): Dictionary containing a serialized Interconnect object.

    Returns:
        Interconnect: deserialized interconnect
    """
    # convert lists back to tuples
    interconnect_info["xs"] = tuple(interconnect_info["xs"])
    interconnect_info["pinstyle"] = tuple(interconnect_info["pinstyle"])
    # deserialize the arrow cell
    arrow = nd.Cell.json_init(interconnect_info.pop("arrow"))

    # instantiate the interconnect
    ic = nd.interconnects.Interconnect(**interconnect_info)
    # overwrite the arrow cell of the new interconnect to ensure that the arrow uses the correct layers
    ic.arrow = arrow
    return ic


def deserialize_tables(table_info: dict) -> None:
    """Deserializes into the lists of objects aggregated in nd.Tables.

    Args:
        table_info (dict): dictionary containing a serialized nd.Tables object.

    Returns:
        None
    """
    # deserialize layer table
    layers = table_info.pop("layers")
    for layer in layers:
        # TODO should overwrite really be False? These are THE layers we care about.
        #      We need at least the warning
        nd.add_layer(**layer, overwrite=False)
        # layer_deserialize(layer)

    xsections = table_info.pop("xsections")
    # deserialize xsections
    for xsection in xsections:
        xs = xsection_deserialize(xsection["xs_info"])

        # Deserialize xsection mask layers
        mask_layers = xsection["mask_layers"]
        mask_layers_deserialized = []
        for mask_layer in mask_layers:
            # convert layer ID back layer object
            layer = nd.get_layer(tuple(mask_layer["layer"]))
            # convert grow back to tuple
            grow = (
                tuple(mask_layer["grow"][0]),
                tuple(mask_layer["grow"][1]),
                mask_layer["grow"][2],
                mask_layer["grow"][3],
            )
            polyline = mask_layer["polyline"]

            mask_layers_deserialized.append((layer, grow, polyline))
        xs.mask_layers = mask_layers_deserialized

    # deserialize stubmap
    stubmap = table_info.pop("stubmap")
    for xsid, stub in zip(stubmap["xsids"], stubmap["stubs"]):
        nd.cfg.stubmap[tuple(xsid)] = stub

    pinstyles = table_info.pop("pinstyles")
    for pinstyle_id, pinstyle in zip(pinstyles["pinstyle_ids"], pinstyles["pinstyles"]):
        # convert 'annotation_move' back to tuple
        if "annotation_move" in pinstyle:
            pinstyle["annotation_move"] = tuple(pinstyle["annotation_move"])
        if "layer" in pinstyle:
            if isinstance(pinstyle["layer"], list):
                pinstyle["layer"] = tuple(pinstyle["layer"])
        nd.cfg.pinstyles[tuple(pinstyle_id)] = pinstyle

    # store technology settings
    if table_info["tech"] is not None:
        # convert default layers LD back to tuple
        if "default_layers" in table_info["settings"]:
            for layerID, LD in table_info["settings"]["default_layers"].items():
                if isinstance(LD, list):
                    table_info["settings"]["default_layers"][layerID] = tuple(LD)

        nd.cfg.technology_settings[table_info["tech"]] = table_info["settings"]
        nd.update_active_settings(table_info["settings"])


def serialize_all_xsections(xs_dict):
    """Serialize all xsections, by serializing each seperate cross-section.

    Args:
        xs_dict (dict): xsections that should be serialized.

    Returns:
        dict: serialized XSdict
    """
    result = {}
    for xs_name, xs in xs_dict.items():
        result[xs_name] = xsection_serialize(xs)
    return result


def deserialize_all_xsections(xs_dict):
    """Deserialize the XSdict.

    During deserialization, serialized XSection objects are reconstructed and the
    relevant information is added to cfg.XSdict.

    Args:
        xs_dict (dict): Dictionary containing the serialized XSdict information.

    Returns:
        None
    """
    for xs_name, xs_info in xs_dict.items():
        xsection_deserialize(xs_info)

# Create a registry of deserialization functions
_DESERIALIZERS = {
    "dict": lambda data: {
        from_dict(data["keys"][key]): from_dict(value) for key, value in data["result"].items()
    },
    "list": lambda data: [from_dict(value) for value in data["result"]],
    "tuple": lambda data: tuple(from_dict(value) for value in data["result"]),
    "np.ndarray": lambda data: np.asarray([from_dict(value) for value in data["result"]]),
    "complex": lambda data: data["result"]["real"] + data["result"]["imag"] * 1j,
    "inf": lambda data: math.inf if data["result"] == "inf" else -math.inf,
    "cell": lambda data: nd.Cell.json_init(data["result"]),
    "interconnect": lambda data: deserialize_interconnect(data["result"]),
    "xsection": lambda data: xsection_deserialize(data["result"]),
    "layer": lambda data: layer_deserialize(data["result"]),
    "tables": lambda data: deserialize_tables(data["result"]),
    "compact_models": lambda data: compact_models_deserialize(data["result"]),
    "bytes": lambda data: base64.decodebytes(data["result"].encode("ascii")),
    "pickled": lambda data: pickle.loads(base64.b64decode(data["result"])),
}


def _serialize_dict(data: dict) -> dict:
    serialized_dict = {}
    serialized_keys = {}

    i = 0
    for key, value in data.items():
        serialized_keys[i] = to_dict(key)
        serialized_dict[i] = to_dict(value)
        i += 1
    return {"type": "dict", "result": serialized_dict, "keys": serialized_keys}


def _serialize_list(data: list) -> dict:
    serialized_list = [to_dict(value) for value in data]
    return {"type": "list", "result": serialized_list}


def _serialize_tuple(data: tuple) -> dict:
    serialized_tuple = [to_dict(value) for value in data]
    return {"type": "tuple", "result": serialized_tuple}


def _serialize_ndarray(data: np.ndarray) -> dict:
    serialized_array = [to_dict(value) for value in data]
    return {"type": "np.ndarray", "result": serialized_array}


def _serialize_bytes(data: bytes) -> dict:
    encoded_data = base64.encodebytes(data).decode("ascii")  # Decode ascii required to avoid Error 422
    return {"type": "bytes", "result": encoded_data}


# Create a registry of serialization functions
_SERIALIZERS = {
    "dict": _serialize_dict,
    "list": _serialize_list,
    "tuple": _serialize_tuple,
    "ndarray": _serialize_ndarray,
    "bytes": _serialize_bytes,
    "complex": lambda data: {"type": "complex", "result": {"real": data.real, "imag": data.imag}},
    "Cell": lambda data: {"type": "cell", "result": nd.cell_tree_serialize(data)},
    "Interconnect": lambda data: {"type": "interconnect", "result": nd.interconnect_serialize(data)},
    "XSID": lambda data: {"type": "xsection", "result": xsection_serialize(data)},
    "Layer": lambda data: {"type": "layer", "result": layer_serialize(data)},
    "Tables": lambda data: {"type": "tables", "result": data.to_dict()},
    "CompactModelLibrary": lambda data: {"type": "compact_models", "result": compact_models_serialize(data)},
}


def to_dict(data: Any) -> dict:
    """Main generic deserialization function.

    This function deserializes the data based on the type of the data and handles Nazca specific objects.

    Args:
        data: data to serialize

    Returns:
        dict: {"type": str, "result": data} serialized data
    """
    if isinstance(data, float) and math.isinf(data):
        return {"type": "inf", "result": str(data)}
    elif is_directly_serializable(data):
        return {"type": "pure", "result": data}  # Directly return serializable data
    elif isinstance(data, dict):
        return _SERIALIZERS.get("dict")(data)
    elif isinstance(data, list):
        return _SERIALIZERS.get("list")(data)
    elif isinstance(data, tuple):
        return _SERIALIZERS.get("tuple")(data)
    elif isinstance(data, np.ndarray):
        return _SERIALIZERS.get("ndarray")(data)
    elif isinstance(data, complex):
        return _SERIALIZERS.get("complex")(data)    
    elif isinstance(data, nd.Cell):
        return _SERIALIZERS.get("Cell")(data)
    elif isinstance(data, nd.interconnects.Interconnect):
        return _SERIALIZERS.get("Interconnect")(data)
    elif isinstance(data, nd.XSID):
        return _SERIALIZERS.get("XSID")(data)
    elif isinstance(data, nd.Layer):
        return _SERIALIZERS.get("Layer")(data)
    elif isinstance(data, nd.Tables):
        return _SERIALIZERS.get("Tables")(data)
    elif isinstance(data, CompactModelLibrary):
        return _SERIALIZERS.get("CompactModelLibrary")(data)
    elif isinstance(data, bytes):
        return _SERIALIZERS.get("bytes")(data)

    # Data needs pickling
    # TODO pickling is a poor solution: can give dependency issues if users are on different versions of packages,
    #  and it might be the case that we're pickling an internal module that the user doesn't have access to (and
    #  therefore wouldn't be able to unpickle).
    #  On top of that, I'm afraid that users sending pickled data top the server can open us up to code injection.
    pickled_data = pickle.dumps(data)
    encoded_data = base64.b64encode(pickled_data).decode("utf-8")
    return {"type": "pickled", "result": encoded_data}


serialize = to_dict


def from_dict(data: dict) -> Any:
    """Main generic deserialization function.

    This function deserializes the data based on the type of the data and handles Nazca specific objects.

    Args:
        data (dict): dictionary containing the serialized data

    Returns:
        Any: deserialized data
    """
    data_type = data["type"]
    
    # Use the registry to find the appropriate deserializer
    deserializer = _DESERIALIZERS.get(data_type)
    if deserializer:
        return deserializer(data)
    
    # Default case for directly serializable data
    return data["result"]

deserialize = from_dict


if __name__ == "__main__":
    import json

    my_dict = {1: "a", 2: "b"}
    serialized_dict = json.dumps(to_dict(my_dict))
    print(f"{serialized_dict=}")
    deserialized_dict = from_dict(json.loads(serialized_dict))
    print(f"{deserialized_dict=}")

    ic = nd.interconnects.Interconnect()
    print(f"\n{ic          = }")
    ic_serialized = to_dict(ic)
    # print(f"{ic_serialized = }")
    ic_restored = from_dict(ic_serialized)
    print(f"{ic_restored = }")

    pinline = nd.PinLine()
    print(f"\n{pinline          = }")
    pinline_serialized = json.loads(json.dumps(to_dict(pinline)))
    # print(f"{pinline_serialized = }")
    pinline_restored = from_dict(pinline_serialized)
    print(f"{pinline_restored = }")

    xsection = nd.add_xsection("NAME", "TECH", name_foundry="xs_fab", origin="test", stub=None, description="serialize", pinstyle=None)
    xsection = nd.get_xsection(xsection)
    print(f"\n{xsection          = }")
    print(f"{xsection.pinstyle = }")
    xsection_serialized = json.loads(json.dumps(to_dict(xsection)))
    # print(f"{pinline_serialized = }")
    xsection_restored = from_dict(xsection_serialized)
    print(f"{xsection_restored = }")
    print(f"{xsection.pinstyle = }")

    layer = nd.add_layer("NAME", "TECH", 1, )
    print(f"\n{layer          = }")
    layer_serialized = to_dict(layer)
    # nd.clear_layers()
    # print(f"{pinline_serialized = }")
    layer_restored = from_dict(layer_serialized)
    print(f"{layer_restored = }")

    bytestring = b"test"
    print(f"\n{bytestring          = }")
    bytestring_serialized = to_dict(bytestring)
    # print(f"{pinline_serialized = }")
    bytestring_restored = from_dict(bytestring_serialized)
    print(f"{bytestring_restored = }")

    nd.add_layer("NAME2", "TECH", 2, )
    nd.add_layer("NAME", "TECH2", 3, )
    nd.add_xsection("NAME2", "TECH2", name_foundry="xs_fab2", origin="test2", stub=None, description="serialize", pinstyle=None)
    print("\nnd.Tables:")
    tech = "TECH"
    print(f"{tech = }")
    tables = nd.Tables(tech=tech)
    tables_serialized = tables.to_dict()
    tables_restored = deserialize_tables(tables_serialized)
    tech = "TECH2"
    print(f"{tech = }")
    tables = nd.Tables(tech=tech)
    tables_serialized = tables.to_dict()
    tables_restored = deserialize_tables(tables_serialized)
