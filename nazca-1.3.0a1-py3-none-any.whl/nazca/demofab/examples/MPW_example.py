#-----------------------------------------------------------------------
# This file is part of Nazca.
#
# Nazca is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or (at
# your option) any later version.
#
# Nazca is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with Nazca.  If not, see <http://www.gnu.org/licenses/>.
#-----------------------------------------------------------------------
#
#@Authors: Jerom Baas
#@email: nazca@brightphotonics.eu
#2024(c)

"""
**DEMO MPW example.**

This file shows an MPW example in the demofab pdk
"""

# import modules
import nazca as nd
nd.logfile(__file__, stdout=False)
nd.pin2pin_drc_on()

import nazca.demofab as demo

def place_io_blocks(cell):
    """Place building-blocks on the IO markers in the active cell and store in an IO dict {<IOname>: <BB>}.

    Args:
        cell (Cell): cell whose pins to place the IO blocks on.

    Returns:
        dict: dictionary with IO markers as keys and BBs placed on the IO markers as values.
    """
    SSCs = {name: demo.io().put("b0", pin) for name, pin in nd.util.iter_items(cell.pin, "ioE")}
    DCpads = {name: demo.pad_dc().put("rc", pin) for name, pin in nd.util.iter_items(cell.pin, "dc")}
    RFpads = {name: demo.pad_rf().put("rc", pin) for name, pin in nd.util.iter_items(cell.pin, "rf")}
    # Concatenate all io dictionaries
    IO = DCpads | RFpads | SSCs
    return IO

# ==============================================================================
# DESIGN
# ==============================================================================
def design1():
    """Design example1

    Basic example that shows how to add optical and electrical IOs.

    Returns:
        Cell: design1 cell
    """

    with nd.Cell(name="Design1") as Design1:
        # place the demofab cell template
        mpw = demo.cell_template().put(0)

        # place IO blocks
        IOs = place_io_blocks(mpw)
        print(f"IOs in MPW cell {Design1.cell_name}:\n{sorted(IOs.keys())}")

        # alignment loops
        demo.shallow.sbend(offset=-400).put(IOs["ioE00"].pin["a0"])
        demo.shallow.ubend_p2p(
            pin2=IOs["ioE01"].pin["a0"],
        ).put()
        demo.shallow.sbend(offset=400).put(IOs["ioE15"].pin["a0"])
        demo.shallow.ubend_p2p(
            pin2=IOs["ioE14"].pin["a0"],
        ).put()

        # example of placing and connecting a building block
        demo.shallow.strt(length=800).put(IOs["ioE04"].pin["a0"])
        demo.shallow.sbend(offset=-500).put()
        demo.shallow.strt(length=250).put()
        demo.s2d().put()
        mzi = demo.mzi().put()
        demo.deep.strt(length=300).put()
        demo.d2s().put()
        demo.shallow.ubend_p2p(pin2=IOs["ioE05"].pin["a0"]).put()

        # metal routing
        demo.metaldc.sbend_p2p(pin1=mzi.pin["c0"], pin2=IOs["dcS04"], Lstart=100).put()
        demo.metaldc.sbend_p2p(pin1=mzi.pin["c1"], pin2=IOs["dcS05"], Lstart=200).put()
        demo.metaldc.sbend_p2p(pin1=mzi.pin["d0"], pin2=IOs["dcN15"], Lstart=100).put()
        demo.metaldc.sbend_p2p(pin1=mzi.pin["d1"], pin2=IOs["dcN14"], Lstart=200).put()

    return Design1


nd.export_gds(design1(), filename="MPW_example.gds")
