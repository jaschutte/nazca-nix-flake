#
# (c) 2025 Xaveer Leijtens
#
# Step-height measurement test structures
#
import nazca as nd
import nazca.geometries as geom

__all__ = ["profile"]


WIDTH = 50
HEIGHT = 500


def profile_wg(wwg: float = 2) -> nd.Cell:
    with nd.Cell(f"step_wg_{wwg}") as C:
        # wtrench = (WIDTH - wwg) / 2
        trench = geom.rectangle(length=WIDTH, height=HEIGHT, position=5)
        wg = geom.rectangle(length=wwg, height=HEIGHT, position=5)
        nd.Polygon(trench, layer="Trench").put()
        nd.Polygon(wg, layer="Waveguide").put()
        nd.Pin("x0").put(-WIDTH / 2, 0, 180)
        nd.Pin("x1").put(WIDTH / 2, 0, 0)
        C.default_pins("x0", "x1")
    return C


def profile_metal_wg() -> nd.Cell:
    with nd.Cell("step_metal_wg") as C:
        wmetal = 10
        wwg = 30
        wtrench = WIDTH
        metal = geom.rectangle(length=wmetal, height=HEIGHT, position=5)
        wg = geom.rectangle(length=wwg, height=HEIGHT, position=5)
        trench = geom.rectangle(length=wtrench, height=HEIGHT, position=5)
        nd.Polygon(metal, layer="Metal").put()
        nd.Polygon(wg, layer="Waveguide").put()
        nd.Polygon(trench, layer="Trench").put()
        nd.Pin("x0").put(-WIDTH / 2, 0, 180)
        nd.Pin("x1").put(WIDTH / 2, 0, 0)
        C.default_pins("x0", "x1")
    return C


def profile_metal() -> nd.Cell:
    with nd.Cell("step_metal") as C:
        wmetal = 10
        wtrench = WIDTH
        metal = geom.rectangle(length=wmetal, height=HEIGHT, position=5)
        trench = geom.rectangle(length=wtrench, height=HEIGHT, position=5)
        nd.Polygon(metal, layer="Metal").put()
        nd.Polygon(trench, layer="Trench").put()
        nd.Pin("x0").put(-WIDTH / 2, 0, 180)
        nd.Pin("x1").put(WIDTH / 2, 0, 0)
        C.default_pins("x0", "x1")
    return C


@nd.cellcache("profile")
def profile() -> nd.Cell:
    with nd.Cell() as C:
        first = profile_wg(2).put()
        profile_wg(10).put()
        profile_metal_wg().put()
        last = profile_metal().put()
        first.raise_pins(["x0"])
        last.raise_pins(["x1"])
        C.default_pins("x0", "x1")
    return C


if __name__ == "__main__":
    profile().put()

    nd.export_gds()
