# -----------------------------------------------------------------------
# This file is part of Nazca.
#
# Nazca is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or (at
# your option) any later version.
#
# Nazca is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with Nazca.  If not, see <http://www.gnu.org/licenses/>.
#
# @author: Ronald Broeke (c) 2016-2021
# @email: ronald.broeke@brightphotonics.eu
# -----------------------------------------------------------------------
# -*- coding: utf-8 -*-
"""
This module defines
1- layers in table 'layer_table'
2- xsections in table 'xsection_table'
3- xsection layers in 'xsection_layer_map', adding layers to each 'xs'
4- The layer and xsection-layer tables are joined into an xsection-layer table.

The result is stored in a dictionary containing the xsection-layer information
per 'xs' needed in layout: 'xsection_layers'

Layers and xsection can be added in two ways
1 - Loading from csv file: load_layers, load_xs
2 - Functions add_layer, add_xsection
When adding layers to a 'xs' the xs_map is built automatically.

It is also possible to first load layers and xs, and then extend them via
'add_layer' and/or 'add_layer2xsection'.
"""

from __future__ import annotations
import os
from pathlib import Path
from collections import defaultdict
from typing import Union, Tuple, NewType, ClassVar, Optional, Any
from copy import copy
import matplotlib as mpl
from matplotlib.colors import rgb2hex
from pydantic import BaseModel
from pydantic.dataclasses import dataclass
from dataclasses import fields
import csv
from nazca.logging_util import logger
import nazca as nd
from nazca import cfg, xsection
from nazca import gds_base
from nazca.bb_util import add_pinstyle

# (partial) layer reference for looking up the (unique) corresponding layer object
layerref = Union[str, Tuple[str, str], int, Tuple[int, int], Tuple[int, str], Tuple[int, int, str]]

# (partial) xsection reference for looking up the (unique) corresponding xsection object
xsectionref = Union[str, Any, Tuple[str, str]]
# TODO Any -> Node (resolve circular import)

# Define a new type for color code
ColorCode = NewType("ColorCode", str)

# keep track of layers used by the designer that have not been defined:
unknown_layers = set()
unknown_xsections = set()


# TODO move to xsection and replace XSID with XSection?
class XSID(BaseModel, extra="allow"):
    """Xsection identifier.

    The Xsection identifier is a tuple of (name, tech) or (N, T).
    """

    name: str
    tech: str = cfg.default_tech
    #
    ID: Tuple[str, str] = None
    #
    doc: str = "Xsection description"
    # geometry attributes
    # TODO some of these could be callables, like taper/os
    width: Optional[float] = None
    radius: Optional[float] = None
    os: Union[str, float] = 0.0
    taper: Optional[float] = None
    # visualization
    stub: Optional[Tuple[str, str]] = None
    _pinstyle: Tuple[str, str] = None  # cfg.default_pinstyle ID
    # DRC
    minimum_radius: Optional[float] = None
    minimum_width: Optional[float] = None
    drc_width: Optional[float] = None
    drc_angle: Optional[float] = None
    drc_pin2pin: list[tuple[str, str]] = []  # list of (name, tech)
    symmetry: bool = True  # True: xs is symmetric, flipping allowed.
    # context
    description: str = ""
    origin: str = ""
    #
    mask_layers: list = []
    # xs simulation elements:
    layers: Optional[list] = None  # TODO: in LGT, but needs defintion
    background: Optional[float] = None
    add_vstack: Optional[float] = None
    add_hstack: Optional[float] = None
    index: Optional[Any] = None

    # class variables:
    NT2xs: ClassVar[dict[tuple[str, str], XSID]] = dict()  # unique lookup with (name, tech)
    N2xs: ClassVar[defaultdict[str, list[XSID]]] = defaultdict(list)  # potentially non-unique lookup

    def __init__(self, **data):
        """Intialized the Xsection object."""
        super().__init__(**data)
        self.ID = (self.name, self.tech)
        self.drc_pin2pin.append(self.ID)
        XSID.NT2xs[self.ID] = self
        XSID.N2xs[self.name].append(self)

        # serialization settings
        self._properties_to_serialize = [
            "name",
            "tech",
            # "ID",
            "doc",
            "width",
            "radius",
            "os",
            "taper",
            "stub",
            "_pinstyle",
            "minimum_radius",
            "minimum_width",
            "drc_width",
            "drc_angle",
            "drc_pin2pin",
            "symmetry",
            "description",
            "origin",
        ]

    def __repr__(self) -> str:
        return f"Xsection with ID:{self.ID}"

    @property
    def pinstyle(self):
        return self._pinstyle

    @pinstyle.setter
    def pinstyle(self, style):
        """Set the pinstyle of the xsection and always store it as a tuple with tech."""
        if isinstance(style, str):
            style = (style, cfg.active_tech)
        self._pinstyle = style  # nd.parse_pinstyle(style)

    def to_dict(self):
        """Serialize the xsection object

        Returns:
            dict: serialized xsection object
        """
        xs_info = {}
        for attr in self._properties_to_serialize:
            val = getattr(self, attr)
            xs_info[attr] = nd.serialize_attribute(val)

        mask_layers = []
        for layer, grow, polyline in self.mask_layers:
            # serialization of mask layer: convert to the layer object to id
            mask_layer = {"layer": layer.ID, "grow": grow, "polyline": polyline}
            mask_layers.append(mask_layer)

        result = {"xs_info": xs_info, "mask_layers": mask_layers}

        return result


# add default pinstyles
for name, pinstyle in cfg.default_pinstyles.items():
    add_pinstyle(name, pinstyle)

def set_technology(tech: str) -> bool:
    """Set the active technology.

    Args:
        tech (str): technology name.

    Returns:
        bool: True if the technology is set successfully.
    """
    nd.cfg.active_tech = tech
    return True


# layercolor table:
cfg.colors = {}
cfg.xs_list = []
colors_attr_csv = [
    "name",
    "layer",
    "datatype",
    "depth",
    "fill_color",
    "frame_color",
    "frame_brightness",
    "fill_brightness",
    "dither_pattern",
    "valid",
    "visible",
    "transparent",
    "width",
    "marked",
    "animation",
]

# xsection-layer-map table, mapping layers to xsections:
cfg.xsection_layer_map = {}


class XSectionLayerInfo(BaseModel):
    """Model to represent XSection Layer mapping data."""

    # TODO add custom validator to make error messages more descriptive
    layer_name: str
    xsection: str
    xsection_foundry: Optional[str] = None
    growx: float
    growy: float
    leftedgefactor: Optional[float] = None
    leftedgeoffset: Optional[float] = None
    rightedgefactor: Optional[float] = None
    rightedgeoffset: Optional[float] = None
    growy1: Optional[float] = None
    growy2: Optional[float] = None
    accuracy: Optional[float] = None
    origin: Optional[str] = None
    remark: Optional[str] = None
    polyline: Optional[bool] = None
    tech: Optional[str] = None
    source: Optional[str] = None


class MaskLayerAttributes(BaseModel):
    """Model containing the relevant data for Mask Layers."""

    # TODO add custom validator to make error messages more descriptive
    layer_name: str
    xsection: str
    layer: Optional[int] = None
    datatype: Optional[int] = None
    tech: Optional[str] = None
    growx: float
    growy: float
    growy1: Optional[float] = None
    growy2: Optional[float] = None
    leftedgefactor: Optional[float] = None
    leftedgeoffset: Optional[float] = None
    rightedgefactor: Optional[float] = None
    rightedgeoffset: Optional[float] = None
    accuracy: Optional[float] = None
    polyline: Optional[bool] = None


class Technology:
    """Context manager to activate a technology setting for xsections and layer methods.

    Technology is a string that is part of the (mask)layer ID and used to keep layers
    with the same name but in different technologies apart. The technology information
    is also used to separate mask layers when exporting to (gds) file.

    Example::

        with Technology("technology_name"):
            # load or create layers, xsections or create cells in a specific technology
    """

    # active_tech = nd.cfg.active_tech
    _open_techs = []  # techs of the currently open Technology contexts, innermost last

    def __init__(self, tech: str):
        """Initialize Technology object.

        Args:
            tech (str): technology id.

        Returns:
            None
        """
        self.stored_tech = nd.cfg.active_tech
        self.tech = tech

    def __enter__(self):
        """Set technology for xsections and layer methods."""

        # When nested in another Technology context, store the live settings of the outer tech first.
        # They are otherwise only stored on __exit__, so a nested (re-)entry of the outer tech, e.g. a
        # @technology decorated cell called during PDK import, would fall back to the default settings
        # and lose changes like pin2pin_drc_on().
        if Technology._open_techs:
            cfg.technology_settings[Technology._open_techs[-1]] = get_active_settings()
        Technology._open_techs.append(self.tech)

        # set technology
        nd.cfg.active_tech = self.tech

        # set technology specific settings if this technology was used before (typically during import of PDK)
        if self.tech in cfg.technology_settings:
            update_active_settings(settings=cfg.technology_settings[self.tech])
        else:
            # first time we enter this technology (typically during import of PDK),
            # reset settings to Nazca's default settings
            update_active_settings(settings=cfg.default_settings)

        return self

    def __exit__(self, type, value, traceback):
        """Cleanup after Technology context manager."""
        Technology._open_techs.pop()
        if value is None:
            nd.cfg.active_tech = self.stored_tech
            cfg.technology_settings[self.tech] = get_active_settings()
            # Back inside an outer Technology context: reactivate its settings (stored in __enter__).
            if Technology._open_techs:
                update_active_settings(settings=cfg.technology_settings[Technology._open_techs[-1]])
        return False


def get_active_settings():
    """Get active settings.

    This function is used to generate and store a specific set of technology settings.

    This function gathers the values for the following settings:
        cfg.redirect_unknown_layers
        cfg.redirect_unknown_xsections
        cfg.default_layers
        cfg.drc
        cfg.bbox_layers_ignore
        cfg.store_bbname
        cfg.parameter_style
        gds_base.gds_db_unit
        gds_base.gds_db_user

    Returns:
        dict: dictionary with technology settings

    """
    # manual deepcopy of instance angle settings
    drc_instance_angle_settings = {}
    for rule, drc_settings in cfg.drc_instance_angle.items():
        drc_instance_angle_settings[rule] = copy(drc_settings)

    settings = {
        "redirect_unknown_layers": copy(cfg.redirect_unknown_layers),
        "redirect_unknown_xsections": copy(cfg.redirect_unknown_xsections),
        "default_layers": copy(cfg.default_layers),
        "drc": copy(cfg.drc),
        "drc_instance_angle": drc_instance_angle_settings,
        "bbox_layers_ignore": copy(cfg.bbox_layers_ignore),
        "store_bbname": copy(cfg.store_bbname),
        "parameter_style": copy(cfg.parameter_style),
        "gds_db_unit": copy(gds_base.gds_db_unit),
        "gds_db_user": copy(gds_base.gds_db_user),
    }

    return settings


def update_active_settings(settings):
    """Update settings in cfg based on provided settings

    Args:
        settings (dict): dictionary containing cfg settings to update
    """
    nd.cfg.redirect_unknown_layers = settings["redirect_unknown_layers"]
    cfg.redirect_unknown_xsections = settings["redirect_unknown_xsections"]
    cfg.default_layers = settings["default_layers"]
    cfg.drc = settings["drc"]
    cfg.drc_instance_angle = settings["drc_instance_angle"]
    cfg.bbox_layers_ignore = settings["bbox_layers_ignore"]
    cfg.store_bbname = settings["store_bbname"]
    cfg.parameter_style = settings["parameter_style"]
    gds_base.gds_db_unit = settings["gds_db_unit"]
    gds_base.gds_db_user = settings["gds_db_user"]


layer_debug = False  # flag for debug output to stdout.
block_load_colors = False
None_layerflag = False  # register if layer=None message has been issued


_layer_attributes_to_serialize = [
    "name",
    "tech",
    "layer",
    "datatype",
    "accuracy",
    "layer_name_foundry",
    "origin",
    "remark",
    "description",
    "source",
]

@dataclass
class Layer():
    """Layer class for (gds) layer identifycation and retrieval.

    A layer identification has four meaningful attributes: name, tech, layer, datatype (N, T, L, D).
    For a gds only layer and datatype (L, D) are used. A name str is used to identify a (L, D) combination.
    It is allowed to have multiple layers with different names (N) pointing to the same (L, D).
    It is not allowed to have multiple layers with the same name pointing to different (L, D).
    When mixing technologies, there can be a clash resulting in a violation of the latter condition as technologies
    select their layer numbers independently from each other.
    Potential conflicts are solved via the technology (T) str attribute, making the (N, T) combination unique,
    pointing to a single (L, D) combination.
    """
    name: str
    tech: str
    layer: int
    datatype: int
    accuracy: float
    layer_name_foundry: Optional[str] = None
    origin: Optional[str] = None
    remark: Optional[str] = None
    description: Optional[str] = None
    source: Optional[str] = None
    # class variables for looking up layers giving a certain input
    NT2layer = dict()  # unique lookup
    N2layers = defaultdict(list)  # potentially non-unique lookup
    L2layers = defaultdict(list)  # potentially non-unique lookup
    LD2layers = defaultdict(list)  # potentially non-unique lookup
    LT2layers = defaultdict(list)  # potentially non-unique lookup
    LDT2layers = defaultdict(list)  # potentially non-unique lookup
    NLD2layers = defaultdict(list)  # potentially non-unique lookup

    def __post_init__(self):
        """Initialize the new layer.

        Returns: None
        """
        self.ID = (self.name, self.tech)
        self.NT = self.ID
        self.LD = (self.layer, self.datatype)
        self.NTLD = (self.name, self.tech, self.layer, self.datatype)
        Layer.NT2layer[self.ID] = self
        Layer.N2layers[self.name].append(self)
        Layer.L2layers[self.layer].append(self)
        Layer.LD2layers[(self.layer, self.datatype)].append(self)
        Layer.LT2layers[(self.layer, self.tech)].append(self)
        Layer.LDT2layers[(self.layer, self.datatype, self.tech)].append(self)
        Layer.NLD2layers[(self.name, self.layer, self.datatype)].append(self)

    def __repr__(self) -> str:
        return f"layer with ID:{self.ID} - ML{self.LD}"

    def to_dict(self):
        """Function to serialize layer object.

        Serialized any attributes in _layer_attributes_to_serialize

        Returns:
            dict: dictionary of layer attributes
        """
        result = {}
        for attr in _layer_attributes_to_serialize:
            result[attr] = getattr(self, attr)
        return result

    # def from_dict(self, data):
    #     """Function to deserialize layer object.

    #     Args:
    #         data (dict): dictionary of layer attributes

    #     Returns:
    #         Layer: layer object
    #     """
    #     return Layer(**data)

cfg.layer_table = Layer.NLD2layers


class Color(BaseModel):
    """Color class for layer color representations."""
    # klayout
    frame_color: ColorCode = ""
    fill_color: ColorCode = ""
    frame_brightness: int = 255
    fill_brightness: int = 255
    dither_pattern: str = ""
    valid: bool = True
    visible: bool = True
    transparent: bool = True
    width: int = 1
    marked: bool = False
    animation: int = 0
    #
    alpha: bool = True


def add_layer(
    name: str = None,
    tech: str = None,
    layer: int | tuple[int, int] = None,
    datatype: int = None,
    # layer attrinutes
    accuracy: float = None,
    layer_name_foundry: str = None,
    origin: str = None,
    remark: str = None,
    description: str = "",
    source: str = "add_layer",
    # flow control:
    overwrite: bool = False,
    # color info to be replaced by e.g. a dataclass:
    frame_color=None,
    fill_color=None,
    frame_brightness=None,
    fill_brightness=None,
    dither_pattern=None,
    valid=None,
    visible=None,
    transparent=None,
    width=None,
    marked=None,
    animation=None,
    alpha=None,
) -> Layer:
    """Create a new mask layer.

    Layer ID is create as tuple (name, tech) and is unique. If a layer with the same ID already exists, it is returned.
    The gds layer information is represented by the tuple (layer, datatype).

    The layer has a number of attributes that can be set in the call to add_layer, like accuracy, origin, remark, etc.

    The merge and overwrite flags control the behavior of add_layer.

    A layer has one or more color settings, which is a group of attributes used in gds, png, or svg export.

    Args:
        name (str): layer name
        tech (str): technology ID
        layer (int | tuple[int, int]): layer number or (layer, datatype)
        datatype (int): layer datatype number. This is only used if layer is a single int
            (and not a tuple of ints)

        overwrite (bool): overwrite an existing layer if True (default=False)

        accuracy (float): mask resolution of the layer in um
        layer_name_foundry (str): optional name used by the foundry for this layer
        origin (str): who created the layer
        remark (str): extra info for the layer
        description (str): description of the layer
        source (str): source for the layer
        ...: color attributes

    Returns:
        nd.Layer: mask layer object.
    """
    if tech is None:
        tech = cfg.active_tech
    if isinstance(layer, tuple):
        if len(layer) != 2:
            raise ValueError("Layer tuple in add_layer() should have length 2: (layer, datatype).")
        if datatype is not None:
            raise ValueError("Provide datatype either in layer=(layer, datatype) or as datatype, not both.")
        layer, datatype = layer
    if name is None:
        name = f"{layer}/{datatype}/{tech}"

    layerID = (name, tech)
    # generate layer object
    if layerID in Layer.NT2layer.keys() and not overwrite:
        msg = (
            f"Reusing an existing layer ID '{layerID}'."
            " Use a different layer name or set overwrite=True."
        )
        nd.main_logger(msg, "warning")
        return Layer.NT2layer[layerID]

    if layer is None:
        # cannot define add a layer without at least the klayout layer value
        msg = "Error: no layer number provided in call to add_layer()."
        logger.exception(msg)
        raise ValueError(msg)
    if datatype is None:
        datatype = 0
    if accuracy is None:
        accuracy = cfg.default_xs_layer["accuracy"][0]
    if origin is None:
        origin = cfg.default_xs_layer["origin"][0]

    new_layer = Layer(
        name=name,
        tech=tech,
        layer=layer,
        datatype=datatype,
        accuracy=accuracy,
        layer_name_foundry=layer_name_foundry,
        origin=origin,
        remark=remark,
        description=description,
        source=source,
    )

    set_layercolor(
        (name, tech),
        frame_color,
        fill_color,
        frame_brightness,
        fill_brightness,
        dither_pattern,
        valid,
        visible,
        transparent,
        width,
        marked,
        animation,
        alpha,
    )

    return new_layer


def get_layer(layer, aslist: bool = False) -> Layer:
    """Return a layer object by layer input.

    A unique layer entry can be requested via <layer> by name, tech, layer number and datatype.
    get_layer() completes the layer information if not complete.
    This allows the user to use a brief syntax to request a layer.
    If a technologu is omitted, get_layer() uses the active technology or if not defined, the default technology.

    NOTE: Nazca has a number of default layers defined as N -> (L, D). If a layer does not exist, get_layer() will
    lookup a default layer. This lookup methodology does only considers layername entries )N) without L and D entries
    provided.

    If a layer does not exist, and there is no default defined, get_layer() has two mode:
    1) it creates a new layer with the provided information
    2) in "strict mode", i.e. if cfg.unknown_layer_redirect = True, get_layer() will redirect unknown layers
    to the layer named "dump". Hence, every layer needs to be defined before it is called.

    Args:
        layer (layerref): layer reference to be cast into a Layer object from the following: Layer object, tuple of (name, tech),
            layer name, layer number, or tuple with specific combinations of integers and strings.
        aslist (bool): if True, return a list of matching layers, default=False.

    Returns:
        Layer: Layer object.
    """

    def handle_degenerate(matches: list):
        """Handle return normal and degenerate cases.

        A degenerate case is where an (incomplete) layer request has multiple matches.

        Args:
            matches (list): List of layer objects matching the layer request.

        Returns:
            Layer | list[Layers]: Layer object or None.
        """
        if len(matches) == 1:
            if aslist:
                return matches
            return matches[0]
        elif len(matches) > 1:
            if aslist:
                return matches
            if cfg.allow_arbitrary_layer_mapping:  # TODO: rename into match_first_layer
                nstring = "\n"
                msg = (
                    f"Non-unique layer identifier used: {layer}; "
                    f"Matching layers are \n{f'{nstring}'.join(str(match.NTLD) for match in matches)}\n"
                    f"Selecting layer '{matches[0].NTLD}'."
                )
                nd.main_logger(level="warning", msg=msg)
                return matches[0]
            else:
                nstring = "\n"
                msg = (
                    f"Non-unique layer identifier used: {layer}; "
                    f"Matching layers are \n{f'{nstring}'.join(str(match.NTLD) for match in matches)}\n"
                    "Set cfg.allow_arbitrary_layer_mapping to True if you want to continue with the first matching layer. "
                    "Or set aslist=True to get all xsectiong layers."
                )
                raise ValueError(msg)
        else:
            return matches

    # collect N, T, L, D if provided. These are used for handling the scenario where no matching layers are found
    # these are collected in the same if-else loop that looks up matching layers so that we do not have to repeat this
    # if-else loop.
    N = None
    T = None
    L = None
    D = None

    layers = None
    if isinstance(layer, Layer):
        # Layer object
        if aslist and not isinstance(layer, list):
            layer = [layer]
        return layer
    elif isinstance(layer, str):
        # str -> N
        N = layer
        layers = Layer.NT2layer.get((layer, cfg.active_tech), [])
        if aslist and not isinstance(layers, list):
            layers = [layers]
    elif isinstance(layer, tuple):
        # tuple
        if len(layer) == 2:
            if all(isinstance(item, str) for item in layer):
                # str, str -> N, T: unique mapping, don't need to do handle_degenerate
                N, T = layer[0], layer[1]
                layers = Layer.NT2layer.get(layer, [])
                if aslist and not isinstance(layers, list):
                    layers = [layers]
            elif all(isinstance(item, int) for item in layer):
                # int, int -> L, D
                L, D = layer
                layers = handle_degenerate( Layer.LDT2layers[(L, D, cfg.active_tech)])
            elif isinstance(layer[0], int) and isinstance(layer[1], str):
                # int, str -> L, T
                L, T = layer
                layers = handle_degenerate(Layer.LT2layers[layer])
        elif len(layer) == 3:
            if isinstance(layer[0], int) and isinstance(layer[1], int) and isinstance(layer[2], str):
                # int, int, str -> L, D, T
                L, D, T = layer
                layers = handle_degenerate(Layer.LDT2layers[layer])
            elif isinstance(layer[0], str) and isinstance(layer[1], int) and isinstance(layer[2], int):
                # NOTE: since active tech is enforced if tech T is missing, this case here is not used in practice.
                # str, int, int -> N, L, D
                N, L, D = layer
                layers = handle_degenerate(Layer.NLD2layers[layer])
    elif isinstance(layer, int):
        # int -> L
        L = layer
        layers = Layer.LT2layers[(L, cfg.active_tech)]
        layers = handle_degenerate(Layer.L2layers[layer])
    elif layer is None:
        layers = []

    # layer format didn't match any of the formats in the if loop above; therefore, layers is still None: raise Exception
    # NB: We do not get the same functionality if we use "else" instead of "if layers is None"; While that would trigger
    # if the layerID is not a Layer, str, int or tuple, it won't trigger for cases where the tuple has the incorrect
    # format as there are many tuples that are not specifically one of the accepted formats. For example, a user could
    # realistically provide (N, L) which has format (str, int) which is not allowed.
    if layers is None:
        msg = (
            f"Unexpected format for layer reference argument: {layer}\n"
            "Accepted formats for layer are:\n"
            "str -> N\n"
            "int -> L\n"
            "(str, str) -> N, T\n"
            "(int, int) -> L, D\n"
            "(int, str) -> L, T\n"
            "(int, int, str) -> L, D, T\n"
            "(str, int, int) -> N, L, D\n"
        )
        raise ValueError(msg)

    if layers:
        return layers

    # no matching layers found, if there is a name it might refer to a default layer
    # NOTE: the selected methodology does only consider layername entries without L and D for default layers mapping.
    if N is not None and L is None and D is None:
        layermapping = cfg.default_layers.get(N, None)
        if isinstance(layermapping, str):
            return get_layer(layermapping)
        elif isinstance(layermapping, tuple):
            # if not cfg.redirect_unknown_layers:

            # TODO the statement below seems to have been removed by RB?
            T = T or cfg.active_tech
            return add_layer(N, T, *layermapping)

    if cfg.redirect_unknown_layers:
        if layers:
            return layers
        lookup = []
        if isinstance(layer, str):
            lookup = Layer.N2layers[layer]
        elif isinstance(layer, tuple):
            lookup = Layer.NT2layer[layer]
        if lookup == []:
            lookup = Layer.NT2layer
        msg = (
            f"Unknown layer reference {layer} in call get_layer(). "
            f"Maybe the active technology is not set properly ({nd.cfg.active_tech})? "
            "Moving layout content to layer 'dump' instead, "
            "because redirect_unknown_layers = True. "
            f"Possible candidate layers are {lookup}."
        )
        if isinstance(cfg.gdsload, str):
            msg += f" Layer popped up while loading file '{cfg.gdsload}'."
        nd.main_logger(msg, "warning")
        return get_layer("dump")
    elif L is None:
        # cannot define a layer if no layer is given. Move to dump layer instead.
        nd.main_logger(
            f"layerID {layer} does not contain a layer. Redirecting it to 'dump' layer instead. "
            f"Alternatively create this layer explicitly using:\n"
            f"add_layer(name='{N}', layer=(<layerinfo>))\n"
            f"This message is only shown once.",
            "warning",
        )
        return get_layer("dump")
    else:  # create new layer
        D = D or 0
        T = T or cfg.active_tech
        N = N or f"{L}/{D}/{T}"
        new_layer = add_layer(
            name=N,
            tech=T,
            layer=L,
            datatype=D,
        )
        if aslist:
            return [new_layer]
        return new_layer


def parse_grow(edge, side, default):
    """Parse growth parameter into a tuple.

    Returns:
        tuple: (a, b) grow information as a*width+b
    """
    if edge is None:
        return (side, default)
    if isinstance(edge, (float, int)):
        return (side, float(edge))
    if not isinstance(edge, tuple):
        logger.error(
            "Growth value for layer in xsection should be a tuple like (width_factor, shift)."
            " Using value (1.0, 0.0) instead of given {}".format(edge)
        )
        return (1.0, 0.0)
    else:
        return edge


def add_layer2xsection(
    xsection: str = "name",
    tech: str = None,
    layer: str | int | tuple | Layer = None,
    growx: float = None,
    leftedge=None,
    rightedge=None,
    growy: float = None,
    growy1: float = None,
    growy2: float = None,
    accuracy: float = None,
    fab_name: str = None,
    origin: str = None,
    overwrite: bool = False,
    polyline: bool = False,
    remark: str = None,
) -> XSID:
    """Add a layer to the Xsection object with name <xsection>.

    If <xsection> does not exist yet it will be created.
    The layer entry is described by (layer, datatype).
    If the (layer, datatype) does not exist yet it will be created.
    The keyword 'accuracy' is only processed in case of a new layer.

    The "leftedge" and "rightedge" keywords describe the the waveguide sidewalls
    by the distance of the guide sidewalls. The waveguide in this concept is oriented
    on the direction of the positive x-axis and the sidewalls are expressed as
    the y-coordinate as a*width+b, or in short (a, b), where width is the width
    of the guide. For a standard waveguide we have leftedge=(0.5, 0.0)
    and rightedge = (-0.5, 0.0). Swapping the values of leftedge and rightedge
    generate the same polygon, so the naming is indicative only.

    NOTE: growy (or growy1 and growy2 for that matter) will only have an
    effect on the straight guide and the linear taper.

    Args:
        xsection (str): xsection name
        tech (str): Optionally technology identifier to use. If None, the active technology is used.
        layer (Layer | str | int | tuple): layer identifier
        accurary (float): Accuracy of the grid in um of the (layer, datatype). Overwrites the accuracy value of the
                layer
        fab_name (str): technology xsection name, e.g. the foundry name for the layer
        origin (str): source/creator of the layer, e.g. 'user', 'foundry'
        growx (float): growth in x-direction of polygon in the (layer, datatype)
            (default = 0.0)
        growy (float): growth in y-direction of polygon in the (layer, datatype)
            (default = 0.0)
        overwrite (bool): Overwrite a layer if it already exists (default=False)
        polyline (bool); Render the structures a polyline rather than polygon (default=False)
        remark (str): extra info about the layer
        leftedge (float | (float, float)): b or (a, b) for an edge at a*width+b, a=0.5 by default
        rightedge (float | (float, float)): b or (a, b) for an edge at a*width+b, a=-0.5 by default

    Returns:
        Xsection: Xsection object having name <xsection>
    """
    if tech is None:
        tech = cfg.active_tech

    # get xsection and layer.
    with nd.Technology(tech):
        XS = get_xsection(xsection)
        layer = get_layer(layer)

    if origin is not None:
        layer.origin = origin
    if fab_name is not None:
        layer.layer_name_foundry = fab_name
    if accuracy is not None:
        layer.accuracy = accuracy

    # parse grow information
    if growx is None:
        growx = cfg.default_xs_layer["growx"][0]
    if growy is None:
        growy = cfg.default_xs_layer["growy"][0]
    leftedgefactor, leftedgeoffset = parse_grow(leftedge, 0.5, growx)
    rightedgefactor, rightedgeoffset = parse_grow(rightedge, -0.5, -growx)
    if growy1 is None:
        growy1 = growy
    if growy2 is None:
        growy2 = growy
    grow = (
        (leftedgefactor, leftedgeoffset),
        (rightedgefactor, rightedgeoffset),
        growy1,
        growy2,
    )

    mask_layer = (layer, grow, polyline)

    # logic to check if the mask layer already exists
    if not overwrite:
        XS.mask_layers.append(mask_layer)
    else:
        # overwrite values for any existing mask layer that uses the same layer name as the new mask_layer
        overwritten = False
        for ML in XS.mask_layers:
            if ML["layer"] == mask_layer["layer"]:
                # overwrite grow and polyline values
                ML["grow"] = mask_layer["grow"]
                ML["polyline"] = mask_layer["polyline"]
        if not overwritten:
            # no existing mask layers -> simply add this layer
            XS.mask_layers.append(mask_layer)

    return XS


add_xsection_layer = add_layer2xsection


def load_layers(filename: str | Path, tech: str = None, clear: bool = False, autocolor: bool = False) -> dict[tuple[str, str], Layer]:
    """Load layer definitions from csv file into the Nazca layer table.

    The load can replace existing layer definitions or extend them (default).

    Expected csv file format (no spaces after the comma!):

        layer_name,layer_name_foundry,layer,datatype,accuracy,origin,remark
        name1,name_alias,2,10,0.001,nazca,this is a remark

    Some columns may be omitted but at the least use these columns:

        layer_name,layer,datatype,accuracy
        name1,2,10,0.001

    Table column definitions:
    layer_name: layer name used in Nazca
    layer_name_foundry: layer name as used by the foundry, if applicable
    layer: layer number
    datatype: datatype number
    accuracy: mask layer resolution in um
    origin: indicates who defines the layer (foundry, nazca, you?)
    remark: optional information on the layer

    Args:
        filename (str): name of layer definition file in csv format
        tech (str): optional, technology name
        clear (bool): clear existing layers (default = False)
        autocolor (bool): Create automated color settings per layer (default = False)

    Returns:
        dict[tuple[str, str], Layer]: layers keyed by (name, tech)
    """
    if clear:
        clear_layers()
    if tech is None:
        tech = cfg.active_tech

    layer_data = {}
    with open(filename, mode="r") as file:
        reader = csv.DictReader(file)
        for layer_info in reader:
            if not any(value != "" for value in layer_info.values()):
                continue  # filter out empty rows

            layer_name = layer_info.pop("layer_name")

            # handle extra user fields and data cleanup
            # TODO: do not delete "unused fields", store in extra (dict) field in stead.
            extra_fields = []
            for key, value in layer_info.items():
                if key not in Layer.__dataclass_fields__:
                    # collect columns not used by nazca
                    extra_fields.append(key)
                if value == "":
                    # replace empty fields with None
                    layer_info[key] = None
            for key in extra_fields:
                # remove columns not used by nazca:
                layer_info.pop(key)

            # insert default if tech is missing in load.
            techloaded = layer_info.pop("tech", None)
            if techloaded is not None:
                tech = techloaded
            elif layer_debug:
                logger.warning(
                    f"Column 'tech' missing in file '{filename}'. "
                    f"Column has been added in load with value '{tech}'."
                )
            # insert source
            if layer_info.get("source") is None:
                layer_info["source"] = str(filename)
            layer_data[(layer_name, tech)] = layer_info

    for (layer_name, tech), layer_info in layer_data.items():
        add_layer(
            name=layer_name,
            tech=tech,
            **layer_info,
            # merge=False,
        )

    if autocolor:
        for layer, layer_info in layer_data.items():
            # LDT = (layer_info.layer, layer_info.datatype, layer_info.tech)
            set_layercolor(
                layer=layer,
                frame_color=None,
                fill_color=None,
                frame_brightness=None,
                fill_brightness=None,
                dither_pattern=None,
                valid=None,
                visible=None,
                transparent=None,
                width=None,
                marked=None,
                animation=None,
                alpha=None,
            )

    return Layer.NT2layer


def load_xsection_layer_map(filename: str | Path, tech: str = None) -> XSID:
    """Load the assignment of layers to xsections from <filename>.

    Layers or xsections in the file that do not yet exist are created automatically.

    Args:
        filename (str): xsection file in csv format
        tech (str): technology ID. If None it defaults to the active tech.
    Returns:
        xs (XSID): cross section object
    """
    if tech is None:
        tech = cfg.active_tech

    with open(filename, mode="r") as file:
        reader = csv.DictReader(file)
        for row in reader:
            if not any(value != "" for value in row.values()):
                continue  # filter out empty rows
            for key, value in row.items():
                if value == "":
                    # replace empty fields with None
                    row[key] = None

            # overwrite technology is the table row contains an explicit technology
            techloaded = row.pop("tech", None)
            if techloaded is not None:
                tech = techloaded
            elif layer_debug:
                logger.warning(
                    f"Column 'tech' missing in file '{filename}'. "
                    f"Column has been added after in load with value '{tech}'"
                )

            # Use pydantic base model for type validation
            xsection_layer_info = XSectionLayerInfo(**row)

            # convert growx and growy to edges
            if xsection_layer_info.leftedgefactor is None:
                xsection_layer_info.leftedgefactor = parse_grow(None, 0.5, xsection_layer_info.growx)[0]
            if xsection_layer_info.leftedgeoffset is None:
                xsection_layer_info.leftedgeoffset = parse_grow(None, 0.5, xsection_layer_info.growx)[1]
            if xsection_layer_info.rightedgefactor is None:
                xsection_layer_info.rightedgefactor = parse_grow(None, -0.5, -xsection_layer_info.growx)[0]
            if xsection_layer_info.rightedgeoffset is None:
                xsection_layer_info.rightedgeoffset = parse_grow(None, -0.5, -xsection_layer_info.growx)[1]
            if xsection_layer_info.growy1 is None:
                xsection_layer_info.growy1 = xsection_layer_info.growy
            if xsection_layer_info.growy2 is None:
                xsection_layer_info.growy2 = xsection_layer_info.growy

            xsref = (xsection_layer_info.xsection, tech)

            if xsref not in XSID.NT2xs:
                msg = f"xsection {xsref} in the xsection_layer_map '{filename}' does not exist." \
                      f"\nPlease make sure you load the xsections before you load the xsection_layer_map."
                nd.main_logger(msg=msg, level="error")

            XS = get_xsection(xsref)

            layerref = (xsection_layer_info.layer_name, tech)

            if layerref not in Layer.NT2layer:
                msg = f"xsection {layerref} in the xsection_layer_map '{filename}' does not exist." \
                      f"\nPlease make sure you load the layers before you load the xsection_layer_map."
                nd.main_logger(msg=msg, level="error")

            layer = get_layer(layerref)

            grow = (
                (xsection_layer_info.leftedgefactor, xsection_layer_info.leftedgeoffset),
                (xsection_layer_info.rightedgefactor, xsection_layer_info.rightedgeoffset),
                xsection_layer_info.growy1,
                xsection_layer_info.growy2,
            )
            # default polyline to False
            polyline = xsection_layer_info.polyline or False

            mask_layer = (layer, grow, polyline)

            # save xsection layer info to the xsection_layer_map
            XS.mask_layers.append(mask_layer)

    return XS


def load_xsections(filename: str | Path, tech: str = None) -> dict[tuple[str, str], XSID]:
    """Load list of xsection from file with stub mapping.

    In addition create a stub map dictionary of a xsection to its stub-xsection.

    Args:
        filename (str): xsection map filename in csv format
        tech (str): technology ID.

    Returns:
        Dict: table with loaded xsections
    """
    if tech is None:
        tech = cfg.active_tech

    with open(filename, mode="r") as file:
        reader = csv.DictReader(file)
        for row in reader:
            if not any(value != "" for value in row.values()):
                continue  # filter out empty rows
            for key, value in row.items():
                if value == "":
                    # replace empty fields with None
                    row[key] = None

            xs_name = row.pop("xsection", None)
            if xs_name is None:
                raise ValueError(f"Column 'xsection' missing in file '{filename}'.")
            techloaded = row.pop("tech", None)

            if techloaded is not None :
                tech = techloaded
            elif layer_debug:
                logger.warning(
                    f"Column 'tech' missing in file '{filename}'. "
                    f"Column has been added after in load with value '{tech}'"
                )
            # TODO what to do if xs_name already in cfg.xsection_table[tech]?
            xsid = (xs_name, tech)
            # cfg.xsection_table[xsid] = xsection_info
            cfg.stubmap[xsid] = row["stub"]

            # add the xsection
            add_xsection(
                name=xs_name,
                tech=tech,
                name_foundry=row.get("xsection_foundry", None),
                origin=row["origin"],
                stub=row.get("stub", None),
                description=row.get("description", ""),
            )

        # TODO: check naming consistency of stubs
        # TODO: check for unique names
        # TODO: fill missing nazca_name with fab_name?
        # TODO: check if all xs are present in the xs definition.

        return XSID.NT2xs


def add_xsection_stub(xsection, stub):
    """Assign a stub xsection to a xsection.

    The default stub is the xsection itself.
    """
    cfg.stubmap[xsection] = stub


def merge_xsection_layers_with_layers():
    """Create a dictionary containing tables of xsections joined with layers.

    The xsection names are the dictionary keys.
    The dictionary contains all attributes for mask export.

    Left-join xsection table with layer table on (layer, datatype) and
    chop it up into a dictionay with xsection as key and the join result as
    values.

    TODO I don't think this is being used anymore -> remove?

    Returns:
        None
    """
    if not Layer.NT2layer or not cfg.xsection_layer_map or not cfg.xsection_table:
        return

    merged_table = {}
    undefined_layers = []  # keep track of undefined layers to raise an exception for all of them at once
    for xsid, xsection_layer_info in cfg.xsection_layer_map.items():
        xs_layer_table = []
        for layerID, layer_info in xsection_layer_info:
            # get matching layer from layer table
            try:
                _layer_layertable = Layer.NT2layer[layerID]
            except KeyError as E:
                alternative_layers = Layer.N2layers[layerID[0]]
                msg = f"Layer {layerID} not defined. Can not add it to a xsection. "
                if alternative_layers:
                    msg += f"Maybe the technology is not set properly ({nd.cfg.active_tech})? "\
                        f"Layer options with other technologies: {alternative_layers}."
                print(msg)
                raise(E)


            # filter out any irrelevant fields
            # TODO this is historic behaviour, but is there actually a good reason to discard this information?
            xsection_layer_info_filtered = {
                key: value
                for key, value in layer_info.model_dump().items()
                if key in MaskLayerAttributes.model_fields
            }
            xsection_layer_info_merged = MaskLayerAttributes(**xsection_layer_info_filtered).model_dump()

            # insert any missing values from the layer table into the new xsection layer map table.
            for field_name, value in xsection_layer_info_merged.items():
                if value is None:
                    xsection_layer_info_merged[f"{field_name}"] = getattr(_layer_layertable, field_name, None)
            xsection_layer_info_merged = MaskLayerAttributes(**xsection_layer_info_merged)
            xs_layer_table.append((layerID, xsection_layer_info_merged))

            # TODO pydantic validation of basemodels means this shouldn't ever happen; error is caught when validating
            #  the fields of the layer_info BaseModel.
            if xsection_layer_info_merged.layer is None:
                undefined_layers.append(layerID)

        merged_table[xsid] = xs_layer_table

    if undefined_layers:
        raise ValueError(
            f"Refering to undefined layer(s) in xsection_layer_map: {undefined_layers}. "
            "Correct the spelling or add the layer(s) explicitly."
        )

    # reset the xsextion's layer-table when merge is called for a fresh build.
    cfg.xs_list = cfg.xsection_table.keys()
    for xs_name, tech in cfg.xs_list:
        add_xsection(name=xs_name, tech=tech).mask_layers = merged_table.get((xs_name, tech), {})
    return


def load_masklayers(layer_file=None, xsection_layer_file=None):
    """Load layer and xsection files and merge them.

    This function combines
    1. load_layers()
    2. load_xsection_layer_map()
    3. merge()

    TODO is this ever used? Anyways, this function shouldn't call the merge anymore probably

    Args:
        layer_file (str): layer file name of csv file
        xsection_layer_file (str): xsection file name of csv file

    Returns:
        dict: {xsection name: mask layer data}
    """
    load_layers(filename=layer_file)
    load_xsection_layer_map(filename=xsection_layer_file)
    return merge_xsection_layers_with_layers()


cfg.xsection_table = XSID.NT2xs
# cfg.xsection_loopup = {}


def add_xsection(
    name: str = cfg.default_xs_name,
    tech: Optional[str] = None,
    name_foundry: str = None,
    origin: str = "add_xsection",
    stub: str = None,
    description: str = "",
    pinstyle=None,
    overwrite: bool = False,
) -> XSID:
    """Create a new Xsection object named <name>.

    If a Xsection with <name> already exists, the existing Xsection is returned.

    Args:
        name (str): xsection name.
        name_foundry (str): optional xsection name used by the foundry
        origin (str): source/creator of the layer, e.g. 'user', 'foundry' or any string.
        stub (str): xsection name to be used for the stub of this xsection
        description (str): Description of this xsection
        pinstyle: Pinstyle used by the xsection
        tech (str): technology id.

    Returns:
        Xsection: Xsection object with name <name>
    """
    if tech == "":
        nd.main_logger("Empty tech in add_xsection(). Selection active tech instead.", "warning")
    if name == "":
        name = cfg.default_xs_name
        nd.main_logger(f"Empty name in add_xsection(). Using '{name}' instead.", "warning")
    tech = tech or cfg.active_tech
    xsid = (name, tech)

    if xsid in XSID.NT2xs.keys() and not overwrite:
        msg = (
            f"Reusing an existing xsection ID '{xsid}'."
            " Use a different xsection name or set overwrite=True."
        )
        nd.main_logger(msg, "warning")
        return XSID.NT2xs[xsid]

    else:
        # create new XS, which is automatically added to XSID.NT2xs
        XS = XSID(name=name, tech=tech)
        XS.description = description
        XS.origin = origin
        XS.stub = stub
        XS.pinstyle = pinstyle

        return XS


def get_xsection(xsref: str | tuple[str, str]) -> XSID:
    """Return the Xsection object corresponding to <name>.

    TODO cleanup code. Handle degenerate is not used and there is a large segment of commented code

    Args:
        xsection (xsectionref): reference to an xsection ID, possibly via a Node object.

    Returns:
        Xsection: Xsection object matching xsref.
    """

    def handle_degenerate(matches: list, aslist: bool = False):
        """Check if a mapping is unique.

        Args:
            matches (list): list of matching xsections
            aslist (bool): return all matching xsections in the list if True

        Returns:
            list or Xsection: matching xsection if unique, list of matching xsections if aslist=True
        """
        if len(matches) == 1:
            return matches[0]
        elif len(matches) > 1:
            if cfg.allow_arbitrary_xsection_mapping:
                msg = (
                    "Non-unique xsection: {0}. "
                    "Matching xsection identifiers for {0} are {1}. "
                    "Continuing here with xsection identifier = '{2}'.".format(
                        xsection, matches, matches[0]
                    )
                )
                logger.log(level="warning", msg=msg)
                return matches[0]
            else:
                msg = (
                    "Non-unique xsection: {0}. "
                    "Matching xsection identifiers for {0} are {1}. "
                    "Set cfg.allow_arbitrary_xsection_mapping to True if you want to continue with the first matching xsection".format(
                        xsection, matches
                    )
                )
                raise ValueError(msg)

        #     if aslist:
        #         return matches
        #     if cfg.allow_arbitrary_xsection_mapping:  # TODO: rename into match_first_xsection
        #         msg = (
        #             f"Non-unique xsection identifier used: {layer}; "
        #             f"Matching xsections are \n{"\n".join(str(match.NT) for match in matches)}\n"
        #             f"Selecting xsection '{matches[0].NT}'."
        #         )
        #         nd.main_logger(level="warning", msg=msg)
        #         return matches[0]
        #     else:
        #         msg = (
        #             f"Non-unique xsection identifier used: {matches}; "
        #             f"Matching xsections are \n{"\n".join(str(match.NT) for match in matches)}\n"
        #             "Set cfg.allow_arbitrary_xsectoin_mapping to True if you want to continue with the first matching layer. "
        #             "Or set aslist=True to get all matching xsections."
        #         )
        #         raise Exception(msg)
        # else:
        #     return matches
    if hasattr(xsref, "xs"):  # if name is a pin (Node) get its xsection name
        xsref = xsref.xs

    xsections = []
    if isinstance(xsref, XSID):
        return xsref
    elif isinstance(xsref, tuple): # name, tech
        N, T = xsref
        xsections = XSID.NT2xs.get(xsref, [])
    elif isinstance(xsref, str):  # name
        N, T = xsref, cfg.active_tech
        xsections = XSID.NT2xs.get((xsref, T), [])
    else:
        raise ValueError(f"Unexpected format for xsection reference argument: {xsref}.")

    if xsections:
        return xsections


    if N == "dump":
        if cfg.redirect_unknown_xsections:
            return add_xsection("dump", T)  # TODO: one dump per tech, or one dump overall?

    if cfg.redirect_unknown_xsections:
        msg = (
            f"Unknown xsection reference {xsref} in call get_xsection(). "
            "Moving layout content to the 'dump 'layer 'dump' instead, "
            "because redirect_unknown_xsections = True. "
            f"Possible candidate xsections are {XSID.N2xs.keys()}"
        )
        #if isinstance(cfg.gdsload, str):
        #    msg += f" Xsection popped up while loading file '{cfg.gdsload}'."
        nd.main_logger(msg, "warning")
        return get_xsection(("dump", T))  # TODO: one dump per tech, or one dump overall?
    else:  # create new xsection
        T = T or cfg.active_tech
        N = N or f"Nazca/{T}"
        return add_xsection(
            name=N,
            tech=T,
        )

    # TODO code below will never execute

    # create new xsection
    newxs = add_xsection(name=N, tech=T)
    return newxs


class Tables(BaseModel):
    """Class object for transfering Nazca tables through the restAPI.

    For a PDK API, copy lists of Nazca types, such as layers and xsections the client side.
    This class groups those list together under one type for easy deserialization.
    """

    layers: Optional[dict] = Layer.NT2layer
    xsections: Optional[dict] = XSID.NT2xs
    stubmap: Optional[dict] = cfg.stubmap
    pinstyles: Optional[dict] = cfg.pinstyles
    settings: Optional[dict] = {}
    tech: Optional[str] = None

    def __init__(self, **data):
        """Intialize the Tables object.

        If a tech is supplied, this filters the layers and xsections to only contain those that match the technology
        """
        super().__init__(**data)

        if self.tech is not None:
            filtered_layers = {}
            for layer_id, layer in self.layers.items():
                if layer.tech == self.tech:
                    filtered_layers[layer_id] = layer
            self.layers = filtered_layers

            filtered_xsections = {}
            for xsection_id, xsection in self.xsections.items():
                if xsection.tech == self.tech:
                    filtered_xsections[xsection_id] = xsection
            self.xsections = filtered_xsections

            filtered_stubmap = {}
            for stub_id, stub in self.stubmap.items():
                if stub_id[1] == self.tech:
                    filtered_stubmap[stub_id] = stub
            self.stubmap = filtered_stubmap

            filtered_pinstyles = {}
            for pinstyle_id, pinstyle in self.pinstyles.items():
                if pinstyle_id[1] == self.tech:
                    filtered_pinstyles[pinstyle_id] = pinstyle
            self.pinstyles = filtered_pinstyles

            self.settings = nd.cfg.technology_settings.get(self.tech, nd.get_active_settings())

    def to_dict(self) -> dict:
        """Serialize the list of Nazca types.

        Returns:
            dict: dictionary containing the serialized tables
        """
        tables = {}

        tables["tech"] = self.tech

        layer_table = []
        for layer in self.layers.values():
            layer_table.append(layer.to_dict())
        tables["layers"] = layer_table

        xsection_table = []
        for xsection in self.xsections.values():
            xsection_table.append(xsection.to_dict())
        tables["xsections"] = xsection_table

        stubmap = {"xsids": [], "stubs": []}
        for xsid, stub in self.stubmap.items():
            stubmap["xsids"].append(xsid)
            stubmap["stubs"].append(stub)
        tables["stubmap"] = stubmap

        pinstyles = {"pinstyle_ids": [], "pinstyles": []}
        for pinstyle_id, pinstyle in self.pinstyles.items():
            pinstyles["pinstyle_ids"].append(pinstyle_id)
            pinstyles["pinstyles"].append(pinstyle)
        tables["pinstyles"] = pinstyles

        tables["settings"] = self.settings

        # TODO other tables/data?
        #  Maybe default layers, compact model tables, etc.

        return tables


def clear_layers() -> None:
    """Clear all objects with layer information.

    Returns:
        None
    """
    global unknown_layers
    unknown_layers = set()

    cfg.colors = {}

    Layer.NT2layer = dict()  # unique lookup
    Layer.N2layers = defaultdict(list)  # potentially non-unique lookup
    Layer.L2layers = defaultdict(list)  # potentially non-unique lookup
    Layer.LD2layers = defaultdict(list)  # potentially non-unique lookup
    Layer.LT2layers = defaultdict(list)  # potentially non-unique lookup
    Layer.LDT2layers = defaultdict(list)  # potentially non-unique lookup


# TODO this is deprecated for new tables
def clear_xsection_layers() -> None:
    """Drop all rows from layers and xs tables.

    Returns:
        None
    """
    cfg.xsection_layer_map = {}
    for xs in XSID.NT2xs.values():
        xs.mask_layers = []
    cfg.xs_list = []


def clear_xsections() -> None:
    """Clear xsection dict"""
    cfg.xs_list = []
    # TODO: clear XSID xsection lookups and XS

    XSID.NT2xs = dict()
    XSID.N2xs = defaultdict(list)


def clear_all() -> None:
    """Clear Nazca layer and xsection structures.

    For now only call certain funtions.

    Returns:
        None
    """
    clear_xsections()
    nd.cfg.stubmap = {}
    clear_layers()


def empty_xsections():
    """Delete info on all xs. Keep layer info.

    Returns:
        None
    """
    cfg.xsection_layer_map = {}
    clear_xsections()


# ==============================================================================
# plt
# ==============================================================================
def set_plt_properties(figsize=14, cmap=None, N=32, alpha=0.3):
    """Set the default colormap to use in Matplotlib output for mask layout.

    Args:
        figsize (float): size of the matplotlib figure (default = 14)
        cmap (str): name of the colormap, (default = None uses cfg.plt_cmap_name)
        N (int): the number of colors in the map in case of a 'linearSegmentedColormap' default = 32)
        alpha (float): transparency of the cmap to see through layers (default = 0.3).

    Returns:
        None
    """
    if cmap is None:
        cmap = cfg.plt_cmap_name

    mp = mpl.colormaps[cmap]
    if isinstance(mp, mpl.colors.LinearSegmentedColormap):
        cfg.plt_cmap = []
        for n in range(N):
            cfg.plt_cmap.append(mp(n / N))
    else:
        cfg.plt_cmap = mp.colors

    cfg.plt_cmap_size = len(cfg.plt_cmap)
    cfg.plt_figsize = figsize
    cfg.plt_alpha = alpha


# make sure colors are set:
set_plt_properties()

# ==============================================================================
# colors
# ==============================================================================
color_defaults = {
    "fill_color": 0,
    "frame_color": 0,
    "transparent": True,  # Klayout transparancy flag
    "frame_brightness": 32,  # Klayout transparency level
    "fill_brightness": 32,  # Klayout transparency level
    "dither_pattern": "I0",  # KLayout dither
    "marked": False,
    "animation": 1,  # blinking if True
    "valid": True,  # KLayout valid flag (editable)
    "visible": True,  # layer visible if True
    "width": 0,  # frame width
    "alpha": 0.3,  # Matplotlib transparency level in
}


def load_layercolors(filename: str | Path) -> None:
    """Read colormap from a .csv Nazca color table file.

    Args:
        filename (str): filename

    Returns:
        None
    """
    # block_load_colors = True

    # For Klayout tabs with groups the layer column contains a '*'
    # and Pandas will create type->str
    # For tabs without groups the layer is read as type->int

    if not os.path.exists(filename):
        nd.main_logger(f"Color file not found, skipping loading of: '{filename}'", "info")
        return

    colors = {}
    with open(filename, mode="r") as file:
        reader = csv.DictReader(file)
        for row in reader:
            if not any(value != "" for value in row.values()):
                continue  # filter out empty rows
            for key, value in row.items():
                if value == "":
                    # replace empty fields with None
                    row[key] = None
            row["alpha"] = 0.3
            color_name = f"{row['layer']}/{row['datatype']}"

            colors[color_name] = row
    cfg.colors = colors


def set_layercolor(
    layer=None,
    frame_color=None,
    fill_color=None,
    frame_brightness=None,
    fill_brightness=None,
    dither_pattern=None,
    valid=None,
    visible=None,
    transparent=None,
    width=None,
    marked=None,
    animation=None,
    alpha=None,
):
    """Set layer color information.

    Generate a table with layer color information.
    For missing attribute values for fill_color and frame_color,
    the default_colors as specified in colormap cfg.plt_cmap are be applied.
    Note that the default colormap can be adjusted by the user.

    Args:
        layer (layerref): layer reference to lookup the matching layer object.
        tech (str) : technology (default = None)
        ...: attributes

    Returns:
        None
    """
    if layer is None:
        raise ValueError("Need to provide a layer number or name to set layer colors.")
    layerobj = get_layer(layer)
    layer_name = layerobj.name
    tech = layerobj.tech
    layer = layerobj.layer
    datatype = layerobj.datatype
    color_name = f"{layer}/{datatype}"
    kltab_name = f"{layer}/{datatype} {layer_name}"
    colors = {
        "depth": 1,  # group depth
        "layer_name": layer_name,
        "tech": tech,
        "name": kltab_name,
        "color_name": color_name,
        "layer": layer,
        "datatype": datatype,
        "fill_color": fill_color,
        "frame_color": frame_color,
        "frame_brightness": frame_brightness,
        "fill_brightness": fill_brightness,
        "dither_pattern": dither_pattern,
        "valid": valid,
        "visible": visible,
        "transparent": transparent,
        "width": width,
        "marked": marked,
        "animation": animation,
        "alpha": alpha,
    }

    assert isinstance(layer, int)
    assert isinstance(datatype, int)
    if cfg.colors:
        color_duplicate = [name for name in cfg.colors.keys() if name == color_name]
        coloritems = len(color_duplicate)
    else:
        coloritems = 0

    if coloritems == 0:
        # TODO: not here or the colors can't be changed later on.
        # col = mpl.colors.to_hex(cfg.plt_cmap[layer % cfg.plt_cmap_size])
        col = rgb2hex(cfg.plt_cmap[int(layer % cfg.plt_cmap_size)])
        if fill_color is None:
            colors["fill_color"] = col
        if frame_color is None:
            colors["frame_color"] = col
        for attr in colors.keys():
            if colors[attr] is None:
                if attr in color_defaults.keys():
                    colors[attr] = color_defaults[attr]
        cfg.colors[color_name] = colors

    elif coloritems == 1:
        for attr, value in cfg.colors[color_name].items():
            # use existing values for undefined attributes or attributes with None value
            if colors.get(attr, None) is None:
                colors[attr] = value
        cfg.colors[color_name] = colors

    else:
        logger.warning("Multiple color entries for ML({}, {}). Skipping...".format(layer, datatype))

    return colors


def save_colormap(filename: str = None) -> None:
    """Save a colormap to csv file.

    Args:
        filename (str): output filename

    Returns:
        None
    """
    if filename is None:
        filename = "colors_saved.csv"
    bools = {"valid", "visible", "transparent", "marked"}
    with open(filename, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=colors_attr_csv, lineterminator="\n")
        writer.writeheader()
        for color in cfg.colors.values():
            row = {}
            for attr in colors_attr_csv:
                value = color.get(attr, "")
                if attr in bools and isinstance(value, bool):
                    value = str(value).lower()
                elif value is None:
                    value = ""
                row[attr] = value
            writer.writerow(row)


def get_layermap(origin: str = None, tech: str = None) -> dict[tuple[str, str], tuple[str, str]]:
    """Create an identity layermap for registered layers.

    Args:
        origin (str): Optional layer origin to include.
        tech (str): Optional technology to include.

    Returns:
        dict: Mapping of layer IDs to themselves.
    """
    return {layer_id: layer_id for layer_id in get_layers(tech=tech, origin=origin)}


# ==============================================================================
# Show or get tables
# ==============================================================================
def get_layers(tech: str = None, origin: str = None) -> dict[tuple[str, str], Layer]:
    """Return registered layers keyed by their unique layer ID.

    Without filters, layers from all technologies and origins are returned.

    Args:
        tech (str): Optional technology to include.
        origin (str): Optional layer origin to include.

    Returns:
        dict: Copy of the selected layer registry as {layer ID: Layer}.
    """
    layers = Layer.NT2layer.values()
    if tech is not None:
        layers = (layer for layer in layers if layer.tech == tech)
    if origin is not None:
        layers = (layer for layer in layers if layer.origin == origin)
    return {layer.ID: layer for layer in layers}


def show_xsections() -> None:
    """Print the xsections table.

    Returns:
        None
    """
    # print('-------------------------------')
    print("\n---------\nxsections\n---------")
    # if cfg.xsection_table:
    if True:  # For now it should print the table, instead of pretending it's empty
        data = XSID.NT2xs

        # get all technologies
        techs = []
        for name, tech in data:
            if tech not in techs:
                techs.append(tech)

        # Extract column headers from the model fields

        column_headers = list(XSID.model_fields)


        for tech in techs:
            print(f"\ntech: {tech}")
            # Calculate column widths
            col_widths = []
            for field in column_headers:
                widths = [len(str(field))]
                for model in data.values():
                    widths.append(len(str(getattr(model, field))))
                col_widths.append(max(widths))
            # calculate width of the row headers
            row_header_width = max([len(TN[0]) for TN in data if TN[1] == tech])

            # Print the column headers
            header_row = f"{'xsection':<{row_header_width}} | " + " | ".join(
                f"{header:<{col_widths[i]}}" for i, header in enumerate(column_headers)
            )
            print(header_row)
            print("-" * row_header_width + "-+-" + "-+-".join("-" * width for width in col_widths))

            # Print the rows
            for name, model in data.items():
                if name[1] != tech:
                    continue
                row = f"{name[0]:<{row_header_width}}"
                for i, field in enumerate(column_headers):
                    field_value_string = str(
                        getattr(model, field) if getattr(model, field) is not None else "None"
                    )
                    alignment_spaces = col_widths[i] - len(field_value_string)
                    row += f" | {field_value_string}" + f"{alignment_spaces * ' '}"
                print(row)
            print("-" * row_header_width + "-+-" + "-+-".join("-" * width for width in col_widths))
    else:
        print("No xsections defined.")


def show_layers() -> None:
    """Print the layer table."""
    # print('-------------------------------')
    # print("Table 'cfg.layer_table' with layer definitions:")
    print("\n------\nlayers\n------")
    if cfg.layer_table:
        data = Layer.NT2layer
        # get all technologies
        techs = []
        for NLD, layer in data.items():
            if layer.tech not in techs:
                techs.append(layer.tech)

        # Extract column headers from the model fields
        column_headers = [f.name for f in fields(Layer)]

        for tech in techs:
            print(f"\ntech: {tech}")
            # Calculate column widths
            col_widths = []
            for field in column_headers:
                widths = [len(str(field))]
                for TN, model in data.items():
                    if TN[1] != tech:
                        continue
                    widths.append(len(str(getattr(model, field))))
                col_widths.append(max(widths))
            # calculate width of the row headers
            row_header_width = max([len(TN[0]) for TN in data if TN[1] == tech])

            # Print the column headers
            header_row = f"{'Layer':<{row_header_width}} | " + " | ".join(
                f"{header:<{col_widths[i]}}" for i, header in enumerate(column_headers)
            )
            print(header_row)
            print("-" * row_header_width + "-+-" + "-+-".join("-" * width for width in col_widths))

            # Print the rows
            for name, model in data.items():
                if name[1] != tech:
                    continue
                row = f"{name[0]:<{row_header_width}}"
                for i, field in enumerate(column_headers):
                    field_value_string = str(
                        getattr(model, field) if getattr(model, field) is not None else "None"
                    )
                    alignment_spaces = col_widths[i] - len(field_value_string)
                    row += f" | {field_value_string}" + f"{alignment_spaces * ' '}"
                print(row)
            print("-" * row_header_width + "-+-" + "-+-".join("-" * width for width in col_widths))
    else:
        print("  ...no layers defined.")


def show_layercolors() -> None:
    """
    Print the layercolor table.

    Returns:
        None
    """
    print("\n-----------\nLayer colors\n-----------")
    if cfg.colors:
        data = cfg.colors
        # Extract column headers from the table
        column_headers = []
        for key, val in cfg.colors.items():
            for col in val.keys():
                if col in column_headers:
                    continue
                column_headers.append(col)

        # Calculate column widths
        col_widths = []
        for field in column_headers:
            widths = [len(str(field))]
            for name, color in data.items():
                widths.append(len(str(color.get(field))))
            col_widths.append(max(widths))

        # calculate width of the row headers
        row_header_width = max([len(colorname) for colorname in data.keys()] + [len("color")])

        # Print the column headers
        header_row = f"{'color':<{row_header_width}} | " + " | ".join(
            f"{header:<{col_widths[i]}}" for i, header in enumerate(column_headers)
        )
        print(header_row)
        print("-" * row_header_width + "-+-" + "-+-".join("-" * width for width in col_widths))

        # Print the rows
        for name, color in data.items():
            row = f"{name:<{row_header_width}} | "
            for i, field in enumerate(column_headers):
                field_value_string = str(color.get(field) if color.get(field) is not None else "None")
                alignment_spaces = col_widths[i] - len(field_value_string)
                row += f"{field_value_string}" + f"{alignment_spaces * ' '} | "
            print(f"{row[:-3]}")
        print("-" * row_header_width + "-+-" + "-+-".join("-" * width for width in col_widths))


def show_xsection_layer_map() -> None:
    """Print the xsection_layer_map table to stdout.

    Returns:
        None
    """
    # print('-------------------------------')
    print("\n-------------------\nxsection-layer_map\n-------------------")

    if cfg.xsection_table:
        data = XSID.NT2xs

        # get all technologies
        techs = []
        for name, tech in data:
            if tech not in techs:
                techs.append(tech)

        for tech in techs:
            print(f"\ntech: {tech}")

            for xsid, xsection in XSID.NT2xs.items():
                if xsid[1] != tech: continue

                columns = {
                    "name": [],
                    "layer": [],
                    "datatype": [],
                    "tech": [],
                    "growx": [],
                    "growy1": [],
                    "growy2": [],
                    "accuracy": [],
                    "polyline": [],
                }

                if not xsection.mask_layers: continue

                # collect all columns:
                for layer, grow, polyline in xsection.mask_layers:
                    columns["name"].append(layer.name)
                    columns["layer"].append(layer.layer)
                    columns["datatype"].append(layer.datatype)
                    columns["tech"].append(layer.tech)
                    columns["growy1"].append(grow[2])
                    columns["growy2"].append(grow[3])
                    columns["accuracy"].append(layer.accuracy)
                    columns["polyline"].append(polyline)

                    # convert rightedge and leftedge to symmetrical grow
                    leftedgefactor = grow[0][0]
                    leftedgeoffset = grow[0][1]
                    rightedgefactor = grow[1][0]
                    rightedgeoffset = grow[1][1]
                    growx = abs(0.5 * (leftedgefactor - leftedgeoffset + rightedgefactor + rightedgeoffset))
                    columns["growx"].append(growx)

                headers = list(columns.keys())
                rows = list(zip(*columns.values()))

                # Compute max width for each column
                col_widths = {
                    str(h): max(len(str(h)), *(len(str(val)) for val in columns[h]))
                    for h in headers
                }

                # Format row template
                fmt_row = "\t| " + " | ".join(f"{{:{col_widths[str(h)]}}}" for h in headers) + " |"

                title = f"{xsid[0]} mask layers"
                total_width = sum(col_widths[str(h)] + 3 for h in headers) + 1  # +3 for ' | ', +1 for final '|'
                centered_title = f"\t| {title.center(total_width - 4, '-')} |"  # -4 for "| " and " |"
                print(centered_title)

                # Print header
                print(fmt_row.format(*[str(h) for h in headers]))
                print("\t|-" + "-|-".join("-" * col_widths[str(h)] for h in headers) + "-|")

                # Print rows
                for row in rows:
                    print(fmt_row.format(*[str(v) for v in row]))

                print("\t|" + "-" * (total_width - 2) + "|\n")
    else:
        print("No xsections defined.")


if __name__ == "__main__":
    layer = dict()
    layer[1] = add_layer("M1", "tech1", 1, 0)
    layer[2] = add_layer("M1", "tech1", 1, 0)
    layer[3] = add_layer("M2", "tech2", 2, 0)
    layer[4] = add_layer("M2", "tech1", 3, 0)
    layer[5] = add_layer("M3", "tech2", 3, 0)
    layer[6] = add_layer("M5", "tech1", 5, 5)
    layer[7] = add_layer("M5", "tech0", 5, 5)
    layer[8] = add_layer(layer=3, datatype=11)
    layer[9] = add_layer(layer=3, datatype=1)
    layer[10] = add_layer(name="M6", layer=6, datatype=0, tech="tech1")
    layer[11] = add_layer(name="M6", layer=6, datatype=0, tech="tech2")


    # # test getting a default layer
    # print(f'{get_layer("dump")=}')
    #
    # # test getting a default layer when there is a str:str mapping for default layers
    # cfg.default_layers["dump2"] = "dump"
    # print(f'{get_layer("dump2")=}')

    print("-----------------TESTING GET LAYER------------------------------")
    for _ in range(1):
        # get_layer(["foo"])
        print(f'{get_layer("M3") = }\n')
        print(f'{get_layer("M2") = }\n')
        print(f'{get_layer(("M1", "tech1")) = }\n')
        print(f'{get_layer((3, 0)) = }\n')
        print(f'{get_layer("foo") = }\n')
        cfg.redirect_unknown_layers = True
        print(f'with redirect:\n{get_layer(4) = }\n') # should give dump layer because redirect unknown layers
        cfg.redirect_unknown_layers = False
        print(f'without_redirect:\n{get_layer(4)=}\n') # should make a new layer
        print(f'{get_layer(2) = }\n')
        #
        print(f'{get_layer((5, 5)) = }\n')
        print(f'{get_layer((5, 5, "tech1")) = }\n')
        #
        print(f'{get_layer("M6") = }\n')
        cfg.active_tech = "tech1"
        print(f'\n{get_layer("M6") = }\n')
        #
        print(f'\n{get_layer("dicelane") = }\n')
        cfg.active_tech = "tech2"
        print(f'\n{get_layer("dicelane") = }\n')

        cfg.redirect_unknown_layers = True
        print(f'{get_layer(("M6", "tech10")) = }\n')
        print(f'{get_layer(4) = }\n')
        print(f'{get_layer("M7") = }\n')
        print(f'{get_layer((10, 10)) = }\n')

    # test Xsection class
    print("======== Testing Xsection class ========\n")

    xs = dict()
    xs[1] = add_xsection("xs1")
    xs[2] = add_xsection("xs2")
    xs[3] = add_xsection("")
    xs[4] = add_xsection("")
    xs[4] = add_xsection("xs3")
    xs[4] = add_xsection("xs3", "tech3")
    xs[4] = add_xsection("xs3", "tech1")

    print(f'{get_xsection("x1") = }\n')
    print(f'{get_xsection(("x1", "tech1")) = }\n')
    print(f'{get_xsection("x2") = }\n')
    print(f'{get_xsection("x3") = }\n')
    print(f'{get_xsection(("x3", "tech1")) = }\n')
    print(f'{get_xsection("x4") = }\n')
    print(f'{get_xsection(("x4", "tech3")) = }\n')

    cfg.redirect_unknown_xsections = True
    print(f'{get_xsection(("x5", "tech4")) = }\n')
    print(f'{get_xsection(("x6")) = }\n')
    print(f'{get_xsection(("x7", "")) = }\n')
