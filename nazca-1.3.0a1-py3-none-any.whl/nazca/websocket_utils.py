# -----------------------------------------------------------------------
#
# Nazca is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or (at
# your option) any later version.
#
# Nazca is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with Nazca.  If not, see <http://www.gnu.org/licenses/>.
# -----------------------------------------------------------------------
#
# @author: Jerom Baas, Rob van Hout
# Bright Photonics B.V. (c) 2025,
# @email: info@brightphotonics.eu
#

"""Module to address functionality for websockets

The module provides the required logic for servers that use a websocket.
"""

import asyncio
import atexit
import json
import os
import traceback
import uuid
from typing import Any, Callable, Dict
from typing_extensions import Self

from queue import Queue
import threading
try:
    import websockets
except ImportError as e:
    raise ImportError(
        "nazca.websocket_utils requires the 'websockets' package; install it with: pip install nazca[ws]"
    ) from e
from concurrent.futures import Future, ThreadPoolExecutor

from nazca import to_dict, from_dict
from nazca import main_server_logger


class WorkloadDispatchService:
    """ A server service that dispatches workloads to connected clients.
    """
    _instance = None

    _request_queues: Dict[str, Queue]
    _request_workloads: Dict[str, list[str]]
    _requests_lock: threading.Lock
    _responses: Dict[str, Dict[str, Any]]
    _responses_lock: threading.Lock
    _ws_event: threading.Condition
    _thread: threading.Thread

    @classmethod
    def start(cls, host: str, port: int) -> "WorkloadDispatchService":
        """ Start the WorkloadDispatchService.
            args:
                host: the host to listen on.
                port: the port to listen on.
        """
        if cls._instance is None:
            cls._instance = object.__new__(cls)
            cls._instance._init(host, port)
            main_server_logger(msg=f"WorkloadDispatchService started on {host}:{port}", level="info")
        return cls._instance

    @classmethod
    def get_instance(cls) -> "WorkloadDispatchService":
        """ Returns the WorkloadDispatchService singleton instance.
        """
        return cls._instance

    def _init(self, host: str, port: int):
        self._request_queues = {}
        self._request_workloads = {}
        self._requests_lock = threading.Lock()
        self._responses = {}
        self._responses_lock = threading.Lock()
        self._ws_event = threading.Condition()
        self._thread = threading.Thread(
            target=self._start_websocket_endpoint_thread,
            args=(host, port),
            daemon=True
        )
        self._instance._thread.start()

    def is_workload_supported(self, ws_id: str, workload: str) -> bool:
        """ Check if a workload is supported by a client.
            args:
                ws_id: the unique identifier of the client.
                workload: the name of the workload.
            returns:
                True if the workload is supported, False otherwise.
        """
        with self._requests_lock:
            if ws_id not in self._request_queues or ws_id not in self._request_workloads:
                raise ValueError(f"Invalid websocket id {ws_id}.")
            return workload in self._request_workloads[ws_id]

    def queue_workload_request(self, ws_id: str, workload: str, **kwargs) -> str:
        """ Queue a workload request for a client.
            args:
                ws_id: the unique identifier of the client.
                workload: the name of the workload.
                kwargs: the arguments for the workload.
            returns:
                the unique identifier of the request.
        """
        if not self.is_workload_supported(ws_id, workload):
            raise ValueError(f"Invalid workload {workload} for websocket id {ws_id}.")
        with self._requests_lock:
            queue = self._request_queues[ws_id]
            id = str(uuid.uuid4())
            request = {
                "id": id,
                "workload": workload,
                "args": kwargs
            }
            queue.put(request)
            main_server_logger(msg=f"Workload request queued: {id} for ws_id {ws_id}", level="debug")

            return id

    def try_get_responses(self, ws_id: str, *ids: str, timeout=0) -> dict[str, Any] | None:
        """ Try to get the responses for a list of requests.
            args:
                ws_id: the unique identifier of the client.
                ids: the unique identifiers of the requests.
                timeout: the maximum time to wait for the responses.
            returns:
                a dictionary of responses for the requests, or None if the responses are not ready.
        """

        def _all_responses_received_or_ws_closed() -> bool:
            with self._responses_lock:
                if ws_id not in self._responses:
                    main_server_logger(msg=f"Websocket ID {ws_id} not found", level="warning")
                return ws_id not in self._responses or all(id in self._responses[ws_id] for id in ids)

        with self._ws_event:
            if self._ws_event.wait_for(_all_responses_received_or_ws_closed, timeout):
                with self._responses_lock:
                    ws_responses = self._responses.get(ws_id)
                    if ws_responses is None:
                        return None
                    result = {id: ws_responses[id] for id in ids}
                    for id in ids:
                        self._responses[ws_id].pop(id)
                        main_server_logger(msg=f"Responses retrieved for request {id} from ws_id {ws_id}", level="debug")
                    main_server_logger(msg=f"Responses retrieved for {len(ids)} requests from ws_id {ws_id}", level="debug")
                    return result
        return None

    def _start_websocket_endpoint_thread(self, host: str, port: int):
        asyncio.run(self._websocket_endpoint(host, port))

    async def _websocket_endpoint(self, host: str, port: int):
        async with websockets.serve(self._websocket_handler, host, port) as server:
            main_server_logger(msg=f"WebSocket server started on {host}:{port}", level="info")
            await server.serve_forever()

    async def _websocket_handler(self, websocket: websockets.ServerConnection):
        ws_id = websocket.request.headers.get("ws_id")
        main_server_logger(msg=f"New WebSocket connection established with ws_id {ws_id}", level="info")
        request_queue = Queue()
        responses = {}
        with self._requests_lock:
            self._request_queues[ws_id] = request_queue
            self._request_workloads[ws_id] = json.loads(websocket.request.headers.get("workloads"))
        with self._responses_lock:
            self._responses[ws_id] = responses
        try:
            while True:
                await asyncio.gather(
                    self._send_requests(websocket, request_queue),
                    self._receive_responses(websocket, responses))
        except websockets.ConnectionClosed:
            with self._requests_lock:
                del self._request_queues[ws_id]
                del self._request_workloads[ws_id]
            with self._responses_lock:
                main_server_logger(msg=f"WebSocket {ws_id} closed -> deleting response dict", level="info")
                del self._responses[ws_id]
            with self._ws_event:
                self._ws_event.notify_all()

    async def _send_requests(self, websocket: websockets.ServerConnection, queue: Queue):
        while True:
            request = await asyncio.to_thread(queue.get)
            if request is not None:
                try:
                    await websocket.send(json.dumps(to_dict(request)))
                finally:
                    queue.task_done()

    async def _receive_responses(self, websocket, responses: Dict[str, Any]):
        while True:
            response = await websocket.recv()
            response_data = from_dict(json.loads(response))
            id = response_data.get("id")
            if id is not None:
                with self._responses_lock:
                    responses[id] = response_data.get("result")
                with self._ws_event:
                    self._ws_event.notify_all()

class WorkloadDispatchServiceProxy:
    @classmethod
    def create(cls, ws_id: str) -> "WorkloadDispatchServiceProxy | None":
        """ Creates a WorkloadDispatchServiceProxy if ws_id is defined and WorkloadDispatchService is started.
            args:
                ws_id: the websocket ID to create the proxy for.
        """
        if ws_id is not None and WorkloadDispatchService.get_instance() is not None:
            instance = object.__new__(cls)
            instance._init(ws_id)
            return instance
        return None

    def _init(self, ws_id: str):
        self._ws_id = ws_id
        self._workload_dispatch_service = WorkloadDispatchService.get_instance()

    def is_workload_supported(self, workload: str) -> bool:
        return self._workload_dispatch_service.is_workload_supported(self._ws_id, workload)

    def queue_workload_request(self, workload: str, **kwargs) -> str:
        return self._workload_dispatch_service.queue_workload_request(self._ws_id, workload, **kwargs)

    def try_get_responses(self, *ids: str, timeout=0) -> dict[str, Any] | None:
        return self._workload_dispatch_service.try_get_responses(self._ws_id, *ids, timeout=timeout)


class WorkloadListenerService:
    """ A client service that listens for workloads forwarded from from a server.
    """

    def __init__(self, uri: str, supported_workloads: Dict[str, Callable]):
        """ Initialize the WorkloadListenerService.
            args:
                uri: the URI of the server to connect to
                supported_workloads: a dictionary of workloads that the client can handle.
                    The dictionary should have the workload name as the key and a callable
                    as the value.
        """
        self.uri = uri
        self._identifier = str(uuid.uuid4())
        self._thread = None
        self._workloads = supported_workloads
        self._executor = None
        self._connected_future = None
        self._shutdown_event = None

        # Start the service automatically
        self._start()

        # Register cleanup on exit
        atexit.register(self.stop)

    def get_identifier(self):
        """ Get the unique identifier of the client.
        """
        return self._identifier

    def _start(self):
        """ Start the WebSocket listener in a separate thread. """
        if self._thread is None:
            self._shutdown_event = asyncio.Event()
            self._executor = ThreadPoolExecutor()
            self._connected_future = Future()
            self._thread = threading.Thread(target=self._start_websocket_listener_thread, daemon=True)
            self._thread.start()
            if self._connected_future.result() == False:
                raise ConnectionError(f"Failed to connect to {self.uri}")

    def stop(self):
        """ Stop the WebSocket listener and clean up resources. """
        if self._thread is not None:
            self._shutdown_event.set()
            self._thread.join()
            self._thread = None
            self._executor.shutdown()

    def _start_websocket_listener_thread(self):
        asyncio.run(self._websocket_listener())

    async def _websocket_listener(self):
        additional_headers = {
            "ws_id": self._identifier,
            "workloads": json.dumps(list(self._workloads.keys()))
        }
        try:
            async with websockets.connect(self.uri, additional_headers=additional_headers) as websocket:
                self._connected_future.set_result(True)
                try:
                    while not self._shutdown_event.is_set():
                        try:
                            request = await asyncio.wait_for(websocket.recv(), timeout=1)
                            data = from_dict(json.loads(request))
                            workload = data.get("workload")
                            id = data.get("id")
                            args = data.get("args")

                            if workload and id and args:
                                asyncio.create_task(self._offload_workload_task(websocket, workload, id, args))
                        except asyncio.TimeoutError:
                            pass  # just to yield for catching _shutdown_event if set
                except websockets.ConnectionClosed:
                    pass  # socket closed; exit thread
                finally:
                    await websocket.close()
        except ConnectionRefusedError:
            self._connected_future.set_result(False)

    async def _offload_workload_task(self, websocket, workload, id, args):
        function = self._workloads.get(workload)
        if function is not None:
            async def send_result():
                loop = asyncio.get_event_loop()

                # deserialize function arguments
                try:
                    result = await loop.run_in_executor(self._executor, lambda: function(**args))
                    response = {
                        "id": id,
                        "result": result
                    }
                    await websocket.send(json.dumps(to_dict(response)))
                except Exception as e:
                    # an exception in the client workload means a programming error;
                    # we should log the exception and exit the client
                    await websocket.close()
                    traceback.print_exc()
                    os._exit(1)

            asyncio.create_task(send_result())