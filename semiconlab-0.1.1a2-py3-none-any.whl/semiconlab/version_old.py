# 2023 Xaveer Leijtens
# This file was copied and adapted from 'miniver': https://github.com/jbweston/miniver
# but the static version, write and archive options were stripped off.
# It will return the package version from a git label and will make it into a pep-440
# compliant version string.
# That is used as argument for poetry to build the package with the proper version.
#
# When this package is installed, this version can be retrieved (as for any of the
# installed packages) with the commands provided by the importlib package. This is used
# in __init__ to set the __version__ string.
#
# When used in a source package (within git) it can be used to retrieve the
# (git-generated) version.
#
#
import os
import re
import subprocess
from collections import namedtuple

Version = namedtuple("Version", ("release", "dev", "labels"))

package_root = os.path.dirname(os.path.realpath(__file__))


def get_version_from_git():

    # git describe --first-parent does not take into account tags from branches
    # that were merged-in. The '--long' flag gets us the 'dev' version and
    # git hash, '--always' returns the git hash even if there are no tags.
    for opts in [["--first-parent"], []]:
        try:
            p = subprocess.Popen(
                ["git", "describe", "--long", "--always"] + opts,
                cwd=package_root,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
        except OSError:
            return
        if p.wait() == 0:
            break
    else:
        return

    description = (
        p.communicate()[0]
        .decode()
        .strip("v")  # Tags can have a leading 'v', but the version should not
        .rstrip("\n")
        .rsplit("-", 2)  # Split the latest tag, commits since tag, and hash
    )

    try:
        release, dev, git = description
    except ValueError:  # No tags, only the git hash
        # prepend 'g' to match with format returned by 'git describe'
        git = "g{}".format(*description)
        release = "unknown"
        dev = None

    labels = []
    if dev == "0":
        dev = None
    else:
        labels.append(git)

    try:
        p = subprocess.Popen(["git", "diff", "--quiet"], cwd=package_root)
    except OSError:
        labels.append("confused")  # This should never happen.
    else:
        if p.wait() == 1:
            labels.append("dirty")

    return Version(release, dev, labels)


def pep440_format(version_info):
    release, dev, labels = version_info

    version_parts = [release]
    if dev:
        if release.endswith(("-dev", ".dev")):
            version_parts.append(dev)
        else:  # prefer PEP440 over strict adhesion to semver
            version_parts.append(f".dev{dev}")

    if labels:
        version_parts.append("+")
        version_parts.append(".".join(labels))

    return "".join(version_parts)


def get_version():
    return pep440_format(get_version_from_git())


def version_xyz(version):
    """Return just the first part of the version string: x.y.z, where x, y and z are
    positive integers.
    (copy of util.version_xyz, because this file will not be part of package)
    E.g:
        1.2.3.888af-dev would return 1.2.3
        4.5.6.anything would return 4.5.6
        4.5.6.7.anything would return 4.5.6
        4.5.anything would return 4.5
        4.anything would return 4
    """
    posint = r"(0|[1-9]\d*)"
    match = re.match(
        f"({posint}"  # First number
        f"(\\.{posint}){{0,2}})",  # zero, one or two following numbers separated by '.'
        version,
    )
    return match.group(0) if match else "*** unknown ***"


def run_poetry(sl_version):
    poetry_root = os.path.dirname(package_root)
    # Set the poetry version
    p = subprocess.Popen(
        ["poetry", "version", sl_version],
        cwd=poetry_root,
        # stdout=subprocess.PIPE,
        # stderr=subprocess.PIPE,
    )
    if p.wait() != 0:
        print("Error in poetry 1")
    # Build the whl and tar.gz packages with proper version.
    p = subprocess.Popen(
        ["poetry", "build"],
        cwd=poetry_root,
        # stdout=subprocess.PIPE,
        # stderr=subprocess.PIPE,
    )
    if p.wait() != 0:
        print("Error in poetry 2")
    # Reset the poetry version
    p = subprocess.Popen(
        ["poetry", "version", version_xyz(sl_version)],
        cwd=poetry_root,
        # stdout=subprocess.PIPE,
        # stderr=subprocess.PIPE,
    )
    if p.wait() != 0:
        print("Error in poetry 3")
