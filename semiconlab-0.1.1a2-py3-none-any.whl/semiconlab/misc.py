#
# (c) 2024 Xaveer Leijtens
#
# Photodiode template
#
from typing import Any

import nazca as nd
import nazca.geometries as geom
from nazca.cellcache_util import cellcache

import semiconlab as sl

__all__ = ["design", "marker_MLA_A", "marker_MLA_B", "sample", "wafer"]


@cellcache("marker_MLA_A", ["layer"])
def marker_MLA_A(layer: int | tuple | str = "Trench") -> nd.Cell:
    """Marker A is to go on the first layer. Marker B will be on the second.

    Args:
        layer (int|tuple|str): layer spec (default "Trench")

    Returns:
        nd.Cell: nazca cell containing marker A"""
    bar = [(0, -2), (40, -2), (40, -5), (120, -5), (120, 5), (40, 5), (40, 2), (0, 2)]
    with nd.Cell() as C:
        nd.Polygon(bar, layer=layer).put()
        nd.Polygon(bar, layer=layer).put(0, 0, 90)
        nd.Polygon(bar, layer=layer).put(0, 0, 180)
        nd.Polygon(bar, layer=layer).put(0, 0, 270)
    return C


@cellcache("marker_MLA_B", ["layer"])
def marker_MLA_B(layer: int | tuple | str = "Metal") -> nd.Cell:
    """Marker A is to go on the first layer. Marker B will be on the second.

    Args:
        layer (int|tuple|str): layer spec (default "Metal")

    Returns:
        nd.Cell: nazca cell containing marker B"""
    corner = [(0, 0), (30, 0), (30, 4), (4, 4), (4, 30), (0, 30)]
    with nd.Cell() as C:
        nd.Polygon(corner, layer=layer).put(-32.5, -32.5)
        nd.Polygon(corner, layer=layer).put(32.5, -32.5, 90)
        nd.Polygon(corner, layer=layer).put(32.5, 32.5, 180)
        nd.Polygon(corner, layer=layer).put(-32.5, 32.5, 270)
    return C


@nd.cellcache("wafer", ["size"])
def wafer(size: float = 100_000) -> nd.Cell:
    """Draw a wafer outline.

    Args:
        size (float): wafer size in µm (default 100_000 µm)

    Return:
        nd.Cell: nazca cell with proper size
    """
    with nd.Cell() as C:
        nd.bend(radius=size / 2, width=10, angle=360, layer="Documentation").put(
            size / 2, 0, 90
        )
    return C


@nd.cellcache("sample", ["w", "h", "edge"])
def sample(w: float = 18_000, h: float = 18_000, edge: float = 1_000) -> nd.Cell:
    """Draw a sample outline

    Args:
        w (float): sample width [mm]
        h (float): sample height [mm]
        edge (float): stay out zone (width of frame)

    Return:
        nd.Cell: nazca cell with proper size
    """
    frame = geom.frame(edge, (w - edge), (h - edge))
    x, y = w / 2 - 1200, h / 2 - 1200
    with nd.Cell() as C:
        marker_MLA_A().put(x, y)
        marker_MLA_A().put(x, -y)
        marker_MLA_A().put(-x, y)
        marker_MLA_A().put(-x, -y)
        marker_MLA_B().put(x, y)
        marker_MLA_B().put(x, -y)
        marker_MLA_B().put(-x, y)
        marker_MLA_B().put(-x, -y)
        nd.Polygon(frame, layer="Coating_DC").put(edge - w / 2, edge - h / 2)
    return C


@nd.cellcache("design", ["width", "height"])
def design(die: Any, width: float = 4600, height: float = 2000) -> nd.Cell:
    with nd.Cell() as C:
        Nw = 3
        Nh = 7
        for i in range(Nw):
            for j in range(Nh):
                if j == 3:  # Skip center row for cleaving
                    continue
                die.put((-(Nw - 1) / 2 + i) * width, (-(Nh - 1) / 2 + j) * height)
    return C


if __name__ == "__main__":
    wafer().put()
    w = 20_000
    h = 18_000
    Nw = 4
    Nh = [3, 5, 5, 3]
    print(sum(Nh))
    # Define a design cell. It has the chip boundary and electrical pads (if wanted).
    project = sl.DesignArea(name="Semicon Lab", height=2000)
    die = project.cell()

    for i in range(Nw):
        for j in range(Nh[i]):
            x = (-(Nw - 1) / 2 + i) * w
            y = (-(Nh[i] - 1) / 2 + j) * h
            sample(w, h).put(x, y)
            design(die, 4600, 2000).put(x, y)
    nd.export_gds()
