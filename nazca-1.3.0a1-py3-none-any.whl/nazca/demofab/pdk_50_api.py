# -----------------------------------------------------------------------
#
# Copyright (c) Bright Photonics B.V. 2016-2024
#
# -----------------------------------------------------------------------
# This PDK file is CONFIDENTIAL
#
# This file is part of a Nazca Design PDK for use with Nazca Design only.
# This file can only be used with a properly executed and valid
# Non-Disclosure Agreement (NDA) in place with the foundry or
# authorized broker. In addition an active subscription
# to the PDK from Bright Photonics B.V. shall be in place.
#
# If you have received this file in error, by mistake, or from a
# non-authorized source then delete this file and all copies immediately
# and notify the sender.
#
# This file can not be distributed or copied by the receiving party
# outside the scope of the NDA.
#
# This file is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# For more information please visit:
# https://www.brightphotonics.eu
# https://www.nazca-design.org
#
# For questions and/or comments:
# Email: nazca@brightphotonics.eu
#-----------------------------------------------------------------------
"""
API configuration
"""

from typing import Type, Optional

import nazca as nd
from nazca import Tables
import nazca.compact_models as cm
from . import BBfunctioncalls
from . import technology

def synchronize_tables() -> Type[Tables]:
    """Function to synchronize PDK tables to the api client.

    Returns:
        nd.Tables: PDK tables
    """
    return nd.Tables(tech=technology)


def synchronize_models() -> Type[cm.CompactModelLibrary]:
    """Function to syncrhonize Compact Models to the api clients.

    Returns:
        nd.CompactModelLibrary: Compact model library
    """
    demofab_models = cm.compact_model_library.technologies.get(technology, {})

    result = cm.CompactModelLibrary(technologies={technology: demofab_models})

    return result

def evaluate_compact_model(
        compact_model: cm.ModelInfo,
        parameters: Optional[dict]=None,
        instance_parameters: Optional[dict]=None,
        sweep: Optional[dict]=None,
) -> dict:
    compact_model.api = None  # set API to None to force local evaluation of the model
    result = cm.evaluate_compact_model(
        compact_model,
        parameters=parameters,
        instance_parameters=instance_parameters,
        sweep=sweep,
    )
    return result


initializer_functions = ["synchronize_tables", "synchronize_models"]


# mandatory functions and/or attributes:
restapi = [
    "synchronize_tables",
    "synchronize_models",
    "evaluate_compact_model",
    "technology",
    "pdk_version",
    "nazca_logo",
    "export_gds",
]

# pdk_20_technology add compact model functions
restapi += [
    "os_shallow",
    "os_deep",
]

# pdk_30_BB_library attributes
restapi += [
    "shallow",
    "deep",
    "metaldc",
    "metalrf",
]

# pdk_30_BB_library BBs
for bb in BBfunctioncalls:
    restapi.append(bb[:-2])  # remove ()

# pdk_40_project_template methods
restapi += [
    "pinlines",
    "unitcell",
    "apply_coating",
    "apply_cleavemarks",
    "cell_template",
]