# -----------------------------------------------------------------------
# This file is part of Nazca.
#
# Nazca is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or (at
# your option) any later version.
#
# Nazca is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with Nazca.  If not, see <http://www.gnu.org/licenses/>.
#
# 2017 (c)  Katarzyna Lawniczuk, Ronald Broeke, Xaveer Leijtens
# -----------------------------------------------------------------------
"""
A set of funtions to create polygon geometries for shapes like  box, taper,
arc, frame. When drawing waveguide structures do not use this module but
instead the interconnects module or the one level deeper mask_elements module.
"""

from typing import TypeAlias
from numpy import radians, sin, cos, tan, linspace, sign, multiply, sqrt
import numpy as np
from .clipper import grow_polygons

PointType: TypeAlias = tuple[float, float]
PolygonType: TypeAlias = list[PointType]


def box(length: float = 10, width: float = 7, grow: float = 0) -> PolygonType:
    """Return box polygon."""
    return [
        (0, 0.5 * width + grow),
        (length, 0.5 * width + grow),
        (length, -0.5 * width - grow),
        (0, -0.5 * width - grow),
    ]


def taper(length: float = 10, width1: float = 2, width2: float = 8, grow: float = 0) -> PolygonType:
    """Return taper polygon."""
    return [
        (0, 0.5 * width1 + grow),
        (length, 0.5 * width2 + grow),
        (length, -0.5 * width2 - grow),
        (0, -0.5 * width1 - grow),
    ]


def arc(radius: float = 5, width: float = 2, angle: float = 180, grow: float = 0, N: int = 20) -> PolygonType:
    """Return arc polygon."""

    u = linspace(0, angle, N)
    plus = sign(angle)
    p1 = [
        ((grow + radius) * sin(radians(abs(a))), plus * (radius - (grow + radius) * cos(radians(a)) - radius))
        for a in u
    ]
    p2 = [
        (
            (-width - grow + radius) * sin(radians(abs(a))),
            plus * (radius - (-width - grow + radius) * cos(radians(a)) - radius),
        )
        for a in u[::-1]
    ]
    return p1 + p2


def ring(radius: float = 5, width: float = 2, grow: float = 0, N: int = 20) -> PolygonType:
    return arc(radius, width, 360, grow, N)


def pie(radius: float = 5, angle: float = 310, N: int = 20) -> PolygonType:
    """Return arc polygon."""
    u = linspace(0, angle, N + 1)
    p1 = [(radius * sin(radians(a)), radius * cos(radians(a))) for a in u]
    if angle != 360:
        p1 = [(0, 0)] + p1 + [(0, 0)]
    return p1


def circle(radius: float = 5, N: int = 20) -> PolygonType:
    """Regular convex polygon approximation of a circle"""
    u = linspace(0, 360, N + 1)
    p1 = [(radius * sin(radians(a)), radius * cos(radians(a))) for a in u]
    return p1


def frame(sizew: float = 2, sizel: float = 10, sizeh: float = 10, grow: float = 0) -> PolygonType:
    """Return frame polygon with of size length, height and thickness width."""
    return [
        (-sizew, 0),
        (-sizew, -sizew),
        (sizel, -sizew),
        (sizel, sizeh),
        (-sizew, sizeh),
        (-sizew, 0),
        (0, 0),
        (0, sizeh - sizew),
        (sizel - sizew, sizeh - sizew),
        (sizel - sizew, 0),
    ]


def mid_pts(p1: PointType, p2: PointType, factor: float = 0) -> PointType:
    """Return point on the line between p1 and p2"""
    X = p1[0] + (p2[0] - p1[0]) * factor
    Y = p1[1] + (p2[1] - p1[1]) * factor
    return X, Y


def read_4positions(position: int = 1, pts: dict[str, PointType] | None = None, shift: PointType = (0, 0)) -> PolygonType:
    """Return 4 corner points based on position"""
    if pts is None:
        pts = {}
    Points = {
        1: pts["P1"],
        2: mid_pts(pts["P1"], pts["P4"], 0.5),
        3: pts["P4"],
        4: mid_pts(pts["P1"], pts["P2"], 0.5),
        5: mid_pts(mid_pts(pts["P1"], pts["P2"], 0.5), mid_pts(pts["P4"], pts["P3"], 0.5), 0.5),
        6: mid_pts(pts["P4"], pts["P3"], 0.5),
        7: pts["P2"],
        8: mid_pts(pts["P2"], pts["P3"], 0.5),
        9: pts["P3"],
    }

    new_pts = [(), (), (), ()]
    for i in range(0, 4):
        new_pts[i] = (
            pts["P" + str(i + 1)][0] - Points[position][0] + shift[0],
            pts["P" + str(i + 1)][1] - Points[position][1] + shift[1],
        )

    return new_pts


def trapezoid(length: float = 10, height: float = 4, angle1: float = 45, angle2: float = 45, position: int = 1, shift: PointType = (0, 0)) -> PolygonType:
    """Return trapezoid polygon."""
    x1 = height / tan(radians(angle1))
    x2 = height / tan(radians(angle2))

    pts = {"P1": (0, 0), "P2": (length, 0), "P3": (length - x2, height), "P4": (x1, height)}

    return read_4positions(position, pts, shift)


def tetragon(length: float = 5, height: float = 10, dx: float = 4, x: float = 10, position: int = 1, shift: PointType = (0, 0)) -> PolygonType:
    """Return tetragon polygon."""

    pts = {"P1": (0, 0), "P2": (length, 0), "P3": (length - dx, height), "P4": (length - dx - x, height)}

    return read_4positions(position, pts, shift)


def parallelogram2(length: float = 10, height: float = 5, angle: float = 45, position: int = 1, shift: PointType = (0, 0)) -> PolygonType:
    """Return parallelogram polygon.

    Args:
        length (float): length of bounding box of parallelogram
        height (float): height of parallelogram
        angle (float): side angle where 90 degrees gives a rectangle
        position (int): 1-9, position of origin
            3 6 9
            2 5 8
            1 4 7
        shift (point): (sx, sy) shift of origin

    Return:
        4 parallelogram coordinate points
    """
    x = height / tan(radians(angle))
    length = length - height * tan(radians(90 - angle))

    pts = {"P1": (0, 0), "P2": (length, 0), "P3": (x + length, height), "P4": (x, height)}

    return read_4positions(position, pts, shift)


def parallelogram(length: float = 10, height: float = 5, angle: float = 45, position: int = 1, shift: PointType = (0, 0)) -> PolygonType:
    """Return parallelogram polygon.

    Args:
        length (float): length of base
        height (float): height of parallelogram
        angle (float): side angle where 90 degrees gives a rectangle
        position (int): 1-9, position of origin
            3 6 9
            2 5 8
            1 4 7
        shift (point): (sx, sy) shift of origin

    Return:
        4 parallelogram coordinate points
    """
    x = height / tan(radians(angle))

    pts = {"P1": (0, 0), "P2": (length, 0), "P3": (x + length, height), "P4": (x, height)}

    return read_4positions(position, pts, shift)


def rhombus(length: float = 10, angle: float = 45, position: int = 1, shift: PointType = (0, 0)) -> PolygonType:
    """Return rhombus polygon."""
    x = length * cos(radians(angle))
    h = length * sin(radians(angle))

    pts = {"P1": (0, 0), "P2": (length, 0), "P3": (x + length, h), "P4": (x, h)}

    return read_4positions(position, pts, shift)


def square(length: float = 10, position: int = 1, shift: PointType = (0, 0)) -> PolygonType:
    """Return square polygon."""
    pts = {"P1": (0, 0), "P2": (length, 0), "P3": (length, length), "P4": (0, length)}

    return read_4positions(position, pts, shift)


def rectangle(length: float = 10, height: float = 5, position: int = 1, shift: PointType = (0, 0)) -> PolygonType:
    """Return rectangle polygon."""
    pts = {"P1": (0, 0), "P2": (length, 0), "P3": (length, height), "P4": (0, height)}

    return read_4positions(position, pts, shift)


def rounded_rect(length: float = 10, height: float = 7, position: int = 1, shift: PointType = (0, 0), shrink: float = 0.1, accuracy: float = 0.05) -> PolygonType:
    """Return rectangle polygon with rounded corners."""
    rect = rectangle(length, height, position, shift)
    shrink = min(height, length) * shrink
    try:
        rect = grow_polygons([rect], grow=-shrink)[0]
        rect = grow_polygons([rect], grow=shrink, accuracy=accuracy)[0]
    except NameError:
        print("Warning: No pyclipper: no rounding applied in call to 'rounded_rect'.")
    return rect


def monkey(width: float = 1000, height: float = 1000) -> PolygonType:
    """Return a polygon with the Nazca monkey.

    The width and height parameters define the size of the bounding box
    that will hold the polygon. The aspect ratio is not changed.
    """
    mk = [
        (214.32, 300.43),
        (221.051, 293.766),
        (226.582, 286.09),
        (231.301, 275.93),
        (234.508, 265.148),
        (238.848, 241.191),
        (239.543, 233.824),
        (239.223, 226.473),
        (237.723, 220.812),
        (234.883, 215.719),
        (229.719, 210.801),
        (223.566, 207.043),
        (214.949, 203),
        (205.832, 200.438),
        (193.523, 200.316),
        (181.492, 203.27),
        (169.98, 208.527),
        (159.418, 215.531),
        (141.684, 231.379),
        (126.027, 246.66),
        (118.734, 256.75),
        (113.387, 267.98),
        (110.238, 279.355),
        (108.102, 290.996),
        (106.406, 304.016),
        (107.164, 315.086),
        (110.367, 325.711),
        (118.102, 337.973),
        (126.094, 345.059),
        (135.461, 350.234),
        (154.137, 356.461),
        (168.098, 361.18),
        (179.93, 362.305),
        (191.871, 361.367),
        (222.434, 357.594),
        (229.531, 356.98),
        (236.395, 355.332),
        (238.598, 354.496),
        (240.922, 354.387),
        (242.996, 355.895),
        (244.129, 359.48),
        (245.828, 370.422),
        (249.602, 383.062),
        (259.223, 398.156),
        (263.184, 406.645),
        (263.688, 413.137),
        (262.805, 419.664),
        (260.203, 430.199),
        (258.578, 434.137),
        (255.535, 437.043),
        (251.375, 437.613),
        (247.148, 437.211),
        (243.602, 437.66),
        (240.543, 439.473),
        (239.027, 441.906),
        (238.656, 444.758),
        (239.535, 447.52),
        (241.488, 449.66),
        (246.582, 450.98),
        (252.43, 449.285),
        (254.402, 448.234),
        (256.535, 447.609),
        (259.574, 448.41),
        (261.871, 450.605),
        (263.898, 453.406),
        (265.254, 454.465),
        (266.926, 454.82),
        (268.301, 454.281),
        (269.121, 453.059),
        (268.848, 451.023),
        (267.492, 449.441),
        (264.895, 447.66),
        (262.617, 445.512),
        (262.141, 444.277),
        (262.484, 443.027),
        (263.211, 442.57),
        (264.07, 442.527),
        (265.637, 443.246),
        (269.41, 446.266),
        (271.043, 446.898),
        (271.914, 446.785),
        (272.617, 446.266),
        (272.891, 445.113),
        (272.43, 444),
        (270.16, 442.371),
        (267.523, 441.359),
        (266.164, 440.34),
        (265.848, 439.547),
        (266.012, 438.719),
        (266.492, 438.254),
        (267.129, 438.039),
        (268.465, 438.152),
        (273.938, 440.039),
        (275.973, 440.301),
        (276.926, 439.918),
        (277.523, 439.098),
        (277.555, 438.355),
        (277.281, 437.664),
        (276.203, 436.645),
        (272.387, 435.824),
        (270.453, 436.297),
        (269.469, 436.242),
        (268.656, 435.699),
        (268.375, 434.578),
        (268.656, 433.438),
        (272.805, 423.816),
        (274.664, 417.137),
        (275.445, 410.23),
        (275.34, 403.934),
        (274.125, 397.777),
        (268.145, 386.848),
        (263.672, 380.84),
        (259.871, 374.441),
        (257.82, 367.977),
        (256.805, 361.234),
        (255.941, 354.348),
        (253.734, 347.895),
        (252.934, 346.027),
        (253.113, 344.816),
        (253.734, 343.758),
        (255.469, 342.023),
        (260.508, 337.043),
        (264.676, 331.352),
        (265.543, 329.961),
        (266.809, 328.949),
        (268.102, 328.809),
        (269.344, 329.219),
        (272.145, 331.75),
        (282.363, 344.281),
        (290.688, 354.562),
        (298.691, 365.77),
        (304.672, 376.355),
        (305.879, 384.59),
        (305.094, 392.984),
        (300.293, 413.395),
        (296.824, 424.734),
        (295.355, 431.539),
        (295.309, 432.672),
        (294.824, 433.672),
        (294.25, 433.992),
        (293.602, 434.082),
        (292.289, 433.941),
        (287.484, 434.605),
        (282.418, 436.742),
        (280.344, 439.781),
        (279.617, 443.41),
        (279.883, 447.414),
        (280.27, 448.438),
        (281.082, 449.148),
        (281.777, 449.211),
        (282.445, 448.996),
        (283.617, 448.215),
        (289.219, 446.348),
        (297.09, 446.746),
        (302.137, 446.43),
        (307.098, 447.148),
        (308.898, 448.066),
        (310.832, 448.613),
        (311.945, 448.379),
        (312.699, 447.547),
        (312.652, 446.398),
        (312.031, 445.414),
        (310.258, 443.91),
        (308.031, 443.277),
        (306.559, 443.383),
        (305.094, 443.277),
        (304.102, 442.582),
        (303.859, 442.02),
        (303.895, 441.41),
        (304.477, 440.676),
        (305.363, 440.344),
        (307.176, 440.391),
        (308.965, 440.742),
        (312.832, 440.211),
        (313.609, 439.559),
        (313.898, 438.609),
        (313.582, 437.895),
        (312.965, 437.406),
        (311.105, 437),
        (309.23, 437.406),
        (307.496, 438.074),
        (306.117, 438.078),
        (305.559, 437.668),
        (305.363, 437.008),
        (305.574, 436.488),
        (306.008, 436.125),
        (307.098, 435.809),
        (310.566, 435.539),
        (313.234, 436.207),
        (315.387, 436.43),
        (316.422, 436.113),
        (317.234, 435.406),
        (317.559, 434.559),
        (317.367, 433.672),
        (316.355, 432.945),
        (315.102, 432.738),
        (312.547, 432.457),
        (310.031, 432.871),
        (307.914, 434.039),
        (306.727, 434.082),
        (306.207, 433.785),
        (305.895, 433.273),
        (305.891, 432.703),
        (306.113, 432.172),
        (306.828, 431.27),
        (308.496, 427.895),
        (309.363, 424.199),
        (315.77, 407.793),
        (319.371, 391.785),
        (321.238, 380.445),
        (320.578, 373.332),
        (318.57, 366.438),
        (314.43, 357.336),
        (308.965, 348.961),
        (299.895, 338.289),
        (291.266, 327.684),
        (286.527, 322.875),
        (281.082, 318.945),
        (279.938, 318.238),
        (279.082, 317.211),
        (278.918, 316.004),
        (279.215, 314.809),
        (280.684, 311.875),
        (284.285, 306.672),
        (298.691, 291.465),
        (311.633, 279.191),
        (318.969, 273.32),
        (326.172, 270.652),
        (335.379, 270.254),
        (347.918, 272.652),
        (363.395, 279.324),
        (368.863, 281.727),
        (372.73, 283.461),
        (374.332, 284.926),
        (374.715, 285.965),
        (374.598, 287.062),
        (373.918, 288.035),
        (373, 288.797),
        (365.66, 296.531),
        (357.391, 306.273),
        (348.32, 318.543),
        (342.848, 330.152),
        (340.848, 343.359),
        (340.32, 346.633),
        (340.715, 349.895),
        (342.047, 352.027),
        (344.984, 355.363),
        (362.191, 370.707),
        (373.934, 381.777),
        (380.602, 386.715),
        (383.418, 388.805),
        (385.406, 391.648),
        (386.207, 396.453),
        (387.805, 399.121),
        (392.074, 402.324),
        (399.414, 405.523),
        (404.883, 405.523),
        (406.52, 405.191),
        (407.223, 404.746),
        (407.684, 404.059),
        (407.551, 402.723),
        (406.898, 401.988),
        (406.02, 401.539),
        (404.082, 401.121),
        (398.613, 399.789),
        (396.453, 399.43),
        (394.609, 398.32),
        (394.227, 397.488),
        (394.344, 396.586),
        (395.27, 395.828),
        (396.477, 395.652),
        (404.215, 396.32),
        (412.086, 393.383),
        (423.023, 389.117),
        (428.496, 386.312),
        (429.797, 385.422),
        (430.496, 384.047),
        (430.305, 383.199),
        (429.695, 382.578),
        (428.195, 382.418),
        (426.762, 382.98),
        (422.891, 384.715),
        (416.621, 387.113),
        (405.414, 390.984),
        (400.613, 392.449),
        (399.406, 393.07),
        (398.078, 393.25),
        (397.387, 392.926),
        (396.93, 392.309),
        (396.836, 391.551),
        (397.145, 390.852),
        (398.066, 390.273),
        (399.145, 390.051),
        (407.016, 387.113),
        (414.355, 383.512),
        (420.09, 378.977),
        (423.293, 372.84),
        (424.105, 371.035),
        (424.492, 369.105),
        (424.344, 368.223),
        (423.824, 367.504),
        (423.176, 367.242),
        (422.473, 367.289),
        (421.289, 368.039),
        (419.824, 370.438),
        (416.488, 375.242),
        (410.086, 380.578),
        (402.215, 384.578),
        (398.879, 386.18),
        (397.867, 386.469),
        (397.34, 386.426),
        (396.879, 386.18),
        (396.594, 385.762),
        (396.516, 385.258),
        (396.879, 384.312),
        (397.797, 383.531),
        (398.879, 382.98),
        (403.281, 380.176),
        (409.02, 376.043),
        (411.844, 374.246),
        (414.219, 371.906),
        (415.289, 369.371),
        (415.406, 368.551),
        (415.152, 367.77),
        (414.488, 367.371),
        (413.75, 367.367),
        (413.055, 367.621),
        (411.82, 368.438),
        (407.551, 370.57),
        (401.281, 375.375),
        (397.891, 377.539),
        (395.012, 380.312),
        (394.078, 381.91),
        (393.156, 382.867),
        (391.941, 383.379),
        (390.68, 383.277),
        (389.539, 382.711),
        (387.141, 380.445),
        (381.668, 376.844),
        (376.867, 371.105),
        (370.863, 364.168),
        (358.992, 354.695),
        (352.723, 350.16),
        (350.719, 346.824),
        (350.719, 343.09),
        (352.188, 334.02),
        (356.055, 325.348),
        (361.926, 317.078),
        (369.129, 306.27),
        (378.066, 295.332),
        (383.539, 288.527),
        (384.461, 287.566),
        (385.672, 287.062),
        (386.594, 287.238),
        (387.406, 287.727),
        (388.875, 288.93),
        (394.477, 290.664),
        (402.883, 289.598),
        (410.887, 284.395),
        (415.953, 278.922),
        (418.621, 274.387),
        (419.023, 271.051),
        (419.676, 269.68),
        (420.281, 269.211),
        (421.023, 269.051),
        (422.039, 269.43),
        (422.891, 270.117),
        (428.207, 272.562),
        (433.965, 273.855),
        (440.824, 276.84),
        (447.172, 280.926),
        (454.734, 286.246),
        (461.578, 292.398),
        (465.727, 297.934),
        (468.781, 304.137),
        (470.352, 309.582),
        (470.785, 315.211),
        (468.648, 324.016),
        (463.578, 332.152),
        (456.645, 341.355),
        (455.766, 342.68),
        (454.508, 343.625),
        (452.902, 343.613),
        (451.574, 342.691),
        (450.105, 340.289),
        (447.305, 337.754),
        (442.453, 335.062),
        (437.031, 334.02),
        (431.676, 335.43),
        (426.895, 338.289),
        (418.758, 343.891),
        (416.691, 345.395),
        (415.289, 347.492),
        (415.219, 348.934),
        (415.953, 350.16),
        (416.969, 350.625),
        (418.09, 350.695),
        (420.891, 349.895),
        (424.094, 346.691),
        (431.031, 342.691),
        (437.566, 341.625),
        (444.77, 342.691),
        (447.703, 343.758),
        (448.238, 344.199),
        (448.504, 344.824),
        (448.367, 345.371),
        (447.973, 345.781),
        (446.906, 346.16),
        (442.234, 346.293),
        (434.633, 347.094),
        (427.16, 349.762),
        (421.559, 352.43),
        (420.223, 354.031),
        (419.801, 355.023),
        (419.82, 355.566),
        (420.09, 356.031),
        (420.723, 356.312),
        (421.426, 356.297),
        (424.094, 355.633),
        (431.965, 352.961),
        (443.57, 349.895),
        (444.77, 349.801),
        (445.836, 350.293),
        (446.121, 350.859),
        (446.105, 351.496),
        (445.633, 352.273),
        (444.902, 352.828),
        (441.035, 354.43),
        (427.695, 357.766),
        (422.359, 358.965),
        (420.219, 359.281),
        (419.316, 359.863),
        (418.891, 360.832),
        (419.148, 361.75),
        (419.824, 362.434),
        (422.227, 363.367),
        (425.16, 364.035),
        (429.062, 363.477),
        (432.762, 362.035),
        (441.168, 358.832),
        (447.039, 354.965),
        (447.863, 354.551),
        (448.773, 354.562),
        (449.18, 354.863),
        (449.438, 355.297),
        (449.574, 356.297),
        (448.906, 358.699),
        (445.891, 361.449),
        (442.234, 363.367),
        (434.898, 368.973),
        (433.746, 369.75),
        (433.32, 370.301),
        (433.164, 370.973),
        (433.594, 371.91),
        (434.496, 372.441),
        (436.246, 372.578),
        (437.965, 372.172),
        (445.172, 368.973),
        (451.973, 363.77),
        (455.441, 358.832),
        (456.242, 356.832),
        (456.531, 356.117),
        (456.809, 355.852),
        (457.176, 355.766),
        (457.465, 355.875),
        (457.672, 356.105),
        (457.844, 356.699),
        (457.445, 359.234),
        (457.711, 365.102),
        (458.523, 366.582),
        (459.977, 367.371),
        (461.133, 367.121),
        (462.113, 366.438),
        (464.781, 362.566),
        (465.449, 356.699),
        (465.582, 351.895),
        (464.914, 346.691),
        (467.184, 342.023),
        (471.719, 336.422),
        (475.379, 329.703),
        (478.922, 322.012),
        (481.324, 308.406),
        (481.77, 302.496),
        (481.188, 296.668),
        (476.922, 287.594),
        (473.02, 280.773),
        (467.98, 274.922),
        (462.434, 271.734),
        (456.375, 269.453),
        (443.168, 264.914),
        (436.711, 263.66),
        (430.496, 261.715),
        (426.895, 260.246),
        (424.758, 260.289),
        (422.625, 260.246),
        (421.656, 259.824),
        (421.309, 259.422),
        (421.156, 258.914),
        (421.43, 258.117),
        (422.09, 257.578),
        (424.594, 257.156),
        (427.16, 257.312),
        (429.027, 256.91),
        (429.789, 256.414),
        (430.031, 256.027),
        (430.094, 255.578),
        (429.871, 255.051),
        (429.457, 254.645),
        (428.629, 253.844),
        (428.441, 252.852),
        (428.629, 251.844),
        (429.16, 250.242),
        (429.648, 249.723),
        (430.094, 249.176),
        (430.215, 248.176),
        (429.695, 247.305),
        (428.758, 246.789),
        (427.695, 246.641),
        (425.16, 247.039),
        (422.09, 248.105),
        (421.219, 248.285),
        (420.355, 248.105),
        (419.789, 247.516),
        (419.422, 246.773),
        (415.289, 240.902),
        (411.418, 235.168),
        (407.18, 232.145),
        (402.082, 230.898),
        (393.008, 232.5),
        (383.539, 237.434),
        (379, 240.102),
        (375.398, 243.57),
        (371.398, 249.977),
        (370.582, 253.012),
        (369.262, 255.844),
        (366.727, 257.578),
        (364.461, 257.711),
        (363.105, 257.402),
        (362.414, 257.418),
        (361.793, 257.711),
        (361.379, 258.336),
        (361.125, 259.047),
        (360.742, 260.02),
        (360.727, 261.047),
        (361.281, 261.699),
        (362.09, 262.016),
        (363.793, 262.383),
        (364.906, 263.188),
        (365.93, 264.117),
        (367.145, 264.652),
        (368.461, 264.516),
        (369.59, 263.797),
        (370.207, 263.535),
        (370.863, 263.582),
        (371.457, 264.152),
        (371.797, 264.918),
        (375.133, 269.051),
        (378.203, 272.652),
        (378.941, 273.898),
        (379, 275.32),
        (378.465, 276.062),
        (377.668, 276.523),
        (375.668, 276.656),
        (374.137, 275.848),
        (372.863, 274.656),
        (364.594, 267.984),
        (349.52, 259.047),
        (342.449, 256.379),
        (329.508, 255.844),
        (324.172, 255.578),
        (319.238, 258.512),
        (302.293, 271.719),
        (285.086, 287.594),
        (273.879, 298.266),
        (263.207, 314.141),
        (247.332, 334.152),
        (238.527, 345.094),
        (237.457, 346.051),
        (236.125, 346.559),
        (234.5, 346.133),
        (233.059, 345.227),
        (229.188, 343.625),
        (218.781, 338.156),
        (211.766, 336.777),
        (204.508, 336.82),
        (170.09, 337.355),
        (157.562, 337.387),
        (145.145, 336.152),
        (138.977, 334.484),
        (133.406, 331.484),
        (129.102, 327.012),
        (125.934, 321.613),
        (121.398, 308.004),
        (119.262, 289.598),
        (119.922, 278.371),
        (122.465, 267.449),
        (125.52, 260.352),
        (129.668, 253.844),
        (141.41, 241.57),
        (155.016, 228.762),
        (162.98, 223.816),
        (171.559, 219.957),
        (188.102, 214.621),
        (204.375, 212.223),
        (212.676, 213.086),
        (220.117, 216.758),
        (224.352, 221.973),
        (227.055, 228.23),
        (229.055, 236.129),
        (229.723, 244.238),
        (227.32, 260.246),
        (224.438, 270.672),
        (220.117, 280.523),
        (214.992, 287.832),
        (208.91, 294.398),
        (202.367, 300.277),
        (195.039, 305.07),
        (188.547, 307.652),
        (181.695, 309.074),
        (172.797, 309.25),
        (164.086, 307.473),
        (156.613, 304.039),
        (149.945, 299.199),
        (144.324, 293.312),
        (140.074, 286.395),
        (137.566, 277.762),
        (137.672, 268.785),
        (140.898, 259.328),
        (146.746, 251.176),
        (153.805, 245.062),
        (161.688, 239.969),
        (173.055, 233.965),
        (185.164, 229.832),
        (192.988, 228.941),
        (200.641, 230.633),
        (207.18, 236.074),
        (211.047, 243.703),
        (212.688, 253.242),
        (211.848, 262.914),
        (208.316, 273.168),
        (202.242, 282.125),
        (195.508, 287.969),
        (187.566, 291.996),
        (176.48, 293.926),
        (165.422, 291.996),
        (157.547, 287.418),
        (152.348, 279.992),
        (151.363, 275.195),
        (151.691, 270.293),
        (155.551, 261.312),
        (162.461, 253.977),
        (171.023, 248.508),
        (176.273, 246.176),
        (181.828, 244.871),
        (187.551, 245.23),
        (192.637, 247.707),
        (196.684, 253.758),
        (197.438, 261.047),
        (195.156, 269.141),
        (190.234, 275.988),
        (183.277, 280.586),
        (179.18, 281.473),
        (175.027, 281.059),
        (169.836, 277.984),
        (166.754, 272.785),
        (166.484, 266.422),
        (169.422, 260.781),
        (174.836, 257.5),
        (181.164, 257.578),
        (185.164, 260.246),
        (186.098, 262.879),
        (185.434, 265.582),
        (182.496, 268.785),
        (181.77, 269.969),
        (180.906, 271.055),
        (179.645, 271.574),
        (178.977, 271.406),
        (178.496, 270.918),
        (178.375, 270.211),
        (178.578, 269.516),
        (179.297, 268.25),
        (179.551, 266.121),
        (178.496, 264.25),
        (176.605, 263.301),
        (174.492, 263.449),
        (172.324, 264.988),
        (171.293, 267.449),
        (172.359, 271.719),
        (176.359, 274.656),
        (180.105, 274.789),
        (183.562, 273.32),
        (186.527, 270.484),
        (188.633, 266.918),
        (190.25, 261.961),
        (190.5, 256.777),
        (189.996, 254.562),
        (188.633, 252.777),
        (185.699, 251.977),
        (177.695, 252.508),
        (171.941, 253.996),
        (166.754, 256.777),
        (162.277, 262.098),
        (160.352, 268.785),
        (160.961, 274.598),
        (163.285, 279.992),
        (166.629, 284.184),
        (171.023, 287.195),
        (176.672, 288.562),
        (182.496, 287.996),
        (189.289, 285.02),
        (195.039, 280.258),
        (200.102, 273.531),
        (203.574, 265.852),
        (205.176, 257.402),
        (203.844, 249.039),
        (200.812, 244.047),
        (196.371, 240.238),
        (187.285, 237.211),
        (177.695, 237.836),
        (167.336, 241.816),
        (158.219, 248.242),
        (149.887, 257.52),
        (146.855, 262.926),
        (144.879, 268.785),
        (144.609, 278.391),
        (147.848, 286.121),
        (153.414, 292.531),
        (161.141, 297.977),
        (169.957, 301.336),
        (180.102, 302.117),
        (189.969, 299.734),
        (200.172, 293),
        (208.379, 283.727),
        (215.465, 272.316),
        (219.852, 259.715),
        (220.586, 250.707),
        (219.051, 241.836),
        (216.246, 235.551),
        (212.379, 229.832),
        (208.09, 225.246),
        (202.773, 222.094),
        (197.363, 221.266),
        (191.879, 221.996),
        (181.43, 225.562),
        (163.285, 231.699),
        (153.246, 237.535),
        (144.879, 245.574),
        (136.074, 259.715),
        (131.305, 269.531),
        (128.867, 279.992),
        (129.281, 285.758),
        (130.891, 291.324),
        (136.871, 301.336),
        (145.352, 309.43),
        (155.281, 315.742),
        (164.215, 319.719),
        (173.691, 321.879),
        (181.477, 321.707),
        (188.902, 319.477),
        (195.551, 315.203),
        (201.707, 310.141),
    ]
    # Coordinates from inkscape ".ps" export
    mk = multiply(mk, [(1, -1)])  # upside-down
    minxy = np.min(mk, 0)
    maxxy = np.max(mk, 0)
    center = np.multiply((maxxy - minxy), 0.5) + minxy  # set image center
    scale = np.min(np.divide((width, height), maxxy - minxy))
    mk = np.multiply(mk - center, scale)
    return mk


#
# Parameterized MMI polygon waveguide outline
#
def MMI_iopoly(wmmi=10, o=None, wio=None, angle=53):
    """MMI_iopoly: helper routine which generates one side of an MMI
    outline polygon, from bottom to top. This side needs to be joined with
    the other side."""
    if o is None or len(o) == 0:  # no waveguides
        poly = [(0, -wmmi / 2), (0, wmmi / 2)]
    else:
        poly = []
        nw = len(o)  # number of waveguides
        if not isinstance(wio, list):
            wio = nw * [wio]
        # Make sure the waveguides are ordered by offset (will become tuples).
        o, wio = zip(*sorted(zip(o, wio)))
        # Use two extra input waveguides, which are mirror images
        # of the lower and upper waveguides.
        o = (-wmmi - o[0],) + o + (wmmi - o[-1],)
        wio = (wio[0],) + wio + (wio[-1],)
        for n in range(nw + 1):
            # y-coordinate of top/bottom of waveguide n/n+1
            y0 = o[n] + wio[n] / 2
            y1 = o[n + 1] - wio[n + 1] / 2
            d = (y1 - y0) / 2
            if d > 0:  # Non-overlapping waveguides
                s = max(0, d / tan(radians(angle)))
                if -wmmi / 2 < y0 < wmmi / 2:
                    poly.append((0, y0))
                poly.append((s, (y0 + y1) / 2))
                if -wmmi / 2 < y1 < wmmi / 2:
                    poly.append((0, y1))
            else:
                poly.append((0, (y0 + y1) / 2))
    return poly


def MMI_poly(wmmi=10, lmmi=100, wi=None, wo=None, oi=None, oo=None, angle=53):
    """MMI layout polygon.

    Returns an MMI polygon outline with angled corners for reduced
    reflections. The input and output waveguides either have all the same
    width (in which case wi and wo are a single float value) or they are
    specified in a list or tuple of length equal to len(oi) and len(oo).

    Parameters:
        wmmi (float): width of the MMI
        lmmi (float): length of the MMI
        wi (float|list): input waveguide width(s)
        wo (float|list): output waveguide width(s)
        oi (list): input waveguide offsets from center
        oo (list): output waveguide offsets from center
        angle (float): corner cut angle (degrees) where 90° is a standard MMI

    Returns:
        poly (list): list of points of the MMI polygon.
    """

    pi = MMI_iopoly(wmmi=wmmi, o=oi, wio=wi, angle=angle)
    po = MMI_iopoly(wmmi=wmmi, o=oo, wio=wo, angle=angle)
    po = [(lmmi - x, y) for (x, y) in reversed(po)]

    return list(pi) + po


def transform(
    points: PolygonType,
    center: tuple[float, float, float] = (0, 0, 0),
    scale: float = 1.0,
    flipx: bool = False,
    flipy: bool = False,
    move: tuple[float, float, float] = (0, 0, 0),
) -> PolygonType:
    """Transform a polygon by translation, rotation, scaling and/or flipping.

    The transformation first relocates the origin to the point in the
    <center> position. Subsequently, the scale, rotate and flips are applied,
    where order does not matter.
    Finally, a (x, y) translation is performed.

    Args:
        polygon (list of (float, float)): points (x, y)
        center ((float, float, float)): (x, y, a) as  center of scaling
            (default = (0, 0, 0))
        scale (float): scaling factor (default = 1.0)
        flipx (bool): flip x coordinate x -> -x (default = False)
        flipy (bool): flip y coordinate y -> -y (default = False)
        move ((float, float, float)): (x, y, a) translation after any scaling
            and/or flipping (default = (0, 0, 0)).

    Returns:
        (list of (float, float)): transformed polygon points
    """
    dx, dy, da = center
    x0, y0, a0 = move
    fu, fv = 1, 1
    if flipx:
        fu = -1
    if flipy:
        fv = -1
    a = radians(-da + a0)
    xy = []
    for u, v in points:
        u = (u - dx) * fu
        v = (v - dy) * fv
        xy.append((x0 + scale * (cos(a) * u - sin(a) * v), y0 + scale * (sin(a) * u + cos(a) * v)))
    return xy


def chevron(width: float = 10.0, length: float = 100, strip_length: float = 40.0) -> PolygonType:
    """Calculate the positions of a chevron marker.

    This is a V-shaped polygon with a flattened tip.
    Four can be used to make a 'crosshair' shape by revolving it about the origin.

    Args:
        width (float): Stroke width of the chevron. Defaults to 10.0.
        length (float): Outer length of the diagonal bar. Defaults to 100.
        strip_length (float): Outer length of the horizontal/vertical segments that stick out. Defaults to 40.0.

    Returns:
        PolygonType: polygon points (x,y).
    """

    # Go around in right-handed fashion
    points = []
    x = 0.5 * sqrt(2) * length
    y = 0.0
    points.append((x, y))
    # Shift right
    x += strip_length
    points.append((x, y))
    # Shift up
    y += width
    points.append((x, y))
    # Jump
    x = (sqrt(2) - 1) * width + 0.5 * sqrt(2) * length
    y = width
    points.append((x, y))
    # Jump
    x = width
    y = (sqrt(2) - 1) * width + 0.5 * sqrt(2) * length
    points.append((x, y))
    # Jump up
    y = 0.5 * sqrt(2) * length + strip_length
    points.append((x, y))
    # Shift left
    x -= width
    points.append((x, y))
    # Shift down
    y -= strip_length
    points.append((x, y))

    return points


def t_junction(
    width_cross: float = 10, width_bar: float = 20, strt_len: float = 5, neck_length: float = 6
) -> PolygonType:
    """Make T-junction shaped polygon

    Can be useful for combined grounds in metal routing.
    The pins can be placed at:
        - (0, 0, 180)
        - (strt_len + neck_length + width_bar / 2, width_cross / 2 + neck_length + strt_len, 90)
        - (strt_len + neck_length + width_bar / 2, -width_cross / 2 - neck_length - strt_len, -90)

    Args:
        width_cross (float): width of left stub. Defaults to 10.
        width_bar (float): width of top and bottom stubs. Defaults to 20.
        strt_len (float): straight segment length before bending. Defaults to 5.
        neck_length (float): straight length hidden by necking, set to zero for a sharp T. Defaults to 6.

    Returns:
        PolygonType: polygon points (x,y).
    """
    points = [
        (0, width_cross / 2),
        (strt_len, width_cross / 2),
        (strt_len + neck_length, width_cross / 2 + neck_length),
        (strt_len + neck_length, width_cross / 2 + neck_length + strt_len),
        (strt_len + neck_length + width_bar, width_cross / 2 + neck_length + strt_len),
        (strt_len + neck_length + width_bar, -width_cross / 2 - neck_length - strt_len),
        (strt_len + neck_length, -width_cross / 2 - neck_length - strt_len),
        (strt_len + neck_length, -width_cross / 2 - neck_length),
        (strt_len, -width_cross / 2),
        (0, -width_cross / 2),
    ]
    return points


def x_junction(
    width_cross: float = 10, width_bar: float = 20, strt_len: float = 5, neck_length: float = 6
) -> PolygonType:
    """Make X-junction shaped polygon

    Can be useful for combined grounds in metal routing.
    The pins can be placed at:
        - (0, 0, 180)
        - (strt_len + neck_length + width_bar / 2, width_cross / 2 + neck_length + strt_len, 90)
        - (strt_len + neck_length + width_bar / 2, -width_cross / 2 - neck_length - strt_len, -90)
        - (2*strt_len + 2*neck_length + width_bar, 0, 0)

    Args:
        width_cross (float): width of left stub. Defaults to 10.
        width_bar (float): width of top and bottom stubs. Defaults to 20.
        strt_len (float): straight segment length before bending. Defaults to 5.
        neck_length (float): straight length hidden by necking, set to zero for a sharp T. Defaults to 6.

    Returns:
        PolygonType: polygon points (x,y).
    """
    points = [
        (0, width_cross / 2),
        (strt_len, width_cross / 2),
        (strt_len + neck_length, width_cross / 2 + neck_length),
        (strt_len + neck_length, width_cross / 2 + neck_length + strt_len),
        (strt_len + neck_length + width_bar, width_cross / 2 + neck_length + strt_len),
        (strt_len + neck_length + width_bar, width_cross / 2 + neck_length),
        (strt_len + 2 * neck_length + width_bar, width_cross / 2),
        (2 * strt_len + 2 * neck_length + width_bar, width_cross / 2),
        (2 * strt_len + 2 * neck_length + width_bar, -width_cross / 2),
        (strt_len + 2 * neck_length + width_bar, -width_cross / 2),
        (strt_len + neck_length + width_bar, -width_cross / 2 - neck_length),
        (strt_len + neck_length + width_bar, -width_cross / 2 - neck_length - strt_len),
        (strt_len + neck_length, -width_cross / 2 - neck_length - strt_len),
        (strt_len + neck_length, -width_cross / 2 - neck_length),
        (strt_len, -width_cross / 2),
        (0, -width_cross / 2),
    ]
    return points


def triangle_cut_corners(size: float = 100, remove_tip_size: float = 10.0) -> PolygonType:
    """Triangle with cut corners

    Can be useful as fiducial, as some foundries do not allow the sharp 60 degree corners.
    The center node is at (0.25 * sqrt(3) * size, 0, 0)

    Args:
        size (float): Length of the triangle legs (before cutting the corners). Defaults to 100.
        remove_tip_size (float): Tip length to be removed. Defaults to 10.0.

    Returns:
        PolygonType: polygon points (x,y).
    """
    tipx = remove_tip_size * 0.5 * sqrt(3)
    tipy = remove_tip_size * 0.5
    points = [
        (0, -size / 2 + 2 * tipy),
        (tipx, -size / 2 + tipy),
        (0.5 * sqrt(3) * size - tipx, -tipy),
        (0.5 * sqrt(3) * size - tipx, tipy),
        (tipx, size / 2 - tipy),
        (0, size / 2 - 2 * tipy),
    ]
    return points


def cross(width: float = 4.0, length: float = 10.0, height: float | None = None) -> PolygonType:
    """Cross/plus symbol"""
    if height is None:
        height = length
    half_width = 0.5 * width
    half_length = 0.5 * length
    half_height = 0.5 * height
    cross = [
        (half_length, half_width),
        (half_width, half_width),
        (half_width, half_height),
        (-half_width, half_height),
        (-half_width, half_width),
        (-half_length, half_width),
        (-half_length, -half_width),
        (-half_width, -half_width),
        (-half_width, -half_height),
        (half_width, -half_height),
        (half_width, -half_width),
        (half_length, -half_width),
    ]
    return cross


def star(inner_radius: float = 8, outer_radius: float = 12, N: int = 8) -> PolygonType:
    """Generate star shape

    Corners lie on two circles with inner/outer radius.

    Args:
        inner_radius (float): Defaults to 8.
        outer_radius (float): Defaults to 12.
        N (int, optional): number of tips. Defaults to 8.

    Returns:
        PolygonType: polygon points (x,y).
    """
    u = linspace(0, 2 * np.pi, 2 * N, endpoint=False)
    poly = []
    radius = outer_radius
    for a in u:
        radius = inner_radius if radius == outer_radius else outer_radius
        poly.append((radius * cos(a), radius * sin(a)))
    return poly


def ellipse(semi_major: float = 6, semi_minor: float = 4, N: int = 30) -> PolygonType:
    """Generate ellipse shape

    Args:
        semi_major (float): Defaults to 6.
        semi_minor (float): Defaults to 4.
        N (int): Number of vertices. Defaults to 30.

    Returns:
        PolygonType: polygon points (x,y).
    """
    u = linspace(0, 2 * np.pi, N, endpoint=False)
    p1 = [(semi_major * cos(a), semi_minor * sin(a)) for a in u]
    return p1


def flat_circle(radius: float = 10.0, sagitta: float = 2.0, N: int = 30) -> PolygonType:
    """Generate circle with a flat side

    Can be used as a fiducial, or to illustrate the perimeter of a wafer.

    Args:
        radius (float): radius of the circle
        sagitta (float): distance from the chord to the original circle perimeter.
        N (int): Number of points. Defaults to 30.

    Returns:
        PolygonType: flattened circle polygon.
    """
    assert 0 <= sagitta < radius
    reduced_radius = radius - sagitta
    angle = np.arccos(reduced_radius / radius)
    u = linspace(angle, 2 * np.pi - angle, N)
    p1 = [(radius * cos(a), radius * sin(a)) for a in u]
    return p1


def notch_circle(
    radius: float = 10.0,
    notch_depth: float = 2.0,
    notch_radius: float = 1.0,
    notch_angle: float = 90,
    N: int = 30,
) -> PolygonType:
    """Generate a circle with a notch

    The base of the notch follows the arc of a smaller circle

    Args:
        radius (float): Radius of the circle. Defaults to 10.0.
        notch_depth (float): Distance from the bottom of the notch to where the
            original circle perimeter used to be. Defaults to 2.0.
        notch_radius (float): Radius of the notch. Defaults to 1.0.
        notch_angle (float): Opening angle of the notch. Defaults to 90.
        N (int): Number of points. Defaults to 30.

    Returns:
        PolygonType: _description_
    """
    notch_angle_rad = np.deg2rad(notch_angle)
    half_angle = 0.5 * notch_angle_rad
    # notch depth when extrapolating to where the sides of the notch intersect.
    full_depth = notch_depth + notch_radius * (1 / sin(half_angle) - 1)
    reduced_radius = radius - full_depth

    # Use rule of sines to get base angle
    # so the angle of the notch, but measured from the center of the circle.
    angle = half_angle - np.arcsin(reduced_radius / radius * sin(half_angle))

    # Arc on big circle
    u = linspace(angle, 2 * np.pi - angle, N)
    p1 = [(radius * cos(a), radius * sin(a)) for a in u]

    # Append small circle at the base of the notch.
    half_angle_complement = 0.5 * np.pi - half_angle
    u = linspace(-half_angle_complement, half_angle_complement, N)
    p2 = [(radius - notch_depth + notch_radius * (1 - cos(a)), notch_radius * sin(a)) for a in u]

    return p1 + p2
