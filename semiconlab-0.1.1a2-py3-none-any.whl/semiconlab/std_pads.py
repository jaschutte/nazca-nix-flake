import nazca as nd
from nazca.cellcache_util import cellcache
from nazca.clipper import grow_polygons
from nazca.geometries import rectangle

import semiconlab as sl

__all__ = ["pad", "padmesa", "padtrench", "std_dcpads"]


@cellcache("pad", ["length", "width"])
def pad(length: float = 90, width: float = 70) -> nd.Cell:
    with nd.Cell() as C:
        grow = 2
        rect = rectangle(width - 2 * grow, length - 2 * grow, position=5)
        roundedrect = grow_polygons([rect], grow)[0]
        nd.Polygon(roundedrect, layer="Metal").put(grow)
        nd.Pin("c0", xs="Metal").put(0, 0, -90)
        nd.Pin("c1", xs="Metal").put(0, -length / 2, -90)
        C.default_pins("c0", "c0")
        nd.put_stub()
    return C


@cellcache("padtrench", ["length", "width"])
def padtrench(length: float = 90, width: float = 70) -> nd.Cell:
    with nd.Cell() as C:
        grow = 2
        grow2 = grow + 5
        rect = rectangle(width - 2 * grow, length - 2 * grow, position=5)
        roundedrect = grow_polygons([rect], grow)[0]
        roundedrect2 = grow_polygons([rect], grow2)[0]
        nd.Polygon(roundedrect, layer="Metal").put()
        nd.Polygon(roundedrect2, layer="Trench").put()
        nd.Pin("c0", xs="Metal").put(0, 0, -90)
        nd.Pin("c1", xs="Metal").put(0, -length / 2, -90)
        C.default_pins("c0", "c0")
        nd.put_stub()
    return C


@cellcache("padmesa", ["length", "width"])
def padmesa(length: float = 90, width: float = 70) -> nd.Cell:
    with nd.Cell() as C:
        grow = 2
        grow2 = grow + 2.5
        grow3 = grow + 5
        rect = rectangle(width - 2 * grow, length - 2 * grow, position=5)
        roundedrect = grow_polygons([rect], grow)[0]
        roundedrect2 = grow_polygons([rect], grow2)[0]
        roundedrect3 = grow_polygons([rect], grow3)[0]
        nd.Polygon(roundedrect, layer="Metal").put()
        nd.Polygon(roundedrect2, layer="Mesa").put()
        nd.Polygon(roundedrect3, layer="Trench").put()
        nd.Pin("c0", xs="Metal").put(0, 0, -90)
        nd.Pin("c1", xs="Metal").put(0, -length / 2, -90)
        C.default_pins("c0", "c0")
        nd.put_stub()
    return C


@cellcache("dcpad_array", ["N"])
def _dcpad_array(
    N: int = 5,
    pad_length: float = 90,
    pad_width: float = 70,
    pitch: float = 150,
    pos: list | None = None,
    nametmpl: str | None = None,
) -> nd.Cell:
    """Return an array of dc pads, each with a label.

    Args:
        N (int): number of pads
        pad_length (float): length of the pad
        pad_width (float): width of the pad
        pitch (float): center-to-center distance between two adjacent pads
        pos (list): position a pad at these sequence numbers or all if None
        nametmpl (str): name template for label. It should contain an int format
            specifier, which will be replaced with the sequence number of the pad

    Returns:
        cell with array
    """
    if not pos:
        pos = set(range(N))
    with nd.Cell() as C:
        x0 = -(N - 1) * pitch / 2
        for i in range(N):
            x = x0 + i * pitch
            name = nametmpl.format(i)
            nd.Pin(name).put(x, -pad_length / 2, 90)
            if i in pos:
                padtrench(length=pad_length, width=pad_width).put("c1", x, 0, -90)
                nd.text(
                    "\n".join([name[:3], name[3:]]),
                    layer="bbox_name",
                    align="cc",
                    height=pad_width / 2,
                ).put(x, -pad_length / 2 - 3.5, 0)
        nd.Pin("cc").put(0, 0, 180)
    return C


@cellcache("std_dcpads", ["height"])
def std_dcpads(
    height: float = 4000, north: int | list = 1, south: int | list = 1
) -> nd.Cell:
    """Generate all DC pads in the template.
    It should be placed in the center of the design cell. The pad locations are
    accessible through the pad name, e.g. ``pin["dc0S07"]``.

    By default all pads in a row are placed. This is typically what is needed, especially
    if the chip should eventually be probed with a probe card. However, if you must, you
    can specify that only specific pads are to be placed. In that case, the north and
    south arguments can also be a list of lists, in which case the pad sequence numbers
    are used to place pads only at the locations specified. So when specifying north=[[0,
    10], [1, 3]] only pads dc0N00, dc0N10, dc1N01, dc1N03 would be placed. The pins for
    all pad centers would still be accessible.

    Args:
        die_height (float): the height of the design cell in µm
        north (int, or list): number of pad rows (0, 1, 2) at north side of cell, or
            north can be a double list, see the above explanation.
        south (int, or list): number of pad rows (0, 1, 2) at south side of cell, or
            south can be a double list see the above explanation.

    Returns:
        cell with DC pad template.

    Example:
        The standard cell height would be 4 mm. This example uses a
        non-standard height of 2 mm::

            import nazca as nd
            import semiconslab as sl
            die = sl.DesignArea(name="My design", height=2000).cell().put()
            sl.std_dcpads(height=2000, south=2).put(die.pin["cc"])
            nd.export_gds()

    .. image:: fig/tue_std_dcpads_2000.png
        :scale: 50
    """
    if isinstance(north, int):
        posN = [None, None]
    else:  # list of lists
        posN = [n for n in north]
        north = len(posN)
    if isinstance(south, int):
        posS = [None, None]
    else:  # list of lists
        posS = [n for n in south]
        south = len(posS)
    assert north in {0, 1, 2} and south in {0, 1, 2}

    with nd.Cell() as C:
        for i in range(south):
            offset = 150 + i * 150
            pads = _dcpad_array(N=29 - i, pos=posS[i], nametmpl=f"dc{i}S{{:02d}}").put(
                "cc", 0, -height / 2 + offset
            )
            padnames = [name for name in pads.pin if name.startswith("dc")]
            pads.raise_pins(padnames)
        for i in range(north):
            offset = 150 + i * 150
            pads = _dcpad_array(N=29 - i, pos=posN[i], nametmpl=f"dc{i}N{{:02d}}").put(
                "cc", 0, height / 2 - offset, 180
            )
            padnames = [name for name in pads.pin if name.startswith("dc")]
            pads.raise_pins(padnames)
    return C


if __name__ == "__main__":
    DIE1 = sl.DesignArea()
    die1 = DIE1.cell().put()

    pads = std_dcpads(DIE1.height, north=[[1, 2, 3, 21], [3, 4, 5]], south=2).put(
        die1.pin["cc"]
    )
    sl.metal.sbend_p2p(pads.pin["dc0N21"], pads.pin["dc1S04"], Lstart=300).put()

    DIE2 = sl.DesignArea(height=2000)
    die2 = DIE2.cell().put(0, 4000, 0)

    pads = std_dcpads(DIE2.height, north=1, south=2).put(die2.pin["cc"])
    sl.metal.sbend_p2p(pads.pin["dc0N21"], pads.pin["dc1S04"], Lstart=300).put()

    nd.export_gds()
