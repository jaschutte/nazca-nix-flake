# -----------------------------------------------------------------------
# This file is part of Nazca.
#
# Nazca is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or (at
# your option) any later version.
#
# Nazca is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.

# You should have received a copy of the GNU Affero General Public License
# along with Nazca.  If not, see <http://www.gnu.org/licenses/>.
# -----------------------------------------------------------------------
# ==============================================================================
# (c) 2016-2022 Ronald Broeke, Katarzyna Lawniczuk, Xaveer Leijtens
# ==============================================================================

"""Module with a set of Buiding Block templates for faciliating PDK creation."""

from __future__ import annotations

import os
import csv
from typing import Any, TYPE_CHECKING, Callable
from collections import OrderedDict
import inspect
from functools import wraps
from dataclasses import dataclass, asdict
from ast import literal_eval
import numpy as np
import matplotlib.pyplot as plt
import json
import yaml
from pprint import pprint
from PIL import Image

import hashlib
import nazca as nd
from nazca import cfg
from nazca.logging_util import logger
from nazca.clipper import merge_polygons

import nazca.geometries as geom
from nazca.yaml_utils import yloader

if TYPE_CHECKING:
    from nazca import Cell


# ==============================================================================
# hash
# ==============================================================================
_hash_id = None
_hash_params = {}
_hash_name = "NONAME"
cfg._hashme = []
HASH_LENGTH = 4  # number of hash characters to add to the cellname


def hashme(
    name: str = "",
    parreprs: list[str] = None,
    suffix: str = None,
    addhash: bool = None,
    config: dict = None,
):
    """Decorator to reuse building blocks (cells) based on the same parameters.

    The @hashme decorator can be used for parametrized cells.
    It checks if a function call (that returns a Cell) occured before
    with the same parameters. If that is the case @hashme returns a reference
    to the previously created cell with these parameters, rather than creating
    a full copy with a new cell name. The hashme ensures a unique cellname by
    adding an md5 hash at the end of the cellname. Note that in gds cell the cellname
    string is the unique identifier for referencing cells. In order to add
    parameters to the cellname each specific parameter name must be added to "parrepr".

    Args:
        name (str): Cell name.
        parreprs (list of dict | list of str): list of parrepr 'parameter representations'
            in the cellname. In case of proving a list-of-str, only the parameter names
            shall be provided, which will automatically be translated in a dict
            internally. A parameter entry in parreprs adds the parameter
            to the cellname in order of appearence in parreprs.
            Each parrepr dict describes not only if, but also how to format
            cell parameter in the cellname. See parrepr formatting rules below.
        config (dict): if set, overrules the default setting in cfg.hashme_config
        suffix (str): cellname suffix. Overules 'config'.
        addhash (bool): flag to show a hash in the cellname.
            Overules 'addhash' setting in 'config'.
            There maybe foundry rules that ban the use of hashme. Note that in such
            cases the parreprs need to be used to uniquely define cell names.

    The default settings for the hashme cellname formatting are set in the
    cfg.hashme_config dict. These setting can be overruled with the "config" dict
    in the hashme call, which has the same structure. Using the "config" keyword
    also facilitate reuse of settings, and simplifies the "parreprs" entry.
    Settings in parrepr overrule settings in "config".
    Note that there can be multiple parameters per cellname, but only one "addhash"
    and one "suffix". The config and parrepr dicts are defined as follows:

        config = {
           "prefix": <parameter specific prefix>,  # Generic prefix for the parameter value, e.g. "", "_", "_L", "_w"

           "format": <format string>,  # parameter format, e.g. ".5f", "2.1g"

           "func": <function(value)>,  # custom formatting function for callback, returns a string

           "suffix": <suffix string>,  # can be overruled by "suffix" keyword in hashme.

           "addhash": <addhash True|False>  # can be overruled by "addhash" keyword in hashme.

        }

        parrepr = {
            "parameter": <parameter name>,  # mandatory parameter name as used in the cell call, e.g. "L", "width"

            "prefix": <parameter specific prefix>,  # optional prefix for the parameter value, e.g. "", "_", "_L", "_w"

            "format": <format string>,  # optional parameter format, e.g. ".5f", "2.1g"

            "func": <function(value)>,  # optional custom formatting function for callback, returns a string

        }

    Example:

        Usage of the hashme decorator::

            @hashme('mycellname')
            def parametrized_cell(W, L):
                with nd.Cell() as C:
                    # cell stuff
                    nd.strt(length=L, width=W).put()
                return C

            parametrized_cell(W=3.0, L=10.0)
            # cell_name ='mycellname'

        Usage of the hashme with adding keyword values to the cellname (default representation)::

            @hashme('mycellname', ['L', 'W'])
            def parametrized_cell(W, L):
                with nd.Cell() as C:
                    # cell stuff
                    nd.strt(length=L, width=W).put()
                return C

            parametrized_cell(W=3.0, L=10.0)
            # cell_name ='mycellname_10.0_3.0'

        Usage of hashme with adding keyword values to the cellname (custom representation)::

            parreprs = [
                {"parameter": "L", "prefix": "_L"},  # Default float format: '.5g'
                {"parameter": "W", "format": ".5g", "min_decimals": 1},  # Force a minimum number of decimals
            ]
            @hashme('mycellname', addhash=False, parrepr=parreprs, suffix="_end")
            def parametrized_cell(W, L):
                with nd.Cell() as C:
                    # cell stuff
                    nd.strt(length=L, width=W).put()
                return C

            parametrized_cell(W=3.0, L=10.0)
            # cell_name = 'mycellname_L10_3.0_end'

        Usage of hashme with config::

            config = {
                "prefix": "/",
                "format": ".2g,"
                "addhash: False",
                "suffix": "_the_end",
            }
            @hashme(
                'name=mycellname',
                 parrepr=[
                     {"parameter": "L", "prefix": "_L"},
                     {"parameter": "W", "prefix": "_W"},
                 ],
                 config=config,
            )
            def parametrized_cell(W, L):
                with nd.Cell() as C:
                    # cell stuff
                    nd.strt(length=L, width=W).put()
                return C

            parametrized_cell(W=3.0, L=10.0)
            # cell_name = 'mycellname_L10_3.0_end'


    Note: do *not* use any global parameters in a parameterized Cell function
    that is decorated with hashme, i.e. put all parameters that may change the
    cell in the function call. The reason is that a change of a global parameter
    could possibly cause a different result of the generated cell without
    being noticed by the function introspection. For this reason function
    in classes should not be decorated with @hashme.

    Returns:
        decorator
    """

    hash_class_warning = """Warning: @hashme decorator on Class method:

By default Nazca will guarantee a unique cell name each time a cell is created.
It does so by suffixing cell names with an ordinal counter.
This may result in multiple copies of the same cell where only one would do.

Decorating the cell generating function with @hashme avoids cell copies of
identical cells by returning an existing cell if the function has been
called with the same parameters earlier.

The @hashme 'state checker' can only be used safely if the state of the
function it decorates is *not* dependent on a state *external* to that
function, i.e. only if the variations of the cell it generates *only* depends
on the function's parameters. In contrast, Class methods typically depend
on attributes stored at class level, hence, by their very nature Class methods
do not fit well with the @hashme concept to guarantee unique cells for
unique names.

Example of a cell function where @hashme should NOT be used, i.e. in a class method:

    class myElement():
        # stuff
        def make_cell(a, b, c):
            # stuff
            return cell_object

    elm = myElement()

Now compare two ways to place a cell multiple times.

* method 1:
    elm.make_cell(a, b, c).put()
    elm.make_cell(a, b, c).put()

a) creates two copies of the cell and suffixes the name with an ordinal counter.
b) if @hashme is used it returns an existing cell if the call profile
   of make_cell has been used earlier.

* method 2:
A secure way in all cases to reuse cells is to call a cell generation function
only once and assign its returns value, i.e. the Cell object, to a variable.
Use this variable to put instances of the cells:

    E = elm.cell(a, b, c)
    E.put()
    E.put()
"""
    # print('params:' , params)
    if parreprs is None:
        parreprs = []
    if config is None:
        config = {}
    if name == "":
        name = _hash_name
        print(f"warning: no cellname given to @hashme, calling it '{name}'.")

    if len(parreprs) > 0:
        if isinstance(parreprs, str):  # single string
            parreprs = [{"parameter": parreprs}]
        elif isinstance(parreprs, list) and isinstance(parreprs[0], str):  # list of str
            parreprs = [{"parameter": par} for par in parreprs]
        # TODO, check beyond item [0] may be needed:
        elif isinstance(parreprs, list) and isinstance(
            parreprs[0], dict
        ):  # list of dict, desired format
            pass
        else:
            raise TypeError(
                "Hashme input variable 'parreprs' (parameter representations) should be a list-of-str or list-of-dict. "
                f"Current value: {parreprs}."
            )

        # Fill all values for parameter representation in the cellname:
        for parrepr in parreprs:
            for key in ["prefix", "format", "func"]:
                if key not in parrepr.keys():
                    parrepr[key] = config.get(key, cfg.cellcache_config[key])

    if addhash is None:
        addhash = config.get("addhash", cfg.cellcache_config["addhash"])
    if suffix is None:
        suffix = config.get("suffix", cfg.cellcache_config["suffix"])
    assert isinstance(
        addhash, bool
    ), f"Hashme parameter 'addhash' should be a boolean. Current value: {addhash}."

    def decorator(cellfunc):
        """Decorator for grabbing and hashing a function's full parameter list.

        While executing the wrapper a global hashid and parameter list are set.
        Before leaving the wrapper the hashid is reset to None.

        Returns:
            function: wrapper function
        """

        @wraps(cellfunc)
        def wrapper(*args, **kwargs):
            global _hash_id
            global _hash_params
            global _hash_name
            nonlocal name

            # if cfg.hashme:
            #    raise Exception(
            #        "Can not call an @hashme-decorated function before the Cell() call inside another @hashme "
            #        "decorated function. Move the function call(s) after the 'with Cell()' context Cellname: '{name}'."
            #    )
            name_long = name
            getargs = inspect.getfullargspec(cellfunc)
            funcargs = getargs.args
            funcdefaults = getargs.defaults
            if funcdefaults is not None:
                delta = len(funcargs) - len(funcdefaults)
            else:
                delta = len(funcargs)
            hashstr = ""
            _hash_params = OrderedDict()

            allow_kwargs = (
                getargs.varkw is not None
            )  # Check if kwargs can be passed to the function
            unknown_params = list(
                set(kwargs.keys()) - set(funcargs)
            )  # Check if non-defined function arguments are passed
            if unknown_params and not allow_kwargs:
                raise TypeError(
                    f"{cellfunc.__name__}() got unexpected keyword argument(s) {unknown_params}"
                )

            if funcargs:
                if (
                    funcargs[0] == "self"
                ):  # Assuming consistent use of string 'self' for class refs.
                    funcargs = funcargs[1:]
                    print(hash_class_warning)

                for i, a in enumerate(funcargs):
                    if i < len(args):
                        default = args[i]
                    elif i - delta >= 0:
                        default = funcdefaults[i - delta]
                    else:
                        default = None
                    _hash_params[a] = kwargs.get(a, default)

                for parrepr in parreprs:
                    val = parrepr["parameter"]
                    parfunc = parrepr["func"]
                    if val in _hash_params.keys():
                        pvalue = _hash_params[val]
                        try:
                            pstr = format(pvalue, parrepr["format"])
                        except (TypeError, ValueError) as e:
                            pstr = pvalue
                            nd.main_logger(
                                f"Warning: format '{parrepr['format']}' not applicable to parameter '{val}' with value '{pvalue}': {e}",
                                "warning",
                            )
                        if parfunc is not None:
                            pstr = parfunc(pstr)  # call formatting function
                        name_long += f"{parrepr['prefix']}{pstr}"
                    else:
                        raise ValueError(
                            f"Parameter '{val}' not found in function parameters {list(_hash_params.keys())}."
                        )

                for p in sorted(_hash_params.keys()):
                    hashstr += "{}_{}".format(p, _hash_params[p])
                _hash_id = hashlib.md5(hashstr.encode()).hexdigest()[:HASH_LENGTH]

            else:
                _hash_id = ""

            if suffix != "":
                name_long = f"{name_long}{suffix}"

            if (_hash_id != "") and addhash:
                _hash_name = f"{name_long}_${_hash_id}"
            else:
                _hash_name = name_long
            _hash_name = cfg.gds_cellname_cleanup(_hash_name)
            # add cfg to avoid explicit import of this module for hashme attributes
            cfg.hashme = True
            cfg.hash_id = _hash_id
            cfg.hash_cellnameparams = tuple(
                parrepr["parameter"] for parrepr in parreprs
            )
            cfg.hash_params = _hash_params
            basename = cfg.gds_cellname_cleanup(name)
            cfg.hash_basename = basename  # base
            cfg.hash_paramsname = cfg.gds_cellname_cleanup(name_long)  # base + params
            cfg.hash_name = _hash_name  # base + params + hash
            cfg.hash_func_id = id(cellfunc)

            # check if basename comes from a unique function:
            funcid = cfg.basenames.get(basename, False)
            if funcid:
                if funcid != cfg.hash_func_id and cfg.check_basename:
                    logger.warning(
                        f"Reusing a basename across function IDs: '{basename}'"
                    )
            else:
                logger.debug(f"Adding basename '{basename}' to cfg.basenames")
                if cfg.validate_basename:
                    nd.validate_basename(basename)
                # add basename:
                cfg.basenames[basename] = cfg.hash_func_id

            cell_exists = _hash_name in cfg.cellnames.keys()

            if cell_exists:
                cfg.hashme = False
                return cfg.cellnames[_hash_name]
            else:
                cell_new = cellfunc(*args, **kwargs)

            # reset:
            _hash_id = None
            _hash_params = {}
            _hash_name = ""
            cfg.hashme = False
            cfg.hash_id = ""
            cfg.hash_params = ""
            cfg.hash_cellnameparams = {}
            cfg.hash_basename = ""
            cfg.hash_paramsname = ""
            cfg.hash_name = ""
            cfg.hash_func_id = None
            return cell_new

        return wrapper

    return decorator


def technology(tech: str):
    """
    Decorator to execute a function within the context of a given technology

    Args:
        tech (str): Technology to use for the context
    Returns:
        decorator
    """

    def decorator(func):
        @wraps(func)
        def wrapper(*func_args, **func_kwargs):
            with nd.Technology(tech):
                return func(*func_args, **func_kwargs)

        return wrapper

    return decorator


def trial_cell(func: Callable) -> Callable:
    """Decorator to delete all Nazca cells generated in the decorated functions.

    It will reset the cell counter to before the trial

    Returns:
        callable: wrapped function
    """

    def wrapper(*args, **kwargs):
        """Wrapper function that deletes new Cells generated in its scope.

        Create a trial cell to extract cell properties .

        Returns:
            Cell | float: result of wrapped function.
        """
        cell = kwargs.pop("cell", False)
        if not cell:
            S1 = set(nd.cfg.cellnames.keys())
            num = nd.netlist.num
        out = func(*args, cell=cell, **kwargs)
        if not cell:
            nd.netlist.num = num
            S2 = set(nd.cfg.cellnames.keys())
            for s in S2 - S1:
                nd.cfg.cellnames.pop(s)
        return out

    return wrapper


def bbox_layers_ignore(layers: list = None, reset: bool = False) -> None:
    """Set the layers that should be ignored in bbox calculations.

    Args:
        layers (layer): list of layers
        reset ((bool): If True, clear existing ignore list and only set <layers>, default=False.

    Returns:
        None
    """
    if layers is None:
        layers = []
    layerIDs = [nd.get_layer(ml) for ml in layers]
    if reset:
        cfg.bbox_layers_ignore = layerIDs
    else:
        cfg.bbox_layers_ignore.extend(layerIDs)


def get_Cell(name: str) -> Cell:
    """Get Cell object by providing cell name.

    Args:
        name (str): cell name

    Returns:
        Cell: cell having cellname <name>
    """
    if name in cfg.cellnames.keys():
        return cfg.cellnames[name]
    else:
        mes = (
            f"Error: Requested cell with name '{name}' not existing. "
            f"Availabe are the following {len(cfg.cellnames)} cells: {sorted(cfg.cellnames.keys())}."
        )
        logger.exception(mes)
        raise ValueError(mes)


@dataclass(frozen=True, slots=True)
class RangeCheckSpec:
    """Range-check specification used during validation."""

    min: Any
    default: Any
    max: Any
    type: str | None  # datatype, e.g. 'int', 'float'.
    doc: str = ""
    unit: str = ""

    def with_numeric_defaults(self) -> "RangeCheckSpec":
        """Replace open numeric boundaries with infinities for comparisons."""
        if self.type not in ["int", "float"]:
            return self
        return RangeCheckSpec(
            min=float("-inf") if self.min is None else self.min,
            default=self.default,
            max=float("inf") if self.max is None else self.max,
            type=self.type,
            doc=self.doc,
            unit=self.unit,
        )


def _to_range_spec(
    varname: str, values: RangeCheckSpec | tuple[Any, Any, Any] | dict[str, Any]
) -> RangeCheckSpec:
    """Convert supported input formats into a range-check dataclass."""
    if isinstance(values, RangeCheckSpec):
        return values

    if isinstance(values, tuple):  # for backward compatibility
        if len(values) != 3:
            raise ValueError(f"Need to provide 3 values, got {len(values)}")

        if values[1] is None:
            raise ValueError(
                f"Value None is not allowed in rangecheck() in cell '{nd.cfg.active_cell().cell_name}'"
            )

        return RangeCheckSpec(
            min=values[0],
            default=values[1],
            max=values[2],
            type=type(values[1]).__name__,
        )

    if isinstance(values, dict):
        missing = [
            key for key in ["min", "default", "max", "type"] if key not in values
        ]
        if missing:
            raise ValueError(f"Missing key(s) {missing} in rangecheck for '{varname}'.")

        return RangeCheckSpec(
            min=values["min"],
            default=values["default"],
            max=values["max"],
            type=values["type"],
            doc=values.get("doc", ""),
            unit=values.get("unit", ""),
        )

    # Still not returned, then the input type is not allowed
    raise TypeError(
        f"Expected type tuple/dict/RangeCheckSpec, not type '{type(values)}'."
    )


def rangecheck(
    allowed_values: (
        dict[str, tuple[Any, Any, Any]]
        | dict[str, dict[str, Any]]
        | dict[str, RangeCheckSpec]
    ),
) -> None:
    """Check if parameter values are in range.

    A dictionary with the allowed values for parameters is sent to rangecheck.
    If any parameter is out of range, a ValueError will be raised and relevant
    error info is provided to solve the issue.

    Args:
        allowed_values (dict): {'<var_name>': (low, <var_name>, high)},
        where the key is the <varname> in a str type,
        and low and high are the min and max values

    Raises:
        ValueError if out of range.

    Returns:
        None

    Example:

        Add a check in a function on 0 <= a <= 10 and -5 <= b <= 5.
        The call will raise a ValueError::

            def func(a, b):
                nd.rangecheck({'a': (0, a, 10), 'b': (-5, b, 5)})

            func(a=100, b=100)

            # output:
            # ValueError: a=100 too large. Allowed values: 0<=a<=10
            # b=100 too large. Allowed values: -5<=b<=5
    """
    errors = []
    for varname, values in allowed_values.items():
        spec = _to_range_spec(varname, values)
        spec_eval = spec.with_numeric_defaults()

        if spec_eval.type not in cfg.allowed_vartypes:
            errors.append(
                f"vartype '{spec_eval.type}' unknown. Allowed vartypes: '{cfg.allowed_vartypes}'"
            )

        if spec_eval.type in ["int", "float"]:
            if spec_eval.default is None:
                raise ValueError(
                    f"Value None is not allowed in rangecheck() in cell '{nd.cfg.active_cell().cell_name}'"
                )

            if spec_eval.default < spec_eval.min:
                errors.append(
                    f"{varname}={spec_eval.default} too small. Allowed values: {spec_eval.min}<={varname}<={spec_eval.max}"
                )
            elif spec_eval.default > spec_eval.max:
                errors.append(
                    f"{varname}={spec_eval.default} too large. Allowed values: {spec_eval.min}<={varname}<={spec_eval.max}"
                )

        # store variable info in cell for later use:
        # TODO: This assignment is flaky.
        #       It assumes rangecheck is called in the cell object creation, which does not have to be the case.
        #       Also, note that a rangecheck could be on a function that is not making a cell.
        #       Rather create a C.rangecheck() option for cells.
        cell = nd.cfg.active_cell()
        if cell is not None:
            cell.ranges[varname] = asdict(spec_eval)

    if errors:
        err = "\n".join(errors)
        if cfg.rangecheck:
            raise ValueError(err)
        else:
            nd.main_logger(
                f"{err}, continuing anyway (rangecheck is set to False).", "error"
            )


# ==============================================================================
#
# ==============================================================================
stubs = dict()  # dict of all stubs. {stub_name: stub_cell_obj}
stubmap = (
    dict()
)  # dict of xsection_name to its stub's xsection_name. {xs_name: stub_xs_name}


class Functional_group:
    """Class to group building blocks syntactically together.

    Example:
        Create bb_splitters group with various splitter components
        such that the mmi can be found under bb_splitters.<tab>::

            bb_splitters = Functional_group()
            bb_splitters.mmi1x2 = mmi1x2
            bb_splitters.mmi2x2 = mmi2x2
            bb_splitters.mmi3x3 = mmi3x3
    """

    def __init__(self, name: str = ""):
        """Create a Functional group object."""
        self.name = name


BB_Group = Functional_group


# Put in this module to avoid loading utils.py:
def parameters_to_string(param: dict) -> str:
    """Create a string from a parameter dictionary.

    Args:
        param (dict): (parameter_name, value)

    Note that the output format, i.e. inside the annotation object)
    may be foundry specific depending on the setting of
    cfg.parameter_style

    'default' output format:

    Parameters:
    <parameter> = <value>
    <parameter> = <value>
    ...

    'yaml' output format:

    <parameter>: <value>
    <parameter>: <value>
    ...

    Returns:
        str: parameters as a string
    """
    if cfg.parameter_style == "yaml":
        return yaml.dump(dict(param))  # change from ordered dict
    elif cfg.parameter_style == "hhi":
        plist = []
        for key, value in param.items():
            plist.append(f"{key}:{value}")
        return "\n".join(plist)
    elif cfg.parameter_style == "default":
        plist = ["Parameters:"]
        for key, value in param.items():
            plist.append(f"{key} = {value}")
        return "\n".join(plist)
    else:
        nd.logger.error(
            f"cfg.parameter_style = '{cfg.parameter_style}' not recognized."
        )


def string_to_parameters(string: str) -> dict:
    """Convert a string to a parameter dictionary.

    The returned parameter values are represented as type str.

    Expected format of <string>:

    "parameters:
    <parameter> = <value>
    <parameter> = <value>
    ..."

    Header 'parameters:' is case incensitive and spaces will be stripped.

    Args:
        string (str): parameters

    Returns:
        OrderedDict: {<parameter_name>: <parameter_value>}
    """
    if cfg.parameter_style == "default":
        lines = string.split("\n")
        p = OrderedDict()
        if lines[0].lower() == "parameters:":
            for line in lines[1:]:
                param = line.split("=", 1)
                if len(param) == 2:
                    p[param[0].strip()] = param[1].strip()
                else:
                    logger.error(
                        f"string_to_parameter: Expected one keyword "
                        f"and one value,\nbut found instead: {param}. "
                        f"Provided string instead: '{string}'"
                    )
        else:
            logger.exception(
                f"string_to_parameter: "
                f"Expected header 'parameters:', because cfg.parameter_style = '{cfg.parameter_style}'. "
                f"Provided string instead: '{string}'"
            )
        return p

    elif cfg.parameter_style == "yaml":
        p = yaml.load(string, Loader=yloader)
        return p

    else:
        logger.error("string_to_parameter: " "Expected header 'parameters:'\n")
        return {}


def put_parameters(parameters: dict = None, pin=None) -> str:
    """Put a parameter list as annotation in a building block.

    Args:
        parameters (dict): {parameter_name: value}

    Returns:
        string: object with the parameterlist
    """
    cell = cfg.active_cell()
    if isinstance(parameters, dict):
        cell.parameters = parameters
        text = parameters_to_string(cell.parameters)
    elif cell.hashme:
        text = parameters_to_string(cell.parameters)
    else:
        text = ""

    if cfg.parameter_style == "hhi":
        for i, plist in enumerate(text.split("\n")):
            anno = nd.Annotation(text=plist, layer="bb_parameter_text")
            if pin is None:
                anno.put(0, 10 * i)
            else:
                anno.put(pin.move(0, 5 * i))
    else:  # standard
        anno = nd.Annotation(text=text, layer="bb_parameter_text")
        if pin is None:
            anno.put(0)
        else:
            anno.put(pin)
    return text


def cellname(
    cellname: str = None,
    length: float = 0,
    width: float = None,
    align: str = "lc",
    name_layer: str = None,
) -> Cell:
    """Create the cellname as a text cell.

    Args:
        cellname (str): name of the cell
        length (float): length available for the BB name in um
        width (float):
        align (str): text alignment (see nazca.text, default = 'lc')
        name_layer (str): name of the layer to be used for bbox name

    Returns:
        Cell: text with cellname
    """
    cell = cfg.active_cell()
    if cellname is None:
        cellname = cell.cell_paramsname

    if width is not None:
        maxheight = min(width * 0.8, cfg.cellname_max_height)
    else:
        maxheight = cfg.cellname_max_height

    if name_layer is None:
        name_layer = "bbox_name"

    length = length * cfg.cellname_scaling
    texth = min(maxheight, abs(length) / nd.linelength(cellname, 1))
    txt = nd.text(cellname, texth, layer=name_layer, align=align)
    return txt


# ==============================================================================
# stubs and pins
# ==============================================================================
def add_pinstyle(name: str, styledict: dict, tech: str = None) -> None:
    """Set a custom pin style for a technology.

    Start with the style in <name> if existing, otherwise with the
    default cfg.pinstyle settings and overrule these
    for the keywords provided in the <styledict>.

    Each pinstyle name will point to a unique dictionary internally.

    A technology label is added to the pinstyle as a namespace to keep technologies apart.

    Args:
        name (str): pinstyle name
        styledict (dict): pinstyle
        tech (str): Optional name of technology for the pinstyle

    Returns:
        None
    """
    if tech is None:
        tech = cfg.active_tech or cfg.default_tech

    present = nd.cfg.pinstyles.get((name, tech), None)
    if present is None:
        present = nd.cfg.pinstyle
    newstyle = present.copy()

    # keys = nd.cfg.pinstyle.keys()
    if styledict is not None:
        for item, setting in styledict.items():
            if item in cfg.pinstylelabels:
                newstyle[item] = setting
            else:
                nd.main_logger(
                    f"No valid pinstyle key '{item}' for pinstyle. Available keys: {cfg.pinstylelabels}",
                    "warning",
                )
    nd.cfg.pinstyles[(name, tech)] = newstyle


def reset_pinstyles() -> None:
    """Define default pinstyle dicts."""
    cfg.set_default_pinstyles()

    for name, _pinstyle in cfg.default_pinstyles.items():
        add_pinstyle(name, _pinstyle)


def parse_pinstyle(pinstyleref: str | tuple[str, str] | None) -> tuple[str, str]:
    """Parse the provided pinstyle. Pinstyles are stored as (name, tech) in cfg.pinstyles.

    The pinstyle ID can be passed as follows:

    str: This is interpreted as the name of the pinstyle. This function returns the first matching (tech, name) in
         cfg.pinstyles. A warning is logged if there are multiple pinstyles for this name.
    tuple: This is interpreted as the (name, tech). The function will return the pinstyle from cfg.pinstyles that
         matches this id.

    Args:
        pinstyle (str | tuple): lookup for the pinstyle ID, either as a name string or a (name, tech) tuple.

    Returns:
        tuple: pinstyle ID in (name, tech) format
    """
    pinstyles = nd.cfg.pinstyles

    # 1) Exact tuple lookup
    if isinstance(pinstyleref, tuple):
        if pinstyleref in pinstyles:
            return pinstyleref

    # 2) Name lookup (or default name)
    if isinstance(pinstyleref, str):
        name = pinstyleref
    elif pinstyleref is None:
        name = cfg.default_pinstyle_name
    else:
        nd.main_logger(
            f"Unsupported pinstyle reference type '{type(pinstyleref)}'. "
            "Expected str, tuple(name, tech), or None. Falling back to default.",
            "warning",
        )
        name = cfg.default_pinstyle_name

    # Try to find pinstyle by name, prioritizing active tech, then default tech
    active_tech = nd.cfg.active_tech
    default_tech = nd.cfg.default_tech

    if (name, active_tech) in pinstyles:
        return (name, active_tech)
    if (name, default_tech) in pinstyles:
        return (name, default_tech)

    # raise Exception(f"Incorrect format for pinstyle: {pinstyle}.\n pinstyle must be a string or a tuple.")
    msg = f"\nNo pinstyle existing under pinstyle identifier '{pinstyleref}'."
    msg += " Available pinstyles are:"
    for style in pinstyles.keys():
        msg += f"\n  {style}"
    msg += "\nAlternatively, add a new pinstyle as:"
    msg += f"\n  add_pinstyle(name=<pinstyle>, style=<pinstyle_dict>)"
    msg += (
        f"\n  add_pinstyle(name=<pinstyle>, tech=<technology>, style=<pinstyle_dict>)"
    )

    nd.main_logger(msg, "error")

    # Return default as fallback
    return (cfg.default_pinstyle_name, active_tech)


# for backward compatibility:
raise_set_pinstyle = False
set_pinstyle_flag = False


def set_pinstyle(name: str, styledict: dict) -> None:
    global set_pinstyle_flag
    if not set_pinstyle_flag:
        print(
            "Method set_pinstyle() is obsolete. Use add_pinstyle() instead."
            " Find the source of this issue by adding nd.raise_set_pinstyle=True after import nazca."
        )
        if nd.raise_set_pinstyle:
            raise RuntimeError("set_pinstyle() is obsolete.")
        add_pinstyle(name, styledict)

        set_pinstyle_flag = True
    add_pinstyle(name, styledict)


def add_pinshape(
    name: str, shape: list[tuple[float, float]], overwrite: bool = True
) -> None:
    """Add a pin shape to the pinshapes dict.

    Args:
        name (str): reference name of the shape
        shape (list of (float, float)): pin shape [(x1, y1), ...]

    Returns:
        None
    """
    if name in cfg.pinshapes.keys() and not overwrite:
        print(
            f"pinshape name '{name}' already exists. Use an other name of set overwrite=True."
        )
    else:
        cfg.pinshapes[name] = shape


def set_default_pinstyle(stylename: str) -> None:
    """Provide the name to use for the standard pinstyle.

    The default standard style utilized in 'default'.

    Returns:
        None
    """
    cfg.default_pinstyle_name = stylename


# Do NOT @cellcache decorate this function,
# because parameter values are finalized inside the function.
# The function will check itself on overlapping cellnames and initiate reuse if possible.
def make_pincell(
    layer: Any = None, shape: str = None, size: float = None, style: str = None
) -> Cell:
    """Create a cell to indicate a pin position.

    The cell contains a shape, e.g. an arrow, to point out a location in the layout.
    Available pin shapes are in a dictionary in cfg.pinshapes: {name: polygon}.
    The predefined shapes have been normalized to unit size.

    Args:
        layer (Any): layer number to place the pin symbol/shape
        shape (str): name (dict key) of the pin symbol/shape
        size (float): scaling factor of the pin symbol/shape
        style (str): set a new pinstyle, to be overruled by other keywords, e.g. size, if provided.

    Returns:
        Cell: cell with pin symbol
    """
    style_id = nd.parse_pinstyle(style)
    pinstyle = cfg.pinstyles[style_id]

    if shape is None:
        shape_use = pinstyle["shape"]
    else:
        shape_use = shape

    if layer is None:
        layer = pinstyle["layer"]
    layer = nd.get_layer(layer)

    if size is None:
        size = pinstyle["size"]

    # if cfg.black_pinstyle is not None:
    #    pinstyle = cfg.pinstyles[cfg.black_pinstyle]
    #    shape_use = cfg.pinstyles[cfg.black_pinstyle]['shape']

    if shape_use not in cfg.pinshapes.keys():
        mes = f"pinshape indentifier '{shape}' not recognized."
        mes += f"Available options are: {cfg.pinshapes.keys()}."
        mes += f"Fall back type '{shape_use}' will be used."
        logger.warning(mes)
    shape = shape_use

    name = f"arrow_{layer.ID}_{shape}_{size}"
    name = cfg.gds_cellname_cleanup(name)
    if name in cfg.cellnames.keys():
        return cfg.cellnames[name]
    with nd.Cell(name, instantiate=cfg.instantiate_pin, store_pins=False) as arrow:
        arrow.auxiliary = True
        outline = [(x * size, y * size) for x, y in cfg.pinshapes[shape]]
        nd.Polygon(layer=layer, points=outline).put(0)
    return arrow


def stubname(
    xs: str,
    width: float,
    thick: float,
    stubshape=None,
    pinshape=None,
    pinsize=None,
    pinlayer=None,
) -> str:
    """Construct a stub name.

    Args:
        xs (str); xsection name
        width (float): stub width
        thick (float): thickness of stub into cell (length)

    Returns:
        str: stub name
    """
    if width is None:
        return "stub_{}".format(xs)
    else:
        name = "stub_{}_w{}_t{}_{}_{}_s{}_l{}".format(
            xs, width, thick, stubshape, pinshape, pinsize, pinlayer
        )
        return cfg.gds_cellname_cleanup(name)


missing_xs = []  # keep a list of encountered misssing xs to flag them only once.


def _makestub(
    xs_guide: str = None,
    width: float = 0,
    length: float = 2.0,
    shape: str = None,
    pinshape: str = None,
    pinsize: float = None,
    pinlayer: Any = None,
    cell: Cell = None,
    pinstyle: str = None,
):
    """Create a stub cell (in the logical layers) and add it to the stub dict.

    A stub is the stub of a xsection shape around a pin to visualize a connection.
    A pincell is added to the stub to indicate the pin position inside the stub.
    The new stub is added to the stubs dictionary: {name: stubcell}

    Args:
        xs_guide (str): name of xsection
        width (float): stub width
        thick (float): thickness of stub into cell (length)
        shape (str): shape of the stub: 'box' | 'circ' (default = 'box')
        pinshape (str): pinshape used in the stub
        pinsize (float): scaling factor of the pinshape (default = 1)
        cell (Cell): use the provided cell as stub instead of creating a new stub cell
        pinstyle (str):

    Returns:
        str: key/name of the stub
    """
    xs_guide = nd.get_xsection(
        xs_guide
    ).ID  # TODO: can this be cast earlier, in put_stub()?
    if cfg.validation_stub_xs is not None:
        xs_logic = cfg.validation_stub_xs
    else:
        xs_logic = cfg.stubmap.get(xs_guide, None)
        if xs_logic is None:  # if no stub defined, use the xs as its own stub.
            if xs_guide is None:  # no stub defined
                arrow = make_pincell(
                    layer=pinlayer,
                    shape=pinshape,
                    size=pinsize,
                    style=pinstyle,
                )
                return arrow
            xs_logic = xs_guide
        xs_logic = nd.get_xsection(xs_logic).ID

        if xs_guide not in nd.XSID.NT2xs:
            if xs_guide in nd.cfg.default_xs_list:
                nd.add_xsection(
                    name=xs_guide, pinstyle=nd.cfg.default_xs_list[xs_guide]["pinstyle"]
                )
            elif xs_guide not in missing_xs:
                missing_xs.append(xs_guide)
                default_xs_name = nd.get_xsection(cfg.default_xs_name).ID
                if xs_guide != default_xs_name:
                    logger.error(
                        "Can not make a stub in cell '{3}' in undefined xsection '{0}'.\n"
                        "  Possible causes: '{0}' is misspelled or not yet defined.\n"
                        "  Will use xsection '{2}' instead and continue.\n"
                        "  To define a new xsection:\n"
                        "      add_xsection(name='{0}')\n"
                        "  or with layers info and adding a custom stub:\n"
                        "      add_xsection(name='{0}', layer=1)\n"
                        "      add_xsection(name='{1}', layer=2)\n"
                        "      add_stub(xsection='{0}', stub='{1}')".format(
                            xs_guide,
                            "stubname",
                            default_xs_name,
                            cfg.active_cell().cell_name,
                        )
                    )
                xs_guide = default_xs_name

            cfg.stubmap[xs_guide] = xs_guide
            xs_logic = xs_guide

    # Resolve pinstyle defaults before constructing the cache key. Otherwise,
    # different pinstyles with implicit pin settings all map to the same stub.
    style_id = nd.parse_pinstyle(pinstyle)
    style = cfg.pinstyles[style_id]
    if pinshape is None:
        pinshape = style["shape"]
    if pinsize is None:
        pinsize = style["size"]
    if pinlayer is None:
        pinlayer = nd.get_layer(style["layer"]).ID

    name = stubname(xs_guide[0], width, length, shape, pinshape, pinsize, pinlayer)
    if name in stubs.keys():
        return name

    # make a new stub:
    stubshapes = ["box", "circle"]
    arrow = make_pincell(
        layer=pinlayer,
        shape=pinshape,
        size=pinsize,
        style=style_id,
    )

    if width is None:
        width = 0

    with nd.Cell(name, instantiate=cfg.instantiate_stub, store_pins=False) as C:
        C.auxiliary = True
        C.default_pins("a0", "a0")
        nd.Pin("a0", chain=0).put(0)
        arrow.put(0)

        if cell is not None:
            cell.put()
        else:
            if length > 0:
                for lay, grow, acc, polyline in nd.layeriter(xs_logic):
                    (a1, b1), (a2, b2), c1, c2 = grow
                    if shape == "circle":
                        outline = geom.circle(radius=0.5 * length, N=32)
                    else:
                        # outline = geom.box(width=width+(b1-b2), length=length)
                        outline = [
                            (0, a2 * width + b2),
                            (0, a1 * width + b1),
                            (length, a1 * width + b1),
                            (length, a2 * width + b2),
                        ]
                    if abs((a2 * width + b2) - (a1 * width + b1)) > 0.0001:
                        nd.Polygon(layer=lay, points=outline).put(0, 0, 180)

                    if shape not in stubshapes:
                        logger.warning(
                            "stub shape '{}' not recognized, possible options are {}.".format(
                                shape, stubshapes
                            )
                        )
    stubs[name] = C
    return name  # name can have change to default_xs


def put_stub(
    pinname: str = None,
    length: float = None,
    shape: str = "box",
    pinshape: str = None,
    pinsize: float = None,
    pinlayer: Any = None,
    pinshow: bool = True,
    annotation_layer: Any = None,
    pinstyle: str = None,
    cell: str | Cell = None,
) -> None:
    """Add a xsection stub to one or more pins.

    The pinstyle is a key poining to a dict which contains the setting for the stub.
    These setting are overruled by the explicit keyword in the call, e.g. shape.

    The method put_stub() places a stub cell (pinshape cell + stub layers) on a Node if
    stub information (see below) has been defined for the xsection assigend to the pin.
    If no xsection has been defined for the pin, only the pincell will the created and used.
    If an annotation_layer is defined, the annotation is added to the parent cell.

    The xsection and width of a stub are obtained from its pin attributes.
    If no attributes are set, the stub layers are empty and the stubcell
    only contains the pincell. It is possible to supply a list of pins.

    The pinstyle is determined by the following sequence:
    1. use the pinstyle of the xsection, if set
    2. use the pinstyle 'default'
    3. update the pinstyle with explicit settings via the keyword parameters

    The pinshape is one of the following:

    1. A reference to a key in the cfg.pinshapes dictionary which contains
        the raisepin polygon description of which a pin cell is created.

    2. A cell.

    For a pin having attribute xs=None, only the pin is drawn.

    Args:
        pinname (str | list of str | None): name(s) of the pin(s) (default = None)
            For pinname=None (default) all chain-pins will obtain a stub.
        length (float): length of the stub (thickness into cell)
        shape (string | Cell): shape of the stub 'box' | 'cirlce' (default = 'box')
        pinshape (string): pinshape used in the stub
        pinsize (float): scaling factor of the pinshape (default = 1)
        layer (str | int | (int, int)): pin layer
        annotation_layer (str | int | (int, int)): annotation layer
        pinstyle (str): pin style name used to look up a dict with pinstyle settings.
            Default it will look in the xsection pinstyle setting. If that is None
            the pinstyle 'default' is used.
        pinshow (bool): set the pin show attribute (default=True)
        cell (str | Cell): reference to a cell to place the stub in.
            Default=None, which adds the stub to the active cell.

    Returns:
        None
    """
    if cell is not None:
        # add user defined cell as temporary active cell:
        if isinstance(cell, str):
            if cell in cfg.cellnames.keys():
                cfg.cells.append(cfg.cellnames[cell])
            else:
                nd.main_logger(
                    f"Trying to put a stub in unknown cell '{cell}'.", "error"
                )
                return
        else:
            cfg.cells.append(cell)
        nd.cfg.patchcell = True
    _cell = cfg.active_cell()

    # prepare pin:
    if pinname is None or pinname == []:
        pinname = [name for name, pin in _cell.pin.items() if pin.chain == 1]
    elif isinstance(pinname, str):
        pinname = [pinname]
    elif isinstance(pinname, nd.Node):
        pinname = [pinname.name]

    # prepare stub
    if isinstance(shape, nd.Cell):
        stubcell = shape
        shape = shape.cell_name
    else:
        stubcell = None

    # prepare pinstyles
    stylestr = None  # 'default'
    if cfg.validation_pinstyle is not None:
        pinstyle = cfg.validation_pinstyle

    pinstylenames = cfg.pinstyles.keys()
    if pinstyle in pinstylenames:
        stylestr = pinstyle
    elif pinstyle is not None:
        logger.warning(
            "pinstyle '{}' unknown. Using default instead. "
            "Known pinstyles: {}".format(pinstyle, pinstylenames)
        )

    # prepare annotation layer
    _annotation_layer = annotation_layer

    for p in pinname:
        _stylestr = stylestr

        node = _cell.pin[p]
        node.show = pinshow  # display pin name in layout and fingerprint
        if stubcell is not None:  # use existing Nazca cell for stub+pin
            name = f"stub_{shape}"
            if name not in stubs.keys():
                stubs[name] = stubcell
            stubs[name].put(node)
        else:
            if node.xs is None:  # pin cell only, no stub
                xs = None
                width = 0
            else:  # define stub + pin from style
                xs = node.xs
                if cfg.validation_pinstyle is None and _stylestr is None:
                    xs_pinstyle = nd.get_xsection(xs).pinstyle
                    if xs_pinstyle in pinstylenames and pinstyle is None:
                        _stylestr = xs_pinstyle
                    else:
                        _stylestr = (nd.cfg.default_pinstyle_name, nd.cfg.default_tech)
                if node.width is None:
                    width = 0
                # TODO: why allow str widths here?
                elif isinstance(node.width, str):
                    width = literal_eval(node.width)
                else:
                    width = node.width

            # make and place cell
            if xs is None:  # pin only
                arrow = make_pincell(
                    layer=pinlayer,
                    shape=pinshape,
                    size=pinsize,
                    style=_stylestr,
                )
                inst = arrow.put(node)
            else:  # stub
                if length is not None:
                    if isinstance(length, (float, int)):
                        stub_length = float(length)
                else:
                    stubstyle = nd.parse_pinstyle(_stylestr)
                    stub_length = nd.cfg.pinstyles[stubstyle].get("stub_length", 0)
                    if stub_length is None:
                        stub_length = 0.0
                name = _makestub(
                    xs_guide=xs,
                    width=width,
                    length=stub_length,
                    shape=shape,
                    pinshape=pinshape,
                    pinsize=pinsize,
                    pinlayer=pinlayer,
                    pinstyle=_stylestr,
                )

                # place stubs without drc check
                drc = cfg.drc
                cfg.drc = False
                if node.io & 1:
                    inst = stubs[name].put(node.rot(180), flip=True)
                else:
                    inst = stubs[name].put(node.rot(180))
                inst.sourcepin = (
                    node  # for accessing pin properties for cell visualisation
                )
                cfg.drc = drc

        # add annotation (keep outside of stub and pin cell, as these are reused for different pin names)
        if _stylestr is None:
            _stylestr = (cfg.default_pinstyle_name, cfg.default_tech)
        if _annotation_layer is None:
            annotation_layer = nd.cfg.pinstyles[_stylestr].get(
                "annotation_layer", False
            )
        else:
            annotation_layer = _annotation_layer
        # Move the annotation location for readability
        drc = cfg.drc  # switch off drc check for annotations
        cfg.drc = False
        if annotation_layer:
            anno = nd.Annotation(layer=annotation_layer, text=p)
            anno.put(node.move(*nd.cfg.pinstyles[_stylestr]["annotation_move"]))
            anno.sourcepin = node  # for accessing pin properties for cell visualisation
        if (
            cfg.store_pin_attr
        ):  # TODO: check how this overlaps with yaml pinstyle for validation.
            if node.type != "bbox":
                text = (
                    f"name: {node.name}\nwidth: {node.width}\nxs: {node.xs}\nxya: {node.fxya(digits=6)}\n"
                    f"flip: {node.io}\nremark: {node.remark}"
                )
                nd.Annotation(layer="bb_pin_attr", text=text).put(node)
        cfg.drc = drc

        # except Exception as E:
        #    mes = "Can't add stub in cell '{_cell.cell_name}' on pin '{p}'."
        #    logger.exception(mes)
        #    raise Exception(E)
    if cell is not None:
        nd.cfg.patchcell = False
        cfg.cells.pop(-1)


def validation_style(
    on: bool = True,
    stub_layer: str = "validation_stub",
    pin_style: dict = None,
    validation_layermapmode: str = "none",
    validation_layermap: dict = None,
) -> None:
    """Set layers and pinstyle and layermap for BB validation stubs.

    Args:
        on (bool): default=True, turn on validation style
        stub_layer (str): layer name of the stub.
        pin_style (dict): optional pinstyle dict for the arrow and stub.
        validation_layermapmode (str):
        validation_layermap (dict): {in_layer: out_layer}

    Returns:
        None
    """
    if not on:  # reset validation settings
        cfg.validation_pinstyle = None
        cfg.validation_stub_xs = None
        cfg.validation_layermapmode = "none"
        cfg.validation_layermap = None
        return

    _layer = nd.get_layer(stub_layer)
    nd.add_xsection(name="validation_stub")
    nd.add_layer(name="validation_stub", layer=_layer.layer, datatype=_layer.datatype)
    nd.add_layer2xsection(xsection="validation_stub", layer=_layer)

    nd.cfg.store_pin_attr = True

    if pin_style is None:
        validation_pinstyle = {
            "shape": "arrow_full",
            "size": 1.0,
            "layer": "bb_pin",  # use string name
            "annotation_layer": "bbox_pin_text",  # use string name
            "annotation_move": (0, 0),
            "stub_length": 1.0,
        }
        nd.add_pinstyle("validation", validation_pinstyle)
    else:
        pin_style["annotation_move"] = (0, 0)  # always force to pin location
        nd.add_pinstyle("validation", pin_style)

    # set global parameters that for overrideing the stub xs and the pinstyle:
    cfg.validation_pinstyle = parse_pinstyle("validation")
    cfg.validation_stub_xs = "validation_stub"

    cfg.validation_layermapmode = validation_layermapmode
    cfg.validation_layermap = validation_layermap


def export_bb2png(
    cellcalls: dict | list, path: str = "", close: bool = True, bbox_pins: bool = True
) -> None:
    """Create png image for all cells in <cellcalls>.

    Only the Cell objects are used from <cellcalls>, but it does accept as well
    the dict as needed in method 'bb_fingerprint'.

    cellcalls (dict | list of Cells): All the cells {function_call_str: cell_from_call} | list of Cells
    close (bool): close cell immediately after drawing (default = True)
    path (str): path for saving png files
    bbox_pins (bool): add pins to the bbox (default = True)

    Returns:
        None
    """
    export = True

    if isinstance(cellcalls, dict):
        cells = cellcalls.values()
    else:
        cells = cellcalls

    N = len(cells)

    for i, cell in enumerate(cells):
        print("{}/{}".format(i + 1, N))
        bbox_stubs_store = cfg.bbox_stubs
        cfg.bbox_stubs = bbox_pins
        if export:
            output = "file"
        else:
            output = None
        nd.export_plt(cell, output=output, path=path, title=cell.cell_paramsname)
        cfg.bbox_stubs = bbox_stubs_store
        plt.close("all")


def bb_fingerprint(
    cellcalls: dict[str, Cell],
    save: bool = False,
    filename: str = "fingerprint.json",
    infolevel: int = 0,
) -> dict:
    """Generate a dict with parameter list and pin list of a list off BBs.

    This generates a blueprint (aka fingerprint).

    Args:
        cellcalls (dict[str, Cell]): All the cells {function_call_str: cell_from_call}

    Returns:
        dict: Dictionary with building block info, Structure is as follows::

            {'<cellname>':
                {'pins':
                    { '<pinname>':
                        {'width': <value>,
                         'xs'   : <value>
                         'xya'  : (<x>, <y>, <a>)
                         'show' : <values>
                        }
                        , ...
                    },
                 'parameters':
                     {'<keyword>': <value>}
                     , ...
                 'paramsname'   : <value>,
                 'basename'     : <value>,
                 'groupname'    : <value>,
                 'module'       : <value>,
                 'function'     : <value>,
                 'length'       : <value>,
                 'width'        : <value>
                }
            }
    """
    fingerprint = {}
    cellcallsorted = sorted(
        cellcalls.items()
    )  # not effective for Python <3.6 with scrambled dict.
    for callstr, cell in cellcallsorted:
        if hasattr(cell, "group"):
            group = cell.group
        else:
            group = ""

        module = cell.module

        pinsetting = {}
        if infolevel > 0:
            logger.info(cell.cell_basename)
        for name, pin in sorted(cell.pin.items()):
            if name != "org":
                pinsetting[name] = {
                    "width": pin.width,
                    "xsection": pin.xs,
                    "pointer": [
                        float("{:.5f}".format(val + 1e-10)) for val in pin.xya()
                    ],
                    "show": pin.show,
                    "type": pin.type,
                    "remark": pin.remark,
                }
                if infolevel > 0:
                    logger.info(name, pinsetting[name])

        paramsetting = {}
        if cell.parameters is None:
            logger.debug(f"Empty parameters in {cell.cell_name}")
        else:
            try:
                for p in cell.parameters:
                    paramsetting[p] = cell.parameters[p]
            except Exception as e:
                logger.debug(
                    f"Failed to parse parameters in {cell.cell_name}, exception: {e}"
                )

        # bbox
        try:
            length = cell.length
        except AttributeError:
            logger.debug(f"Empty length in {cell.cell_name} setting it to None.")
            length = "None"
        try:
            width = cell.width
        except AttributeError:
            logger.debug(f"Empty width in {cell.cell_name} setting it to None.")
            width = "None"

        cellnameparameters = cell.properties.get("cellnameparameters", None)
        fingerprint[cell.cell_name] = {
            "pins": pinsetting,
            "parameters": paramsetting,
            "paramsname": cell.cell_paramsname,
            "cellnameparameters": cellnameparameters,
            "basename": cell.cell_basename,
            "group": group,
            "modulename": module,
            "function": callstr,
            "length": length,
            "width": width,
            "connect": (cell.default_in, cell.default_out),
        }

    if save:
        try:
            with open(filename, "w") as fp:
                json.dump(fingerprint, fp, indent=2, sort_keys=True)
            print(f"Saved fingerprint to {filename}")
        except Exception as E:
            print(f"ERROR in json.dump of fingeprint: {E}")
            nd.main_logger(f"ERROR in json.dump of fingeprint: {E}", "error")
    if infolevel > 1:
        pprint(fingerprint)
    return fingerprint


def validate_black_to_white_mapping(
    black2whiteMap: dict, allBBcells: list[Cell], infolevel: int = 0
) -> None:
    """Validate if all white and black boxes are mapped.

    By increasing the infolevel more information will be displayed on where
    black <-> white mappings are missing.

    Args:
        black2whiteMap (dict): {blackbox-basename: whitebox-function}
        allBBcells (list of Cell): all black box cells.
        infolevel: amount of feedback to stdout (default = 0)

    """

    if infolevel > 0:
        print("Validate black <-> white box mappings:")

    okay = True
    mesg = []
    # print("\nStatus of white-box implementation:")
    mappings = ""
    header = "   {0:30}{1}".format("BASENAME", "FUNCTION")
    black_in_map = list(black2whiteMap.keys())
    basenames = {cell.cell_basename: cell for cell in allBBcells}
    black_count = len(basenames)
    white_found = 0
    for basename, cell in sorted(basenames.items()):
        func = ""
        defined = "?"
        if basename in black_in_map:
            defined = "*"
            white_found += 1
            func = black2whiteMap[basename]
        mappings += "{0}  {1:30}{2}\n".format(defined, basename, func)

    black_orphan_count = black_count - white_found
    text = "Found {} black orphans".format(black_orphan_count)
    logger.info("{}".format(text))
    if black_orphan_count > 0:
        okay = False
        mesg.append(text)
        if infolevel > 0:
            print(header)
            print(mappings)

    white_orphans = set(black2whiteMap) - set(basenames.keys())
    white_orphan_count = len(white_orphans)
    text = "Found {} white orphans".format(white_orphan_count)
    logger.warning("{}".format(text))
    if white_orphan_count > 0:
        okay = False
        mesg.append("{}{}".format(text, "."))
        if infolevel > 0:
            logger.info(header)
            for name in white_orphans:
                logger.info("?  {:30}{}".format(name, black2whiteMap[name]))

    if not okay:
        logger.error("Incorrect white <-> black box mappings.")
        for m in mesg:
            logger.error("- {}{}".format(m, "."))
    else:
        logger.info("\nSuccesful black <-> white mapping.")


bbox_pinnames = [
    "lb",
    "lc",
    "lt",
    "tl",
    "tc",
    "tr",
    "rt",
    "rc",
    "rb",
    "br",
    "bc",
    "bl",
    "cc",
]


def put_boundingbox(
    pinname: str,
    length: float,
    width: float,
    raise_pins: bool = True,
    show_outline: bool = True,
    align: str = "lc",
    name: bool = True,
    params: bool = True,
    move: tuple[float, float, float] = (0, 0, 0),
    name_layer: str = None,
    prefix: str = "",
    add_properties: bool = True,
) -> None:
    """Create bounding box (bbox) cell inside the active cell.

    This function places a bbox cell and raises by default the bbox pins into
    the active cell. The bbox displays a bbox outline (can be switched off).
    By default it also adds the active cellname and parameters.

    Args:
        pinname (str): pin to place bbox on (center left of bbox)
        length (float): length of the bbox
        width (float): width of the bbox
        raise_pins (bool): raise bbox pins into active cell (default = True)
        outline (bool): draw bbox outline (default = True)
        align (str): align the bbox on the specified bbox pin <pinname> (default = 'lc')
        name (bool): display the (active) cell name in the bbox. (default = True)
        params (bool): add parameter annotation to the bbox
        move (tuple): move the bbox placement by (float, float, float)
        name_layer (str): name of the layer to be used for bbox name
        prefix (str): prefix to add to the bounding box pin names
        add_properties (bool): True, add to the cell properties the dimension of the bbox

    Returns:
        None
    """
    cell = cfg.active_cell()
    _paramsname = cell.cell_paramsname
    _parameters = cell.parameters
    with nd.Cell(name="bbox", instantiate=False) as C:
        C.default_pins("org", "org")
        if show_outline:
            outline = geom.box(length, width)
            nd.Polygon(layer="bbox", points=outline).put(0)

        stbs = cfg.bbox_stubs and show_outline
        nd.Pin(f"{prefix}lb", type="bbox", show=stbs).put(0, -0.5 * width, 180)
        nd.Pin(f"{prefix}lc", type="bbox", show=stbs).put(0, 0, 180)
        nd.Pin(f"{prefix}lt", type="bbox", show=stbs).put(0, 0.5 * width, 180)

        nd.Pin(f"{prefix}tl", type="bbox", show=stbs).put(0, 0.5 * width, 90)
        nd.Pin(f"{prefix}tc", type="bbox", show=stbs).put(0.5 * length, 0.5 * width, 90)
        nd.Pin(f"{prefix}tr", type="bbox", show=stbs).put(length, 0.5 * width, 90)

        nd.Pin(f"{prefix}rt", type="bbox", show=stbs).put(length, 0.5 * width, 0)
        nd.Pin(f"{prefix}rc", type="bbox", show=stbs).put(length, 0, 0)
        nd.Pin(f"{prefix}rb", type="bbox", show=stbs).put(length, -0.5 * width, 0)

        nd.Pin(f"{prefix}br", type="bbox", show=stbs).put(length, -0.5 * width, -90)
        nd.Pin(f"{prefix}bc", type="bbox", show=stbs).put(
            0.5 * length, -0.5 * width, -90
        )
        nd.Pin(f"{prefix}bl", type="bbox", show=stbs).put(0, -0.5 * width, -90)

        nd.Pin(f"{prefix}cc", type="bbox", show=cfg.bbox_stubs).put(0.5 * length, 0, 0)

        if stbs:
            pin_placement = {
                "bbox_left": [
                    f"{prefix}lt",
                    f"{prefix}tr",
                    f"{prefix}rb",
                    f"{prefix}bl",
                ],
                "bbox_right": [
                    f"{prefix}lb",
                    f"{prefix}tl",
                    f"{prefix}rt",
                    f"{prefix}br",
                ],
                "bbox_center": [
                    f"{prefix}lc",
                    f"{prefix}tc",
                    f"{prefix}rc",
                    f"{prefix}bc",
                ],
            }
            for _style, pins in pin_placement.items():
                style = nd.parse_pinstyle(_style)
                nd.put_stub(
                    pins,
                    pinshape=cfg.pinstyles[style]["shape"],
                    pinsize=cfg.pinstyles[style]["size"],
                    pinlayer=cfg.pinstyles[style]["layer"],
                    annotation_layer=cfg.pinstyles[style]["annotation_layer"],
                )

        if name:
            cellname(
                cellname=_paramsname,
                length=length,
                width=width,
                align="cc",
                name_layer=name_layer,
            ).put(C.pin[f"{prefix}cc"])
        if params:
            put_parameters(parameters=_parameters, pin=C.pin[f"{prefix}cc"])

    # options to align the bbox in this cell w.r.t. to its pins:
    align_shift = {
        f"{prefix}lb": (0, 0.5 * width),
        f"{prefix}lc": (0, 0),
        f"{prefix}lt": (0, -0.5 * width),
        f"{prefix}rb": (-length, 0.5 * width),
        f"{prefix}rc": (-length, 0),
        f"{prefix}rt": (-length, -0.5 * width),
        f"{prefix}bc": (-0.5 * length, 0.5 * width),
        f"{prefix}cc": (-0.5 * length, 0),
        f"{prefix}tc": (-0.5 * length, -0.5 * width),
    }
    dx = align_shift[f"{prefix}{align}"][0]
    dy = align_shift[f"{prefix}{align}"][1]

    box = C.put(cell.pin[pinname].move(dx, dy).move(*move))
    cell.length = length
    cell.width = width
    if add_properties:
        cell.add_property(
            {"dimension": {"length": length, "width": width, "area": length * width}}
        )

    if raise_pins:
        prefixed_pinnames = []
        for pinname in bbox_pinnames:
            prefixed_pinnames.append(f"{prefix}{pinname}")
        box.raise_pins(prefixed_pinnames, show=False)


def load_gdsBB(
    gdsfilename: str,
    cellname: str,
    pinfilename: str = None,
    newcellname: str = None,
    layermap: dict = None,
    cellmap: dict = None,
    flip: bool = False,
    flop: bool = False,
    scale: float = None,
    stubs: bool = True,
    native: bool = True,
    bbox: bool = False,
    bboxbuf: float = 0,
    hull=None,
    prefix: str = "",
    suffix: str = "_stubs",
    instantiate: bool = None,
    flat: bool = False,
    layermapmode: str = None,
) -> Cell:
    """Load a gds cell and the corresponding pin info from file.

    This function uses method 'load_gds' for loading the gds file
    and adds pins and stubs to the cell according to the pinfile.
    This creates building block cell with connectivity.
    If there is not pinfile available, then use method 'load_gds" instead.

    Format of the pin file, including the single line header:

    port, x, y, a, xs, w
    a0, 100, 0, 90, nazca, 2.0
    ...

    If stubs == True then both the stubs and the loaded GDS are instantiated
    inside the cell returned by this function.
    This to ensure that for this cell that the gds and stubs remain aligned
    under flipping and flopping.

    Args:
        gdsfilename (str): gds filename to import from
        cellname (str): cellname to import
        pinfilename (str): optional name of csv file containing pin info for stubs.
        newcellname (str): new cell name
        cellmap (dict): mapping of cellnames {cellname_in: celllname_out}
        layermap (dict): mapping of layer {number_in: number_out}
        flip (bool): mirror the gds without changing pin direction (default = False)
        flop (bool): mirror the gds with reversing pin direction (default = False)
        scale (float): scaling factor (default = 1.0). Use with great care
            as scaled building blocks will not make much sense from a functional
            prespective.
            pin positions will be scaled along with the gds, however,
            xs information, like 'width' will *not* be scaled
        stubs (bool): place stubs in the cell (default = True).
            The stub value also set the instantiation value of the returned cell
        native (bool): load gds into a Nazca native format (default = True)
        bbox (bool): add a bounding box if True (default = False)
        bboxbuf (float): add a buffer layer around the structure and the bounding box.
        prefix (str): prefix to add the cell name to avoid cellname clashes.
            See help(nazca.load_gds)) more info on cellname resolution
        suffix (str): suffix to indicate it is cell wuth stubs added (default = '_stubs')
        instantiate (bool): intantiate the returned cell

    Returns:
        Cell: Nazca Cell with the loaded gds and (if provided) pins and stubs.
    """
    if stubs:
        _instantiate = True
        bboxgds = False
        topbbox = bbox
    else:
        _instantiate = False
        bboxgds = bbox
        topbbox = False

    # instantiate override:
    if instantiate is None:
        instantiate = _instantiate

    with nd.Cell(
        prefix + cellname + suffix, instantiate=instantiate, autobbox=topbbox
    ) as C:
        # TODO: if instantiate is true the instance and gds file may get the same name
        #      causing a topology error in GDS.
        nd.load_gds(
            filename=gdsfilename,
            cellname=cellname,
            newcellname=newcellname,
            layermap=layermap,
            layermapmode=layermapmode,
            cellmap=cellmap,
            scale=scale,
            native=native,
            bbox=bboxgds,
            bboxbuf=bboxbuf,
            hull=hull,
            prefix=prefix,
            instantiate=instantiate,
            flat=flat,
        ).put(0, flip=flip, flop=flop)
        if flip:
            s = -1.0
        else:
            s = 1.0
        if pinfilename is not None:
            if not os.path.exists(pinfilename):
                nd.main_logger(
                    f"Pin file not found '{pinfilename}'. No pins and stubs placed.",
                    "error",
                )
            else:
                with open(pinfilename, newline="") as f:
                    rows = [row for row in csv.DictReader(f) if any(row.values())]
                for row in rows:
                    io = row.get("port") or ""
                    x = row.get("x") or ""
                    y = row.get("y") or ""
                    a = row.get("a") or ""
                    xs = row.get("xs") or ""
                    w = row.get("w") or ""
                    x = float(x) if x != "" else 0.0
                    y = float(y) if y != "" else 0.0
                    a = float(a) if a != "" else 0.0
                    try:
                        xs = xs.strip()
                        if xs == "" or xs.upper() == "NONE":
                            xs = None
                    except AttributeError:
                        logger.exception("xsection not parseble.")
                        xs = None
                    try:
                        w = float(w)
                    except ValueError:
                        if w not in (None, "", "None"):
                            logger.warning(
                                "load_gdsBB: Could not cast width to float on pin '{}': {}".format(
                                    io, w
                                )
                            )
                        w = 0.0
                    if scale is None:
                        scale = 1.0
                    nd.Pin(name=io, xs=xs, width=w).put(scale * x, s * scale * y, a)
                    if stubs:  # and xs is not None :
                        put_stub(io)
        if instantiate and bbox:
            C.autobbox = True
            C.bboxbuf = bboxbuf
    return C


def _PIL2array(img):
    return np.asarray(img, dtype=bool)


def image(
    name: str,
    layer: int = 1,
    size: int = 256,
    pixelsize: float = 1,
    threshold: float = 0.5,
    cellname: str = None,
    invert: bool = False,
    align: str = "cc",
    box_layer: Any = None,
    box_buf: float = 0,
    merge: bool = True,
    bg_white: bool = True,
) -> Cell:
    """Read an image file and return a nazca cell with the image.

    Image format can be png, jpg, gif, bpm, eps and others, as supported by Pillow.
    Note that the output resolution (size) does not exceed the image resolution.
    Increase <pixelsize> in this case to obtain a larger image in gds.

    A rectangular box can be added around the image by providing a <box_layer>.
    This box can be enlarged beyond the original image size by setting <box_buf> > 0.

    Args:
        name (str): name of the image file
        layer (int): layer number that the image will be written to (default 1)
        size (int): maximum bounding box size in pixels (default 256). Setting this to
            zero keeps the natural size of the image. This may be slow and can result
            in a large GDS file, depending on the image size.
        pixelsize (float): pixel size in micron (default 1)
        threshold (float): black/white threshold (default 0.5)
        cellname (str): Nazca cell name (default image filename)
        invert (bool): flag to invert black & white (default False)
        align (str): two character string for image alignment (default 'cc')
            allowed:
            lt, ct, rt,
            lc, cc, rc,
            lb, cb, rb

        box_layer (str | int | tuple): layer reference to generate a rectangular
            box behind the image, e.g. for tiling exclusion areas (NOFILL)
            (default = None)
        box_buf (float): extra buffer for the box_layer in um
        merge (bool): merge polygons after generating image (merge is True) or leave
            many small polygons (merge is False), which is faster but results in a
            somewhat larger file size.
        bg_white (bool): transparent background (if present) is interpreted as
            white (True, default) or black (False).

    Returns:
        Cell: cell with image

    Examples:
        Load an image in a cell and put and/or export it to gds::

            import nazca as nd

            logo = nd.image('mylogo.png', align='lb') # left/bottom alignment
            logo.put(0)
            nd.export_gds()

        or::

            import nazca as nd

            nd.export_gds(logo, filename='mylogo.gds')
    """
    if cellname is None:
        cellname = os.path.basename(name)
    p = pixelsize
    threshold = int(threshold * 255)
    a = {"lb", "cb", "rb", "lc", "cc", "rc", "lt", "ct", "rt"}
    if align not in a:
        mes = "Invalid alignment specification '{}' for image '{}'.".format(align, name)
        mes += "Allowed values are {}.".format(a)
        mes += "Using default value 'cc'"
        logger.warning(mes)
        align = "cc"
    halign = {"l": 0, "c": -0.5, "r": -1}
    valign = {"b": 0, "c": -0.5, "t": -1}

    # Treat transparent background as white (usually good) or black.
    im = Image.open(name).convert("RGBA")
    new = Image.new("RGBA", im.size, "WHITE" if bg_white else "BLACK")
    new.paste(im, mask=im)
    gray = new.convert("L")
    # resize keep aspect, only if smaller
    gray.thumbnail((size, size), Image.LANCZOS)
    bw = gray.point(lambda x: 0 if x < threshold else 255, "1")
    pix = _PIL2array(bw)
    width, height = bw.size
    width_tot = width * p + 2 * box_buf
    height_tot = height * p + 2 * box_buf
    logger.info(
        "Generating {}x{} pixels image of {:.0f}x{:.0f} um2, edge is {} um.".format(
            width, height, width * p, height * p, box_buf
        )
    )
    h0 = halign[align[0]] * width_tot
    v0 = valign[align[1]] * height_tot
    # Ensure pixel alignment on the minimum GDS grid size (default 1 nm)
    h0 = nd.gds_base.round_to_db_unit(h0) * nd.gds_base.gds_db_user
    v0 = nd.gds_base.round_to_db_unit(v0) * nd.gds_base.gds_db_user
    box_buf = nd.gds_base.round_to_db_unit(box_buf) * nd.gds_base.gds_db_user

    polygons = []

    with nd.Cell(cellname) as C:
        for line in range(height):
            x1 = x0 = h0 + box_buf
            lb = lw = 0
            y0 = (height - line) * p + v0 + box_buf
            for pixel in pix[line]:
                if pixel == invert:
                    lb += 1
                    if lw > 0:
                        x0 += lw * p
                        lw = 0
                else:
                    lw += 1
                    if lb > 0:
                        x1 = x0 + lb * p
                        xy = [(x0, y0), (x1, y0), (x1, y0 - p), (x0, y0 - p)]
                        polygons.append(xy)
                        x0 = x1
                        lb = 0
            if lb > 0:
                x1 = x0 + lb * p
                xy = [(x0, y0), (x1, y0), (x1, y0 - p), (x0, y0 - p)]
                polygons.append(xy)
        if merge:
            if polygons:
                polygons = merge_polygons(polygons)
            else:
                logger.warning(f"Resulting image is empty for '{name}'.")
        for pol in polygons:
            nd.Polygon(points=pol, layer=layer).put()

        if box_layer is not None:
            nd.Polygon(
                layer=box_layer,
                points=[
                    (0, 0),
                    (0, height_tot),
                    (width_tot, height_tot),
                    (width_tot, 0),
                ],
            ).put(h0, v0, 0)
    return C


def trace_image(
    name: str,
    layer: Any = 1,
    width: float = 0,
    height: float = 0,
    threshold: float = 0.5,
    cellname: str = "",
    invert: bool = False,
    align: str = "cc",
    box_layer: Any = None,
    box_buf: float = 0,
    bg_white: bool = True,
    upscale: float = 1,
) -> Cell:
    """Read an image file and return a nazca cell with the traced image. Although the
    trace process itself can be quite involved, the resulting polygons may be much
    smaller, which in the end could lead to faster and better rendering. All depends on
    the details of the image.

    Image format can be png, jpg, gif, bpm, eps and others, as supported by Pillow.

    A rectangular box can be added around the logo by providing a box_layer.
    This box can be enlarged beyond the original image size by setting box_buf > 0.

    Args:
        name (str): name of the image file
        layer (int): layer number that the image will be written to (default 1)
        width (float): width of image. If height is not specified, the aspect ratio is
            maintained.
        height (float): height of image. If width is not specified, the aspect ratio is
            maintained.
        threshold (float): black/white threshold (default 0.5)
        cellname (str): Nazca cell name (default image filename)
        invert (bool): flag to invert black & white (default False)
        align (str): two character string for image alignment (default 'cc')
            allowed:
            lt, ct, rt,
            lc, cc, rc,
            lb, cb, rb

        box_layer (str | int | tuple): layer reference to generate a rectangular
            box behind the image, e.g. for tiling exclusion areas (NOFILL)
            (default = None)
        box_buf (float): extra buffer for the box_layer in um
        bg_white (bool): transparent background (if present) is interpreted as
            white (True, default) or black (False).
        upscale (float): upscale resolution factor before tracing (default 1). Upscaling
            might improve a poor quality bitmap.

    Returns:
        Cell: cell with image

    Examples:
        Load an image (typically a logo) in a cell and put and/or export it to gds::

            import nazca as nd

            logo = nd.trace_image('mylogo.png', align='lb') # left/bottom alignment
            logo.put(0)
            nd.export_gds()

        or::

            import nazca as nd

            nd.export_gds(logo, filename='mylogo.gds')
    """
    if not cellname:
        cellname = os.path.basename(name)
    try:
        import potrace

        if hasattr(potrace, "potrace"):  # This is potracer
            invert = not invert  # They don't agree on CW and CCW
            mod = "potracer"
            get_xy = lambda p: (p.c.x, p.c.y)
        else:  # This is pypotrace
            mod = "pypotrace"
            get_xy = lambda p: (p.c[0], p.c[1])

    except ModuleNotFoundError:
        logger.warning(
            "Can't load module 'potrace'. Function trace_image() not available.\n"
            "For vector images, install 'pypotrace' (fast, but may be difficult to\n"
            "install) or install 'potracer' (slower but easier install).\n"
            "Or use (bitmap) nd.image()."
        )
        # Return empty cell.
        with nd.Cell(f"{cellname}_NoTrace") as C:
            pass
        return C
    threshold = int(threshold * 255)
    a = {"lb", "cb", "rb", "lc", "cc", "rc", "lt", "ct", "rt"}
    if align not in a:
        mes = f"Invalid alignment specification '{align}' for image '{name}'."
        mes += f"  Allowed values are {a}."
        mes += "  Using default value 'cc'"
        logger.warning("\n".join(mes))
        align = "cc"
    halign = {"l": 0, "c": -0.5, "r": -1}
    valign = {"b": 0, "c": -0.5, "t": -1}

    # Treat transparent background as white (usually good) or black.
    im = Image.open(name).convert("RGBA")
    if upscale != 1:
        new_width = int(upscale * im.width + 0.5)
        new_height = int(upscale * im.height + 0.5)
        im = im.resize((new_width, new_height), Image.Resampling.LANCZOS)

    new = Image.new("RGBA", im.size, "WHITE" if bg_white else "BLACK")
    new.paste(im, mask=im)
    gray = new.convert("L")
    gray.save("gray.png")
    if invert:
        bw = gray.point(lambda x: 0 if x < threshold else 255, "1")
    else:
        bw = gray.point(lambda x: 0 if x >= threshold else 255, "1")
    imwidth, imheight = bw.size

    # Scalings
    scalew: float = 0
    scaleh: float = 0
    if width:
        scalew = width / imwidth
    if height:
        scaleh = height / imheight
    if not scalew:
        scalew = scaleh
    if not scaleh:
        scaleh = scalew
    if not scaleh and not scalew:
        scalew, scaleh = 1, 1
    width = imwidth * scalew
    height = imheight * scaleh
    width_tot = width + 2 * box_buf
    height_tot = height + 2 * box_buf
    logger.info(
        f"Tracing image ({mod}) of "
        f"{width:.0f}x{height:.0f} um2, edge is {box_buf} um, t={threshold}"
    )
    h0 = halign[align[0]] * width_tot
    v0 = valign[align[1]] * height_tot

    pix = _PIL2array(bw)  # 2D numpy array
    bmp = potrace.Bitmap(np.flipud(pix))
    path = bmp.trace(alphamax=0.0)  # don't use bezier curves
    pols = []
    # _clipper2GDS takes clipper coordinates, to pervent rounding
    cscale = 1e8
    scaleh *= cscale
    scalew *= cscale
    for p in path:
        poly = [(x * scalew, y * scaleh) for point in p for x, y in [get_xy(point)]]
        pols.append(poly)
    # Handle polygons with holes.
    pols = nd.clipper._clipper2GDS(pols)  # doesn't need clipper in spite of the name
    # Write out the polygons
    with nd.Cell(cellname) as C:
        for pol in pols:
            pol = [(x / cscale, y / cscale) for (x, y) in pol]
            nd.Polygon(points=pol, layer=layer).put(h0 + box_buf, v0 + box_buf, 0)
        if box_layer is not None:
            nd.Polygon(
                layer=box_layer,
                points=[
                    (0, 0),
                    (0, height_tot),
                    (width_tot, height_tot),
                    (width_tot, 0),
                ],
            ).put(h0, v0, 0)
    return C


def trace_image2(
    name: str,
    layer: Any = 1,
    width: float = 0,
    height: float = 0,
    threshold: float = 0.5,
    cellname: str = "",
    invert: bool = False,
    align: str = "cc",
    box_layer: Any = None,
    box_buf: float = 0,
    bg_white: bool = True,
    upscale: float = 1,
) -> Cell:
    """Read an image file and return a nazca cell with the traced image. Although the
    trace process itself can be quite involved, the resulting polygons may be much
    smaller, which in the end could lead to faster and better rendering. All depends on
    the details of the image.
    Trace_image2 differs from trace_image because it uses tesselate to convert bezier
    curves, where trace_image only uses the control points and tesselation is not
    needed.

    Image format can be png, jpg, gif, bpm, eps and others, as supported by Pillow.

    A rectangular box can be added around the logo by providing a box_layer.
    This box can be enlarged beyond the original image size by setting box_buf > 0.

    Args:
        name (str): name of the image file
        layer (int): layer number that the image will be written to (default 1)
        width (float): width of image. If height is not specified, the aspect ratio is
            maintained.
        height (float): height of image. If width is not specified, the aspect ratio is
            maintained.
        threshold (float): black/white threshold (default 0.5)
        cellname (str): Nazca cell name (default image filename)
        invert (bool): flag to invert black & white (default False)
        align (str): two character string for image alignment (default 'cc')
            allowed:
            lt, ct, rt,
            lc, cc, rc,
            lb, cb, rb

        box_layer (str | int | tuple): layer reference to generate a rectangular
            box behind the image, e.g. for tiling exclusion areas (NOFILL)
            (default = None)
        box_buf (float): extra buffer for the box_layer in um
        bg_white (bool): transparent background (if present) is interpreted as
            white (True, default) or black (False).
        upscale (float): upscale resolution factor before tracing (default 1). Upscaling
            might improve a poor quality bitmap.

    Returns:
        Cell: cell with image

    Examples:
        Load an image (typically a logo) in a cell and put and/or export it to gds::

            import nazca as nd

            logo = nd.trace_image2('mylogo.png', align='lb') # left/bottom alignment
            logo.put(0)
            nd.export_gds()

        or::

            import nazca as nd

            nd.export_gds(logo, filename='mylogo.gds')
    """
    if not cellname:
        cellname = os.path.basename(name)
    try:
        import potrace

        if hasattr(potrace, "potrace"):  # This is potracer
            invert = not invert  # They don't agree on CW and CCW
            mod = "potracer"
            get_xy = lambda p: (p.c.x, p.c.y)
        else:  # This is pypotrace
            mod = "pypotrace"
            get_xy = lambda p: (p.c[0], p.c[1])

    except ModuleNotFoundError:
        logger.warning(
            "Can't load module 'potrace'. Function trace_image2() not available.\n"
            "For vector images, install 'pypotrace' (fast, but may be difficult to\n"
            "install) or install 'potracer' (slower but easier install).\n"
            "Or use (bitmap) nd.image()."
        )
        # Return empty cell.
        with nd.Cell(f"{cellname}_NoTrace") as C:
            pass
        return C
    threshold = int(threshold * 255)
    a = {"lb", "cb", "rb", "lc", "cc", "rc", "lt", "ct", "rt"}
    if align not in a:
        mes = f"Invalid alignment specification '{align}' for image '{name}'."
        mes += f"  Allowed values are {a}."
        mes += "  Using default value 'cc'"
        logger.warning("\n".join(mes))
        align = "cc"
    halign = {"l": 0, "c": -0.5, "r": -1}
    valign = {"b": 0, "c": -0.5, "t": -1}

    # Treat transparent background as white (usually good) or black.
    im = Image.open(name).convert("RGBA")
    if upscale != 1:
        new_width = int(upscale * im.width + 0.5)
        new_height = int(upscale * im.height + 0.5)
        im = im.resize((new_width, new_height), Image.Resampling.LANCZOS)

    new = Image.new("RGBA", im.size, "WHITE" if bg_white else "BLACK")
    new.paste(im, mask=im)
    gray = new.convert("L")
    gray.save("gray.png")
    if invert:
        bw = gray.point(lambda x: 0 if x < threshold else 255, "1")
    else:
        bw = gray.point(lambda x: 0 if x >= threshold else 255, "1")
    imwidth, imheight = bw.size

    # Scalings
    scalew: float = 0
    scaleh: float = 0
    if width:
        scalew = width / imwidth
    if height:
        scaleh = height / imheight
    if not scalew:
        scalew = scaleh
    if not scaleh:
        scaleh = scalew
    if not scaleh and not scalew:
        scalew, scaleh = 1, 1
    width = imwidth * scalew
    height = imheight * scaleh
    width_tot = width + 2 * box_buf
    height_tot = height + 2 * box_buf
    logger.info(
        f"Tracing image ({mod}) of "
        f"{width:.0f}x{height:.0f} um2, edge is {box_buf} um, t={threshold}"
    )
    h0 = halign[align[0]] * width_tot
    v0 = valign[align[1]] * height_tot

    pix = _PIL2array(bw)  # 2D numpy array
    bmp = potrace.Bitmap(np.flipud(pix))
    path = bmp.trace()  # don't use bezier curves
    pols = []
    sc = 1e8  # Scale to prevent rounding
    for curve in path:
        # Convert bezier to points, scale and move.
        pols.append(
            [
                [(x * scalew) * sc, (y * scaleh) * sc]
                for x, y in curve.tesselate(curve.adaptive)
            ]
        )
    # Handle polygons with holes.
    pols = nd.clipper._clipper2GDS(pols)  # doesn't need clipper in spite of the name
    # Write out the polygons
    with nd.Cell(cellname) as C:
        for pol in pols:
            nd.Polygon(points=[[x / sc, y / sc] for x, y in pol], layer=layer).put(
                h0 + box_buf, v0 + box_buf, 0
            )
        if box_layer is not None:
            nd.Polygon(
                layer=box_layer,
                points=[
                    (0, 0),
                    (0, height_tot),
                    (width_tot, height_tot),
                    (width_tot, 0),
                ],
            ).put(h0, v0, 0)
    return C

# =============================================================================
# predefined example cell for documentation examples
# =============================================================================
def example_cell() -> Cell:
    """Create a Nazca example cell.

    Returns:
        cell
    """
    with nd.Cell("example_cell") as example:
        s = nd.strt(length=20).put(0)
        b = nd.bend(angle=45).put()
        nd.Pin("a0", pin=s.pin["a0"]).put()
        nd.Pin("b0", pin=b.pin["b0"]).put()
    return example


dir_path = os.path.dirname(os.path.abspath(__file__))


def nazca_logo(
    layers: dict[str, Any] | None = None,
    cellname: str = "nazca_logo",
    scale: float = 1.0,
    bbox: bool = True,
) -> Cell:
    """Return the nazca logo as a cell.

    Args:
        layers (dict): gds layers of the logo. default = {'ring':1, 'box':2, 'bird':3}
        cell_name (str): default = 'nazca_logo'
        scale (float): scaling factor (default = 1)
    """
    if layers is None:
        layers = {"ring": 1, "box": 2, "bird": 3}
    return nd.load_gds(
        filename=os.path.join(dir_path, "nazca_logo.gds"),
        instantiate=True,
        cellname="nazca",
        newcellname=cellname,
        scale=scale,
        bbox=bbox,
        layermap={1: layers["ring"], 2: layers["box"], 3: layers["bird"]},
    )
