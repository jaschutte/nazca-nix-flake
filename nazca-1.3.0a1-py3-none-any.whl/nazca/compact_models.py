# -----------------------------------------------------------------------
#
# Nazca is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or (at
# your option) any later version.
#
# Nazca is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with Nazca.  If not, see <http://www.gnu.org/licenses/>.
# -----------------------------------------------------------------------
#
# @author: Jerom Baas, Ronald Broeke
# Bright Photonics B.V. (c) 2023,
# @email: info@brightphotonics.eu
#

"""Module to address functionality for compact models.

The module provides registration of compact models and ways to add compact models
 to Cells.

# TODO: To avoid relying on an approximate model, a flag needs to be set on how accurate it is
# TODO: Implement a logger that keeps track of every step taken in the background
"""
from __future__ import annotations
from copy import deepcopy
import importlib.util as importutil
from inspect import signature
from pathlib import Path
import sys
import os
import json
import hashlib
import pickle
from typing import TYPE_CHECKING, Any
import yaml
from pydantic import BaseModel, model_validator, ValidationError, ConfigDict, field_validator
from pydantic_core import InitErrorDetails, PydanticCustomError
from typing import List, Dict, Optional
import nazca.cfg as cfg
import nazca.netlist as netlist
from nazca.bb_util import bbox_pinnames
import nazca.cm_template_ic_geo as cm_template_ic_geo
from .yaml_utils import NazcaYAMLDumper, yloader
if TYPE_CHECKING:
    from nazca.netlist import Cell

# globals for compact_models.py
modulesmap = {
    "cm_template_ic_geo": cm_template_ic_geo,
}  # mapping to imported compact model python modules
_simulation_results = {}
_kwarg_warnings = []  # list to keep track of warnings for unused kwargs that have already been issued
compact_model_accuracies = [
    "undefined",  # no accuracy flag provided
    "phenomenological",  # high-level model with approximate behaviour
    "analytical", # based on analytical simulation
    "approximate-simulation",  # simple simulation result, with large approximations in the simulation
    "accurate-simulation",  # simulation with no large approximations, but may not be phase-accurate
    "foundry-data",  # data provided by the foundry
    "measured",  # data extracted from real world measurements
    "phase-accurate-simulation",  # simulation that accurately predicts phase and amplitude
]  # list of allowed accuracy levels for compact models, ordered by accuracy (from low accuracy to high accuracy)


def _is_tube_pin(name, pin=None):
    """Return True for tube pins based on prefix or pin/node metadata."""
    if str(name).startswith(cfg.tubepin_prefix):
        return True
    if pin is not None and (
        getattr(pin, "xs", None) == "tube"
        or getattr(pin, "type", None) == "tube"
    ):
        return True
    return False

# mask elements for which there is a geo model in nazca/compact_models/cm_geo.py
_mask_element_geo_models = {
    "straight": {"call": "strt", "module": "cm_template_ic_geo", "connections": [["a0", "b0"]]},
    "arc":  {"call": "arc", "module": "cm_template_ic_geo", "connections": [["a0", "b0"]]},
    "arc2":  {"call": "arc", "module": "cm_template_ic_geo", "connections": [["a0", "b0"]]},
    "taper":  {"call": "taper", "module": "cm_template_ic_geo", "connections": [["a0", "b0"]]},
    "ptaper":  {"call": "ptaper", "module": "cm_template_ic_geo", "connections": [["a0", "b0"]]},
    "sinecurve": {"call": "sinecurve", "module": "cm_template_ic_geo", "connections": [["a0", "b0"]]},
    # "euler": {"call": "euler", "module": "cm_template_ic_geo", "connections": [["a0", "b0"]]},
    # "cobra": {"call": "cobra", "module": "cm_template_ic_geo", "connections": [["a0", "b0"]]},
}

class ModelParameter(BaseModel):
    """Parameter class for compact models. Used to store and validate information for compact model parameters.

    Args:
        unit (str): Unit of the parameter
        min (Optional[float]): Optional minimum allowed value for the parameter
        max (Optional[float]): Optional maximum allowed value for the parameter
        default (Optional[float]): Optional default value for the parameter
    """
    model_config = ConfigDict(extra="ignore")

    unit: str
    min: Optional[float] = None
    max: Optional[float] = None
    default: Optional[float | str | List[float] | List[str]] = None


class ModeInfo(BaseModel):
    """Metadata for a compact-model mode on a physical pin."""

    model_config = ConfigDict(extra="forbid")

    label: str
    neff: Optional[float] = None
    TE_fraction: Optional[float] = None


def _cm_log_and_print(msg: str, level: str = "warning") -> None:
    """Log a compact-model message and make compatibility warnings visible."""
    netlist.compact_model_logger(msg, level)
    if level in {"warning", "error"}:
        print(f"{level.upper()}: {msg}")


def _context_msg(msg: str, source: str = None) -> str:
    if source:
        return f"{source}: {msg}"
    return msg


def _raise_cm_value_error(msg: str, source: str = None, cause: Exception = None) -> None:
    msg = _context_msg(msg, source)
    _cm_log_and_print(msg, "error")
    raise ValueError(msg) from cause


def _warn_deprecated_pins(source: str = None) -> None:
    msg = "'pins' in compact model definitions is deprecated and will be removed in future releases. Use 'pin_modes' instead."
    _cm_log_and_print(_context_msg(msg, source), "warning")


def _warn_pins_ignored(source: str = None) -> None:
    msg = "Both 'pin_modes' and deprecated 'pins' are defined. Using 'pin_modes' and ignoring 'pins'."
    _cm_log_and_print(_context_msg(msg, source), "warning")


def default_mode_label() -> str:
    """Return the configured default compact-model mode label."""
    return getattr(cfg, "default_mode_label", "m0")


def _log_implicit_default_mode(source: str = None) -> None:
    mode = default_mode_label()
    msg = f"Unqualified compact-model pin labels are treated as mode '{mode}'."
    netlist.compact_model_logger(_context_msg(msg, source), "info")


def split_channel_label(label: str) -> tuple[str, str | None]:
    """Return physical pin and optional mode label from a compact-model channel label."""
    delimiter = cfg.pin_mode_delimiter
    if delimiter and delimiter in label:
        pin, mode = label.split(delimiter, 1)
        return pin, mode
    return label, None


def format_channel_label(pin: str, mode: str = None, legacy: bool = False) -> str:
    """Format a compact-model channel label using the configured delimiter."""
    if mode in (None, ""):
        mode = default_mode_label()
    return f"{pin}{cfg.pin_mode_delimiter}{mode}"


def _mode_label(mode: str | ModeInfo | dict) -> str:
    if isinstance(mode, ModeInfo):
        return mode.label
    if isinstance(mode, dict):
        return ModeInfo(**mode).label
    return ModeInfo(label=mode).label


def _normalize_pin_modes(
    pin_modes: dict[str, list[str | ModeInfo | dict]] | None,
    source: str = None,
) -> dict[str, list[ModeInfo]] | None:
    """Normalize compact pin-mode forms to ModeInfo objects."""
    if pin_modes is None:
        return None

    normalized = {}
    for pin, modes in pin_modes.items():
        if modes is None:
            modes = []
        normalized_modes = []
        labels = []
        for mode in modes:
            try:
                info = mode if isinstance(mode, ModeInfo) else ModeInfo(**mode) if isinstance(mode, dict) else ModeInfo(label=mode)
            except Exception as exc:
                _raise_cm_value_error(
                    f"Invalid mode entry '{mode}' for compact-model pin '{pin}'.",
                    source,
                    cause=exc,
                )
            if info.label in labels:
                _raise_cm_value_error(f"Duplicate mode label '{info.label}' for compact-model pin '{pin}'.", source)
            labels.append(info.label)
            normalized_modes.append(info)
        normalized[pin] = normalized_modes
    return normalized


def _pin_modes_from_pins(pins: list[str] | None) -> dict[str, list[ModeInfo]] | None:
    if pins is None:
        return None
    return {pin: [ModeInfo(label=default_mode_label())] for pin in pins}


def _pin_modes_from_connections(connections: list[list[str]] | None) -> dict[str, list[ModeInfo]]:
    pin_modes = {}
    if connections is None:
        return pin_modes

    for connection in connections:
        for pin in connection:
            pin_modes.setdefault(pin, [])
            mode = default_mode_label()
            if mode not in [info.label for info in pin_modes[pin]]:
                pin_modes[pin].append(ModeInfo(label=mode))
    return pin_modes


def model_physical_pins(model_info: "ModelInfo") -> list[str]:
    """Return the physical compact-model pins."""
    if model_info.pin_modes is None:
        return []
    return list(model_info.pin_modes.keys())


def model_channel_label(model_info: "ModelInfo", channel: str) -> str:
    """Map a declared connection label to the S-matrix channel label."""
    pin, mode = split_channel_label(channel)
    mode = mode or default_mode_label()
    return format_channel_label(pin, mode)


def model_channel_labels(model_info: "ModelInfo", pin: str = None) -> list[str]:
    """Return S-matrix channel labels for a model or one physical pin."""
    if model_info.pin_modes is None:
        return []
    channels = []
    for physical_pin, modes in model_info.pin_modes.items():
        if pin is not None and physical_pin != pin:
            continue
        for mode in modes:
            channels.append(format_channel_label(physical_pin, mode.label))
    return channels


def model_mode_labels(model_info: "ModelInfo", pin: str) -> list[str]:
    """Return declared mode labels for a physical pin."""
    if model_info.pin_modes is None or pin not in model_info.pin_modes:
        return []
    return [mode.label for mode in model_info.pin_modes[pin]]


def normalize_model_info(model_info: "ModelInfo", source: str = None) -> "ModelInfo":
    """Normalize deprecated pins and implicit channels to canonical pin_modes."""
    source = source or model_info.source
    if model_info.pin_modes:
        model_info.pin_modes = _normalize_pin_modes(model_info.pin_modes, source=source)
        if model_info.pins is not None:
            _warn_deprecated_pins(source)
            _warn_pins_ignored(source)
    elif model_info.pins is not None:
        _warn_deprecated_pins(source)
        model_info.pin_modes = _pin_modes_from_pins(model_info.pins)
    else:
        model_info.pin_modes = _pin_modes_from_connections(model_info.connections)

    if model_info.connections:
        for connection in model_info.connections:
            for pin in connection:
                physical_pin, mode = split_channel_label(pin)
                if mode is not None:
                    _raise_cm_value_error(
                        f"Connection '{pin}' uses a modal channel label. Compact-model connections must use physical pin names only.",
                        source,
                    )
                pin = physical_pin
                if pin not in model_info.pin_modes:
                    _raise_cm_value_error(
                        f"Connection pin '{pin}' references undeclared compact-model pin '{pin}'.",
                        source,
                    )

    return model_info


def _model_source(source: str, tech: str, sigtype: str, cellname: str, instance_label: str = None) -> str:
    """Return a compact identifier for diagnostics."""
    model_id = f"{tech}/{sigtype}/{cellname}"
    if instance_label is not None:
        model_id = f"{model_id}[instance: {instance_label}]"
    return f"{source}: {model_id}" if source else model_id


class ModelInfo(BaseModel):
    """Model info class for compact model library. This class is used to store information on a compact model for a
    specific cell.

    At the very least, a compact model should contain 'connections'. For compact models that use python functions, it
    should also contain 'call' and 'module'.
    The fields 'parameters', 'nonlinear' and 'api' provide some extra functionalities, but are not required.
    The fields 'pin_modes', 'source', 'pins', 'sigtype' and 'tech' exists only for metadata purposes

    Args:
        connections (List[List[str]]): List of connections that are described by the compact model. The
            connections are reciprocal, i.e. if ['a0', 'b0'] is in the list, ['b0', 'a0'] is also in the list.
        call (Optional[str]): Name of the function that is called to evaluate the compact model.
        module (Optional[str]): Reference to module that contains the compact model function call.
        parameters (Optional[Dict[str, ModelParameter]]): Dictionary containing the parameter metadata of the compact model.
        nonlinear (Optional[bool]): Flag is the model is nonlinear (depends on the input power). Default is False.
        api (Optional[str]): Optional string reference to the server api, used when a compact model was loaded from a server
        source (Optional[str]): Path to the source yaml file that describes this compact model.
        pin_modes (Optional[Dict[str, List[ModeInfo]]]): Modes per pin. This is used for netlist generation.
        pins (Optional[str]): Deprecated pins in the compact model. Use pin_modes instead.
        sigtype (Optional[str]): Signal type of the compact model.
        tech (Optional[str]): The tech of the compact model.
        accuracy (Optional[str]): Flag for the accuracy of this compact model.
    """
    model_config = ConfigDict(extra='forbid')

    # required, but can come from defaults in the header
    connections: Optional[List[List[str]]] = None

    # optional, but required for model functions
    call: Optional[str] = None
    module: Optional[str] = None

    # optional functional fields
    # Dictionary of all compact model parameters, so:
    # - pcell data (length, radius, width, etc...),
    # - stimuli (wl, voltage, current),
    # - miscellaneous (temperature, humidity, strain).
    parameters: Optional[Dict[str, ModelParameter]] = None
    nonlinear: Optional[bool] = False
    api: Optional[str] = None

    # optional metadata fields
    source: Optional[str] = None
    pin_modes: Optional[Dict[str, List[ModeInfo]]] = None
    pins: Optional[List[str]] = None
    accuracy: Optional[str] = "undefined"

    @field_validator('pin_modes', mode='before')
    def validate_pin_modes(cls, value):
        return _normalize_pin_modes(value)

    @field_validator('accuracy')
    def validate_accuracy(cls, v):
        """ensure accuracy is defined in compact_model_accuracies"""
        if v not in compact_model_accuracies:
            # Log the error if the accuracy is not valid
            msg = f"Invalid accuracy '{v}' for compact model. " \
                  f"\n\tAccuracy must be one of {compact_model_accuracies}. \n\tSetting accuracy to 'undefined'"
            netlist.compact_model_logger(msg=msg, level="error")
            return "undefined"
        return v

class _CMDefaults(BaseModel):
    """Defaults for a compact model library. These defaults are applied to all cells in the library if they do not
    contain the relevant information themselves.

    NB: This is only used for validating compact model libraries

    Args:
        module (Optional[str]): Optional path of the default module with compact model functions
        connections (Optional[List[List[str]]]): List of default connections that are described by the compact model.
            The connections are reciprocal, i.e. if ['a0', 'b0'] is in the list, ['b0', 'a0'] is also in the list.
        accuracy (Optional[str]): Default accuracy for compact models. Must be one of the accuracies in compact_model_accuracies
    """
    model_config = ConfigDict(extra='forbid')

    module: Optional[str] = None
    connections: Optional[List[List[str]]] = None
    accuracy: Optional[str] = None


class _CMModel(BaseModel):
    """A single cell's model definition, including an optional set of instance-specific overrides.

    NB: This is only used for validating compact model libraries.

    Args:
        model (ModelInfo): ModelInfo for this compact model
        instance_models (Optional[Dict[str, ModelInfo]]): Optional set of instance labels and corresponding ModelInfo
            fields that are to be overwritten for these specific instance labels.
    """
    model_config = ConfigDict(extra='forbid')

    model: ModelInfo
    instance_models: Optional[Dict[str, ModelInfo]] = None

class _CMCells(BaseModel):
    """A mapping from cell names to their corresponding model configurations.

    NB: This is only used for validating compact model libraries

    Args:
        cells (Dict[str, _CMModel]): Dictionary mapping cells to the corresponding _CMModel
    """
    model_config = ConfigDict(extra='forbid')

    cells: Dict[str, _CMModel]

class _CMSigtypes(BaseModel):
    """A grouping of cells/models under a specific signal type (e.g., 'ampl', 'loss').

    NB: This is only used for validating compact model libraries

    Args:
        sigtypes (Dict[str, _CMCells]): Dictionary mapping signal types to _CMCells
    """
    model_config = ConfigDict(extra='forbid')

    sigtypes: Dict[str, _CMCells] = None

class _CompactModelHeader(BaseModel):
    """Class to validate compact model header files.

    NB: This is only used for validating compact model libraries

    Args:
        defaults (_CMDefaults): Defaults for the compact model library. These defaults are applied to all cells in the
            library if they do not contain the relevant information themselves.
        technologies (Dict[str, _CMSigtypes]): Dictionary mapping technologies to their corresponding model libraries
        source (Optional[str]): Path to the yaml file that was used to generate this library.
    """
    model_config = ConfigDict(extra='forbid')

    defaults: Optional[_CMDefaults] = _CMDefaults()
    technologies: Dict[str, _CMSigtypes]
    source: Optional[str] = None

    @model_validator(mode='wrap')
    def validate_yaml(self, handler):
        """Custom model validator for the HeaderLibrary class.

        Performs the following checks:
            - For each model, connections is defined (either directly or through defaults)
            - If a model contains a call, check if the module is defined (either directly or through defaults)
            - Standard pydantic validation of the model

        All validation errors are collected, and logged in a single custom error msg.
        Errors are custom to make it easy for uses to find and correct the problem in the header library file.
        """
        # collect all validation errors so that they can be output at once
        validation_errors = []

        defaults = self.get('defaults', {})
        source = self.get('source')

        # validate default accuracy
        default_accuracy = defaults.get("accuracy", None)
        if default_accuracy is not None and default_accuracy not in compact_model_accuracies:
            validation_errors.append(
                InitErrorDetails(
                    type=PydanticCustomError(
                        "Invalid default accuracy",
                        f"{source}: Invalid default accuracy '{default_accuracy}'. "
                        f"\n\tAllowed values: {compact_model_accuracies}."
                    ),
                    input="defaults.accuracy",
                )
            )

        # check if module and connections are defined in the model or in the defaults, and validate model accuracies
        for technology, sigtype_info in self.get("technologies", {}).items():
            for sigtype, cell_info in sigtype_info.get("sigtypes", {}).items():
                for cell, model_info in cell_info.get("cells", {}).items():
                    if model_info["model"].get("connections") is None and (defaults is None or defaults.get("connections") is None):
                        validation_errors.append(
                            InitErrorDetails(
                                type=PydanticCustomError(
                                    "Missing connections",
                                    f"{source}: Missing 'connections' for model '{technology}/{sigtype}/{cell}'."
                                ),
                                input="connections",
                            )
                        )

                    if model_info["model"].get("call", None):
                        # if a call is defined, there should also be a corresponding module
                        if model_info["model"].get("module") is None and (defaults is None or defaults.get("module") is None):
                            validation_errors.append(
                                InitErrorDetails(
                                    type=PydanticCustomError(
                                        "Missing module",
                                        f"{source}: Missing 'module' for model '{technology}/{sigtype}/{cell}'."
                                    ),
                                    input="module",
                                )
                            )

                    # validate if accuracy value is allowed (that is, in compact_model_accuracies)
                    accuracy = model_info["model"].get("accuracy", None)
                    if accuracy:
                        if accuracy not in compact_model_accuracies:
                            validation_errors.append(
                                InitErrorDetails(
                                    type=PydanticCustomError(
                                        "Invalid accuracy",
                                        f"{source}: Invalid accuracy '{accuracy}' for model '{technology}/{sigtype}/{cell}'."
                                        f"\n\tAllowed values: {compact_model_accuracies}."
                                    ),
                                    input="accuracy",
                                )
                            )

        validated_self = None
        try:
            validated_self = handler(self)
        except ValidationError as e:
            # Generate custom error messages for the validation errors that specify the location of the yaml file so
            # that the user can easily find the file responsible for the error.
            for error in e.errors():
                loc = ''
                for _loc in error["loc"]:
                    loc += f'{_loc}.'
                loc = loc[:-1]
                validation_errors.append(
                    InitErrorDetails(
                        type=PydanticCustomError(
                            f"{error['type']}",
                            f"Error of type {error['type']} for {loc} in {source}: {error['msg']}.",
                        ),
                        input=f"{error['input']}",
                    )
                )

        if validation_errors:
            raise ValidationError.from_exception_data(title=source, line_errors=validation_errors)

        return validated_self

class CompactModelLibrary(BaseModel):
    """Class for storing the compact model library. 
    
    This class is used to add or retrieve information on a compact model library.

    Args:
        technologies Dict[str, _CMSigtypes]: Dictionary containing the model library, organized per technology
    """
    technologies: Dict[str, _CMSigtypes]

    def _add_model(
        self,
        tech: str,
        sigtype: str,
        cellname: str,
        model_info: ModelInfo,
        instance_models: Optional[Dict[str, ModelInfo]] = None,
    ):
        """Internal method to add a model to the compact model library.

        This populates the internal technology/signal-type/cell hierarchy with a new
        model definition. If the technology or signal type does not exist yet, they
        will be created on the fly.

        Note:
            This method is intended for internal use only. Use `add_model()` to add compact models instead

        Args:
            tech (str): Technology identifier
            sigtype (str): Signal type identifier.
            cellname (str): Name of the model cell.
            model_info (ModelInfo): Dictionary containing model-level data.
            instance_models (Optional[Dict[str, Dict]]): Optional mapping of instance labels to alternate models
        """
        # Check if technology already exists, if not, create it
        if tech not in self.technologies:
            self.technologies[tech] = _CMSigtypes(sigtypes={})

        # Check if signal type already exists within the technology, if not, create it
        if sigtype not in self.technologies[tech].sigtypes:
            self.technologies[tech].sigtypes[sigtype] = _CMCells(cells={})

        # Check if the cell already exists, and raise an error if it does
        if cellname in self.technologies[tech].sigtypes[sigtype].cells:
            # TODO implement optional overwriting of models
            msg = f"{model_info.source}: Model '{tech}/{sigtype}/{cellname} has already been registered"
            netlist.compact_model_logger(msg, 'error')
        else:
            # Add the new cell only if it does not already exist
            self.technologies[tech].sigtypes[sigtype].cells[cellname] = _CMModel(
                model=model_info,
                instance_models=instance_models
            )

    def show(
        self,
        show_model_functions: bool = True,
        show_source_file: bool = True,
        sigtype: str | None = None,
        ignore_interconnects: bool = False,
    ) -> None:
        """
        Print all models and their associated function

        Args:
            show_model_functions (bool): Print the file location of the model function.
            show_source_file (bool): Print the file location of the source yaml. Ignored if show_model_functions is False.
            sigtype (str): Only show the models for a certain sigtype
            ignore_interconnects (bool): Ignore any default interconnect models that were automatically generated by Nazca.

        Returns:
            None
        """
        print('----------------Compact model library----------------')
        for tech_name, sigtypes in self.technologies.items():
            if not sigtypes or not sigtypes.sigtypes:
                continue
            print(f"Technology: {tech_name}")

            for _sigtype, cells in sigtypes.sigtypes.items():
                if sigtype is not None and _sigtype != sigtype:
                    continue
                print(f"  Sigtype: {_sigtype}")
                for cell_name, cm_model in cells.cells.items():
                    # Default model
                    def_model = cm_model.model
                    if ignore_interconnects and def_model.module == "cm_template_ic_geo":
                        continue
                    print(f"    Cell: {cell_name}")
                    if show_model_functions:
                        msg = f"      [model] Function: {def_model.module}/{def_model.call}()"
                        if show_source_file:
                            msg += f" | Source: {def_model.source}"
                        print(msg)

                    # Instance models
                    if cm_model.instance_models:
                        for inst_label, model in cm_model.instance_models.items():
                            # Inherit module and source from the default model if not specified
                            inherited_module = model.module or def_model.module
                            inherited_source = model.source or def_model.source

                            if ignore_interconnects and "cm_template_ic_geo.yaml" in inherited_source:
                                continue
                            if show_model_functions:
                                msg = f"      [instance: {inst_label}] Function: {inherited_module}/{model.call}()"
                                if show_source_file:
                                    msg += f" | Source: {inherited_source}"
                                print(msg)

        print('-----------------------------------------------------')


compact_model_library = CompactModelLibrary(technologies={})


class InstanceModel(BaseModel):
    circuit: str | None  # name of the circuit (pointer into topology.circuits)
    cell_id: str # name of the cell (pointer into compact_models.technologies[tech].sigtypes[sigtype].cells)
    tech: str
    instance_label: str
    pcell_data: dict[str, Any] # Dictionary containing Parameteric Cell data. Such as length, angle, radius, width, etc...


class CircuitModel(BaseModel):
    cell_id: str  # cell ID
    tech: str  # technology string
    instances: dict[str, InstanceModel]  # instances contained in the cell
    pins: list[str]  # list of pins
    raised_pins: dict[str, dict[str, str]]  # raised pins
    connections: list[list[dict[str, str]]]  # pin connectivity
    topcell: bool  # boolean to indicate if this is the topcell


class CircuitTopology(BaseModel):
    # Circuit topology
    topcell: str
    circuits: dict[str, CircuitModel]


class CircuitNetlist(BaseModel):
    """Universal netlist (uNetlist) format combining topology and compact models."""
    topology: CircuitTopology
    compact_models: CompactModelLibrary

    def save(self, filename: str | Path) -> None:
        """Serialize the netlist to YAML."""
        with open(filename, "w") as f:
            yaml.dump(self.model_dump(), f, Dumper=NazcaYAMLDumper, default_flow_style=False, sort_keys=False)


def _load_and_validate_yaml(yaml_file: str | Path) -> _CompactModelHeader:
    """Load a compact-model YAML header and validate it against _CompactModelHeader.

    Args:
        yaml_file (str | Path): Path to the YAML file.

    Returns:
        _CompactModelHeader: Validated header data.

    Raises:
        ValidationError: If the YAML content does not match the schema.
    """

    with open(yaml_file, 'r') as f:
        data = yaml.load(f, Loader=yloader)

    return _CompactModelHeader(**data, source=str(yaml_file))


def register_compact_model(
    header_file: str | Path,
    _xs: str = None,
    root: str | Path = None,
) -> None:
    """Register compact models from a header YAML file in compact_model_library.

    The header is validated first. Defaults are applied per model, pins are
    derived from connections when omitted, model modules are resolved and
    imported when possible, and the resulting models are stored in the
    module-level compact_model_library.

    Args:
        header_file (str | Path): YAML header file that maps cells to compact models.
        _xs (str | None): Optional cross-section suffix appended to
            auto-generated interconnect model names.
        root (str | Path | None): Replacement for ``$CM_ROOT`` in module paths.
            When omitted, module paths remain relative to the header file.

    Returns:
        None
    """
    yaml_file = Path(header_file)
    if not yaml_file.is_file():
        netlist.compact_model_logger(f"Compact model header file '{yaml_file}' not found", "error")
        print(f"ERROR: Compact model header file '{yaml_file}' not found")
        return
    model_header = _load_and_validate_yaml(yaml_file)

    # obtain defaults
    defaults = model_header.defaults
    if defaults:
        default_module = defaults.module
        default_connections = defaults.connections
        default_accuracy = defaults.accuracy
    else:
        default_module = None
        default_connections = None
        default_accuracy = None

    modules_not_found = []

    for technology, sigtype_info in model_header.technologies.items():
        for sigtype, cell_info in sigtype_info.sigtypes.items():
            for cellname, info in cell_info.cells.items():
                model_info = info.model
                instance_models = info.instance_models
                model_source = _model_source(str(yaml_file), technology, sigtype, cellname)

                # parse defaults
                model_info.connections = model_info.connections or default_connections
                if model_info.accuracy == "undefined" and default_accuracy:
                    model_info.accuracy = default_accuracy
                module = model_info.module or default_module
                if module is not None:
                    module = module.replace("$CM_ROOT", str(root) if root is not None else ".")

                # set source to absolute path of the yaml file
                model_info.source = os.path.abspath(yaml_file)
                model_info = normalize_model_info(model_info, source=model_source)

                if instance_models:
                    for instance_label, instance_model_info in instance_models.items():
                        instance_model_info.connections = instance_model_info.connections or model_info.connections
                        if instance_model_info.pin_modes is None and instance_model_info.pins is None:
                            instance_model_info.pin_modes = model_info.pin_modes
                        if instance_model_info.accuracy == "undefined" and model_info.accuracy != "undefined":
                            instance_model_info.accuracy = model_info.accuracy
                        instance_model_info.source = instance_model_info.source or model_info.source
                        normalize_model_info(
                            instance_model_info,
                            source=_model_source(str(yaml_file), technology, sigtype, cellname, instance_label),
                        )

                # update cellname for auto generated models for interconnects
                if _xs is not None:
                    cellname = f"{cellname}_{_xs}"

                # import python module containing the model function
                if module is None:
                    pass
                elif os.path.isfile(os.path.join(yaml_file.parents[0], module)):
                    # module path relative to yaml file
                    module = os.path.join(yaml_file.parents[0], module)
                    _import_module(str(module), module)
                    model_info.module = str(module)
                elif os.path.isfile(os.path.abspath(Path(module))):
                    # module path relative to python file from which register_compact_model() is called
                    module = os.path.abspath(Path(module))
                    _import_module(str(module), module)
                    model_info.module = str(module)
                else:
                    model_info.module = str(module)
                    if module not in modules_not_found:
                        msg = f"Error for library '{yaml_file}': Module at '{module}' not found"
                        netlist.compact_model_logger(msg, "error")
                        modules_not_found.append(module)

                if module is not None and module not in modules_not_found:
                    # check if the call is actually present in the module:
                    if not hasattr(modulesmap.get(model_info.module, {}), model_info.call):
                        msg = f"Error for library '{yaml_file}': Model function '{model_info.call}' for cell '{cellname}' " \
                              f"not found in module '{model_info.module}'."
                        netlist.compact_model_logger(msg, 'error')

                # store compact model in Nazcas compact_model_library
                compact_model_library._add_model(
                    tech=technology,
                    sigtype=sigtype,
                    cellname=cellname,
                    model_info=model_info,
                    instance_models=instance_models,
                )


def merge_unetlist_and_header(
    unetlist_file: str | Path,
    header_file: str | Path,
    output_file: str | Path = None,
) -> CircuitNetlist:
    """Load a uNetlist, register compact models from a header file, and return the enriched netlist.

    The topology from unetlist_file is kept unchanged. Compact models are
    registered through register_compact_model(), so the module-level
    compact_model_library is also updated as a side effect.

    Args:
        unetlist_file (str | Path): Path to the uNetlist YAML file.
        header_file (str | Path): Path to the compact-model header YAML file.
        output_file (str | Path | None): Optional output path for the enriched netlist.

    Returns:
        CircuitNetlist: Netlist with topology from unetlist_file and compact
        models replaced by the registered library.
    """
    unetlist_file = Path(unetlist_file)
    header_file = Path(header_file)

    # Load the unetlist topology
    with unetlist_file.open() as f:
        data = yaml.load(f, Loader=yloader)
        unetlist = CircuitNetlist(**data)

    # Register the compact models from the header file using Nazca's logic
    # This handles all processing: defaults application, pins generation, source tracking, etc.
    register_compact_model(header_file)

    # Enrich the unetlist with topology and registered compact models
    unetlist.compact_models = compact_model_library

    # Write the enriched unetlist to file
    if output_file is not None:
        unetlist.save(output_file)
        print(f"Enriched unetlist written to: {output_file}")
    
    return unetlist


def _import_module(module_name, file_path):
    """Import a compact-model module from file.

    Args:
        module_name (str): name id for the module.
        file_path (str): path to the compact model module file including the filename.

    Returns:
        None
    """
    if module_name in modulesmap:
        # module already imported
        return
    spec = importutil.spec_from_file_location(module_name, file_path)
    modulesmap[module_name] = importutil.module_from_spec(spec)  # "module" is now the modulename
    spec.loader.exec_module(modulesmap[module_name])


def add_model(
    tech: str,
    sigtype: str,
    cellname: str,
    model,
    connections=None,
    pin_modes=None,
    parameters=None,
    nonlinear=None,
    accuracy=None,
    pins=None,
) -> None:
    """User-level function to add model to compact model at runtime.

    NB: It is best practice to define compact models in a compact model header file, and add these using
    register_compact_model(). This function is intended as a 'quick' solution to just check something.

    Args:
        tech (str): Technology identifier for the model
        sigtype (str): Signal type identifier for the model.
        cellname (str): Name of the cell to which this model belongs.
        model (Dict | ModelInfo | function): Model to add, can be either a dictionary, ModelInfo object or a function.
        connections (List[List[str]]): Optional list of connections that are described by the compact model. The
            connections are reciprocal, i.e. if ['a0', 'b0'] is in the list, ['b0', 'a0'] is also in the list.
            This has to be provided if the provided model is a function.
        pin_modes (Dict): Optional dictionary of modes per physical pin.
        parameters (Optional[Dict[str, ModelParameter]]): Dictionary containing the parameter metadata of the compact model.
        nonlinear (Optional[bool]): Flag is the model is nonlinear (depends on the input power). Default is False.
        accuracy (Optional[str]): Flag for the accuracy of this compact model.
        pins (List): Deprecated optional list of model pins. Use pin_modes instead.
    """
    model_source = _model_source("add_model()", tech, sigtype, cellname)
    if isinstance(model, dict):
        try:
            model["source"] = model.get("source") or model_source
            model = ModelInfo(**model)
        except ValidationError as e:
            msg = f"{model_source}: provided model is of type dict, but cannot be converted to ModelInfo."
            msg += f"\nValidation Errors: {e.errors()}"
            raise ValueError(msg)

    if isinstance(model, ModelInfo):
        model.source = model_source
        # override model fields if these were explicitly provided in the function call
        if connections is not None:
            model.connections = connections
        if pin_modes is not None:
            model.pin_modes = pin_modes
        if parameters is not None:
            model.parameters = parameters
        if nonlinear is not None:
            model.nonlinear = nonlinear
        if accuracy is not None:
            model.accuracy = accuracy
        if pins is not None:
            model.pins = pins
        model = normalize_model_info(model, source=model_source)

        # process module
        if model.module in modulesmap:
            # module already registered, don't need to do any processing
            pass
        elif os.path.isfile(os.path.abspath(Path(model.module))):
            # module path relative to python file from which register_compact_model() is called
            module = os.path.abspath(Path(model.module))
            _import_module(str(module), module)
            model.module = str(module)
        else:
            msg = f"{model_source}: Module at '{model.module}' not found"
            netlist.compact_model_logger(msg, "error")
            raise FileNotFoundError(msg)

        # add model to compact_model_library
        compact_model_library._add_model(
            tech=tech,
            sigtype=sigtype,
            cellname=cellname,
            model_info=model,
        )

    elif callable(model):
        if connections is None:
            msg = f"{model_source}: Connections not defined for function " \
                  f"'{model.__name__}'"
            raise ValueError(msg)

        # generate model_info for function
        model_info = {
            "call": model.__name__,
            "connections": connections,
            "source": model_source,
        }
        if parameters is not None:
            model_info["parameters"] = parameters
        if nonlinear is not None:
            model_info["nonlinear"] = nonlinear
        if accuracy is not None:
            model_info["accuracy"] = accuracy
        if pin_modes is not None:
            model_info["pin_modes"] = pin_modes
        if pins is not None:
            model_info["pins"] = pins

        # process module and register to modulesmap
        module_path = model.__module__
        module = sys.modules.get(module_path)
        modulesmap[module_path] = module
        model_info["module"] = module_path

        # add model to compact_model_library
        try:
            model = ModelInfo(**model_info)
        except ValidationError as e:
            msg = f"{model_source}: generated function model cannot be converted to ModelInfo."
            msg += f"\nValidation Errors: {e.errors()}"
            raise ValueError(msg)
        model = normalize_model_info(model, source=model_source)
        compact_model_library._add_model(
            tech=tech,
            sigtype=sigtype,
            cellname=cellname,
            model_info=model,
        )

    else:
        msg = f"{model_source}: Type {type(model)} for {model} not supported. 'model' must be either ModelInfo or a function"
        raise ValueError(msg)


def get_model(
    tech: str,
    sigtype: str,
    cellname: str,
) -> ModelInfo:
    """Look up a registered model entry in compact_model_library.

    Args:
        tech (str): Technology identifier.
        sigtype (str): Signal type identifier.
        cellname (str): Name of the cell.

    Returns:
        The stored model entry for tech, sigtype, and cellname, or None when
        no model is registered.
    """
    if tech not in compact_model_library.technologies:
        return None
    if sigtype not in compact_model_library.technologies[tech].sigtypes:
        return None
    if cellname in compact_model_library.technologies[tech].sigtypes[sigtype].cells:
        return compact_model_library.technologies[tech].sigtypes[sigtype].cells[cellname]
    return None


def show_models(
    cml: CompactModelLibrary = compact_model_library,
    show_model_functions: bool = True,
    show_source_file: bool = True,
    sigtype: str | None = None,
    ignore_interconnects: bool = False,
) -> None:
    """
    Print all models and their associated function

    Args:
        cml (CompactModelLibrary): Compact model library.
        show_model_functions (bool): Print the file location of the model function.
        show_source_file (bool): Print the file location of the source yaml. Ignored if show_model_functions is False.
        sigtype (str): Only show the models for a certain sigtype
        ignore_interconnects (bool): Ignore any default interconnect models that were automatically generated by Nazca.

    Returns:
        None
    """
    cml.show(
        show_model_functions=show_model_functions,
        show_source_file=show_source_file,
        sigtype=sigtype,
        ignore_interconnects=ignore_interconnects,
    )


def _fetch_compact_models(cell):
    """Fetch compact model(s) information and apply them to <cell>.

    Fetch from the registered models in the compact_model_library and store them
    in the cell.model_info. If the model contains information on different pin connections,
    those pins are connected in the cell. The cell calls this function upon cell closure.

    Args:
        cell (Cell): cell to fetch models for.

    Returns:
        None
    """
    # obtain model_info for the cell cm_id
    cellname = cell.cm_id[0]
    tech = cell.cm_id[1]
    models = {}

    technology_data = compact_model_library.technologies.get(tech, None)
    if not technology_data:
        cell.model_info = models
        return

    sigtypes = technology_data.sigtypes

    for sigtype, cm_cells in sigtypes.items():
        cell_data = cm_cells.cells.get(cellname, {})

        if not cell_data:
            continue

        model = cell_data.model
        models[sigtype] = model

        # Check connections and connect physical paths described by the model.
        connected_pins = []
        for channel1, channel2 in model.connections:
            pin1, _mode1 = split_channel_label(channel1)
            pin2, _mode2 = split_channel_label(channel2)
            assert pin1 in cell.pin.keys(), f"Pin '{pin1}' in compact model connections of '{model.call}' for " \
                                            f"cm_id '{cell.cm_id}' is not a pin of cell '{cell.cell_basename}'"
            assert pin2 in cell.pin.keys(), f"Pin '{pin2}' in compact model connections of '{model.call}' for " \
                                            f"cm_id '{cell.cm_id}' is not a pin of cell '{cell.cell_basename}'"
            if [pin1, pin2] in connected_pins or [pin2, pin1] in connected_pins:
                continue
            connected_pins.append([pin1, pin2])
            netlist.connect_path(
                cell.pin[pin1],
                cell.pin[pin2],
                model,
                sigtype,
            )

    cell.model_info = models


def export_unetlist(
    cell: Cell,
    filename: str | Path = None,
    clear_models: bool = False,
) -> CircuitNetlist:
    """Generate a netlist from the provided Cell

    The circuit is generated by extracting and filtering the circuit information from the Nazca cell tree

    TODO consider serialization of pcell_data; we do not have control over these values, so they might not be suited for
        the yaml format. We probably have to implement dynamic serialization, since these pcell_data can in theory be
        anything.
        Simplest approach would be to use our serializer in pcell_data. However, I am not entirely sure how appropriate
        the result will be.

    Args:
        cell (nd.Cell): Cell for which to generate a uNetlist
        filename (str): filename of the resulting uNetlist (if not None)
        clear_models (bool): Set to true to discard existing models during export.

    Returns:
        dict: circuit_netlist dictionary
    """
    print(f"Starting circuit export...")

    circuits = {}

    # iterate over all cells that either have a model or contain a model down in the hierarchy
    # bottom up iteration: this way we can extract the relevant model pins of compound instances directly
    for params in netlist.cell_iter_bottom_up(topcell=cell):
        if params.cell.auxiliary: continue
        if "bbox" in params.cell.cell_name: continue
        if "icon" in params.cell.cell_name: continue

        if params.cell_open:
            circuits = _create_subnetlist(
                params,
                circuits=circuits,
                topcell=cell,
            )

    print(f"...netlist generation")
    topology = CircuitTopology(topcell=f"{cell.cell_name}", circuits=circuits)
    cml = CompactModelLibrary(technologies={}) if clear_models else compact_model_library
    circuit_netlist = CircuitNetlist(topology=topology, compact_models=cml)

    if filename is not None:
        circuit_netlist.save(filename)
        print(f"...Wrote file '{filename}'")

    return circuit_netlist


def _create_subnetlist(
    params,
    circuits: dict[str, CircuitModel],
    topcell: Cell,
) -> dict[str, CircuitModel]:
    """Generate circuit information of the cell.

    This will construct the circuit of the cell without going deeper into the hierarchy of the cell

    Args:
        params (named_tuple): celltree information from cell tree iterator.
        circuits (dict): Dictionary containing circuit information of previously encountered circuits.
        topcell (Cell): Top level cell for which we are constructing the circuit.

    Returns:
        circuits (dict): Dictionary containing circuit information of encountered subcircuits, updated with subcircuit
            that was extracted from the passed celltree params.
    """

    instances = {}  # calling the subcircuits instances for now, so that it is easier to understand what's going on here
    raised_pins = {}
    connections = []
    pins = []

    for name, pin in params.cell.pin.items():
        if pin == pin.cnode: continue  # ignore cnode
        if name in bbox_pinnames: continue # ignore bbox pins
        if _is_tube_pin(name, pin): continue # ignore tube pins
        pins.append(name)

    for inode, xya, flip in params.iters['instance']:
        current_cell = inode.cnode.cell
        if current_cell.auxiliary: continue
        if "bbox" in current_cell.cell_name: continue
        if "icon" in current_cell.cell_name: continue

        instance = inode.instance
        pcell_data = instance.pcell_data

        # construct connectivity
        for name, pin in instance.pin.items():
            if name in bbox_pinnames:
                continue
            if _is_tube_pin(name, pin):
                continue
            for node in pin.geo_nb_filter_iter():
                if _is_tube_pin(node.basename, node):
                    continue
                # if a neighbouring pin is in a different instance, and both instances are in the same cell, then
                # we are dealing with a pin-to-pin connection
                if (
                        node.cnode.instance is not pin.cnode.instance
                        and node.cnode.parent_cnode is pin.cnode.parent_cnode
                ):
                    pin1 = {"name": pin.basename, "instance": pin.cnode.instance.name}
                    pin2 = {"name": node.basename, "instance": node.cnode.instance.name}

                    connection = [pin1, pin2]
                    if connection not in connections and connection[::-1] not in connections:
                        connections.append(connection)

                # otherwise, it is possible that the node is a raised pin.
                elif (
                        pin.cnode.parent_cnode is node.cnode
                        and pin.x == node.x
                        and pin.y == node.y
                        and not node.name.isdigit()
                ):
                    pin_info = {"name": pin.basename, "instance": pin.cnode.instance.name}
                    raised_pins[node.basename] = pin_info

        circuit = f"{current_cell.cell_name}"
        if circuit not in circuits:
            circuit = None

        instances[instance.name] = InstanceModel(
            circuit=circuit,
            cell_id=current_cell.cm_id[0],            
            tech=current_cell.cm_id[1],
            instance_label=instance.label,
            pcell_data=pcell_data,
        )

    circuits[f"{params.cell.cell_name}"] = CircuitModel(
        cell_id=params.cell.cm_id[0],
        tech=params.cell.cm_id[1],
        instances=instances,
        pins=pins,
        raised_pins=raised_pins,
        connections=connections,
        topcell=params.cell == topcell,
    )

    return circuits


def _get_pins_to_discard(
    sigtype: str,
    raised_pins: dict[str, dict[str, str]],
    instances: dict[str, InstanceModel],
    topology: CircuitTopology,
    models: CompactModelLibrary,
) -> list[str]:
    """Identify raised pins that should be discarded during netlist filtering.

    A raised pin is discarded if:
    - Its instance is not present in the instances dict
    - Its pin name is not in the circuit pins of the corresponding subcircuit
    - Its pin name is not in the model pins when the instance has no circuit reference

    Args:
        sigtype (str): Signal type to filter for (e.g., 'ampl', 'loss')
        raised_pins (dict[str, dict[str, str]]): Mapping of raised pin names to their instance and pin info
        instances (dict[str, InstanceModel]): Dictionary of instances in the current circuit
        topology (CircuitTopology): The circuit topology containing all circuits
        models (CompactModelLibrary): Library of compact models

    Returns:
        list[str]: List of raised pin names to discard
    """
    pins_to_discard = []
    for raised_pin, pin_info in raised_pins.items():
        if pin_info["instance"] not in instances:
            pins_to_discard.append(raised_pin)
            continue

        _instance = instances[pin_info["instance"]]
        _circuit = _instance.circuit

        if _circuit is not None:
            subckt = topology.circuits.get(_circuit)
            if subckt is None or pin_info["name"] not in subckt.pins:
                pins_to_discard.append(raised_pin)
            continue

        # _circuit is None => validate against model pins
        _tech = _instance.tech
        _cell_id = _instance.cell_id
        model = (
            models.technologies.get(_tech, _CMSigtypes(sigtypes={}))
            .sigtypes.get(sigtype, _CMCells(cells={}))
            .cells.get(_cell_id, None)
        )
        if model is None or pin_info["name"] not in model_physical_pins(model.model):
            pins_to_discard.append(raised_pin)

    return pins_to_discard


def _is_valid_model_pin(
    pin: dict[str, str],
    sigtype: str,
    instances: dict[str, InstanceModel],
    topology: CircuitTopology,
    models: CompactModelLibrary,
) -> bool:
    """Check if a pin represents a valid model pin for the given signal type.

    A pin is valid if:
    - Its instance exists in the instances dict
    - The pin name is in the circuit pins (if the instance has a circuit reference)
    - The pin name is in the model pins (if the instance has no circuit reference)

    Args:
        pin (dict[str, str]): Pin information with 'name' and 'instance' keys
        sigtype (str): Signal type to check against (e.g., 'ampl', 'loss')
        instances (dict[str, InstanceModel]): Dictionary of instances in the current circuit
        topology (CircuitTopology): The circuit topology containing all circuits
        models (CompactModelLibrary): Library of compact models

    Returns:
        bool: True if the pin is valid for the signal type, False otherwise
    """
    if pin["instance"] not in instances:
        return False

    _instance = instances[pin["instance"]]
    _circuit = _instance.circuit
    if _circuit and pin["name"] not in topology.circuits[_circuit].pins:
        return False

    _tech = _instance.tech
    _cell_id = _instance.cell_id
    if (
        _circuit is None
        and pin["name"] not in model_physical_pins(models.technologies[_tech].sigtypes[sigtype].cells[_cell_id].model)
    ):
        return False

    return True


def _get_new_connections(
    sigtype: str,
    connections: list[list[dict[str, str]]],
    instances: dict[str, InstanceModel],
    toplogy: CircuitTopology,
    models: CompactModelLibrary,
) -> list[list[dict[str, str]]]:
    """Filter connections to retain only those between valid model pins.

    A connection is retained only if both pins are valid model pins for the given signal type.
    See _is_valid_model_pin for the validation criteria.

    Args:
        sigtype (str): Signal type to filter for (e.g., 'ampl', 'loss')
        connections (list[list[dict[str, str]]]): List of pin-to-pin connections
        instances (dict[str, InstanceModel]): Dictionary of instances in the current circuit
        toplogy (CircuitTopology): The circuit topology containing all circuits
        models (CompactModelLibrary): Library of compact models

    Returns:
        list[list[dict[str, str]]]: Filtered list of connections between valid model pins
    """
    connections_new = []
    for connection in connections:
        pin1 = connection[0]
        if not _is_valid_model_pin(pin1, sigtype, instances, toplogy, models):
            continue
        pin2 = connection[1]
        if not _is_valid_model_pin(pin2, sigtype, instances, toplogy, models):
            continue
        connections_new.append(connection)
    return connections_new


def _load_unetlist(unetlist: str | Path | CircuitNetlist) -> CircuitNetlist:
    """Normalize uNetlist input to a CircuitNetlist instance."""
    if isinstance(unetlist, CircuitNetlist):
        return unetlist

    # Treat anything path-like (str/Path/...) as a filename
    path = Path(unetlist)
    if not path.is_file():
        raise FileNotFoundError(f"unetlist '{path}' not found")

    with path.open("r") as f:
        data = yaml.load(f, Loader=yloader)
    return CircuitNetlist(**data)


def _get_model_and_instance_models(
    compact_models: CompactModelLibrary,
    tech: str,
    sigtype: str,
    cell_id: str,
) -> tuple[ModelInfo | None, dict[str, ModelInfo] | None]:
    """Return (model, instance_models) for tech/sigtype/cell_id, or (None, None)."""
    sigtypes = compact_models.technologies.get(tech, None)
    if sigtypes is None:
        return None, None

    model_cells = sigtypes.sigtypes.get(sigtype, None)
    if model_cells is None:
        return None, None

    cm_model = model_cells.cells.get(cell_id, None)
    if cm_model is None:
        return None, None

    return cm_model.model, cm_model.instance_models


def _ensure_sigtype_bucket(
    filtered_models: CompactModelLibrary,
    tech: str,
    sigtype: str,
) -> None:
    """Ensure filtered model hierarchy exists for technology/sigtype."""
    if tech not in filtered_models.technologies:
        filtered_models.technologies[tech] = _CMSigtypes(sigtypes={})

    if sigtype not in filtered_models.technologies[tech].sigtypes:
        filtered_models.technologies[tech].sigtypes[sigtype] = _CMCells(cells={})


def _has_filtered_model(
    filtered_models: CompactModelLibrary,
    tech: str,
    sigtype: str,
    cell_id: str,
) -> bool:
    """Check if model already exists in filtered model library."""
    return (
        filtered_models.technologies.get(tech, _CMSigtypes(sigtypes={}))
        .sigtypes.get(sigtype, _CMCells(cells={}))
        .cells.get(cell_id, None)
        is not None
    )


def _filter_instances_for_sigtype(
    circuit_info: CircuitModel,
    filtered_models: CompactModelLibrary,
    filtered_topology: CircuitTopology,
    sigtype: str,
) -> dict[str, InstanceModel]:
    """Keep only instances that remain relevant after filtering for sigtype.

    Direct-model instances are kept with their circuit reference cleared.
    Hierarchical instances are kept only when their referenced subcircuit
    survives in filtered_topology.
    """
    instances_new = {}
    for instance_name, instance_info in circuit_info.instances.items():
        cell_id = instance_info.cell_id
        tech = instance_info.tech

        if _has_filtered_model(filtered_models, tech, sigtype, cell_id):
            # instance is a model: keep and clear circuit reference
            instances_new[instance_name] = instance_info
            instances_new[instance_name].circuit = None
        elif instance_info.circuit in filtered_topology.circuits:
            # instance is not a direct model, but references a kept subcircuit
            instances_new[instance_name] = instance_info
        else:
            # discard instance
            pass

    return instances_new


def _filter_circuit_io_for_sigtype(
    circuit_info: CircuitModel,
    filtered_topology: CircuitTopology,
    filtered_models: CompactModelLibrary,
    sigtype: str,
) -> None:
    """Prune raised pins, external pins, and connections that are not valid for sigtype.

    This mutates circuit_info in place.
    """
    pins_to_discard = _get_pins_to_discard(
        sigtype=sigtype,
        raised_pins=circuit_info.raised_pins,
        instances=circuit_info.instances,
        topology=filtered_topology,
        models=filtered_models,
    )

    for pin in pins_to_discard:
        circuit_info.raised_pins.pop(pin)

    pins_new = []
    for pin in circuit_info.pins:
        if pin not in pins_to_discard:
            pins_new.append(pin)
    circuit_info.pins = pins_new

    connections_new = _get_new_connections(
        sigtype=sigtype,
        connections=circuit_info.connections,
        instances=circuit_info.instances,
        toplogy=filtered_topology,
        models=filtered_models,
    )
    circuit_info.connections = connections_new


def _get_circuit_children(topology: CircuitTopology) -> dict[str, set[str]]:
    """Build a lookup table of which circuits directly contain which subcircuits.

    Each circuit in ``topology.circuits`` can contain instances. Some of those
    instances point to another circuit in the same topology through
    ``instance_info.circuit``. This function collects those references so later
    code can walk the circuit hierarchy like a graph.

    In other words:
    - the dictionary key is a circuit name
    - the dictionary value is the set of child circuits directly instantiated by
      that circuit

    Only references to circuits that are actually present in
    ``topology.circuits`` are kept.

    Example:
        If ``top`` contains instances of ``mzi`` and ``splitter``, and ``mzi``
        contains an instance of ``phase_shifter``, the result is roughly:

            {
                "top": {"mzi", "splitter"},
                "mzi": {"phase_shifter"},
                "splitter": {},
                "phase_shifter": {},
            }

    This function does not decide whether a circuit is kept or dropped. It only
    describes the raw hierarchy so later functions can reason about reachability.
    """
    children = {}
    for circuit_name, circuit_info in topology.circuits.items():
        children[circuit_name] = {
            instance_info.circuit
            for instance_info in circuit_info.instances.values()
            if instance_info.circuit in topology.circuits
        }
    return children


def _get_direct_model_circuits(
    compact_models: CompactModelLibrary,
    topology: CircuitTopology,
    sigtype: str,
) -> set[str]:
    """Return all circuits that have their own compact model for this sigtype.

    A "direct model" means that the circuit itself has a registered compact
    model for the selected ``sigtype``. If a circuit has a direct model, the
    solver can treat that whole circuit as a black box instead of expanding its
    child instances one by one.

    Example:
        Suppose the hierarchy is ``top -> mzi -> phase_shifter``.

        For ``sigtype="ampl"``:
        - ``top`` has no direct model
        - ``mzi`` has a direct ampl model
        - ``phase_shifter`` also has a direct ampl model

        Then this function returns ``{"mzi", "phase_shifter"}``.

    This function only answers:
    "Which circuits have a direct model?"

    It does not decide whether those circuits are actually used in the final
    filtered topology. That depends on reachability and shadowing, which are
    handled later.
    """
    direct_model_circuits = set()
    for circuit_name, circuit_info in topology.circuits.items():
        model, _ = _get_model_and_instance_models(
            compact_models=compact_models,
            tech=circuit_info.tech,
            sigtype=sigtype,
            cell_id=circuit_info.cell_id,
        )
        if model is not None:
            direct_model_circuits.add(circuit_name)
    return direct_model_circuits


def _get_reachable_circuits(
    topcell: str,
    children_by_circuit: dict[str, set[str]],
    stop_at: set[str] | None = None,
) -> set[str]:
    """Return the circuits that can be reached from the topcell.

    Reachability is defined by following the parent -> child relations from
    ``children_by_circuit``, starting at ``topcell``.

    The optional ``stop_at`` set changes the traversal slightly:
    if a circuit is in ``stop_at``, that circuit itself is still marked
    reachable, but traversal does not continue into its children.

    That behavior matches how the solver treats a circuit with a direct model:
    the circuit itself matters, but once it can be solved as a black box there
    is no need to descend further into the hierarchy below it.

    Example without ``stop_at``:
        ``top -> mzi -> phase_shifter`` gives
        ``{"top", "mzi", "phase_shifter"}``.

    Example with ``stop_at={"mzi"}``:
        ``top -> mzi -> phase_shifter`` gives
        ``{"top", "mzi"}``.

    Notice that ``mzi`` is still reachable, but ``phase_shifter`` is not,
    because traversal stops once ``mzi`` is encountered.

    This function is therefore used in two modes:
    - full hierarchy traversal
    - solver-style traversal that stops at direct-model circuits
    """
    reachable = set()
    pending = [topcell]
    stop_at = stop_at or set()

    while pending:
        circuit_name = pending.pop()
        if circuit_name in reachable:
            continue

        # The current circuit is reachable as soon as we arrive at it, even if
        # we choose not to descend into its children.
        reachable.add(circuit_name)

        # Treat circuits in stop_at as black boxes: keep the circuit itself in
        # the result, but do not continue traversal below it.
        if circuit_name in stop_at:
            continue
        pending.extend(children_by_circuit.get(circuit_name, ()))

    return reachable


def _get_shadowed_circuits(
    compact_models: CompactModelLibrary,
    topology: CircuitTopology,
    sigtype: str,
) -> set[str]:
    """Return circuits that are hidden behind a parent direct model.

    A "shadowed circuit" is a circuit that exists in the full hierarchy, but is
    not reachable anymore when the solver stops descending at circuits that
    already have a direct model for this ``sigtype``.

    Intuition:
    if a parent already has a direct model, the solver can use that parent
    as a black box. Any child circuits below that parent are then no longer
    visited during solving. Those child circuits are said to be shadowed by the
    parent model.

    This function computes shadowed circuits as the difference between two sets:

        fully_reachable - solver_reachable

    where:
    - ``fully_reachable`` means all circuits reachable from the topcell if we
      expand the complete hierarchy
    - ``solver_reachable`` means all circuits reachable from the topcell if we
      stop descending once we hit a direct-model circuit

    Small example:
        Suppose the hierarchy is ``top -> mzi -> phase_shifter``.

        For ``sigtype="ampl"``:
        - ``top`` has no direct model
        - ``mzi`` has a direct ampl model
        - ``phase_shifter`` may or may not have an ampl model of its own

        Then:
        - ``fully_reachable = {"top", "mzi", "phase_shifter"}``
        - ``solver_reachable = {"top", "mzi"}``
        - ``shadowed_circuits = {"phase_shifter"}``

    Important subtle point:
    a circuit can be shadowed even if it also has its own direct model.
    Shadowed only means "the solver would never reach it by descending from the
    topcell", not "this circuit has no model".
    """
    children_by_circuit = _get_circuit_children(topology)
    direct_model_circuits = _get_direct_model_circuits(compact_models, topology, sigtype)

    fully_reachable = _get_reachable_circuits(topology.topcell, children_by_circuit)

    solver_reachable = _get_reachable_circuits(
        topology.topcell,
        children_by_circuit,
        stop_at=direct_model_circuits,
    )
    return fully_reachable - solver_reachable


def _log_sigtype_prune(
    circuit_name: str,
    circuit_info: CircuitModel,
    sigtype: str,
    reason: str,
    level: str = "info",
    details: str | None = None,
) -> None:
    """Log an explanation for why a circuit was removed.

    "Pruned" here means that the circuit existed in the original uNetlist
    topology, but is not kept in the filtered netlist for the selected
    ``sigtype``.
    """
    msg = (
        f"Pruned circuit '{circuit_name}' (cell_id='{circuit_info.cell_id}', tech='{circuit_info.tech}') "
        f"from '{sigtype}' netlist: {reason}"
    )
    if details:
        msg = f"{msg}. {details}"
    netlist.compact_model_logger(msg, level)


def export_netlist_by_sigtype(
    unetlist: str | CircuitNetlist, sigtype: str = "ampl", filename: str | Path = None
) -> CircuitNetlist:
    """Create a sigtype-specific view of a uNetlist.

    The input uNetlist contains two kinds of information:
    - the full circuit hierarchy
    - all registered compact models, potentially for multiple signal types

    This function builds a smaller netlist for one selected ``sigtype`` such as
    ``"ampl"``, ``"dis"``, or ``"loss"``.

    The filtered result keeps only the parts of the hierarchy that still matter
    for solving that sigtype. A circuit can be dropped for three main reasons:
    - it is hidden behind a parent that already has a direct model
    - it is a circuit without children and with no direct model for this sigtype
    - after filtering its children, nothing useful remains inside it

    Key terms used below:
    - direct model:
      the circuit itself has a compact model for the selected sigtype, so the
      solver can treat the whole circuit as a black box. So there is no need
      to further examine the circuit's children.
    - reachable circuit:
      a circuit you can reach from the topcell by following child-circuit
      references in the hierarchy
    - shadowed circuit:
      a circuit that exists in the raw hierarchy, but is never expanded by the
      solver because a parent direct model stops traversal before reaching it

    Very small example:
        Suppose the hierarchy is ``top -> mzi -> phase_shifter``.

        For ``sigtype="ampl"``:
        - if ``mzi`` has a direct ampl model, the solver can use ``mzi`` as a
          black box
        - then ``phase_shifter`` becomes shadowed from the point of view of
            solving from ``top``. It is not added to ``filtered_topology``.
        - if ``phase_shifter`` has no direct ampl model of its own, it will not
            be added to ``filtered_models``
        - if ``phase_shifter`` does have its own direct ampl model, it will
            still remain in ``filtered_models`` even though it is shadowed

    Loop logic overview:
        For each circuit in the original topology, the function asks:
        1. Does this circuit have a direct model for the selected sigtype?
        2. If not, is it shadowed by a parent direct model?
        3. If not, does it still contain child instances that survive filtering?

        The three main branches in the loop are:

        A) Circuit has a direct model
           Keep the model in ``filtered_models``.
           If this circuit is also the topcell, keep its topology entry too.
           Then stop processing that circuit, because it will be solved through
           its direct model rather than by expanding its internals.

        B) Circuit has no direct model and has no child instances
           Drop it.
           This is a circuit that cannot contribute anything to the
           selected sigtype.

        C) Circuit has no direct model, but does contain child instances
           First filter its child instances to only those still relevant.
           Then remove pins and connections that no longer point to valid kept
           instances or model pins.
           If at least one child instance remains, keep the circuit.
           Otherwise drop it because the circuit has become empty for this
           sigtype.

    Note on shadowed circuits:
        The early shadowed-circuit check only prunes circuits when
        ``model is None``. That is intentional. Under the current logic, a
        circuit can be shadowed and still have its own direct model. Those
        direct-model circuits are still kept in ``filtered_models``.

    Args:
        unetlist (str|CircuitNetlist): uNetlist path or already loaded netlist.
        sigtype (str): signal type to filter on (e.g., "ampl", "loss").
        filename (str|Path|None): optional output path for the filtered netlist.

    Returns:
        CircuitNetlist: filtered netlist for the requested signal type.
    """
    print(f"Starting '{sigtype}' netlist export...")

    unetlist = _load_unetlist(unetlist)

    compact_models = unetlist.compact_models
    topcell = unetlist.topology.topcell

    shadowed_circuits = _get_shadowed_circuits(compact_models, unetlist.topology, sigtype)

    print(f"...'{sigtype}' netlist generation")
    filtered_models = CompactModelLibrary(technologies={})
    filtered_topology = CircuitTopology(topcell=topcell, circuits={})

    # Walk every circuit from the original topology and decide whether it stays
    # in the filtered view as:
    # - a direct model in filtered_models,
    # - circuit in filtered_topology,
    # - or something to prune away.
    for circuit_name, circuit_info in unetlist.topology.circuits.items():
        cell_id = circuit_info.cell_id
        tech = circuit_info.tech

        model, instance_models = _get_model_and_instance_models(
            compact_models=compact_models,
            tech=tech,
            sigtype=sigtype,
            cell_id=cell_id,
        )

        # If this circuit has no direct model and sits below a parent that
        # already has a direct model, the solver will never descend into it.
        # It cannot affect solving for this sigtype, so it is
        # dropped immediately.
        if model is None and circuit_name in shadowed_circuits:
            _log_sigtype_prune(
                circuit_name=circuit_name,
                circuit_info=circuit_info,
                sigtype=sigtype,
                reason=f"this circuit sits inside a parent circuit that already has its own '{sigtype}' model",
                details="The solver treats that parent as a black box and never expands this subcircuit.",
            )
            continue

        # A) This circuit itself has a direct model for the selected sigtype.
        # Keep that model so the solver can use the 
        # whole circuit as a black box. We do not need to inspect its internal
        # children any further for solving this sigtype.
        if model is not None:
            _ensure_sigtype_bucket(filtered_models, tech, sigtype)

            # Store the direct model in the filtered model library.
            filtered_models.technologies[tech].sigtypes[sigtype].cells[cell_id] = _CMModel(
                model=model,
                instance_models=instance_models,
            )

            # The topcell still needs a topology entry, even when it also has a
            # direct model, because it is the external entry point of the
            # filtered netlist.
            if circuit_name == topcell:
                filtered_topology.circuits[circuit_name] = circuit_info
            continue

        # B) No direct model and no child instances.
        # This is a circuit with nothing to solve for this sigtype and no
        # deeper hierarchy to inspect.
        if not circuit_info.instances:
            _log_sigtype_prune(
                circuit_name=circuit_name,
                circuit_info=circuit_info,
                sigtype=sigtype,
                reason=f"this circuit has no '{sigtype}' model of its own and contains no child circuits to keep",
                details=f"After filtering for '{sigtype}', there is nothing left in this circuit that can contribute to the exported netlist",
            )
            continue

        # C) No direct model, but this circuit may still matter as hierarchy if
        # it contains child instances that survive sigtype filtering.
        original_instance_count = len(circuit_info.instances)

        # Keep only child instances that either:
        # - are direct models themselves, or
        # - still point to a subcircuit that survives in filtered_topology.
        circuit_info.instances = _filter_instances_for_sigtype(
            circuit_info=circuit_info,
            filtered_models=filtered_models,
            filtered_topology=filtered_topology,
            sigtype=sigtype,
        )

        # After dropping child instances, some raised pins and internal
        # connections may refer to things that no longer exist in the filtered
        # view. Remove those stale references so the remaining topology stays
        # consistent.
        _filter_circuit_io_for_sigtype(
            circuit_info=circuit_info,
            filtered_topology=filtered_topology,
            filtered_models=filtered_models,
            sigtype=sigtype,
        )

        # If at least one relevant child instance remains, this circuit still
        # acts as useful hierarchy and should stay in the filtered topology.
        if circuit_info.instances:
            filtered_topology.circuits[circuit_name] = circuit_info
        else:
            # No relevant child instances remain, so this circuit has become
            # empty for this sigtype and can be pruned.
            _log_sigtype_prune(
                circuit_name=circuit_name,
                circuit_info=circuit_info,
                sigtype=sigtype,
                reason=f"all {original_instance_count} child instances inside this circuit were removed during '{sigtype}' filtering",
                details="Because no relevant child instances remain, this parent circuit is now empty and is removed too.",
            )

    new_unetlist = CircuitNetlist(topology=filtered_topology, compact_models=filtered_models)
    if filename is not None:
        new_unetlist.save(filename)
        print(f"...Wrote file {filename}")

    return new_unetlist


def evaluate_compact_model(
    compact_model: dict | ModelInfo,
    cell=None,
    parameters: dict = None,
    instance_parameters: dict = None,
    sweep: dict = None,
) -> dict:
    """Function to manage evaluation compact model of instance.

    This function takes care of the following things:
    - Obtaining the relevant keyword arguments from the instance and extracts relevant keyword arguments from parameters
    - Generating and storing simulation metadata
    - Storing compact model results
    - Retrieving compact model results from this run and optionally retrieving stored compact model results

    If nd.cfg.reuse_cm_results is set to True (default is False), stored results in compact_model_data will be used if
    available. Use with care: results can be outdated, as any changes in the compact model python file or in the
    index models will not result in a different simulation hash.

    Args:
        compact_model (dict | ModelInfo): dictionary or ModelInfo object containing the compact model information.
        cell (nd.Cell): Optional Cell corresponding to the model. If the label is not provided, this will be used to
            retrieve the simulation parameters. If None the model will be evaluated without obtaining parameters from
            the cell/instance.
        parameters (dict): Optional dictionary containing model parameters.
        instance_parameters (dict): Optional dictionary containing instance specific model parameters
        sweep (dict): Optional dictionary containing a sweep of parameters/instance parameters. This dict should be
            formatted as:
            {
                0: "params": <params for run 0>, "instance_params": <instance_params for run 0>,
                1: "params": <params for run 1>, "instance_params": <instance_params for run 1>,
                ...
                n: "params": <params for run n>, "instance_params": <instance_params for run n>,
            }

    Returns:
        Dict: compact model result, or dictionary containing compact model results if sweep is not None
    """
    if not os.path.isdir('compact_model_data') and cfg.store_cm_results:
        netlist.compact_model_logger('compact_model_data folder not found. Generating folder...', 'info')
        os.mkdir('compact_model_data')

    if not isinstance(compact_model, ModelInfo):
        try:
            compact_model = ModelInfo(**compact_model)
        except ValidationError as e:
            source = compact_model.get("source", "evaluate_compact_model()") if isinstance(compact_model, dict) else "evaluate_compact_model()"
            msg = f"{source}: compact model cannot be converted to ModelInfo."
            msg += f"\nValidation Errors: {e.errors()}"
            raise ValueError(msg)

    compact_model = normalize_model_info(compact_model, source=compact_model.source or "evaluate_compact_model()")

    if compact_model.api is not None:  # model is part of a server and needs to be solved through restapi call
        args = {
            "compact_model": compact_model,
            "parameters": parameters,
            "instance_parameters": instance_parameters,
            "sweep": sweep,
        }
        result = cfg.apis[compact_model.api]["evaluate_compact_model"](**args)
        return result

    if sweep is not None:
        result = {}
        for i, run in sweep.items():
            result[i] = evaluate_compact_model(
                compact_model=compact_model,
                parameters=run["params"],
                instance_parameters=run["instance_params"]
            )
        return result

    module = compact_model.module
    call = compact_model.call

    if module not in modulesmap.keys():
        msg = f"Module '{module}' from header file '{compact_model.source}' was not imported correctly. Circuit simulation" \
              f" will not be possible."
        netlist.compact_model_logger(msg, 'error')
        raise ModuleNotFoundError(msg)

    if parameters is None:
        parameters = {}
    kwargs = __get_cm_kwargs(
        compact_model,
        cell=cell,
        default_parameters=parameters,
        instance_parameters=instance_parameters
    )

    cm_hash, metadata = __create_simulation_info(module=module, call=call, kwargs=kwargs)

    if cm_hash in _simulation_results.keys():
        # model has already been evaluated in this run. Reuse output
        result = _simulation_results[cm_hash]
    elif cfg.reuse_cm_results and os.path.isfile(f'compact_model_data/simulation_{cm_hash}/result.p'):
        # model has already been evaluated in a previous run. Reuse output if reuse_cm_results is True
        result = __retrieve_simulation_result(cm_hash)
    else:
        result = __exec_model(modulename=module, funcname=call, kwargs=kwargs)
        assert isinstance(result, dict), \
            "compact model needs to return a dict-based result matrix like {'a0': {'b0': value}}. " \
                                 + f"Instead got a {type(result)} instead for {metadata}."

        if cfg.store_cm_results:
            __store_simulation_result(metadata=metadata, cm_hash=cm_hash, result=result)
        _simulation_results[cm_hash] = result

    return result


def _filter_params(params: dict) -> None:
    # TODO: This list looks like something for cfg file, not inline
    excluded_keys = [
        "xs",
        "width",
        "width1",
        "width2",
        "call",
        "parabolic",
        "shift",
        "offset1",
        "offset2",
        "angle_cal",
        "radius_cal",
    ]
    for key in excluded_keys:
        params.pop(key, None)


def __get_cm_kwargs(
    compact_model,
    cell=None,
    default_parameters=None,
    instance_parameters=None,
):
    """Function to obtain all relevant keyword arguments for the provided compact model.

    This function will obtain any parameters from the Instance's pcell_data or from the default_parameters.
    Any parameters that are not arguments of the function are ignored. If this is the case, a warning is issued. Repeat
    warnings (same parameters for same function) are ignored.

    Args:
        compact_model (ModelInfo): ModelInfo object containing the compact model information.
        cell (nd.Cell): Optional Cell corresponding to the model. If the label is not provided, this will be used to
            retrieve the simulation parameters. If None the model will be evaluated without obtaining parameters from
            the cell/instance.
        default_parameters (dict): Optional dictionary containing default parameters
        instance_parameters (dict): Optional dictionary containing instance specific parameters
    Returns:
        dict: Relevant keyword arguments for the compact model
    """
    if default_parameters is None:
        default_parameters = {}

    if instance_parameters is None and cell is None:
        netlist.compact_model_logger(
            f"get_cm_kwargs: no label or cell provided. Attempting to evaluate function without"
            f" obtaining pcell_data.",
            "warning",
        )
        pcell_data = {}
    elif instance_parameters is None:
        # get params from cell
        if cfg.warn_missing_label:
            netlist.compact_model_logger(
                f"get_cm_kwargs: no label provided, obtaining pcell_data from cell", "warning"
            )
        pcell_data = cell.pcell_data
    else:
        # get params from label
        pcell_data = instance_parameters

    module = compact_model.module
    call = compact_model.call
    if call is None:
        return {}
    function = getattr(modulesmap[module], call)

    # introspection to obtain keyword arguments of the compact model function
    sig = signature(function)
    function_params = []
    for name, param in sig.parameters.items():
        function_params.append(name)

    # obtain all relevant keyword arguments for the compact model
    kwargs = {}
    for par in function_params:
        if par in pcell_data.keys():
            kwargs[par] = pcell_data[par]
        elif par in default_parameters.keys():
            kwargs[par] = default_parameters[par]

    # raise warnings if any default parameters are not used.
    for par in default_parameters.keys():
        if par not in kwargs.keys():
            if cell is not None:
                if (par, module, call, cell.cell_basename) in _kwarg_warnings:  # do not repeat the same warning
                    continue
                _kwarg_warnings.append((par, module, call, cell.cell_basename))
                msg = f"Parameter '{par}' is not a parameter of the model '{module}.{call}' " \
                    f"of cell '{cell.cell_basename}'"
                netlist.compact_model_logger(msg, 'warning')
            else:
                if (par, module, call) in _kwarg_warnings and cfg.filter_kwarg_warnings:  # do not repeat the same warning
                    continue
                _kwarg_warnings.append((par, module, call))
                msg = f"Parameter '{par}' is not a parameter of the model '{module}.{call}' "
                netlist.compact_model_logger(msg, 'warning')

    # raise warnings if any pcell_data parameters are not used
    pcell_data_local = deepcopy(pcell_data)
    if cfg.filter_basic_param_warnings:
        # Filter out basic parameters that are typically not used in the compact models, to avoid unnecessary warnings.
        _filter_params(pcell_data_local)
    for par in pcell_data_local.keys():
        if par not in kwargs.keys():
            if cell is not None:
                if (par, module, call, cell.cell_basename) in _kwarg_warnings:  # do not repeat the same warning
                    continue
                _kwarg_warnings.append((par, module, call, cell.cell_basename))
                msg = f"Parameter '{par}' is not a parameter of the model '{module}.{call}' " \
                    f"of cell '{cell.cell_basename}'"
                netlist.compact_model_logger(msg, 'warning')
            else:
                if (par, module, call) in _kwarg_warnings and cfg.filter_kwarg_warnings:  # do not repeat the same warning
                    continue
                _kwarg_warnings.append((par, module, call))
                msg = f"Parameter '{par}' is not a parameter of the model '{module}.{call}'"
                netlist.compact_model_logger(msg, 'warning')

    return kwargs


def __exec_model(
    modulename: str,
    funcname: str,
    kwargs: dict = None,
) -> dict:
    """Execute a registered compact-model function from modulesmap.

    Args:
        modulename (str): Key of the imported compact-model module in modulesmap.
        funcname (str): Function name to execute inside the module.
        kwargs (dict | None): Keyword arguments passed to the compact-model function.

    Returns:
        dict: Result returned by the compact-model function, or an empty dict
        if the function is missing.
    """
    if kwargs is None:
        kwargs = {}
    if hasattr(modulesmap[modulename], funcname):
        func = getattr(modulesmap[modulename], funcname)
        return func(**kwargs)

    netlist.main_logger(f"No model: {modulename}.{funcname}", "error")
    return {}


def parse_cm_result(pin_in, pin_out, compact_model, result, missing_as_zero: bool = False):
    """Function to safely extract a connection value from a compact model result

    If the connection is described by the connections in the compact model dictionary, return the connection
    value. If the connection is not described by the connections in the compact model dictionary, return None.

    If the connection is described by the connections in the compact model dictionary, but is not part of the results
    dictionary, this function deals with the error handling.

    Args:
        pin_in (str): Input pin.
        pin_out (str): Output pin.
        compact_model (ModelInfo): ModelInfo object containing the compact model information.
        result (dict): Dictionary containing the compact-model result.

    Returns:
        Any | None: Connection value from result, or None for an undefined connection.
    """
    physical_pin_in, _mode_in = split_channel_label(pin_in)
    physical_pin_out, _mode_out = split_channel_label(pin_out)
    if (
        [physical_pin_in, physical_pin_out] not in compact_model.connections
        and [physical_pin_out, physical_pin_in] not in compact_model.connections
    ):
        connection_value = None
    else:
        result_pin_in = model_channel_label(compact_model, pin_in)
        result_pin_out = model_channel_label(compact_model, pin_out)
        connection_value = result.get(result_pin_in, {}).get(result_pin_out, False)
        if connection_value is False:
            connection_value = result.get(result_pin_out, {}).get(result_pin_in, False)
        if connection_value is False:
            mode_in = _mode_in or default_mode_label()
            mode_out = _mode_out or default_mode_label()
            default_mode = default_mode_label()
            legacy_result_pin_in = physical_pin_in if mode_in == default_mode else result_pin_in
            legacy_result_pin_out = physical_pin_out if mode_out == default_mode else result_pin_out
            connection_value = result.get(legacy_result_pin_in, {}).get(legacy_result_pin_out, False)
            if connection_value is False:
                connection_value = result.get(legacy_result_pin_out, {}).get(legacy_result_pin_in, False)

    if connection_value is False:
        if missing_as_zero:
            return 0
        msg = f"Python compact model function '{compact_model.module}.{compact_model.call}' does " \
              f"not contain information\n for the connection between input pin '{pin_in}' and output pin '{pin_out}' " \
              f"as described in '{compact_model.source}.\n" \
              f"\tHint: Make sure the python function return value is formatted as a dictionary containing all " \
              f"connections as described by the yaml. \n\tFor example:\n" \
              "\t{\n\t\t'a0': {'b0': 3.2, 'b1': 4.1},\n\t\t'a1': {'b0': 4.1, 'b1': 3.2}," \
              "\n\t\t'b0': {'a0': 3.2, 'a1': 4.1},\n\t\t'b1': {'a0': 4.1, 'a1': 3.2},\n\t}"
        netlist.compact_model_logger(msg, 'error')
        raise ValueError(msg)
    return connection_value


def __create_simulation_info(module: str, call: str, kwargs=None) -> tuple[str, dict]:
    """Build a deterministic hash and metadata record for a compact-model evaluation.

    Args:
        module (str): Compact-model module identifier.
        call (str): Compact-model function name.
        kwargs (dict | None): Keyword arguments passed to the compact-model function.

    Returns:
        tuple[str, dict]: Simulation hash and the metadata dictionary used to
        create it.
    """
    metadata = {'module': module, 'call': call, 'kwargs': kwargs}

    bytes = pickle.dumps(metadata, protocol=pickle.HIGHEST_PROTOCOL)
    hasher = hashlib.sha256()
    hasher.update(bytes)

    return hasher.hexdigest(), metadata


def __store_simulation_result(metadata, cm_hash, result) -> None:
    """Persist simulation metadata and result for a compact-model evaluation.

    Metadata is written as JSON and the raw result object is written as a
    pickle file.

    Args:
        metadata (dict): Compact-model call metadata.
        cm_hash (str): Unique hash for the simulation call.
        result (dict): Result dictionary for the simulation call.

    Returns:
        None
    """
    if not os.path.isdir(f'compact_model_data/simulation_{cm_hash}'):
        os.mkdir(f'compact_model_data/simulation_{cm_hash}')

    # store metadata
    with open(f'compact_model_data/simulation_{cm_hash}/metadata.json', "w") as f:
        json.dump(metadata, f, indent=3)

    # convert complex values in dictionary to strings
    with open(f'compact_model_data/simulation_{cm_hash}/result.p', 'wb') as f:
        pickle.dump(result, f)


def __retrieve_simulation_result(cm_hash: str) -> dict:
    """Load a previously stored compact-model result from disk.

    Args:
        cm_hash (str): Unique hash for the compact-model function call and kwargs.

    Returns:
        dict: dictionary containing the compact model result
    """

    with open(f'compact_model_data/simulation_{cm_hash}/result.p', 'rb') as f:
        result = pickle.load(f)

    return result


def cm_dict(value: complex) -> dict:
    """Format a pin-type compact model into a cell type format.

    Args:
        value: result of a pin type compact model.

    Returns:
        dict: cell type compact models result.
    """
    return {'a0': {'b0': value}, 'b0': {'a0': value}}
