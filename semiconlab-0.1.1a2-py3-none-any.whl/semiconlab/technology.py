"""
SemiconLab PDK technology definition

This module defines the layers, the xsectional structures and the interconnections
of waveguide and metal in the SemiconLab technology.
"""

import os
from typing import Any

import nazca as nd


def offset(
    width: Any = None, radius: float = 500, pol: str = "TE", wl: Any = None
) -> float:
    """Return offset parameterized from ADS simulation, 400 nm Q1.25 core waveguide
    thickness on InP substrate, 100 nm InP cladding. Waveguide is 2 µm wide, and etched
    into the substrate (~100 nm, but this is not simulated in ADS).

    Args:
        width (any): ignored.
        radius (float): Radius of curvature in µm, default 500; 0 is straight waveguide.
        pol (str): Polarization, "TE" or "TM". Only TE implemented
        wl (any): ignored. Only simulated at 1.55 µm.

    Returns:
        float: Optimum offset in micron.

    """
    if pol != "TE":
        print(f"Only TE polarization supported. You specified {pol} which is ignored.")
    # Offset for zero curvature (straight waveguide) is 0
    if radius == 0:  # Signals straight waveguide
        return 0
    a, b = 29.53510546, 8.2078946
    return a / radius**2 + b / radius


# Store the path to the pdk directory (= path of this file).
dir_path = os.path.dirname(__file__)

# ==============================================================================
# Load SemiconLab layers and xsections from the csv tables
# ==============================================================================
layer_file = os.path.join(dir_path, "table_layers.csv")
xsection_file = os.path.join(dir_path, "table_xsections.csv")
xsection_layer_file = os.path.join(dir_path, "table_xsection_layer_map.csv")
layercolor_file = os.path.join(dir_path, "table_colors_Light.csv")

# load the tables
nd.load_layers(filename=layer_file)
nd.load_xsections(filename=xsection_file)
nd.load_xsection_layer_map(filename=xsection_layer_file)
nd.load_layercolors(filename=layercolor_file)

nazca_logo_layers = {"ring": "Trench", "box": None, "bird": "Metal"}
nazca_logo = nd.nazca_logo(nazca_logo_layers)

nd.add_pinstyle(
    name="default",
    styledict={
        "size": 1.5,  # size of the pin shape (by default an arrow)
        "stub_length": 4.0,  # length of the stub in um
    },
)
nd.add_pinstyle(
    name="metal",
    styledict={
        "size": 1.5,
        "stub_length": 4.0,  # length of the stub in um
    },
)

nd.pin2pin_drc_on()  # Switch on pin2pin DRC

xsWG = nd.get_xsection("WG")
xsMetal = nd.get_xsection("Metal")
xsMetalTrench = nd.get_xsection("MetalTrench")
xsMetalTrenchMesa = nd.get_xsection("MetalTrenchMesa")

# Set default values for these cross sections
xsWG.width = 2
xsWG.radius = 500
xsWG.os = offset
xsMetal.width = 10
xsMetal.radius = 15
xsMetalTrench.width = 10
xsMetalTrench.radius = 15
xsMetalTrenchMesa.width = 10
xsMetalTrenchMesa.radius = 15

xsMetal.pinstyle = "metal"

# Define the interconnections
wg = nd.interconnects.Interconnect(
    xs="WG",
    varname="wg",
    doc="Optical waveguide",
)  # Waveguide interconct
metal = nd.interconnects.Interconnect(xs="Metal")
metaltrench = nd.interconnects.Interconnect(xs="MetalTrench")
metalmesa = nd.interconnects.Interconnect(xs="MetalTrenchMesa")
