# -----------------------------------------------------------------------
# This file is part of Nazca.
#
# Nazca is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or (at
# your option) any later version.
#
# Nazca is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with Nazca.  If not, see <http://www.gnu.org/licenses/>.
# -----------------------------------------------------------------------
#
# @Authors: Katarzyna Lawniczuk, Ronald Broeke (c) 2017-2024
# @email: nazca@brightphotonics.eu


"""
**DEMO PDK building block definition.**

This module is intended to define the **building blocks** of a technology.
Building block definitions makes use of building block template functions.

This module also defines the default **Interconnect objects**,
which greatly facilitate making waveguide or metal interconnects between
building blocks.

To see the available building block and their details.
"""


import os

import nazca as nd
from nazca import Cell
import nazca.cfg as cfg
from nazca.cellcache_util import cellcache
from nazca.logging_util import logger
import nazca.bb_util as bbu
import nazca.compact_models as cm
import nazca.interconnects as interconnect

from . import __version__
from . import technology
import nazca.demofab.pdk_35_BB_icons as icons

logger.info(f"DEMOfab - PDK version: {__version__}")
dir_path = os.path.dirname(os.path.abspath(__file__))
store_pins = False
cfg.store_bbname = True

# switch pin2pin DRC on
nd.pin2pin_drc_on()

# switch off group connect in this file to save time (switch on again at bottom).
nd.cfg.group_connect = False

BBfunctioncalls = []  # Store PDK BB calls for test and documentation purposes

# Define the version info that will be added as annotation to each PDK cell
version = {
    "cellname": "auto",  # 'auto' will replace 'auto' with the actual cellname
    "owner": "nazca-design.org",  # building block owner
    "nazca_pdk_version": __version__,  # version string
}

# import compact models
cm.register_compact_model(
    header_file=os.path.join(dir_path, "cm_demofab.yaml"),
)

# ==============================================================================
# Optional: Assign xsection objects to variable names for ease of use in this file.
# ==============================================================================
xsShallow = nd.get_xsection("Shallow")  #: 'Shallow' xsection
xsDeep = nd.get_xsection("Deep")  #: 'Deep' xsection
xsMetalDC = nd.get_xsection("MetalDC")  #: 'MetalDC' xsection
xsMetalRF = nd.get_xsection("MetalRF")  #: 'MetalRF' xsection


# ==============================================================================
# Optional: Assign xsection parameter settings for ease of use in this file.
# ==============================================================================
wshal = xsShallow.width
Rshal = xsShallow.radius
wdeep = xsDeep.width
Rdeep = xsDeep.radius
wmetdc = xsMetalDC.width
Rmetdc = xsMetalRF.radius
wmetrf = xsMetalDC.width
Rmetrf = xsMetalRF.radius
wact = 2.0


# ==============================================================================
# Optional: define (multiple) pin styles and assign them to xsections
# See cfg.py pinstylelabels for all style options
# ==============================================================================
nd.add_pinstyle(
    name="guide",
    styledict={
        "size": 1.5,  # size of the pin shape (by default an arrow)
        "stub_length": 4.0,  # length of the stub in um
    },
)

nd.add_pinstyle(
    name="metal",
    styledict={
        "shape": "inv_pointer",  # shapes are defined as polygons in cfg.py
        "size": 3.0,
        "stub_length": 5.0,
    },
)

# Assign pinstyles to xsections:
xsShallow.pinstyle = "guide"
xsDeep.pinstyle = "guide"
xsMetalDC.pinstyle = "metal"
xsMetalRF.pinstyle = "metal"


# ==============================================================================
# Define Interconnects (settings default to values in the xsection attributes).
# ==============================================================================
shallow = interconnect.Interconnect(
    xs="Shallow",
    varname="shallow",
    doc="Shallow waveguide",
)  #: 'Shallow' interconnect

deep = interconnect.Interconnect(
    xs="Deep",
    varname="deep",
    doc="Deep waveguide",
)  #: 'Deep' interconnect

metaldc = interconnect.Interconnect(
    xs="MetalDC",
    varname="metaldc",
    doc="Metal DC line",
)  #: 'MetalDC' interconnect

metalrf = interconnect.Interconnect(
    xs="MetalRF",
    varname="metalrf",
    doc="Metal RF line",
)  #: 'MetalRF' interconnect


# ==============================================================================
#
# BUILDING BLOCKS
#
# ==============================================================================


# ==============================================================================
# waveguide transitions
# ==============================================================================
@bbu.technology(technology)
@cellcache("d2s")
def d2s() -> Cell:
    """Create a Deep to Shallow waveguide transition

    Returns:
        Cell
    """
    with nd.Cell() as C:
        C.default_pins("a0", "b0")
        C.store_pins = store_pins
        C.version = version
        nd.Pin(name="a0", xs="Deep", width=wdeep, remark="optical").put(0, 0, 180)
        nd.put_stub("a0")
        nd.Pin(name="b0", xs="Shallow", width=wshal, remark="optical").put(75, 0, 0)
        nd.put_stub("b0")
        nd.connect_path(C.pin["a0"], C.pin["b0"], 75)
        C.userbbox = [(0, -27.5), (75, -27.5), (75, 27.5), (0, 27.5)]
        C._add_bbox()
        icons.icon_d2s(length=C.length, width=C.width).put("cc", 0, "cc")
        C.group = "None"
    return C


BBfunctioncalls.append("d2s()")


@bbu.technology(technology)
@cellcache("s2d")
def s2d() -> Cell:
    """Create a Shallow to Deep waveguide transition

    Returns:
        Cell
    """
    with nd.Cell() as C:
        C.default_pins("a0", "b0")
        C.store_pins = store_pins
        C.version = version
        nd.Pin(name="a0", xs="Shallow", width=wshal, remark="optical").put(0, 0, 180)
        nd.put_stub("a0")
        nd.Pin(name="b0", xs="Deep", width=wdeep, remark="optical").put(75, 0, 0)
        nd.put_stub("b0")
        nd.connect_path(C.pin["a0"], C.pin["b0"], 75)
        C.userbbox = [(0, -27.5), (75, -27.5), (75, 27.5), (0, 27.5)]
        C._add_bbox()
        icons.icon_s2d(length=C.length, width=C.width).put("cc", 0, "cc")
        C.group = "None"
    return C


BBfunctioncalls.append("s2d()")


@bbu.technology(technology)
@cellcache("a2s")
def a2s() -> Cell:
    """Create an Active to Shallow waveguide transition

    Returns:
        Cell
    """
    with nd.Cell() as C:
        C.default_pins("a0", "b0")
        C.store_pins = store_pins
        C.version = version
        nd.Pin(name="a0", xs="Active", width=wact, remark="optical").put(0, 0, 180)
        nd.put_stub("a0")
        nd.Pin(name="b0", xs="Shallow", width=wshal, remark="optical").put(75, 0, 0)
        nd.put_stub("b0")
        nd.connect_path(C.pin["a0"], C.pin["b0"], 75)
        C.userbbox = [(0, -27.5), (75, -27.5), (75, 27.5), (0, 27.5)]
        C._add_bbox()
        icons.icon_a2s(length=C.length, width=C.width).put("cc", 0, "cc")
        C.group = "None"
    return C


BBfunctioncalls.append("a2s()")


@bbu.technology(technology)
@cellcache("s2a")
def s2a() -> Cell:
    """Create a Shallow to Active waveguide transition

    Returns:
        Cell
    """
    with nd.Cell() as C:
        C.default_pins("a0", "b0")
        C.store_pins = store_pins
        C.version = version
        nd.Pin(name="a0", xs="Shallow", width=wshal, remark="optical").put(0, 0, 180)
        nd.put_stub("a0")
        nd.Pin(name="b0", xs="Active", width=wact, remark="optical").put(75, 0, 0)
        nd.put_stub("b0")
        nd.connect_path(C.pin["a0"], C.pin["b0"], 75)
        C.userbbox = [(0, -27.5), (75, -27.5), (75, 27.5), (0, 27.5)]
        C._add_bbox()
        icons.icon_s2a(length=C.length, width=C.width).put("cc", 0, "cc")
        C.group = "None"
    return C


BBfunctioncalls.append("s2a()")


# ==============================================================================
# splitters
# ==============================================================================
@bbu.technology(technology)
@cellcache("modefilter_sh")
def mmi1x1_sh() -> Cell:
    """Create a modefilter cell in shallow cross-section

    Returns:
        Cell
    """
    with nd.Cell() as C:
        C.default_pins("a0", "b0")
        C.store_pins = store_pins
        C.version = version
        nd.Pin(name="a0", xs="Shallow", width=wshal, remark="optical").put(0, 0, 180)
        nd.put_stub("a0")
        nd.Pin(name="b0", xs="Shallow", width=wshal, remark="optical").put(80)
        nd.put_stub("b0")
        nd.connect_path(C.pin["a0"], C.pin["b0"], 80)
        C.userbbox = [(0, -27.5), (80, -27.5), (80, 27.5), (0, 27.5)]
        C._add_bbox()
        icons.icon_modefilter_sh(length=C.length, width=C.width).put("cc", 0, "cc")
        C.group = "None"
    return C


BBfunctioncalls.append("mmi1x1_sh()")


@bbu.technology(technology)
@cellcache("mmi1x2_sh")
def mmi1x2_sh() -> Cell:
    """Create a 1x2 MMI cell in shallow cross-section

    Returns:
        Cell
    """
    with nd.Cell() as C:
        C.default_pins("a0", "b0")
        C.store_pins = store_pins
        C.version = version
        nd.Pin(name="a0", xs="Shallow", width=wshal, remark="optical").put(0, 0, 180)
        nd.put_stub("a0")
        nd.Pin(name="b0", xs="Shallow", width=wshal, remark="optical").put(80, 2)
        nd.put_stub("b0")
        nd.Pin(name="b1", xs="Shallow", width=wshal, remark="optical").put(80, -2)
        nd.put_stub("b1")
        nd.connect_path(C.pin["a0"], C.pin["b0"], 80)
        nd.connect_path(C.pin["a0"], C.pin["b1"], 80)
        C.userbbox = [(0, -27.5), (80, -27.5), (80, 27.5), (0, 27.5)]
        C._add_bbox()
        icons.icon_mmi1x2_sh(length=C.length, width=C.width).put("cc", 0, "cc")
        C.group = "None"
    return C


BBfunctioncalls.append("mmi1x2_sh()")


@bbu.technology(technology)
@cellcache("mmi2x2_sh")
def mmi2x2_sh() -> Cell:
    """Create a 2x2 MMI cell in shallow cross-section

    Returns:
        Cell
    """
    with nd.Cell() as C:
        C.default_pins("a0", "b0")
        C.store_pins = store_pins
        C.version = version
        nd.Pin(name="a0", xs="Shallow", width=wshal, remark="optical").put(0, 4, 180)
        nd.put_stub("a0")
        nd.Pin(name="a1", xs="Shallow", width=wshal, remark="optical").put(0, -4, 180)
        nd.put_stub("a1")
        nd.Pin(name="b0", xs="Shallow", width=wshal, remark="optical").put(350, 4)
        nd.put_stub("b0")
        nd.Pin(name="b1", xs="Shallow", width=wshal, remark="optical").put(350, -4)
        nd.put_stub("b1")
        nd.connect_path(C.pin["a0"], C.pin["b0"], 350)
        nd.connect_path(C.pin["a0"], C.pin["b1"], 350)
        nd.connect_path(C.pin["a1"], C.pin["b0"], 350)
        nd.connect_path(C.pin["a1"], C.pin["b1"], 350)
        C.userbbox = [(0, -30.0), (350.0, -30.0), (350.0, 30.0), (0, 30.0)]
        C._add_bbox()
        icons.icon_mmi2x2_sh(length=C.length, width=C.width).put("cc", 0, "cc")
        C.group = "None"
    return C


BBfunctioncalls.append("mmi2x2_sh()")


@bbu.technology(technology)
@cellcache("mmi1x2_dp")
def mmi1x2_dp() -> Cell:
    """Create a 1x2 MMI cell in deep cross-section

    Returns:
        Cell
    """
    with nd.Cell() as C:
        C.default_pins("a0", "b0")
        C.store_pins = store_pins
        C.version = version
        nd.Pin(name="a0", xs="Deep", width=wdeep, remark="optical").put(0, 0, 180)
        nd.put_stub("a0")
        nd.Pin(name="b0", xs="Deep", width=wdeep, remark="optical").put(80, 2)
        nd.put_stub("b0")
        nd.Pin(name="b1", xs="Deep", width=wdeep, remark="optical").put(80, -2)
        nd.put_stub("b1")
        nd.connect_path(C.pin["a0"], C.pin["b0"], 80)
        nd.connect_path(C.pin["a0"], C.pin["b1"], 80)
        C.userbbox = [(0, -27.5), (80, -27.5), (80, 27.5), (0, 27.5)]
        C._add_bbox()
        icons.icon_mmi1x2_dp(length=C.length, width=C.width).put("cc", 0, "cc")
        C.group = "None"
    return C


BBfunctioncalls.append("mmi1x2_dp()")


@bbu.technology(technology)
@cellcache("mmi2x2_dp")
def mmi2x2_dp() -> Cell:
    """Create a 2x2 MMI cell in deep cross-section

    Returns:
        Cell
    """
    with nd.Cell() as C:
        C.default_pins("a0", "b0")
        C.store_pins = store_pins
        C.version = version
        nd.Pin(name="a0", xs="Deep", width=wdeep, remark="optical").put(0, 4, 180)
        nd.put_stub("a0")
        nd.Pin(name="a1", xs="Deep", width=wdeep, remark="optical").put(0, -4, 180)
        nd.put_stub("a1")
        nd.Pin(name="b0", xs="Deep", width=wdeep, remark="optical").put(250, 4)
        nd.put_stub("b0")
        nd.Pin(name="b1", xs="Deep", width=wdeep, remark="optical").put(250, -4)
        nd.put_stub("b1")
        nd.connect_path(C.pin["a0"], C.pin["b0"], 250)
        nd.connect_path(C.pin["a0"], C.pin["b1"], 250)
        nd.connect_path(C.pin["a1"], C.pin["b0"], 250)
        nd.connect_path(C.pin["a1"], C.pin["b1"], 250)
        C.userbbox = [(0, -30.0), (250.0, -30.0), (250.0, 30.0), (0, 30.0)]
        C._add_bbox()
        icons.icon_mmi2x2_dp(length=C.length, width=C.width).put("cc", 0, "cc")
        C.group = "None"
    return C


BBfunctioncalls.append("mmi2x2_dp()")


# ==============================================================================
# modulators
# ==============================================================================
@bbu.technology(technology)
@cellcache("abb_eopm_dc", ["length", "contacts"])
def abb_eopm_dc(length: float = 750, contacts: int = 2) -> Cell:
    """Create an electro-optic phase modulator cell.

    Args:
        length (float): length of the modulator section in um

    Returns:
        Cell: eopm element
    """
    varsinfo = {
        "length": nd.varinfo(
            min=100,
            default=length,
            max=2000,
            type="float",
            unit="um",
            doc="length of eopm",
        ),
        "contacts": nd.varinfo(0, contacts, 6, "int", "null", "number of contacts"),
    }

    with nd.Cell() as C:
        nd.rangecheck(varsinfo)
        C.default_pins("a0", "b0")
        C.store_pins = store_pins
        C.version = version
        nd.Pin(name="a0", xs="Deep", width=wdeep, remark="optical").put(0, 0, 180)
        nd.put_stub("a0")
        nd.Pin(name="b0", xs="Deep", width=wdeep, remark="optical").put(length, 0, 0)
        nd.put_stub("b0")
        nd.connect_path(C.pin["a0"], C.pin["b0"], length)

        # x-positions of pads:
        L = 0.5 * (length - wmetdc)
        xpos = []
        if contacts > 1:
            for n in range(contacts):
                xpos.append(0.5 * wmetdc + L * 2 * n / (contacts - 1))
        elif contacts == 1:
            xpos = [0.5 * length]
        elif contacts == 0:
            pass
        for n, x in enumerate(xpos):
            pinname = "c" + str(n)
            nd.Pin(name=pinname, xs="MetalDC", width=wmetdc).put(x, 0, 90)
            nd.put_stub(pinname)

        C.userbbox = [(0, -30.0), (length, -30.0), (length, 30.0), (0, 30.0)]
        C._add_bbox()
        icons.icon_strt(C.length, C.width, bufx=0, bufy=10, layer="MetalDCLogic").put("cc", 0, "cc")
        icons.icon_strt(C.length, C.width, bufx=10, bufy=-8, layer="DeepLogic").put("cc", 0, "cc")
    return C


BBfunctioncalls.append("abb_eopm_dc()")


# ==============================================================================
# photodiodes
# ==============================================================================
@bbu.technology(technology)
@cellcache("pd")
def pd() -> Cell:
    """Create a PhotoDetector Cell in deep cross-section.

    Returns:
        Cell
    """
    with nd.Cell() as C:
        C.default_pins("a0", "a0")
        C.store_pins = store_pins
        C.version = version
        bb_length = 50 + 20
        nd.Pin(name="a0", xs="Deep", width=wdeep, remark="optical").put(0, 0, 180)
        nd.put_stub("a0")
        nd.Pin(name="c0", xs="MetalDC", width=wmetdc, remark="electrical").put(bb_length)
        nd.put_stub("c0")
        nd.connect_path(C.pin["a0"], C.pin["c0"], cm=0, sigtype="o2e")
        C.userbbox = [(0, -27.5), (70, -27.5), (70, 27.5), (0, 27.5)]
        C._add_bbox()
        icons.icon_strt(C.length, C.width, bufx=0, bufy=12.5, layer="MetalDCLogic").put("cc", 0, "cc")
    return C


BBfunctioncalls.append("pd()")


# ==============================================================================
# laser elements
# ==============================================================================
@bbu.technology(technology)
@cellcache("soa", ["length", "pad"])
def soa(length: float = 100.0, pad: bool = True) -> Cell:
    """Create a SOA cell.

    Args:
        length (float): length of gain section in um

    Returns:
        Cell: SOA element
    """
    if pad:
        width = 200
    else:
        width = 50

    varsinfo = {
        "length": nd.varinfo(10, length, 2000, "float", "um", "length of soa"),
    }

    dy = -70
    with nd.Cell() as C:
        nd.rangecheck(varsinfo)
        C.default_pins("a0", "b0")
        C.store_pins = store_pins
        C.version = version
        nd.Pin(name="a0", xs="Active", width=wact).put(0, dy, 180)
        nd.put_stub("a0")
        nd.Pin(name="b0", xs="Active", width=wact).put(length, dy, 0)
        nd.put_stub("b0")
        nd.connect_path(C.pin["a0"], C.pin["b0"], length)
        nd.Pin(name="c0", xs="MetalDC", width=wmetdc).put(0.5 * length, 5.0, 90)
        nd.put_stub("c0")
        C.userbbox = [(0, -width / 2), (length, -width / 2), (length, width / 2), (0, width / 2)]
        C._add_bbox()
        icons.icon_strt(length, width, bufx=0, bufy=10, layer="MetalDCLogic").put("cc", 0, "cc")
        icons.icon_strt(length, width, bufx=10, bufy=-8, layer="ActiveLogic").put("cc", 0, dy, "cc")
    return C


BBfunctioncalls.append("soa()")


@bbu.technology(technology)
@cellcache("soa_sh", ["length"])
def soa_sh(length: float = 100.0) -> Cell:
    """Create a SOA cell with Shallow io.

    Args:
        length (float): length of gain section in um

    Returns:
        Cell: SOA element
    """
    varsinfo = {
        "length": nd.varinfo(10, length, 2000, "float", "um", "length of soa"),
    }

    with nd.Cell() as C:
        nd.rangecheck(varsinfo)
        C.default_pins("a0", "b0")
        C.store_pins = store_pins
        C.version = version
        s2a_ = s2a().put(0)
        soa_ = soa(length).put()
        a2s_ = a2s().put()
        nd.Pin(name="a0", pin=s2a_.pin["a0"]).put()
        nd.Pin(name="b0", pin=a2s_.pin["b0"]).put()
        nd.Pin(name="c0", pin=soa_.pin["c0"]).put()

    return C


BBfunctioncalls.append("soa_sh()")


@bbu.technology(technology)
@cellcache("dbr", ["length", "pitch", "duty_cycle"])
def dbr(length: float = 100.0, pitch: float = 0.250, duty_cycle: float = 0.5) -> Cell:
    """Create a DBR cell.

    Args:
        length (float): length of DBR section in um
        pitch (float): pitch (full period) of dbr in um
        duty_cycle (float): duty cycle of grating (default = 0.5)

    Returns:
        Cell: dbr element
    """
    width = 200
    dy = -70
    varsinfo = {
        "length": nd.varinfo(
            min=0.0,
            default=length,
            max=1000.0,
            type="float",
            unit="um",
            doc="length of dbr",
        ),
        "pitch": nd.varinfo(
            min=0.1,
            default=pitch,
            max=0.5,
            type="float",
            unit="um",
            doc="pitch (full period) of dbr",
        ),
        "duty_cycle": nd.varinfo(
            min=0.0,
            default=duty_cycle,
            max=1.0,
            type="float",
            unit="um",
            doc="duty cycle of grating",
        ),
    }

    with nd.Cell() as C:
        nd.rangecheck(varsinfo)
        C.default_pins("a0", "b0")
        C.store_pins = store_pins
        C.version = version
        nd.Pin(name="a0", xs="Active", width=wact).put(0, dy, 180)
        nd.put_stub("a0")
        nd.Pin(name="b0", xs="Active", width=wact).put(length, dy, 0)
        nd.put_stub("b0")
        nd.Pin(name="c0", xs="MetalDC", width=wmetdc).put(0.5 * length, 5.0, 90)
        nd.put_stub("c0")
        nd.connect_path(C.pin["a0"], C.pin["b0"], length)
        C.userbbox = [(0, -width / 2), (length, -width / 2), (length, width / 2), (0, width / 2)]
        C._add_bbox()
        icons.icon_strt(length, width, bufx=0, bufy=10, layer="MetalDCLogic").put("cc", 0, "cc")
        icons.icon_strt(length, width, bufx=10, bufy=-8, layer="ActiveLogic").put("cc", 0, dy, "cc")
        icons.icon_grating(length, width, bufx=5, bufy=-40).put("cc", 0, dy, "cc")
    return C


BBfunctioncalls.append("dbr()")


@bbu.technology(technology)
@cellcache("phase_shifter", ["length"])
def phase_shifter(length: float = 100.0) -> Cell:
    """Create a current injection phase shifting cell.

    Args:
        length (float): length of phase section in um

    Returns:
        Cell: phase-shifter element
    """

    width = 200
    dy = -70
    with nd.Cell() as C:
        nd.rangecheck(
            {
                "length": nd.varinfo(
                    min=10,
                    default=length,
                    max=2000,
                    type="float",
                    unit="um",
                    doc="length of phase_shifter",
                ),
            }
        )
        C.default_pins("a0", "b0")
        C.store_pins = store_pins
        C.version = version
        nd.Pin(name="a0", xs="Active", width=wact).put(0, dy, 180)
        nd.put_stub("a0")
        nd.Pin(name="b0", xs="Active", width=wact).put(length, dy, 0)
        nd.put_stub("b0")
        nd.Pin(name="c0", xs="MetalDC", width=wmetdc).put(0.5 * length, 5.0, 90)
        nd.put_stub("c0")
        nd.connect_path(C.pin["a0"], C.pin["b0"], length)
        C.userbbox = [(0, -width / 2), (length, -width / 2), (length, width / 2), (0, width / 2)]
        C._add_bbox()
        icons.icon_strt(length, width, bufx=0, bufy=10, layer="MetalDCLogic").put("cc", 0, "cc")
        icons.icon_strt(length, width, bufx=10, bufy=-8, layer="ActiveLogic").put("cc", 0, dy, "cc")
    return C


BBfunctioncalls.append("phase_shifter()")


@bbu.technology(technology)
@cellcache("isolation_sh", ["length"])
def isolation_sh(length: float = 100.0) -> Cell:
    """Create a p-isolation cell in shallow.

    Args:
        length (float): length of the isolation section in um

    Returns:
        Cell: isolation element
    """
    with nd.Cell() as C:
        nd.rangecheck(
            {
                "length": nd.varinfo(
                    min=0,
                    default=length,
                    max=2000,
                    type="float",
                    unit="um",
                    doc="length of isolation",
                ),
            }
        )
        C.default_pins("a0", "b0")
        C.store_pins = store_pins
        C.version = version
        nd.Pin(name="a0", xs="Shallow", width=wshal).put(0, 0, 180)
        nd.put_stub("a0")
        nd.Pin(name="b0", xs="Shallow", width=wshal).put(length, 0, 0)
        nd.put_stub("b0")
        nd.connect_path(C.pin["a0"], C.pin["b0"], length)
        C.userbbox = [(0, -10), (length, -10), (length, 10), (0, 10)]
        C._add_bbox()
        icons.icon_strt(length, 20, bufx=4, bufy=-8, layer="ShallowLogic").put("cc", 0, "cc")
    return C


BBfunctioncalls.append("isolation_sh()")


@bbu.technology(technology)
@cellcache("isolation_act", ["length"])
def isolation_act(length: float = 100.0) -> Cell:
    """Create a p-isolation cell in active.

    Args:
        length (float): length of the isolation section in um

    Returns:
        Cell: isolation element
    """
    with nd.Cell() as C:
        nd.rangecheck(
            {
                "length": nd.varinfo(
                    min=0,
                    default=length,
                    max=2000,
                    type="float",
                    unit="um",
                    doc="length of isolation",
                ),
            }
        )
        C.default_pins("a0", "b0")
        C.store_pins = store_pins
        C.version = version
        nd.Pin(name="a0", xs="Active", width=wact).put(0, 0, 180)
        nd.put_stub("a0")
        nd.Pin(name="b0", xs="Active", width=wact).put(length, 0, 0)
        nd.put_stub("b0")
        nd.connect_path(C.pin["a0"], C.pin["b0"], length)
        C.userbbox = [(0, -10), (length, -10), (length, 10), (0, 10)]
        C._add_bbox()
        icons.icon_strt(length, 20, bufx=4, bufy=-8, layer="ActiveLogic").put("cc", 0, "cc")
    return C


BBfunctioncalls.append("isolation_act()")


# ==============================================================================
# io_optical
# ==============================================================================
@bbu.technology(technology)
@cellcache("io", ["shape", "width_out", "bend", "deep_input"])
def io(
    shape: str = "tapered", width_out: float = 4.5, bend: bool = False, deep_input: bool = False
) -> Cell:
    """Create an IO cells that for edge coupling waveguide interfaces.

    Args:
        shape (str): shape of IO. values: None | 'simple' | 'tapered' | 'angled'
        width_out (float): Optional output width of the io in um.
        bend (bool): make the IO connection horizontal (True) for connecting to layout
        deep_input (bool): add a transition to a deeply-etched waveguides (default = False)

    Returns:
        Cell: io element
    """
    options = ["simple", "tapered", "angled"]
    if shape is None:
        shape = "simple"
    if shape not in options:
        print("Error: io shape '{}'not recognized. Options are: {}".format(shape, options))

    pin_indent = 0
    length = 100 - pin_indent

    if shape == "tapered":
        with nd.Cell() as C:
            C.default_pins("a0", "b0")
            C.store_pins = store_pins
            C.version = version
            C.autobbox = True
            s = shallow.strt(length, arrow=False).put(0)
            iowg = shallow.taper(length, width1=wshal, width2=width_out, arrow=False).put()
            if deep_input:
                s = shallow.strt(10, arrow=False).put(s.pin["a0"])
                iowg = s2d().put()
            nd.Pin("a0", pin=s.pin["a0"]).put()
            nd.Pin("b0", pin=iowg.pin["b0"]).put()
            nd.put_stub()

    elif shape == "angled":
        with nd.Cell() as C:
            C.default_pins("a0", "b0")
            C.store_pins = store_pins
            C.version = version
            C.autobbox = True
            if not bend:
                s = shallow.strt(length, arrow=False).put(0)
                iowg = shallow.taper(length, width1=wshal, width2=width_out, arrow=False).put()
                if deep_input:
                    shallow.strt(10, arrow=False).put()
                    iowg = s2d().put()
                nd.Pin("a0", pin=s.pin["a0"]).put()
                nd.Pin("b0", pin=iowg.pin["b0"]).put()
                nd.put_stub()

            else:
                s = shallow.strt(length, arrow=False).put(0, 0, 7)
                iowg = shallow.taper(length, width1=wshal, width2=width_out, arrow=False).put()
                b = shallow.bend(angle=-7, arrow=False).put(s.pin["a0"])
                if deep_input:
                    b = shallow.strt(10, arrow=False).put()
                    iowg = s2d().put()
                nd.Pin("a0", pin=b.pin["b0"]).put()
                nd.Pin("b0", pin=iowg.pin["b0"]).put()
                nd.put_stub()

    else:  # shape == None or shape == 'simple':
        with nd.Cell() as C:
            C.default_pins("a0", "b0")
            C.store_pins = store_pins
            C.version = version
            C.autobbox = True
            iowg = shallow.strt(length).put(0)
            if deep_input:
                s = s2d().put(iowg.pin["a0"])
                nd.Pin("a0", pin=s.pin["b0"]).put()
                nd.Pin("b0", pin=iowg.pin["b0"]).put()
            else:
                nd.Pin("a0", pin=iowg.pin["a0"]).put()
                nd.Pin("b0", pin=iowg.pin["b0"]).put()
            nd.put_stub()

    return C


BBfunctioncalls.append("io()")


# ==============================================================================
# io_electrical
# ==============================================================================
@bbu.technology(technology)
@cellcache("pad_dc", ["length", "width"])
def pad_dc(length: float = 150.0, width: float = 150.0) -> Cell:
    """Create and return a DCpad cell.

    Args:
        length (float): pad length in um
        width (float): pad width in um

    Returns:
        Cell: pad element
    """
    with nd.Cell() as C:
        C.default_pins("c0", "c0")
        C.store_pins = store_pins
        C.version = version
        bb_length = length + 20
        bb_width = width + 20
        C.default_pins("c0", "c0")
        nd.Pin(name="c0", xs="MetalDC", width=wmetdc, remark="electrical").put(0.5 * bb_length, 0, 180)
        nd.put_stub("c0", length=wmetdc, shape="circle")
        C.userbbox = [
            (0, -bb_width / 2),
            (bb_length, -bb_width / 2),
            (bb_length, bb_width / 2),
            (0, bb_width / 2),
        ]
        C._add_bbox()
        icons.icon_pad_dc(length=C.length, width=C.width).put("cc", 0, "cc")
    return C


BBfunctioncalls.append("pad_dc()")


@bbu.technology(technology)
@cellcache("pad_rf", ["length", "width"])
def pad_rf(length: float = 80.0, width: float = 80.0) -> Cell:
    """Create a RFpad cell.

    Returns:
        Cell
    """
    with nd.Cell() as C:
        C.default_pins("c0", "c0")
        C.store_pins = store_pins
        C.version = version
        nd.Pin(name="c0", xs="MetalRF", width=wmetrf, remark="electrical").put(0, 0, 180)
        nd.put_stub("c0")
        C.userbbox = [(0, -width / 2), (length, -width / 2), (length, width / 2), (0, width / 2)]
        C._add_bbox()

        icons.icon_strt(
            length=C.length,
            width=C.width,
            bufx=0,
            bufy=5,
            layer="MetalRFLogic",
        ).put("cc", 0, "cc")
    return C


BBfunctioncalls.append("pad_rf()")


# =============================================================================
# Composite building blocks
# =============================================================================
@bbu.technology(technology)
@cellcache("eopm_dc", ["length", "pads", "sep"])
def eopm_dc(length: float = 1000.0, pads: bool = False, sep: float = 10.0) -> Cell:
    """EOPM with pad option.

    Args:
        length (float): modulator length in um
        pads (bool): draw pads if True (default = False)
        sep (float): separation of pad bbox from eopm stub.

    Returns:
        Cell: eopm element
    """
    # Define range checking:
    varinfo = {
        "length": nd.varinfo(
            min=0.0,
            default=length,
            max=2000.0,
            type="float",
            unit="um",
            doc="length of eopm",
        ),
        "pads": nd.varinfo(
            min=None,
            default=pads,
            max=None,
            type="bool",
            unit="null",
            doc="flag to add pads or not",
        ),
        "sep": nd.varinfo(
            min=0.0,
            default=sep,
            max=500.0,
            type="float",
            unit="um",
            doc="separtions of pads from the soa",
        ),
    }

    contacts = 2
    with nd.Cell() as C:
        nd.rangecheck(varinfo)
        C.default_pins("a0", "b0")
        C.store_pins = store_pins
        C.version = version
        E1 = abb_eopm_dc(length=length, contacts=contacts).put(0)
        if pads:
            for i in range(contacts):
                pname = "c" + str(i)
                E2 = pad_dc().put("rc", E1.pin[pname].move(sep))
                metaldc.strt_p2p(pin1=E1.pin[pname], pin2=E2).put()
                E2.raise_pins(["c0"], [pname])
            E1.raise_pins(["a0", "b0"])
        else:
            E1.raise_pins()
    return C


BBfunctioncalls.append("eopm_dc()")


@bbu.technology(technology)
@cellcache("PD_dc", ["pads", "sep"])
def pd_dc(pads: bool = False, sep: float = 0.0) -> Cell:
    """PhotoDiode with pad option.

    Args:
        pads (bool): draw pads if True (default = False)
        sep (float): separation of pad bbox from pin stub.

    Returns:
        Cell: PD element
    """
    # Define range checking:
    varinfo = {
        "pads": nd.varinfo(
            min=None,
            default=pads,
            max=None,
            type="bool",
            unit="null",
            doc="flag to add pads or not",
        ),
        "sep": nd.varinfo(
            min=0.0,
            default=sep,
            max=500.0,
            type="float",
            unit="um",
            doc="separtions of pads from the pd",
        ),
    }

    with nd.Cell() as C:
        nd.rangecheck(varinfo)
        C.default_pins("a0", "a0")
        C.store_pins = store_pins
        C.version = version
        E1 = pd().put(0)
        if pads:
            E2 = pad_dc().put("rc", E1.pin["c0"].move(sep))
            metaldc.strt_p2p(pin1=E1.pin["c0"], pin2=E2).put()
            E2.raise_pins(["c0"])
            E1.raise_pins(["a0"])
        else:
            E1.raise_pins()
    return C


BBfunctioncalls.append("pd_dc()")


@bbu.technology(technology)
@cellcache("dbr_laser", ["Ldbr1", "Ldbr2", "Lsoa", "Lpm"])
def dbr_laser(
    Ldbr1: float = 50.0, Ldbr2: float = 500.0, Lsoa: float = 750.0, Lpm: float = 70.0
) -> Cell:
    """Create a parametrized dbr laser building block.

    Args:
        Ldbr1 (float): length of the front dbr in um.
        Ldbr2 (float): length of the back dbr in um.
        Lsoa (float): length of the SOA in um.
        Lpm (float): length of the phase modulator in um.

    Returns:
        Cell: DBR laser element
    """
    Liso = 20
    with nd.Cell() as C:
        C.default_pins("a0", "b0")
        C.store_pins = store_pins
        C.version = version
        C.autobbox = True
        # create an isolation cell for reuse
        iso = isolation_act(length=Liso)

        # draw the laser
        s2a1 = s2a().put(0)
        iso.put()
        dbr1 = dbr(length=Ldbr1).put()
        iso.put()
        soa1 = soa(length=Lsoa).put()
        iso.put()
        phase1 = phase_shifter(length=Lpm).put()
        iso.put()
        dbr2 = dbr(length=Ldbr2).put()
        iso.put()
        a2s1 = a2s().put()

        # add pins to the laser building block
        nd.Pin("a0", pin=s2a1.pin["a0"]).put()
        nd.Pin("b0", pin=a2s1.pin["b0"]).put()
        nd.Pin("c0", pin=dbr1.pin["c0"]).put()
        nd.Pin("c1", pin=soa1.pin["c0"]).put()
        nd.Pin("c2", pin=phase1.pin["c0"]).put()
        nd.Pin("c3", pin=dbr2.pin["c0"]).put()
        nd.put_stub()
    return C


BBfunctioncalls.append("dbr_laser()")


@bbu.technology(technology)
@cellcache("mzi", ["length", "sep"])
def mzi(length: float = 1000.0, sep: float = 50.0) -> Cell:
    """Creates a symmetric MZI with phase shifters in both arms

    Args:
        length (float): Length of the phase shifters
        sep (float): offset of the internal s-bends

    Returns:
        Cell: MZI element
    """
    with nd.Cell() as C:
        C.default_pins("a0", "b0")
        C.store_pins = store_pins
        C.version = version
        C.autobbox = True

        eopm = eopm_dc(length=length, sep=40)
        mmi_left = mmi2x2_dp().put("lc")
        deep.sbend(offset=sep).put(mmi_left.pin["b0"])
        eopm_top = eopm.put()
        deep.sbend(offset=-sep, length1=0.01).put()
        mmi_right = mmi2x2_dp().put()

        deep.sbend(offset=-sep).put(mmi_left.pin["b1"])
        eopm_bot = eopm.put(flip=True)
        deep.sbend_p2p(pin2=mmi_right.pin["a1"]).put()

        nd.Pin("a0", pin=mmi_left.pin["a0"]).put()
        nd.Pin("a1", pin=mmi_left.pin["a1"]).put()
        nd.Pin("b0", pin=mmi_right.pin["b0"]).put()
        nd.Pin("b1", pin=mmi_right.pin["b1"]).put()
        nd.Pin("c0", pin=eopm_top.pin["c0"]).put()
        nd.Pin("c1", pin=eopm_top.pin["c1"]).put()
        nd.Pin("d0", pin=eopm_bot.pin["c0"]).put()
        nd.Pin("d1", pin=eopm_bot.pin["c1"]).put()
        nd.put_stub()
    return C


BBfunctioncalls.append("mzi()")


# ==============================================================================
# GDS based BBs
# ==============================================================================
@bbu.technology(technology)
@cellcache("awg1x4")
def awg1x4() -> Cell:
    """Creates a 1x4 AWG cell

    Returns:
        Cell: AWG element
    """
    with nd.Cell() as awg1x4BB:
        awg1x4BB.version = version
        awg = nd.load_gds(
            filename=os.path.join(dir_path, "gdsBB", "AWG_1x4.gds"),
            cellname="awg",
            newcellname="demo_awg",
            layermap={1: 3, 20: "BB"},
        )
        awg.put()

        nd.Pin("a0", xs="Deep", width=wdeep).put((9.184851e-016, -5, -90))
        nd.Pin("b0", xs="Deep", width=wdeep).put((273.63575, -4.5798919, -85.569401))
        nd.Pin("b1", xs="Deep", width=wdeep).put((269.89849, -4.9532407, -88.523134))
        nd.Pin("b2", xs="Deep", width=wdeep).put((266.1423, -4.9532407, -91.476866))
        nd.Pin("b3", xs="Deep", width=wdeep).put((262.40504, -4.5798919, -94.430599))

        #nd.put_stub(["a0", "b0", "b1", "b2", "b3"])
    return awg1x4BB


BBfunctioncalls.append("awg1x4()")


def BBcells():
    return [eval(F) for F in BBfunctioncalls]


nd.cfg.group_connect = True
