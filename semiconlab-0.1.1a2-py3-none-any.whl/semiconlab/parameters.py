"""Define the (geometrical) parameters"""

# These are arbitrary numbers. The MMIs will not work with these dimensions.

# Length, width and offset of 1x2 MMI
LMMI1x2 = 50
WMMI1x2 = 6
OMMI1x2 = 1.5

# Length, width and offset of 2x2 MMI
LMMI2x2 = 80
WMMI2x2 = 7
OMMI2x2 = 1.75
