# ==============================================================================
# (c) 2017,2018 Katarzyna Lawniczuk, Ronald Broeke, Xaveer Leijtens
# ==============================================================================
"""
SemiconLab MPW initialization
"""

from itertools import count
from math import cos, radians, sin, tan

import nazca as nd
import nazca.geometries as geom
import nazca.pdk_template as tdk
from nazca.bb_util import make_pincell
from nazca.cellcache_util import cellcache

import semiconlab as sl

from .technology import xsWG


# ==============================================================================
# Die template
# ==============================================================================
class DesignArea:
    """Class containing a Die - Design Area template for Polarization MPW."""

    instnum = count()

    def __init__(
        self,
        name: str = "SemiconLab",
        length: float = 4600,
        height: float = 4000,
        cleave: float = 100,
        coatingW: str = "NO",
        coatingE: str = "NO",
        pitch: float = 12.5,
    ) -> None:
        """Construct a DieArea object.

        Args:
            name (str): name of Design Area cell.
            length (float): die length in um
            height (float): die height in um
            cleave (float): width of cleaving area
            coatingW (str): type of coating on west facet,
                options: AR | HR | NO | NA
            coatingE (str): type of coating on east facet,
                options: AR | HR | NO | NA
            pitch (float): pitch of optical IO at facet (default = 12.5)

        Returns:
            None
        """
        self.name = name
        self.length = length
        self.height = height
        self.cleave = cleave
        self.coatingE = coatingE
        self.coatingW = coatingW
        self.pitch = pitch

        self.arrow = make_pincell(layer="package_pin")

    def size(
        self, length: float = 4600, height: float = 4000, cleave: float = 100
    ) -> None:
        """Set size of the design area."""
        self.length = length
        self.height = height
        self.cleave = cleave

    def coating(self, coatingW: str = "AR", coatingE: str = "AR") -> None:
        """Set coating at the west and at the east side of the design area."""
        self.coatingW = coatingW
        self.coatingE = coatingE

    def cell(self) -> nd.Cell:
        """Create a SemiconLab MPW cell with IO postitions"""

        with nd.Cell(name=f"{self.name}_{next(self.instnum)}") as C:
            # put the dice/cleave border
            frame = geom.frame(sizew=self.cleave, sizel=self.length, sizeh=self.height)
            nd.Polygon(layer="DiceArea", points=frame).put(0)
            hcleave = 0.5 * self.cleave

            nd.Pin("box", show=False).put(-hcleave, 0.5 * self.height - hcleave, 180)
            tdk.put_boundingbox("box", self.length, self.height)

            cleaveline = [
                (-hcleave, -hcleave),
                (self.length - hcleave, -hcleave),
                (self.length - hcleave, self.height - hcleave),
                (-hcleave, self.height - hcleave),
                (-hcleave, -hcleave),
            ]
            nd.Polyline(
                layer="chip_cleave", width=0.1, pathtype=2, points=cleaveline
            ).put(0)

            # Placing IOs
            num_ios = round((self.height - self.cleave - self.pitch) / self.pitch)

            # IOs positions

            # pin_indent = 0.5*self.cleave
            pin_indent = 0.5 * self.cleave
            iox = 12.5

            for no in range(num_ios):
                pinIDW = f"ioW{no:03d}"
                pinIDE = f"ioE{no:03d}"

                if no % 2 == 0:
                    angle = 7  # Even numbered
                else:
                    angle = 0  # Odd numbered

                # IOs West
                p = nd.Pin(name=pinIDW, type=angle).put(
                    -self.cleave + pin_indent, iox + no * self.pitch, angle
                )
                self.arrow.put(p)
                t = nd.text(pinIDW, layer="package_pin_text", height=0.15, align="rc")
                t.put(p.move(-0.1))

                # IOs East
                p = nd.Pin(name=pinIDE, type=angle).put(
                    -pin_indent + self.length, iox + no * self.pitch, 180 + angle
                )
                self.arrow.put(p)
                t = nd.text(pinIDE, layer="package_pin_text", height=0.15, align="rc")
                t.put(p.move(-0.575, 0, 180))

            # Adding coating to nd.Cell boundary: West and East
            options = {
                "AR": "Coating_AR",
                "HR": "Coating_HR",
                "NO": "Coating_NO",
                "NA": "Coating_NA",
            }
            coating_on_chip = 100

            box_coatno = [
                (0, 0),
                (hcleave, 0),
                (hcleave, self.height),
                (0, self.height),
            ]
            box_coatother = [
                (0, 0),
                (coating_on_chip + hcleave, 0),
                (coating_on_chip + hcleave, self.height),
                (0, self.height),
            ]

            pinW = nd.Pin().put(-hcleave, -hcleave)
            pinE = nd.Pin().put(self.length - hcleave, self.height - hcleave, 180)

            coatings = {"W": (self.coatingW, pinW), "E": (self.coatingE, pinE)}
            for coat, pin in coatings.values():
                if coat in options:
                    layer = options[coat]
                else:
                    print("""Available coating options: AR | HR | NO | NA
                        AR: Anti-reflection
                        HR: High-reflection (not available in standard MPW)
                        NO: No coating (facets as-cleaved, default)
                        NA: Don't care (specify if your circuit has no waveguides on
                            that side)""")
                if coat == "NO":
                    box = box_coatno
                else:
                    box = box_coatother
                nd.Polygon(layer=layer, points=box).put(pin)
            # Cell reference is in center of cell
            ccin = nd.Pin("ccin").put(
                (self.length - self.cleave) / 2, (self.height - self.cleave) / 2, 180
            )
            nd.Pin("ccout").put(ccin.rotate(180))
            C.default_pins("ccin", "ccout")
        return C

    def get_height(self) -> float:
        """Return height of the design area"""
        return self.height

    def get_length(self) -> float:
        """Return length of the design area"""
        return self.length

    def get_cleave(self) -> float:
        """Return cleave of the design area"""
        return self.cleave

    def get_NIO(self) -> int:
        """Return number of optical IOs"""
        return round((self.height - self.cleave - self.pitch) / self.pitch)


# ==============================================================================
# io_optical
# ==============================================================================
@cellcache("io", ["angle"])
def __io_cell(
    angle: int | None = None, bend: bool | None = None, bendgrid: bool | None = None
) -> nd.Cell:
    """Create io cell."""
    ltap = 50
    length = 100
    grid = 25
    # Place waveguides on IO positions
    wa = 3.5  # width angled io
    ws = 2.0  # width straight io

    with nd.Cell() as C:
        if angle == 0:  # Straight
            wg = sl.wg.strt(length, arrow=False).put(-length / 2)
            nd.Pin("a0", pin=wg.pin["a0"]).put(0, 0, 180)
            nd.Pin("b0", pin=wg.pin["b0"]).put()

        elif angle == 7:  # Angled
            a = radians(angle)
            lextra = (
                grid / sin(a)
                - 0.5 * length / cos(a)
                - ltap
                + xsWG.radius / sin(a) * (cos(a) - 1)
            )
            l = 0.5 * length / cos(a)  # half the length of the hypotenuse.
            for lay, growtup, *_ in nd.layeriter("WG"):
                (_a1, grow), (_a2, _b2), _c1, _c2 = growtup

                w = (wa + 2 * grow) / 2
                x = w * tan(a)
                outline = [(l, w), (-l + x, w), (-l - x, -w), (l, -w)]
                wg = nd.Polygon(layer=lay, points=outline).put(0)
            tap = sl.wg.ptaper(ltap, wa, ws, arrow=False).put(l)
            nd.Pin("a0").put(0, 0, 180)
            nd.Pin("b0", pin=tap.pin["b0"]).put()
            if bendgrid:
                bend = True
                wg = sl.wg.strt(lextra, arrow=False).put()
                nd.Pin("b0", pin=wg.pin["b0"]).put()
            if bend:
                wg = sl.wg.bend(angle=-angle, arrow=False).put()
                nd.Pin("b0", pin=wg.pin["b0"]).put()
        else:
            print(f"Warning: SemiconLab IO for angle = {angle} is not allowed.")
        # core.arrow.put(C.pin["a0"])
        # core.arrow.put(C.pin["b0"])
    return C


def io(pin: nd.Pin, bend: bool = False, bendgrid: bool = False) -> nd.Cell:
    """Standard io for SemiconLab for edge coupling.

    Even pin numbers are automatically perpendicular to the facet,
    odd numbers at 7 degrees. The current pin will be set at <pin>.

    Args:
        pin (Node): pin to connect standard io to. Standard pin is required.
        bend (bool): flag for angled IO which adds a bend to end in a horizontal position.
        bendgrid (bool): as the bend option, but end on a 12.5 um grid for easy align
               of two opposit IOs.

    Returns:
        Cell: cell with io waveguide structure

    Example:
        Place optical io's in the mask::

            import nazca as nd
            import semiconlab as sl

            project = sl.DesignArea() # project template with io pins
            die = project.cell().put()

            sp.io(die.pin['ioL100'], bend=True).put()
            sp.io(die.pin['ioR101']).put()

            nd.export_plt()
    """
    nd.cfg.cp = pin
    return __io_cell(angle=pin.type, bend=bend, bendgrid=bendgrid)
