# -----------------------------------------------------------------------
# This file is part of Nazca.
#
# Nazca is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or (at
# your option) any later version.
#
# Nazca is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with Nazca.  If not, see <http://www.gnu.org/licenses/>.
# -----------------------------------------------------------------------
# ==============================================================================
# (c) 2024 Ronald Broeke
# ==============================================================================
"""
Unit cell template
"""
from __future__ import annotations
from typing import TYPE_CHECKING
from dataclasses import dataclass
import nazca as nd
import nazca.geometries as geom

if TYPE_CHECKING:
    from nazca import Cell


ML_PINLINETEXT: str = "pinline_text"

# ==============================================================================
# Package template
# ==============================================================================


@dataclass
class UnitCell:
    """Unit cell template for PIC design: die outline, dicelane and design area.

    Layout of one die edge, from the outside in (all four edges are the same)::

        outer dicelane edge                           nominal die edge                   design area edge
                |                                             |                                  |
                |<-- dicelane_width - dicelane_inner_width -->|<----- dicelane_inner_width ----->|
                |<------------------------------- dicelane_width ------------------------------->|

    Terms:
        nominal die: the intended die size, nominal_die_width x nominal_die_height. Its border, the nominal
            die edge, is where the die is meant to be singulated (diced).
        actual die: the die after dicing. The cut, dicecut_width wide, is centered on the nominal die edge,
            so each actual dimension is the nominal one minus dicecut_width.
        dicelane: band of dicelane_width around the design area that may hold, e.g., edge couplers. The part
            of width dicelane_inner_width lies inside the nominal die; the rest lies outside it. Foundries
            differ in whether the dicelane reaches beyond the nominal die edge.
        design area: the area where the circuit layout is drawn. It is the nominal die minus
            dicelane_inner_width on each side and never overlaps the dicelane.

    Size the cell in one of two ways:
        * dicelane_width > 0 (default): designarea_width and designarea_height are computed and any values
          given for them are overwritten.
        * dicelane_width == 0: dicelane_width is derived as nominal size minus design area size.
          dicelane_width must be the same in x and y, and dicelane_inner_width is set to half of it.

    The cell has bounding-box pins for alignment, prefixed "des_" for the design area and "nom_" for the
    nominal die, e.g. "nom_lc".

    Attributes:
        nominal_die_width (float): nominal horizontal size of the die.
        nominal_die_height (float): nominal vertical size of the die.
        designarea_width (float): horizontal size of the design area. Only used as input when
            dicelane_width == 0.
        designarea_height (float): vertical size of the design area. Only used as input when
            dicelane_width == 0.
        dicelane_width (float): total width of the dicelane, inside plus outside the nominal die edge.
        dicelane_inner_width (float | None): part of the dicelane inside the nominal die edge. Default None
            sets it to half the dicelane_width, i.e. the nominal die edge runs through the middle of the
            dicelane.
        dicecut_width (float): width of the saw cut, centered on the nominal die edge.
        origin (tuple[float, float]): point that becomes the cell origin, measured from the outer
            bottom-left corner of the dicelane. The default (0, 0) puts the cell origin at that corner.
        dicelane_clip_to_nominal (bool): if True, draw only the inner half of dicelane_width, which ends at
            the nominal die edge when dicelane_inner_width has its default value.
        ml_dicecut (str): mask layer for the dicecut.
        ml_dicelane (str): mask layer for the dicelane.
        ml_nominal_die_edge (str): mask layer for the nominal die edge outline.
        actual_die_width (float): computed; nominal_die_width - dicecut_width.
        actual_die_height (float): computed; nominal_die_height - dicecut_width.
    """

    nominal_die_width: float = 2100
    nominal_die_height: float = 1100
    designarea_width: float = 0
    designarea_height: float = 0
    dicelane_width: float = 100
    dicelane_inner_width: float | None = None
    dicecut_width: float = 10
    origin: tuple[float, float] = (0, 0)
    # some foundries do not allow polygons outside of the nominal dimensions, with dicelane_clip_to_nominal
    # the dicelane is only draw up to the nominal die edge.
    dicelane_clip_to_nominal: bool = False
    # mask layers, defaults are nazca layers.
    ml_dicecut: str = "dicecut"
    ml_dicelane: str = "dicelane"
    ml_nominal_die_edge: str = "nominal_die_edge"

    # Actual die size will be computed automatically
    actual_die_width: float | None = None
    actual_die_height: float | None = None

    def __post_init__(self) -> None:
        self.actual_die_width = self.nominal_die_width - self.dicecut_width
        self.actual_die_height = self.nominal_die_height - self.dicecut_width
        if self.dicelane_inner_width is None:
            self.dicelane_inner_width = 0.5 * self.dicelane_width
        if self.dicelane_width == 0:
            self.dicelane_width = self.nominal_die_width - self.designarea_width
            self.dicelane_inner_width = 0.5 * self.dicelane_width
            assert self.dicelane_width == self.nominal_die_height - self.designarea_height
        else:
            self.designarea_width = self.nominal_die_width - 2 * self.dicelane_inner_width
            self.designarea_height = self.nominal_die_height - 2 * self.dicelane_inner_width

    def cell(self) -> Cell:
        """Create a unit cell.

        Returns:
            Cell: Unit cell including dice info, pin locations and bounding boxes.
        """
        return UnitCell._build_unitcell(
            nominal_die_width=self.nominal_die_width,
            nominal_die_height=self.nominal_die_height,
            actual_die_width=self.actual_die_width,
            actual_die_height=self.actual_die_height,
            designarea_width=self.designarea_width,
            designarea_height=self.designarea_height,
            dicelane_width=self.dicelane_width,
            dicelane_inner_width=self.dicelane_inner_width,
            dicecut_width=self.dicecut_width,
            origin=self.origin,
            dicelane_clip_to_nominal=self.dicelane_clip_to_nominal,
            ml_dicecut=self.ml_dicecut,
            ml_dicelane=self.ml_dicelane,
            ml_nominal_die_edge=self.ml_nominal_die_edge,
        )

    @staticmethod
    @nd.cellcache(name="UnitCell")
    def _build_unitcell(
        nominal_die_width: float,
        nominal_die_height: float,
        actual_die_width: float,
        actual_die_height: float,
        designarea_width: float,
        designarea_height: float,
        dicelane_width: float,
        dicelane_inner_width: float,
        dicecut_width: float,
        origin: tuple[float, float],
        dicelane_clip_to_nominal: bool,
        ml_dicecut: str,
        ml_dicelane: str,
        ml_nominal_die_edge: str,
    ) -> Cell:
        """Build a unit cell

        Returns:
            Cell: Unit cell including dice info, pin locations and bounding boxes.
        """
        xorg, yorg = origin
        shift = dicelane_width - dicelane_inner_width
        with nd.Cell(autobbox=True) as C:
            # design area
            C.default_pins = ["org", "org"]
            # dicelane
            frame_width = dicelane_width
            if dicelane_clip_to_nominal:
                frame_width *= 0.5
            frame = geom.frame(
                sizew=frame_width,
                sizel=designarea_width + frame_width,
                sizeh=designarea_height + frame_width,
            )

            nd.Polygon(layer=ml_dicelane, points=frame).put(dicelane_width - xorg, dicelane_width - yorg)

            # nominal die edge
            nominal_die_edge = [
                (0, 0),
                (nominal_die_width, 0),
                (nominal_die_width, nominal_die_height),
                (0, nominal_die_height),
                (0, 0),
            ]
            nd.Polyline(
                layer=ml_nominal_die_edge,
                width=0.0,
                pathtype=2,
                points=nominal_die_edge,
            ).put(shift - xorg, shift - yorg)

            # dicecut
            if dicecut_width > 0:
                nd.Polyline(
                    layer=ml_dicecut,
                    width=dicecut_width,
                    pathtype=2,
                    points=nominal_die_edge,
                ).put(shift - xorg, shift - yorg)

            #  design area: (invisible) bounding box for later pin alignment
            nd.bb_util.put_boundingbox(
                prefix="des_",  # design area (des)
                pinname="org",
                width=designarea_height,
                length=designarea_width,
                move=(
                    dicelane_width - xorg,
                    dicelane_width + 0.5 * designarea_height - yorg,
                ),
                add_properties=False,
                show_outline=False,
                name=False,
            )

            #  nominal die area: (invisible) bounding box for later pin alignment
            nd.bb_util.put_boundingbox(
                prefix="nom_",  # nominal die area (nom)
                pinname="org",
                width=nominal_die_height,
                length=nominal_die_width,
                move=(shift - xorg, shift + 0.5 * nominal_die_height - yorg),
                add_properties=False,
                show_outline=False,
                name=False,
            )
            C.properties["unitcell"] = dict(
                dicelane_width=dicelane_width,
                dicelane_inner_width=dicelane_inner_width,
                designarea_width=designarea_width,
                designarea_height=designarea_height,
                nominal_die_width=nominal_die_width,
                nominal_die_height=nominal_die_height,
                actual_die_width=actual_die_width,
                actual_die_height=actual_die_height,
                dicecut_width=dicecut_width,
            )
        return C


def apply_coating(
    cell: Cell,
    west_coating: dict | None = None,
    east_coating: dict | None = None,
    north_coating: dict | None = None,
    south_coating: dict | None = None,
) -> Cell:
    """Define the coating overspray region on the chip's edges.

    Coatings are placed with respect to the nominal die edge.

    Args:
        cell (Cell): the unitcell to apply the coating to.
        coatings (dict|None): Specify on which facet you want coating.
            e.g. west_coating = {"layer": "Coating_AR", "overspray": 100.0}
            The layer indicates which layer to draw the box in,
            with width=overspray.
            Coatings that are None will be skipped.

    Returns:
        Cell: the cell with the coating, which can be applied to the unit cell
    """
    die_height = cell.properties["unitcell"]["nominal_die_height"]
    die_width = cell.properties["unitcell"]["nominal_die_width"]

    polgs = []  # list of polygons to be put in the cell
    coatings = [
        (west_coating, "nom_lc", die_height),
        (east_coating, "nom_rc", die_height),
        (north_coating, "nom_tc", die_width),
        (south_coating, "nom_bc", die_width),
    ]

    for coat, pinname, coat_size in coatings:
        if coat is None:
            continue
        coating_width = coat["overspray"]
        poly = nd.Polygon(layer=coat["layer"], points=geom.box(coating_width, coat_size))
        polgs.append((poly, pinname))

    if len(polgs) == 0:
        nd.main_logger("apply_coating was called, but all coatings are None", level="warning")
    with nd.Cell("coating", instantiate=False) as C:
        for polg, pinname in polgs:
            polg.put(cell.pin[pinname].clone(da=180))
    return C
