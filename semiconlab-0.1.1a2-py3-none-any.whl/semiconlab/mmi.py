#
# (c) 2024 Xaveer Leijtens
#
# MMI coupler template
#
import nazca as nd
import nazca.geometries as geom
from nazca.cellcache_util import cellcache

import semiconlab as sl
import semiconlab.parameters as par

__all__ = ["mmi1x2", "mmi2x2"]


@cellcache("mmi1x2")
def mmi1x2() -> nd.Cell:
    with nd.Cell() as C:
        lmmi = par.LMMI1x2
        wmmi = par.WMMI1x2
        offset = par.OMMI1x2
        wio = sl.xsWG.width  # Standard waveguide width (can be adapted)
        angle = 53  # No need to change
        off = (offset, -offset)
        C.autobbox = True

        # Draw the polygons in the proper layer(s)
        for lay, growtup, *_ in nd.layeriter("WG"):
            (_a1, grow), (_a2, _b2), _c1, _c2 = growtup
            g = 2 * grow
            poly = geom.MMI_poly(
                wmmi=wmmi + g,
                lmmi=lmmi,
                wi=wio + g,
                wo=wio + g,
                oi=[0],
                oo=off,
                angle=angle,
            )
            nd.Polygon(layer=lay, points=poly).put()
        # Put pins so we can connect to the MMI
        nd.Pin(name="a0", xs="WG").put(0, 0, 180)
        nd.Pin(name="b0", xs="WG").put(lmmi, offset, 0)
        nd.Pin(name="b1", xs="WG").put(lmmi, -offset, 0)
        nd.put_stub()
    return C


@cellcache("mmi2x2")
def mmi2x2() -> nd.Cell:
    with nd.Cell() as C:
        lmmi = par.LMMI2x2
        wmmi = par.WMMI2x2
        offset = par.OMMI2x2
        wio = sl.xsWG.width  # Standard waveguide width (can be adapted)
        angle = 53  # No need to change
        off = (offset, -offset)
        C.autobbox = True

        # Draw the polygons in the proper layer(s)
        for lay, growtup, *_ in nd.layeriter("WG"):
            (_a1, grow), (_a2, _b2), _c1, _c2 = growtup
            g = 2 * grow
            poly = geom.MMI_poly(
                wmmi=wmmi + g,
                lmmi=lmmi,
                wi=wio + g,
                wo=wio + g,
                oi=off,
                oo=off,
                angle=angle,
            )
            nd.Polygon(layer=lay, points=poly).put()
        # Put pins so we can connect to the MMI
        nd.Pin(name="a0", xs="WG").put(0, offset, 180)
        nd.Pin(name="a1", xs="WG").put(0, -offset, 180)
        nd.Pin(name="b0", xs="WG").put(lmmi, offset, 0)
        nd.Pin(name="b1", xs="WG").put(lmmi, -offset, 0)
        nd.put_stub()
    return C


if __name__ == "__main__":
    mmi1x2().put()
    mmi2x2().put(100)

    nd.export_gds()
