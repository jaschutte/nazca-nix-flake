"""
Created on Mon May 29 13:10:45 2023

Template compact models for geometrical path length of interconnects

@author: rgb
"""

from math import pi, sin, tan, sqrt
from scipy.integrate import quad


def strt(length):
    return {"a0": {"b0": length}}


def taper(length, shift=0):
    return {"a0": {"b0": sqrt(length**2 + shift**2)}}


ptaper = strt


def arc(radius, angle):
    return {"a0": {"b0": radius * abs(angle) * pi / 180}}


def arc2(radius, angle):
    """PCB bend."""
    return {"a0": {"b0": 2.0 * abs(radius * tan(angle * pi / 90))}}


# TODO: this model is never called
def sinecurve(distance, offset):
    def arclen_sb(t, d=distance, s=offset):  # function to integrate
        return s / (2 * pi) * sqrt((d / s) ** 2 + (1 - sin(t)) ** 2)

    length_geo = quad(arclen_sb, 0, 2 * pi, args=(distance, offset))[0]

    return {"a0": {"b0": length_geo}}


# TODO add models for other interconnects
def euler(radius, angle, scale=1.0):
    """Euler bend geometric length calculation."""
    return {"a0": {"b0": 2 * radius * abs(angle) * pi / 180}}


def cobra(radius1:float=0, radius2:float=0):
    """Cobra/pcurve geometric length calculation."""
    arc_length = 0  # TODO
    return {"a0": {"b0": arc_length}}



