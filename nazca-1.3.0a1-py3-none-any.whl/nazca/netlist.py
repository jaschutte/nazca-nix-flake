# -----------------------------------------------------------------------
#
# Nazca is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or (at
# your option) any later version.
#
# Nazca is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with Nazca.  If not, see <http://www.gnu.org/licenses/>.
# -----------------------------------------------------------------------
#
# @author: Ronald Broeke (c) 2016-2020, 2011 (c) Xaveer Leijtens,
# @email: ronald.broeke@brightphotonics.eu
#
"""
Nazca classes to construct Nodes, Pointers and Cells,
and from those the graphs/netlists of the design.
"""
# Needed for deferred type annotation in classes, e.g. ptr: Pointer inside the Pointer class itself.
from __future__ import annotations

import os
from pathlib import Path
from itertools import count
from collections import defaultdict, OrderedDict, namedtuple
import copy as COPY
from math import sin, cos, acos, pi, atan2, hypot, degrees
from typing import Any

from scipy.spatial import ConvexHull
from numpy.linalg import inv
from numpy import dot
import numpy as np
# from pprint import pprint
from .clipper import grow_polygons
import yaml
import traceback

from . import cfg
from nazca.logging_util import logger, server_logger
from .mask_layers import get_layer, get_xsection
from .geometries import ring, transform
from . import gds_import as gdsimp
from . import gds_base as gb
import nazca.bb_util as bbu
import nazca.font as font
import nazca.util as util
import nazca.compact_models as cm


Et = count(0)  # counter for default cell names:
elmlist = []
Pt = count(0)

# message counters:
cfg.ND_msgcnt = 0  # counter for cummulative errors
cfg.NL_msgcnt = 0  # counter for netlist errors
cfg.IC_msgcnt = 0  # counter for interconnect messages
cfg.CM_msgcnt = 0  # counter for compact model messages
cfg.drc_msgcnt = 0  # count DRC messages.drc (None raises all)
cfg.suspend_logging = False  # useful when running trial_cell.
# TODO: apply suspend_logging in a with contexts so it switched off automatically.

cfg.ND_raise = False
cfg.NL_raise = False
cfg.IC_raise = False
cfg.CM_raise = False

# gds loading flags:
cfg.gdsload = False  # flag that contains the gds file name if a file is loading. False otherwise
cfg.gdsloadstore = (
    ""  # store name of gds if a layer mapping conflict occurs file while loading a gds to only message a warning once.
)


nazca_dir = os.path.dirname(__file__)  # Directory on disk where Nazca is located

# formatting of info indentation:
TAB_OPEN = "> "
TAB_CLOSE = "< "
TAB_REUSE = "r "
TAB_FLAT = "- "
TAB_ELM = ". "
TAB_INST = "+ "

def to_mat(chain:float=0.0, x:float=0.0, y:float=0.0, a:float=0.0, inverse:bool=False):
    """Transform vector into matrix."""
    a = (a + chain * 180.0) / 180.0 * pi
    c, s = cos(a), sin(a)
    if not inverse:
        return np.array([[c, s, 0.0], [-s, c, 0.0], [x, y, 1.0]])
    else:
        return np.array([[c, -s, 0.0], [s, c, 0.0], [-x * c - y * s, x * s - y * c, 1.0]])


def inverse(mat):
    """Return inverse matrix of <mat>"""
    c, s = mat[0, 0], mat[0, 1]
    x, y = mat[2, 0], mat[2, 1]
    return np.array([[c, -s, 0.0], [s, c, 0.0], [-x * c - y * s, x * s - y * c, 1.0]])
    # return inv(mat) # ~4x slower


def get_caller_info(nazca_dir:str):
    """Get the filename and line number of the caller of this function."""
    for frame in reversed(traceback.extract_stack(limit=7)):  # limit set to 7 to account for this call
        if nazca_dir not in frame.filename:
            filename = os.path.basename(frame.filename)
            codeinfo = f"file:{filename}, line:{frame.lineno}"
            return codeinfo
    return None

def set_db_unit():
    pass


def set_db_user():
    pass


def drc_instance_angle(rule, cell:Cell|None=None):
    """Set design rule for the angle of an instantiated cell."""
    if cell is None:
        cell = cfg.active_cell()
    cfg.drc_instance_angle["angle"][cell.cell_basename] = rule


def pin2pin_drc(on: bool = True) -> None:
    """Switch pin2pin DRC on.

    NOTE: the drc error maybe in a connection that is not exported to (gds) output
        and, therefore, not show up in that specific layout view.

    Args:
        on (bool): raise exception for trace back if True (default=True)
        num (int): if provided, raise exception on drc number <num> (default=None)
            if num is set then raise=True unless explicitly set to False

    Returns:
        None
    """
    if on:
        if not cfg.drc:
            cfg.drc = True
            logger.info("pin2pin drc: {}".format(cfg.drc))
    else:
        cfg.drc = False
        logger.info("pin2pin drc: {}".format(cfg.drc))


def pin2pin_drc_on(exception=None, num=None) -> None:
    pin2pin_drc(on=True)


def pin2pin_drc_off() -> None:
    pin2pin_drc(on=False)


def pin2pin_drc_raise(num=0) -> None:
    if num > 0:
        logger.info("Set to raise pin2pin drc on message: {}".format(num))
    if not cfg.drc:
        pin2pin_drc(on=True)
    cfg.drc_raisenum = num
    cfg.drc_raise = True


raise_pin2pin_drc = pin2pin_drc_raise


def netlist_raise(num:int=0, on:bool=True) -> None:
    """Switch on or off exceptions for netlist errors.

    The traceback can be used to find the cause of the netlist error.

    Args:
        num (int): if provided, raise exception on drc number <num> (default=None)
            if num is set then raise=True unless explicitly set to False
        on (bool): raise exception for trace back if True (default=True)

    Returns:
        None
    """
    if on:
        cfg.NL_raisenum = num
        cfg.NL_raise = True
    else:
        cfg.NL_raise = False


raise_netlist = netlist_raise


def interconnect_raise(num:int=0, on:bool=True) -> None:
    """Switch on or off exceptions for interconnect warnings and errors.

    The traceback can be used to find the cause of the netlist error.

    Args:
        num (int): if provided, raise exception on drc number <num> (default=None)
            if num is set then raise=True unless explicitly set to False
        on (bool): raise exception for trace back if True (default=True)

    Returns:
        None
    """
    if on:
        cfg.IC_raisenum = num
        cfg.IC_raise = True
    else:
        cfg.IC_raise = False


raise_interconnect = interconnect_raise


def compact_model_raise(num:int=0, on:bool=True) -> None:
    """Switch on or off exceptions for compact model warnings and errors.

    The traceback can be used to find the cause of the netlist error.

    Args:
        num (int): if provided, raise exception on drc number <num> (default=None)
            if num is set then raise=True unless explicitly set to False
        on (bool): raise exception for trace back if True (default=True)

    Returns:
        None
    """
    if on:
        cfg.CM_raisenum = num
        cfg.CM_raise = True
    else:
        cfg.CM_raise = False


raise_compact_model = compact_model_raise


def nazca_raise(num:int=0, on:bool=True) -> None:
    """Raise an exception for any design related Nazca error.

    Args:
        num (int): if provided, raise exception on drc number <num> (default=None)
            if num is set then raise=True unless explicitly set to False
        on (bool): raise exception for trace back if True (default=True)

    Returns:
        None
    """
    if on:
        cfg.ND_raisenum = num
        cfg.ND_raise = True
    else:
        cfg.ND_raise = False


raise_nazca = nazca_raise


# =============================================================================
# message loggers to be used in combination with raising Exceptions.
# =============================================================================
def netlist_logger(msg:str="", level:str="info") -> None:
    """Raise netlist exception if conditions apply.

    Args:
        msg (str): log message
        level (str): log level: 'debug', 'info' (default), 'error', or 'exception'.

    Returns:
        None
    """
    if cfg.suspend_logging:
        return

    fullmsg = f"NL-{cfg.NL_msgcnt}/ND-{cfg.ND_msgcnt}: {msg}"
    if cfg.NL_raise and cfg.NL_msgcnt == cfg.NL_raisenum:
        raise RuntimeError(fullmsg)
        # TIP: use the traceback (2 steps up) to find the cause of the exception.

    elif cfg.ND_raise:
        main_logger(msg=msg, level=level)

    cfg.NL_msgcnt += 1
    cfg.ND_msgcnt += 1

    if level == "warning":
        logger.warning(fullmsg)
    elif level == "error":
        logger.error(fullmsg)
    elif level == "info":
        logger.info(fullmsg)
    else:
        raise ValueError(f"Unknown interconnect_logger level given: '{level}'")
        # TIP: use the traceback (2 steps up) to find the cause of the exception.


def interconnect_logger(msg:str="", level:str="info") -> None:
    """Log or raise an interconnect exception if conditions apply.

    Args:
        msg (str): log message
        level (str): log level: 'debug', 'info' (default), 'error', or 'exception'.

    Raises:
        Exception if the "exception number" is set and matching this log entry.
        Exception if unknown level is provided

    Returns:
        None
    """
    if cfg.suspend_logging:
        return

    cfg.IC_msgcnt += 1
    cfg.ND_msgcnt += 1
    fullmsg = f"{msg}"
    if level == "warning":
        logger.warning(fullmsg)
    elif level == "error":
        logger.error(fullmsg)
    elif level == "info":
        logger.info(fullmsg)
    else:
        raise ValueError(f"Unknown interconnect_logger level given: '{level}'")
        # TIP: use the traceback (2 steps up) to find the cause of the exception.
    if cfg.IC_raise:
        if cfg.IC_msgcnt == cfg.IC_raisenum:
            raise RuntimeError(fullmsg)
            # TIP: use the traceback (2 steps up) to find the cause of the exception.
    elif cfg.ND_raise:
        main_logger(msg=msg, level=level, _redirect=True)


def compact_model_logger(msg:str="", level:str="info") -> None:
    """Log or raise a compact model exception if conditions apply.

    Args:
        msg (str): log message
        level (str): log level: 'debug', 'info' (default), 'error', or 'exception'.

    Raises:
        Exception if the "exception number" is set and matching this log entry.
        Exception if unknown level is provided

    Returns:
        None
    """
    if cfg.suspend_logging:
        return

    cfg.CM_msgcnt += 1
    cfg.ND_msgcnt += 1
    fullmsg = f"CM-{cfg.CM_msgcnt}/ND-{cfg.ND_msgcnt}: {msg}"
    if level == "warning":
        logger.warning(fullmsg)
    elif level == "error":
        logger.error(fullmsg)
    elif level == "info":
        logger.info(fullmsg)
    else:
        raise ValueError(f"Unknown interconnect_logger level given: '{level}'")
        # TIP: use the traceback (2 steps up) to find the cause of the exception.
    if cfg.CM_raise:
        if cfg.CM_msgcnt == cfg.CM_raisenum:
            raise RuntimeError(fullmsg)
            # TIP: use the traceback (2 steps up) to find the cause of the exception.
    elif cfg.ND_raise:
        main_logger(msg=msg, level=level, _redirect=True)


def main_server_logger(msg:str, level:str="info", _redirect:bool=False) -> None:
    """Log server-related messages.

    Args:
        msg (str): log message
        level (str): log level: 'debug', 'info' (default), 'error', or 'exception'.

    Returns:
        None
    """
    fullmsg = f"{msg}"

    if level == "warning":
        server_logger.warning(fullmsg)
    elif level == "error":
        server_logger.error(fullmsg)
    elif level == "info":
        server_logger.info(fullmsg)
    elif level == "debug":
        server_logger.debug(fullmsg)
    else:
        raise ValueError(f"Unknown server_logger level given: '{level}'")


# TODO: check out logging.LoggerAdapter and logging.Filter
def main_logger(msg:str, level:str="info", _redirect:bool=False) -> None:
    """Log or raise an exception if conditions apply.

    This message handler will take care of loggin any error or warning.
    It will raise an exception if the error counter = errnum
    (if errnum has been set) for debugging/trace back purposes.

    Arg:
        msg (str): log message
        level (str): log level: 'debug', 'info' (default), 'error', or 'exception'.
        _redirect (bool): internal variable for counting messages.

    Returns:
        None
    """
    if cfg.suspend_logging:
        return

    if not _redirect:
        cfg.ND_msgcnt += 1

    fullmsg = f"{msg}"
    if cfg.ND_raise and cfg.ND_msgcnt == cfg.ND_raisenum:
        raise RuntimeError(fullmsg)
        # TIP: use the traceback (2 steps up) to find the cause of the exception.

    if level == "warning":
        logger.warning(fullmsg)
    elif level == "error":
        logger.error(fullmsg)
    elif level == "info":
        logger.info(fullmsg)
    else:
        raise ValueError(f"Unknown main_logger level given: '{level}'")
        # TIP: use the traceback (2 steps up) to find the cause of the exception.


def varinfo(min, default, max, type:str, unit:str, doc:str)->dict:
    """Set parameter value info by creating a dict.

    Experimental function.

    Returns:
        dict: var info
    """
    return {
        "min": min,
        "default": default,
        "max": max,
        "type": type,
        "unit": unit,
        "doc": doc,
    }


class Pointer:
    """A pointer with state information.

    Note: For normal Nazca usage avoid using this class directly and use the methods
    provided in the Node class instead.

    The pointer has the positional information of a node.
    The positional information is kept in a matrix that holds the homogeneous
    coordinates. Structures are drawn in local coordinates and are easily
    converted to the global coordinate system by a matrix multiplication. By
    using homogeneous coordinates, translations are also described by a
    matrix multiplication.
    """

    def __init__(self, x:float=0.0, y:float=0.0, a:float=0.0):
        """Constructor.

        Args:
            x (float): x coordinate in um
            y (float): y coordinate in um
            a (float): angle coordinate un degrees
        """
        self.flipstate = False
        self.mat = None
        self.chain = 0
        self.goto(x, y, a)

    def __str__(self):
        return "{0}:\t(x = {2:.2f}, y = {3:.2f}, a = {1:.2f}°)".format(self.__class__.__name__, self.a, *self.get_xy())

    def goto(self, x:float, y:float, a:float=0.0):  # Absolute
        """Move pointer to a coordinate relative to the org.

        Args:
            x (float): x-coordinate of the pointer position [µm]
            y (float): y-coordinate of the pointer position [µm]
            a (float): angle of the pointer [degrees]

        Returns:
            None
        """
        a = pi * a / 180
        self.mat = np.array([[cos(a), sin(a), 0], [-sin(a), cos(a), 0], [x, y, 1]])
        self.flipstate = False

    def scale_position(self, scale:float) -> Pointer:
        """Scale x and y about the origin, preserving rotation and flip state.

        Args:
            scale (float): multiplier for the position coordinates.

        Returns:
            Pointer: self, with its position scaled.
        """
        # Pointer.copy() shares the matrix until a coordinate operation replaces it.
        self.mat = self.mat.copy()
        self.mat[2, :2] *= scale
        return self

    def move(self, x:float=0, y:float=0, a:float=0.0):  # Relative
        """Move pointer relative to current location.

        Args:
            x (float): x-coordinate of the pointer position [µm]
            y (float): y-coordinate of the pointer position [µm]
            a (float): angle of the pointer [degrees]

        Returns:
            Pointer: self
        """
        a = pi * a / 180
        mat = np.array([[cos(a), sin(a), 0.0], [-sin(a), cos(a), 0.0], [x, y, 1.0]])
        self.mat = dot(mat, self.mat)
        return self

    def set_a(self, a:float=0.0):
        """Set angle absolute. Keep x, y position

        Args:
            a (float): angle of the pointer [degrees]

        Returns:
            Pointer: self
        """
        a = pi * a / 180
        x = self.x
        y = self.y
        self.mat = np.array([[cos(a), sin(a), 0.0], [-sin(a), cos(a), 0.0], [x, y, 1.0]])
        # self.mat = dot(mat, self.mat)
        return self

    def move_ptr(self, ptr:Pointer):  # Relative
        """Move pointer relative by a pointer 'ptr' w.r.t. current location.

        Args:
            ptr (Pointer): move by value in pointer

        Returns:
            Pointer: self
        """
        x, y, a = ptr.get_xya()
        a = pi * a / 180
        mat = np.array([[cos(a), sin(a), 0.0], [-sin(a), cos(a), 0.0], [x, y, 1.0]])
        self.mat = dot(mat, self.mat)
        return self

    def multiply_ptr(self, ptr:Pointer):  # Relative
        """Multiply the pointer by the matrix in <ptr>.

        Args:
            ptr (Pointer): multiply by <ptr>

        Returns:
            Pointer: self
        """
        self.mat = dot(self.mat, ptr.mat)
        return self

    def inv(self):  # Relative
        """Inverse the matrix in the pointer. Returns the pointer.

        Returns:
            Pointer: self
        """
        self.mat = inv(self.mat)
        return self

    def trans(self, mat):  # Relative
        """Translate pointer by matrix <mat>.

        Return:
            Pointer: translated by matrix <mat>
        """
        return dot(mat, self.mat)

    def chain(self, chain:bool):
        """Set the chain property of the pointer.

        Args:
            chain (bool): True for chain connecting pins.

        Returns:
            None
        """
        self.chain = chain

    def set_mat(self, t:tuple[float, float, float]):  # Relative
        """Fill pointer matrix based on vector <t> = (x, y, a).

        Args:
            t (tuple): (x, y, a)
        Returns:
           None
        """
        self.mat = t

    def skip(self, s:float):  # move forward (negative: backward)
        """Translate a pointer in the direction it is pointing in.

        Args:
            s (float): move pointer along its direction by <s>

        Returns:
            Pointer: self, moved
        """
        self.move(s, 0, 0)
        return self

    def offset(self, s:float):  # offset positive/negative to left/right.
        """Translate a pointer perpendicular to the direction it is pointing in.

        Note that in a cartesian coordinate system while pointing/looking
        along the positive x-axis, a positive offset is in the left direction,
        i.e. along the positive y-axis.

        Args:
            s (float): move pointer along perpendicular direction by <s>

        Returns:
            Pointer: self, moved pointer
        """
        self.move(0, s, 0)
        return self

    def flip(self):
        """Flip (mirror) the state of the pointer.

        Returns:
            Pointer: self, flipped
        """
        self.mat = dot(self.mat, [[1, 0, 0], [0, -1, 0], [0, 0, 1]])
        self.flipstate = not self.flipstate
        return self

    def rotate(self, a:float):
        """Rotate pointer by angle a.

        Args:
            a (float): angle of the pointer [degrees]

        Returns:
            Pointer: self, rotated
        """
        self.move(0, 0, a)
        return self

    @property
    def x(self):
        """Return position x of the pointer."""
        return self.mat[2, 0]

    @property
    def y(self):
        """Return the position y of the pointer."""
        return self.mat[2, 1]

    @property
    def a(self):
        """Return angle a of the pointer."""
        a = min(1, max(self.mat[0, 0], -1))  # clip to [-1, 1]
        if self.mat[0, 1] >= 0:
            return acos(a) * 180 / pi
        else:
            return 360 - acos(a) * 180 / pi

    def get_xy(self, x:float=0, y:float=0):
        """Return the (x, y) position of the pointer."""
        return tuple(dot([x, y, 1], self.mat))[0:2]

    def get_xya(self):
        """Return the pointer position as (x, y, a)."""
        return (self.x, self.y, self.a)

    def get_xy_a(self):
        """Return the pointer position as (x, y, a)."""
        return ((self.x, self.y), self.a)

    def xya(self):
        """Return the pointer position as (x, y, a)."""
        return (self.x, self.y, self.a)

    def fxya(self, digits:int=3):
        """Get formatted pointer position (x, y, a) of the Node.

        Returns:
            str: formatted pointer position (x, y, a)
        """
        return "({0:0.{prec}f}, {1:0.{prec}f}, {2:0.{prec}f})".format(self.x, self.y, self.a, prec=digits)

    def xy(self, x:float=0, y:float=0):
        """Return the (x, y) position of the pointer."""
        return tuple(dot([x, y, 1], self.mat))[0:2]

    def copy(self, flip:bool=False):
        """Copy pointer.

        Returns:
            Pointer: copy of the Pointer
        """
        # One level deep copy. The state information is still copied by
        # reference only. This is probably the desired way of working.
        copy = COPY.copy(self)
        if flip:
            copy.y = -copy.y
            copy.a = -copy.a
        return copy


class smatrix:
    """S-matrix tbd."""

    # TE-TE
    # TM-TM
    # TE-TM
    # TM-TE
    # phase
    # amplitude
    def __init__(self, tete=(0, 0), tmtm=(0, 0), tetm=(0, 0), tmte=(0, 0)):
        self.tete = tete
        self.tmtm = tmtm
        self.tetm = tetm
        self.tmte = tmte


class Node:
    """Node class for creating node objects.

    Note that pins in the Nazca design terminology are actually Node objects.

    The netlist of Nodes and connections between the nodes (edges) construct
    the photonic circuit and/or layout.
    """

    def __init__(self, name:str|None=None):
        """Contruct a Node.

        Args:
            name (str): optional Node name (default is an integer counter)

        Returns:
            None
        """
        # print('______________________new node', name)
        self.id = next(Pt)  # Node ID
        self.nb_geo = []  # nearest neighbors geometry
        self.nb_cm = []  # nearest neighbors, compact model connection (e.g. for Smatrix)
        # self.nb_ele = []  # nearest neighbors, electronic connection
        self.nb_cnode = []  # cell tree, only for used for cnodes
        self.cnode = None  # cnode of the node. A cnode is its own cnode
        self.parent_cnode = None  # parent node of Node's cnode
        self.cell = None  # TODO: in use? Cell object of the cnode
        self.pointer = None  # Pointer of the Node. Contains the node position.
        self.xs = None  # String reference to the xs of the node.
        self.width = None  # width of the node
        self.radius = None  # radius of the curvature at the pin.
        self.instance = None  # store if node resides in a cell (None) or instance (True)
        self.show = False  # show pin in layout.
        self.remark = None  # add info to the pin for users
        self.io = None  # indicate signal directionality of a port, where if relevant 0 standard, 1=anti.
        self.type = None  #

        if name is None:
            self.name = str(self.id)
        else:
            self.name = str(name)

    def __repr__(self):
        coor = "({t[0]:0.3f}, {t[1]:0.3f}, {t[2]:0.3f})".format(t=self.xya())
        if self.cnode.instance is not None:
            cell = "instance of cell '{}'".format(self.cnode.cell.cell_name)
        else:
            cell = "cell '{}'".format(self.cnode.cell.cell_name)

        if self.radius is None:
            radiusstr = "None"
        else:
            radiusstr = f"{self.radius:0.3f}"
        return (
            f"<Node(id={self.id}, name='{self.name}') object in {cell}, "
            f"xs='{self.xs}', width={self.width}, radius={radiusstr}, "
            f"xya={coor}, type={self.type}, io={self.io}, remark='{self.remark}'>"
        )

    @classmethod
    def json_init(cls, node_dict:dict):
        """Reconstruct a node object using a serialized dictionary.

        Args:
            node_dict (dict): dictionary containing serialized node information

        Returns:
            Node: deserialized node object
        """
        node = super(Node, cls).__new__(cls)

        # reconstruct the pointer
        pointer = Pointer(x=node_dict.pop("x"), y=node_dict.pop("y"), a=node_dict.pop("a"))
        pointer.chain = node_dict.pop("chain")
        node.pointer = pointer

        # initialize empty geometry
        node.nb_geo = []  # nearest neighbors geometry
        node.nb_cm = []  # nearest neighbors, compact model connection (e.g. for Smatrix)
        node.nb_cnode = []  # cell tree, only for used for cnodes
        node.parent_cnode = None

        for attr, value in node_dict.items():
            setattr(node, attr, value)
        if isinstance(node.xs, list):
            node.xs = tuple(node.xs)
        node.id = next(Pt)

        return node

    def to_dict(self):
        """Serialize the Node object."""
        info = {}
        info["name"] = self.name
        info["xs"] = self.xs
        info["width"] = self.width
        info["radius"] = self.radius
        info["remark"] = self.remark
        info["type"] = self.type
        info["io"] = self.io
        info["show"] = self.show
        info["x"] = self.x
        info["y"] = self.y
        info["a"] = self.a
        info["chain"] = self.chain
        info["instance"] = self.instance

        return info

    @property
    def basename(self):
        try:
            return self.up.name
        except AttributeError:
            return self.name

    def copy(self, inplace:bool=False, _strict:bool=True):
        """Copy a Node object into the active cell (or inplace).

        This copy function assumes that the new node is going to be connected to the self node.

        Args:
            strict (bool): True. For other use cases see xycopy().
            inplace (bool): obsolete? Copy node in the active cell (default), or in the same cell as the original node
                if inplace is True.

        Returns:
            Node: copy of the node with the same attributes as the original

        Example::

            import nazca as nd

            n1 = nd.Node()
            n2 = n1.copy()
        """
        # do NOT use deepcopy: extremely slow.
        node = Node()
        node.pointer = self.pointer.copy()
        node.xs = self.xs
        node.width = self.width
        node.instance = self.instance
        node.type = self.type
        node.io = self.io
        node.remark = self.remark

        if inplace:  # TODO: check if inplace is still needed
            cnode = self.cnode
        else:
            cnode = cfg.active_cell().cnode
        in_parent = cnode is self.cnode.parent_cnode
        in_same = cnode is self.cnode
        if _strict and not in_same and not in_parent:
            raise RuntimeError(
                "It is not allowed to copy a Node from outside the connectivity scope of max one level deep. "
                "More precise, you cannot connect the new Node to a cell that is not the active cell, "
                "nor to an instance of a cell that is not placed inside the active cell."
            )

        node.cnode = cfg.active_cell().cnode  # place node in active cell.
        # node.cnode.parent_cnode = cfg.active_cell().parent_cnode
        return node

    def xyclone(self, dx: float = 0, dy: float = 0, a: float = 0):
        """Copy a node object into the active cell from any cell for its (x,y) values and resets angle a.

        xyclone "mirrors" the node in the active cell, but is not connected to the original node.
        This copy is useful to "borrow" pins and their positions in other cells, e.g. to draw overlays.

        Args:
            dx (float): relative move in x-direction
            dy (float): relative move in y-direction
            a (float): absolute angle of the new node in degrees with respect to the org of the active cell.

        Returns:
            Node: copy of the node with the same attributes as the original but moved by (dx, dy) and absolute angle a.
        """
        node = self.copy(_strict=False)
        node.pointer.goto(node.x + dx, node.y + dy, a)
        return node

    def clone(self, dx: float = 0, dy: float = 0, da: float = 0):
        """Copy a node object into the active cell from any cell for its (x,y) values and resets angle a.

        Clone "mirrors" the node in the active cell, but is not connected to the original node.
        This copy is useful to "borrow" pins and their positions in other cells, e.g. to draw overlays.

        Args:
            dx (float): relative move in x-direction
            dy (float): relative move in y-direction
            da (float): relative rotation in a-direction

        Returns:
            Node: copy of the node with the same attributes as the original, but moved by (dx, dy, da)
        """
        node = self.copy(_strict=False)
        node.pointer.goto(node.x + dx, node.y + dy, node.a + da)
        return node

    @property
    def chain(self):
        """Attribute to indicate if a Node is a chain connector."""
        return self.pointer.chain

    def goto(self, x:float=0, y:float=0, a:float=0):
        """Create a new Node at position (<x>, <y>, <a>) relative to the cell origin.

        Args:
            x (float): x position in um
            y (float): y position in um
            a (float): angle a in degrees

        Returns:
            Node: a new Node at (<x>, <y>, <a>) w.r.t. the cell's origin
        """
        node = Node()
        node.pointer = COPY.copy(self.pointer)
        node.xs = self.xs
        node.width = self.width
        node.type = self.type

        # node.pointer.chain = 0
        node.cnode = cfg.active_cell().cnode
        node.parent_cnode = cfg.active_cell().parent_cnode
        connect_geo(cfg.active_cell().cnode, node, (x, y, a), 1, 0)
        # print('cfg.active_cell().cnode.cell.cell_name:', cfg.active_cell().cnode.cell.cell_name)
        cfg.cp = node
        return node

    def xya(self):
        """Get (x, y, a) pointer position of the Node.

        Returns:
            tuple: pointer position (x, y, a) with respect to the cell origin
        """
        return self.pointer.get_xya()

    def xy(self):
        """Get (x, y) pointer position of the Node.

        Returns:
            tuple: pointer position (x, y, a) with respect to the cell origin
        """
        return self.pointer.get_xy()

    def fxya(self, digits:int=3):
        """Get formatted pointer position (x, y, a) of the Node.

        Returns:
            str: formatted pointer position (x, y, a) with respect to the cell origin
        """
        return self.pointer.fxya(digits=digits)

    def fxy(self, digits:int=3):
        """Get formatted pointer position (x, y) of the Node.

        Returns:
            str: formatted pointer position (x, y) with respect to the cell origin
        """
        p = self.pointer.get_xya()
        return "({:.3f}, {:.3f})".format(p[0], p[1])

    @property
    def x(self):
        """Get pointer x-position of the Node.

        Returns:
            float: pointer x-position with respect to the cell origin
        """
        return self.pointer.x

    @property
    def y(self):
        """Get pointer y-position of the Node.

        Returns:
            float: pointer y-position with respect to the cell origin
        """
        return self.pointer.y

    @property
    def a(self):
        """Get pointer a-position of the Node.

        Returns:
            float: pointer a-position with respect to the cell origin
        """
        return self.pointer.a

    def angle(self, angle:float):
        """Set pointer a-position of the Node.

        Returns:
            tuple: pointer after angle update.
        """
        self.pointer.set_a(angle)
        return self

    # ==============================================================================
    #     Create pointer operations on Node level for syntax convenience
    # ==============================================================================
    def move(self, x:float=0, y:float=0, a:float=0, xs=0, width:float=0, radius:float=0, drc:bool=True):
        """Create a new Node translated by (<x>, <y>, <a>) with respect to self.

        Also 'width' and 'xs' attributes of the can be 'moved'. This is for
        controlling DRC on pin2pin connections; It allows for explicitly
        connecting pins having a different width and or xs without raising a
        DRC error.

        Args:
            x (float): move in x-direction
            y (float): move in y-direction
            a (float): angle of rotation in degree
            xs (str): move to xs
            width (float): move to width
            radius (float): move to radius
            drc (bool): switch off drc if False (default=True)

        Returns:
            Node: a new Node translated by vector (<x>, <y>, <a>)
        """
        node = self.copy()
        if cfg.clear_pin_on_move:
            if max(abs(x), abs(y)) > cfg.drc_max_distance:
                node.xs = None
                node.width = None
        if xs != 0:
            drc = False
            node.xs = xs
        #           if xs is not None:
        #               node.width = get_xsection(xs).width
        if width != 0:
            drc = False
            node.width = width
        if radius != 0:
            drc = False
            node.radius = radius
        connect_geo(self, node, (x, y, a), 0, 0, drc=drc)
        return node

    def org4move(self, x:float=0, y:float=0, a:float=0, xs=0, width:float=0, radius:float=0, drc:bool=True):
        """Create a new Node translated by (<x>, <y>) and absolute <a> with respect to self.

        Move x and y relative to the parent cell coordinate system and set the absolute angle a.
        The new node is connected to the org of the parent cell.
        Also 'width' and 'xs' attributes of the can be 'moved'. This is for
        controlling DRC on pin2pin connections; It allows for explicitly
        connecting pins having a different width and or xs without raising a
        DRC error.

        Args:
            x (float): move in x-direction
            y (float): move in y-direction
            a (float): angle of rotation in degree with respect to the parent node
            xs (str): move to xs
            width (float): move to width
            radius (float): move to radius
            drc (bool): switch off drc if False (default=True)

        Returns:
            Node: a new Node translated by vector (<x>, <y>, <a>)
        """
        node = self.copy()
        if cfg.clear_pin_on_move:
            if max(abs(x), abs(y)) > cfg.drc_max_distance:
                node.xs = None
                node.width = None
        if xs != 0:
            drc = False
            node.xs = xs
        if width != 0:
            drc = False
            node.width = width
        if radius != 0:
            drc = False
            node.radius = radius
        connect_geo(self.cnode, node, (self.x + x, self.y + y, a), 0, 0, drc=drc)
        return node

    def rotate(self, a:float=0, xs=0, width:float=0, radius:float=0, drc:bool=True):
        """Create a new Node rotate pointer by <a>.

        Also 'width' and 'xs' attributes of the can be 'moved'. This is for
        controlling DRC on pin2pin connections; It allows for explicitly
        connecting pins having a different width and or xs without raising a
        DRC error.

        Args:
            a (float): angle of rotation in degree
            xs (str): move to xs
            width (float): move to width
            radius (float): move to radius
            drc (bool): switch off drc if False (default=True)

        Returns:
            Node: a new Node translated by vector (0, 0, <a>) w.r.t. self
        """
        node = self.copy()
        if xs != 0:
            drc = False
            node.xs = xs
        #            if xs is not None:
        #                node.width = get_xsection(xs).width
        if width != 0:
            drc = False
            node.width = width
        if radius != 0:
            drc = False
            node.radius = radius
        connect_geo(self, node, (0, 0, a), 0, 0, drc=drc)
        return node

    rot = rotate

    def rot2ref(self, angle:float=0.0, ref:Node|None=None, xs=0, width:float=0, radius:float=0, drc:bool=True):
        """Create a new Node rotate pointer by <a> with respect to node ref.

        Also 'width' and 'xs' attributes of the can be 'moved'. This is for
        controlling DRC on pin2pin connections; It allows for explicitly
        connecting pins having a different width and or xs without raising a
        DRC error.

        Args:
            angle (float): angle of rotation in degree w.r.t. ref (default is 0)
            ref (Node): if None, org of current cell is assumed
            xs (str): move to xs
            width (float): move to width
            radius (float): move to radius
            drc (bool): switch off drc if False (default=True)

        Returns:
            Node: a new Node translated by vector (0, 0, <a>) w.r.t. ref
        """
        node = self.copy()
        if ref is None:
            ref = cfg.active_cell().pin["org"]
        x, y, a = diff(ref.rot(angle), self)
        if xs != 0:
            drc = False
            node.xs = xs
        #            if xs is not None:
        #                node.width = get_xsection(xs).width
        if width != 0:
            drc = False
            node.width = width
        if radius != 0:
            drc = False
            node.radius = radius
        connect_geo(self, node, (0, 0, -a), 0, 0, drc=drc)
        return node

    def skip(self, x:float=0, xs=0, width:float=0, radius:float=0, drc:bool=True):
        """Create a new Node skipping <x> in direction of the pointer.

        Also 'width' and 'xs' attributes of the can be 'moved'. This is for
        controlling DRC on pin2pin connections; It allows for explicitly
        connecting pins having a different width and or xs without raising a
        DRC error.

        Args:
            x (float): move in x-direction
            xs (str): move to xs
            width (float): move to width
            radius (float): move to radius
            drc (bool): switch off drc if False (default=True)

        Returns:
            Node: a new Node translated by vector (<x>, 0, 0) w.r.t. self
        """
        node = self.copy()
        if cfg.clear_pin_on_move:
            if abs(x) > cfg.drc_max_distance:
                node.xs = None
                node.width = None
        if xs != 0:
            drc = False
            node.xs = xs
        #            if xs is not None:
        #                node.width = get_xsection(xs).width
        if width != 0:
            drc = False
            node.width = width
        if radius != 0:
            drc = False
            node.radius = radius
        connect_geo(self, node, (x, 0, 0), 0, 0, drc=drc)
        return node

    def shift(self, x:float=0, y:float=0, xs=0, width:float=0, radius:float=0, drc:bool=True):
        """Create a new Node shifting pointer (<x>, <y>), keeping orientation.

        Also 'width' and 'xs' attributes of the can be 'moved'. This is for
        controlling DRC on pin2pin connections; It allows for explicitly
        connecting pins having a different width and or xs without raising a
        DRC error.

        Args:
            x (float): move in x-direction
            y (float): move in y-direction
            xs (str): move to xs
            width (float): move to width
            radius (float): move to radius
            drc (bool): switch off drc if False (default=True)

        Returns:
            Node: a new Node translated by vector (<x>, <y,> 0) w.r.t. self
        """
        node = self.copy()
        if cfg.clear_pin_on_move:
            if max(abs(x), abs(y)) > cfg.drc_max_distance:
                node.xs = None
                node.width = None
        if xs != 0:
            drc = False
            node.xs = xs
        #            if xs is not None:
        #                node.width = get_xsection(xs).width
        if width != 0:
            drc = False
            node.width = width
        if radius != 0:
            drc = False
            node.radius = radius
        connect_geo(self, node, (x, 0, 0), 0, 0, drc=drc)
        return node

    def offset(self, y:float=0, xs=0, width:float=0, radius:float=0, drc:bool=True):
        """Create a new Node that is offset by <y>.

        Also 'width' and 'xs' attributes of the can be 'moved'. This is for
        controlling DRC on pin2pin connections; It allows for explicitly
        connecting pins having a different width and or xs without raising a
        DRC error.

        Args:
            y (float): move in y-direction
            xs (str): move to xs
            width (float): move to width
            radius (float): move to radius
            drc (bool): switch off drc if False (default=True)

        Returns:
            Node: a new Node translated by vector (0, <y>, 0) w.r.t. self
        """
        node = self.copy()
        if cfg.clear_pin_on_move:
            if abs(y) > cfg.drc_max_distance:
                node.xs = None
                node.width = None
        if xs != 0:
            drc = False
            node.xs = xs
        #            if xs is not None:
        #                node.width = get_xsection(xs).width
        if width != 0:
            drc = False
            node.width = width
        if radius != 0:
            drc = False
            node.radius = radius
        connect_geo(self, node, (0, y, 0), 0, 0, drc=drc)
        return node

    os = offset

    def flip(self):
        """Create a new Node that is flipped.

        A 'flip' mirrors the Node in the line of the pointer.
        Note that a flip state of a Node doesn't matter in Nazca.
        Flipping is handled by 'put', hence this funtion is equivalent to
        a Node copy in place (pointer not effected).

        Returns:
            Node: a new Node flipped w.r.t. self
        """
        node = self.copy()
        connect_geo(self, node, (0, 0, 0), 0, 0)
        return node

    def flop(self):
        """Create a new Node that is flopped.

        A 'flop' mirrors the Node pointer 'backward'.
        A flop is effecively a flip + 180 degree rotation.
        Note that the flip state of a Node or not doesn't matter in Nazca,
        hence this flop is equivalent to rot(180).

        Returns:
            Node: a new Node flopped w.r.t. self
        """
        node = self.copy()
        connect_geo(self, node, (0, 0, 0), 0, 0)
        return node

    # ==============================================================================
    # netlist generators
    # ==============================================================================
    # TODO: rename "extra in something more descriptive
    def path_nb_iter(self, sigtype:str, sigkwargs:dict|None=None):
        """Iterator to get path info to neighbours.

        Args:
            sigtype (str): type of neighbour connections to traverse
            sigkwargs (dict): additional info for filtering the connections

        Yields:
            Node: next neighbor
        """
        for nn in self.nb_cm:
            if nn[3] != sigtype and not nn[0].cnode.cell.void:
                continue
            if sigkwargs is None:
                yield nn[0], nn[1], nn[2], nn[3], None
            elif nn[5][0] is None:
                yield nn[0], nn[1], nn[2], nn[3], sigkwargs
            else:
                sigkwargs_in, sigkwargs_out = nn[4]
                if sigkwargs_in == sigkwargs:
                    yield nn[0], nn[1], nn[2], nn[3], sigkwargs_out

    def geo_nb_iter(self):
        """Get geometrical neighbours.

        Yields:
            Node: next neighbour
        """
        for nn in self.nb_geo:
            yield nn

    def geo_nb_filter_iter(self):
        """Yield all neighbouring nodes except for the origin, and pins of auxiliary cells.

        Iterates over the neighbours in the Cell.

        Yields:
            Node: iterator over the filtered neighbours
        """
        for nb, _ in self.nb_geo:
            if "org" not in nb.name and nb.cnode.cell.auxiliary is False:
                yield nb

    def cnode_nb_iter(self, end:bool|None=None, auxiliary:bool|None=None):
        """Get cnodes at the cell level below the cell level of the node.

        Args:
            end (bool or None): include last element
            auxiliary (bool or None): filter on auxiliary flag. Ignore flag if None

        Yields:
            Node: next cell node
        """
        if end is None:
            cnodes = self.nb_cnode
        else:
            cnodes = self.nb_cnode[:end]
        for nn in cnodes:
            if nn[2] == 1:
                cnode = nn[0]
                if auxiliary is None:
                    yield cnode
                elif auxiliary is cnode.cell.auxiliary:
                    yield cnode

    instance_iter = cnode_nb_iter

    def print_neighbours(self):
        """Print neighbours of the node in the netlists.

        Returns:
            str: information on neighbors of this node
        """
        out = "\n".join(
            [
                "---neighbours geo:",
                "\n".join(map(str, self.nb_geo)),
                "---neighbours opt:",
                "\n".join(map(str, self.nb_cm)),
                # '---neighbours ele:', '\n'.join(map(str, self.nb_ele)),
            ]
        )
        return out

    def get_info(self):
        """Get information string.

        Returns:
            str: information on the node.
        """
        s = "Node---------------------:\n  name: {}\n  cell: {}\n  node: {}".format(
            self.name, self.cnode.cell.cell_name, self
        )
        s += "\n--cnode:\n    name: {}\n    cnode: {}".format(self.cnode.name, self.cnode)
        # s += '\n--parent_cnode:\n    cell: {1}\n    cnode: {0}'.format(
        #     self.cnode.parent_cnode,
        #     self.cnode.parent_cnode.cell.cell_name)
        return s


# ==============================================================================
# Functions to defining an edge (geometrical, optical, electrical) between nodes.
# ==============================================================================


def pin_drc(pin1: Node, pin2: None, t: tuple[float, float, float]) -> None:
    """Perform DRC on pin-pin connections.

    Pin2pin DRC can be turned on and off.
    Included DRC are xsection, width, radius, angle DRC, and symmetry.

    Args:
        pin1 (Node): first pin
        pin2 (Node): second pin
        t (tuple): (x, y, a) distance between pins, needed for angle a.

    Returns:
        None
    """
    global drc_msgcnt
    if not (pin1.xs is not None and pin2.xs is not None):
        return
    # else continue if both pins have a xs ->

    if not (pin1 is not pin1.cnode and pin2 is not pin2.cnode):
        return
    # else continue if pins are not a cnode ->

    DRCxsection = DRCangle = DRCwidth = DRCsymmetry = DRCradius = False

    # check for xsection DRC:
    xs1 = get_xsection(pin1.xs)
    xs2 = get_xsection(pin2.xs)
    if xs1.ID not in xs2.drc_pin2pin:
        DRCxsection = True

    # check for symmetry DRC:
    elif not xs1.symmetry:
        sameside = pin1.io == pin2.io
        sameflip = pin1.cnode.flip == pin2.cnode.flip
        sameparent = pin1.cnode.parent_cnode == pin2.cnode.parent_cnode
        if not (sameside != sameflip) and sameparent:
            DRCsymmetry = True

    # check for width DRC:
    drc_width1 = True
    drc_width2 = True
    if hasattr(xs1, "drc_width"):
        drc_width1 = xs1.drc_width
    if hasattr(xs2, "drc_width"):
        drc_width2 = xs2.drc_width
    if not (drc_width1 is False or drc_width2 is False):
        if pin1.width != pin2.width:
            if pin1.width is not None and pin2.width is not None:
                DRCwidth = True

    # check for angle DRC:
    drc_angle1 = True
    drc_angle2 = True
    if hasattr(xs1, "drc_angle"):
        drc_angle1 = xs1.drc_angle
    if hasattr(xs2, "drc_angle"):
        drc_angle2 = xs2.drc_angle
    if not (drc_angle1 is False or drc_angle2 is False):
        delta = cfg.drc_max_angle
        # TODO: Why both 0 and 180 angles are allowed / mixed?
        #       Now it may show 180 error when 180 + cfg.drc_max_angle + epsilon occurs.
        if abs(t[2]) > delta and abs(abs(t[2]) - 180) > delta and abs(t[2] - 360) > delta and abs(t[2] + 360) > delta:
            DRCangle = True

    # check for radius DRC:
    drc_radius1 = True
    drc_radius2 = True
    if hasattr(xs1, "drc_radius"):
        drc_radius1 = xs1.drc_angle
    if hasattr(xs2, "drc.radius"):
        drc_radius2 = xs2.drc_angle
    if not (drc_radius1 is False or drc_radius2 is False):
        if pin1.radius != pin2.radius:
            if pin1.radius is not None and pin2.radius is not None:
                DRCradius = True
    # Switch off radius DRC pending validation:
    DRCradius = False

    # Act on DRC violations:
    if DRCxsection or DRCangle or DRCwidth or DRCradius or DRCsymmetry:
        cp = cfg.cp
        # create pin reference strings for logging:
        if pin1.cnode.instance is False:
            pin1name = "{}.pin['{}']".format(pin1.cnode.cell.cell_name, pin1.up.name)
        elif pin1.cnode.instance is None:  # None in case of the topcell.
            pin1name = "{}.pin['{}']".format(pin1.cnode.cell.cell_name, pin1.name)
        else:
            pin1name = "{}.pin['{}']".format(pin1.cnode.cell.cell_name, pin1.up.name)
        if pin2.cnode.instance is False:
            pin2name = "{}.pin['{}']".format(pin2.cnode.cell.cell_name, pin2.up.name)
        elif pin2.cnode.instance is None:
            pin2name = "{}.pin['{}']".format(pin2.cnode.cell.cell_name, pin2.name)
        else:
            pin2name = "{}.pin['{}']".format(pin2.cnode.cell.cell_name, pin2.up.name)

        if DRCxsection:
            cfg.drc_msgcnt += 1
            cfg.ND_msgcnt += 1
            msg = "DRC-{}/ND-{}: xsection mismatch in cell '{}': {} != {} : {} - {} @ {}".format(
                cfg.drc_msgcnt,
                cfg.ND_msgcnt,
                cfg.active_cell().cell_name,
                pin1.xs,
                pin2.xs,
                pin1name,
                pin2name,
                pin1.fxy(),
            )
            Polygon(points=ring(*cfg.drc_ring_xs), layer=cfg.drc_layer_xs).put(pin1)
            font.text("x" + str(cfg.drc_msgcnt), layer=cfg.drc_layer_xs, height=5, align="cc").put(pin1)
            if (cfg.drc_raise and (cfg.drc_msgcnt == cfg.drc_raisenum)) or (
                cfg.ND_raise and (cfg.ND_msgcnt == cfg.ND_raisenum)
            ):
                logger.error(msg, exc_info=True)
                raise RuntimeError(msg)
            else:
                logger.error(msg)

        if DRCsymmetry:
            cfg.drc_msgcnt += 1
            cfg.ND_msgcnt += 1
            msg = "DRC-{}/ND-{}: symmetry mismatch in cell '{}' for xs = {} on pins {} to {} @ {}".format(
                cfg.drc_msgcnt,
                cfg.ND_msgcnt,
                cfg.active_cell().cell_name,
                pin1.xs,
                pin1name,
                pin2name,
                pin1.fxy(),
            )
            Polygon(points=ring(*cfg.drc_ring_sym), layer=cfg.drc_layer_sym).put(pin1)
            font.text("s" + str(cfg.drc_msgcnt), layer=cfg.drc_layer_sym, height=5, align="cc").put(pin1)
            if (cfg.drc_raise and (cfg.drc_msgcnt == cfg.drc_raisenum)) or (
                cfg.ND_raise and (cfg.ND_msgcnt == cfg.ND_raisenum)
            ):
                logger.error(msg, exc_info=True)
                raise RuntimeError(msg)
            else:
                logger.error(msg)

        if DRCangle:
            cfg.drc_msgcnt += 1
            cfg.ND_msgcnt += 1
            msg = "DRC-{}/ND-{}: angle mismatch in cell '{}': {:.3f} != 0 deg between pins {} and {} @ {}".format(
                cfg.drc_msgcnt,
                cfg.ND_msgcnt,
                cfg.active_cell().cell_name,
                t[2],
                pin1name,
                pin2name,
                pin1.fxy(),
            )
            Polygon(points=ring(*cfg.drc_ring_angle), layer=cfg.drc_layer_angle).put(pin1)
            font.text(
                "a" + str(cfg.drc_msgcnt),
                layer=cfg.drc_layer_angle,
                height=5,
                align="cc",
            ).put(pin1)
            if (cfg.drc_raise and (cfg.drc_msgcnt == cfg.drc_raisenum)) or (
                cfg.ND_raise and (cfg.ND_msgcnt == cfg.ND_raisenum)
            ):
                logger.error(msg, exc_info=True)
                raise RuntimeError(msg)
            else:
                logger.error(msg)

        if DRCwidth and not DRCxsection:
            cfg.drc_msgcnt += 1
            cfg.ND_msgcnt += 1
            msg = "DRC-{}/ND-{}: width mismatch in cell '{}': {} != {} : {} - {} @ {}".format(
                cfg.drc_msgcnt,
                cfg.ND_msgcnt,
                cfg.active_cell().cell_name,
                pin1.width,
                pin2.width,
                pin1name,
                pin2name,
                pin1.fxy(),
            )
            Polygon(points=ring(*cfg.drc_ring_width), layer=cfg.drc_layer_width).put(pin1)
            font.text(
                "w" + str(cfg.drc_msgcnt),
                layer=cfg.drc_layer_width,
                height=5,
                align="cc",
            ).put(pin1)
            if (cfg.drc_raise and (cfg.drc_msgcnt == cfg.drc_raisenum)) or (
                cfg.ND_raise and (cfg.ND_msgcnt == cfg.ND_raisenum)
            ):
                logger.error(msg, exc_info=True)
                raise RuntimeError(msg)
            else:
                logger.error(msg)

        if DRCradius:
            cfg.drc_msgcnt += 1
            cfg.ND_msgcnt += 1
            msg = "DRC-{}/ND-{}: radius mismatch in cell '{}': {} != {} : {} - {} @ {}".format(
                cfg.drc_msgcnt,
                cfg.ND_msgcnt,
                cfg.active_cell().cell_name,
                pin1.radius,
                pin2.radius,
                pin1name,
                pin2name,
                pin1.fxy(),
            )
            Polygon(points=ring(*cfg.drc_ring_width), layer=cfg.drc_layer_radius).put(pin1)
            font.text(
                "r" + str(cfg.drc_msgcnt),
                layer=cfg.drc_layer_radius,
                height=5,
                align="cc",
            ).put(pin1)
            if (cfg.drc_raise and (cfg.drc_msgcnt == cfg.drc_raisenum)) or (
                cfg.ND_raise and (cfg.ND_msgcnt == cfg.ND_raisenum)
            ):
                logger.error(msg, exc_info=True)
                raise RuntimeError(msg)
            else:
                logger.error(msg)

        cfg.cp = cp


def register_drc_xs(group: list[str | tuple[str, str]]) -> None:
    """Function to register which group of xsections are allowed to be connected.

    Note that connection goes both ways from xs1 to xs2 and from xs2 to xs1.

    Args:
        group: list of cross sections. Cross sections can be specified as string, 
            or as XSID.ID, so a tuple of (name, tech).

    Example::

       register_drc_xs(['A', 'B'])
       register_drc_xs(['A', ('B', "tech1')])

    The group list can be arbitrarily long, and every xs in the group connects to 
    every other xs in the group. If you do not want this, you need multiple calls:
    register_drc_xs(['A', 'B', 'C'])
    register_drc_xs(['B', 'D'])
    This means:
        - A connects to B and C.
        - B connects to A, C and D. 
        - C connects to A and B.
    If you did register_drc_xs(['A', 'B', 'C', 'D']) all xs would be mutually connected.

    Returns:
        None
    """
    ids = [get_xsection(xsref).ID for xsref in group]
    for xs1id in ids:
        xs1 = get_xsection(xs1id)
        for xs2id in ids:
            if xs2id not in xs1.drc_pin2pin:
                xs1.drc_pin2pin.append(xs2id)


def connect_geo(
    pin1: Node,
    pin2: Node,
    t: tuple[float, float, float] = (0, 0, 0),
    chain_node: int = 0,
    chain_connect: int | None = None,
    drc: bool = True,
    solve: bool = True,
):
    """Generate a geometrical edge between two Nodes.

    Connect pin1 and pin2 with geometrical transformation t.
    Pins are only allowed to connect if they the have the same parent cell,
    same cell or are part of an instance placed in the same parent cell.

    Args:
        pin1 (Node): 1st pin
        pin2 (Node): 2nd pin
        t (tuple): edge value: transformation (x, y, a) to get from pin1 to pin2
        chain_node (int): 1 if a chain node, 0 if not (default=0)
        chain_connect: overrules chain connect rules if None.
            chain_connect = 0 -> chain pin,
            chain_connect = 1 -> no-chain pin,
        (default=None)
        DRC (bool): apply DRC on the edge (default=True)

    Returns:
        None

    Exceptions:
        Pin connection out of scope.
    """
    # create a pointer in the nodes if none exists.
    assert pin1.pointer is not None
    # print("1: {}, 2: {}".format(pin1.pointer, pin2.pointer))
    if pin1.pointer is None:
        pin1.pointer = Pointer()
        pin1.pointer.chain = chain_node
    if pin2.pointer is None:
        pin2.pointer = Pointer()
        pin2.pointer.chain = chain_node

    if chain_connect is None:
        if pin1.cnode is pin2.cnode:  # pins in same cell
            chain_connect = 0
        else:
            chain_connect = pin1.pointer.chain or pin2.pointer.chain

    mat = to_mat(chain_connect, *t)
    pin1.nb_geo.append((pin2, mat))
    pin2.nb_geo.append((pin1, inverse(mat)))

    if solve:
        if pin2.cnode is pin1.cnode:
            # pins placed in the same parent
            pin2.pointer.set_mat(pin1.pointer.trans(mat))
        elif pin2.cnode.parent_cnode is pin1.cnode:
            # pin2 in instance placed in the same parent as pin1
            pin2.pointer.set_mat(pin1.pointer.trans(mat))
        elif pin1.cnode.parent_cnode is pin2.cnode:
            # pin1 in instance placed in the same parent as pin2
            pin2.pointer.set_mat(pin1.pointer.trans(mat))
        elif pin1.cnode.parent_cnode is pin2.cnode.parent_cnode:
            # both are pins of instances placed in the same parent
            pin2.pointer.set_mat(pin1.pointer.trans(mat))
        else:
            if pin1.cnode.instance:
                cell1 = f"instance-pin '{pin1.cnode.cell.cell_name}.{pin1.up.name}' in cell '{pin1.cnode.parent_cnode.cell.cell_name}"
            else:
                cell1 = f"cell-pin '{pin1.cnode.cell.cell_name}.{pin1.name}'"
            if pin2.cnode.instance:
                cell2 = f"instantiate '{pin2.cnode.cell.cell_name} via pin {pin2.up.name}'"
            else:
                cell2 = f"place cell-pin '{pin2.cnode.cell.cell_name}.{pin2.name}'"
            msg = f"Error: pins in connection not in scope inside active cell '{pin2.cnode.parent_cnode.cell.cell_name}' when trying to "\
                f"{cell2} onto {cell1}."
            raise RuntimeError(msg)

    if cfg.drc and drc:
        if abs(t[0]) < cfg.drc_max_distance and abs(t[1]) < cfg.drc_max_distance:
            # points at same location
            pin_drc(pin1, pin2, t)


def connect_path(
    n1: Node,
    n2: Node,
    cm: Any,
    sigtype: str = "dis",
    allowed_in: dict | None = None,
    allowed_out: dict | None = None,
):
    """Generate a connection/edge between n1 and n1 with edge s.

    Args:
        n1 (Node): first node
        n2 (Node): second node
        cm (any): compact model between node n1 and n2
        sigtype (str): # identifier to track the desired compact model between pins
            Default is 'dis' (geometrical distance).
        sigtype (str): Deprecated, for backwards compatibility. See 'track' for usage.
        allowed_in (dict): dictionary of the allowed extra parameters for sigtype at pin n1
        allowed_out (dict): dictionary of the allowed extra parameters for sigtype at pin n2

    Returns:
        None
    """
    # TODO: flag that active cell has an optical/sigtype connection
    if n1 is not None:
        n1.nb_cm.append((n2, cm, 1, sigtype, (allowed_in, allowed_out)))
    if n2 is not None:
        n2.nb_cm.append((n1, cm, -1, sigtype, (allowed_out, allowed_in)))
    # None neighbours represent terminations.


def connect_cnode(n1:Node, n2:Node, s)->None:
    """Generate cell connection.

    Args:

    Returns:
        None
    """
    n1.nb_cnode.append((n2, s, 1, 0))
    n2.nb_cnode.append((n1, s, -1, 0))


def _connect_ribbon(pin1, pin2, N0:int):
    """Helper function to connect all pins from ribbons rib0 and rib1.

    This function is called by the ribbon_connect function specifically to
    connect the ribbon pins.

    Args:
        rib0 (Ribbon pin): first Ribbon that is put
        rib1 (Ribbon pin): second Ribbon that is put
        N0 (int): amount of waveguides of both ribbons

    Returns:
        None
    """
    order1 = list(range(N0))
    order0 = range(N0)

    flip = pin1.cnode.flip != pin2.cnode.flip
    sameside = pin1.up.type == pin2.up.type

    if (sameside and not flip) or (not sameside and flip):
        order1.reverse()

    # TODO: store prefix in instance for flexibility instead of assuming 'a', 'b'
    if pin1.up.type == 3:
        prefix1 = "a"
    else:  # TODO: check explicitly for 4
        prefix1 = "b"

    if pin2.up.type == 3:
        prefix2 = "a"
    else:  # TODO: check explicitly for 4
        prefix2 = "b"

    # print(f"ribbons: {pin1.cnode.cell.cell_name}, {pin2.cnode.cell.cell_name}")
    for ord0, ord1 in zip(order0, order1):
        # print(f"{prefix1}{ord0}", f"{prefix2}{ord1}") # print connection made
        connect_geo(
            pin1.cnode.instance.pin[f"{prefix1}{ord0}"],
            pin2.cnode.instance.pin[f"{prefix2}{ord1}"],
        )


def parse_pin(
    C1=None,
    C2=None,
    C3=None,
    C4=None,
    /,
    instance=None,
    rot:bool=False,
    default:str="out",
):
    """Parse the part of the put statement after a potential first string arg.

    Args:
        C1: tuple of floats, len<=3; C2 = pinname
        C1 to C[i]: 1<=i<=3 are floats; C[i+1] = pinname
        instance (Instance object): Instance object to connect to
        rot (bool): Add an extra rotation for end pins in p2p connections if True

    Returns:
        pin, (x, y, a): describes a point at 'translation' from 'pin'.
            default='org', (0, 0, 0).

    Examples:
        Allowed input formats:

        'pin': can refer to one of the following types:
        - str: pin name of a pin in the active cell
        - Node: pin of an Instance in the active cell.

        * ()
        * (Node)
        * ((0))
        * ((0, 0))
        * ((0, 0, 0))
        * (0,)
        * (0, 0)
        * (0, 0, 0)

        * (pin)
        * (None, pin)
        * ((0), pin)
        * ((0, 0), pin)
        * ((0, 0, 0), pin)
        * (0, pin)
        * (0, 0, pin)
        * (0, 0, 0, pin)
    """
    if C1 is None:
        return cfg.cp, (0, 0, 0)

    xya = [0, 0, 0]
    if isinstance(C1, tuple):
        P = C2
        for i, elm in enumerate(C1):
            # Assume it can be converted to float:
            try:
                xya[i] = float(elm)
            except (TypeError, ValueError):
                main_logger(
                    f"Can't make sense of pin tuple: '{C1}'\n" f"    {elm} can't be converted to float.",
                    "error",
                )
    elif isinstance(C1, str):
        return cfg.active_cell().pin[P], xya
    elif isinstance(C1, Node):
        return C1, xya
    else:
        P = C4
        for i, elm in enumerate([C1, C2, C3]):
            try:
                xya[i] = float(elm)
            except (TypeError, ValueError):
                P = elm
                break

    if P is None:  # position w.r.t. 'org'
        if instance is None:
            if rot:
                xya[2] += 180
            return cfg.active_cell().cnode, xya
        else:
            return instance.cnode.parent_cnode, xya
    elif isinstance(P, str):
        return cfg.active_cell().pin[P], xya
    elif isinstance(P, Node):
        return P, xya
    elif isinstance(P, Instance):
        if default == "out":
            return P.pin[P.cnode.cell.default_out], xya
        else:
            return P.pin[P.cnode.cell.default_in], xya
    else:
        raise ValueError(f"pin could not be parsed {C1}, {C2}, {C3}, {C4}")


def validate_basename(basename:str)->bool:
    """Check if basename is unique on substring level.

    This is only relevant for pcell replacement where no mistake between
    different basenames is allowed.

    Args:
        basename (str): basename of a cell's name

    Returns:
        bool: True if basename is valid
    """
    size1 = len(basename)
    for bname in cfg.basenames:
        size2 = len(bname)
        size = min(size1, size2)
        # print(bname[0:size], basename[0:size])
        if bname[0:size] == basename[0:size]:
            main_logger(f"basename overlap {bname} - {basename}", "error")
            return False
    return True


def _raise_pin(node: Node, new_name: str, show: bool = True) -> None:
    """Helper function to raise a single pin."""
    # Determine IO based on flip state
    if node.cnode.flip:
        io = {0: 1, 1: 0}[node.io]
    else:
        io = node.io

    Pin(
        new_name,
        width=node.width,
        radius=node.radius,
        xs=node.xs,
        type=node.type,
        io=io,
        chain=node.chain,
        show=show,
        remark=node.remark,
    ).put(node)


class Instance:
    """Class to store pin information and properties of cell instantiations."""

    id = 0

    def __init__(self, cell_name:str|None=None):
        """Construct an Instance object.

        Args:
            cell_name (str): Cell name to be used in the instance name

        Returns:
            None
        """
        self.cnode = None
        self.cell = None
        self.parent_cnode = None
        self.pin: dict[str, Node] = {}
        self.default_in = None
        self.default_out = None
        self.org = None
        self.flip = None
        self.array = None
        self.id = Instance.id
        self.name = f"{cell_name}_I{self.id}"
        self.bbox = None  # bbox position of the instance in the parent cell
        self.scale = None
        self.propattr = None  # instance property (must be ordinal counter: 1, 2, 3, ..,)
        self.propvalue = None  # property string
        Instance.id += 1  # keep instance counter unique
        self.model_info = {}

    def __repr__(self):
        return "<Instance() object of cell '{}' in cell '{}'>".format(
            self.cnode.cell.cell_name, self.cnode.parent_cnode.cell.cell_name
        )

    def ic_pins(self):
        """Generator over interconnect pins, filter out org and bounding box.

        Yields:
            str, Pin: iterator over pins in cell
        """
        for name, p in self.pin.items():
            if (name != "org") and (name not in bbu.bbox_pinnames):
                yield name, p

    def raise_pins(
        self,
        namesin: list[str] = None,
        namesout: list[str] = None,
        show: bool = True,
        hierarchy_label: bool = False,
        pass_pins_through: bool = False,
    ):
        """Copy pins of a cell instance to its parent cell.

        Method raise_pins copies all pin attributes from the instance <self>
        to its parent.

        If a cell A is "put" in cell P, then an instance of cell A is created
        inside "parent" cell P. Each instance of cell A, say A1, A2, ...,
        contains a copy of all pins of cell A to represent cell A in P at a
        particular location, rotation, flip state and/or scaling.
        Note that these instance pins are not pins of cell P. For that,
        pins have to be explicitly set in P with nd.Pin.put().
        Alternatively to many of such puts, all or part of the pins in an instance
        can be set at once in P by raise_pins(). This can be very useful when
        an instance has a large number of pins that have to be "raised".

        Note:
            raise_pins is a method of Class Instance, not of Cell. Hence,
            it operates on a cell-that-has-been-put.

         Note:
             that raise_pins returns the instance it operates on, hence
             the following syntax still assigns the instance to variable I::

             I = cell().put().raise_pins(['a0'])

        Args:
            namesin (list of str): list of pin names to raise
                (default=all pins of the instance)
            namesout (list of str): list of new names of the raised pins
                (default=<namesin>)
            show (bool): show the pins in the layout with an arrow (default=True)
            hierarchy_label (bool): append the instance label to the pin name
                if no new names are given (default=False)
            pass_pins_through (bool): if True, raise pins that were raised
                in a lower level (default=False)

        Returns:
            Instance: instance it raised pins for

        Example:
            Raise (copy) all pins of an instance into its parent cell.
            In this example a 90 degree bend is connected to port 'a0'
            of the new_cell.

            Create pins without the `raise_pins` method looks like this::

                # create and put Pins explicitly one by one:
                import nazca as nd

                with nd.Cell('new_cell') as new_cell:
                    instance1 = nd.example_cell().put(100, 200)
                    nd.Pin('a0').put(instance1.pin['a0'])
                    nd.Pin('b0').put(instance1.pin['b0'])

                instance2 = new_cell.put(0)
                nd.bend(angle=90).put(instance2.pin['a0'])
                nd.export_plt()

            Now **raise** pins with `raise_pins()` on <instance1> in 'new_cell'.
            This automatically copies all pin attributes::

                # raise pins
                import nazca as nd

                with nd.Cell('new_cell') as new_cell:
                    instance1 = nd.example_cell().put(100, 200)
                    instance1.raise_pins()

                instance2 = new_cell.put(0)
                nd.bend(angle=90).put(instance2.pin['a0'])
                nd.export_plt()

            Now **raise and rename** pins 'a0' and 'b0' of <instance1>
            with method `raise_pins`. Note that the
            cell default pins, 'a0' and 'b0', are automatically added to
            <new_cell>::

                # raise and rename pins
                import nazca as nd

                with nd.Cell('new_cell') as new_cell:
                    instance1 = nd.example_cell().put(0)
                    instance1.raise_pins(['a0', 'b0'], ['new_a0', 'new_b0'])

                instance2 = new_cell.put(0)
                nd.bend(angle=90).put(instance2.pin['new_a0'])
                nd.bend(angle=-90).put(instance2.pin['a0'])
                nd.export_plt()
        """
        if not hierarchy_label and pass_pins_through:
            msg = f"Pins are being passed through instance '{self.label}' "
            msg += "but hierarchy labels are not being applied"
            main_logger(msg, "warning")

        do_not_raise = ["org"]  # List of pins to ignore in raising.
        available_pinnames = list(self.pin.keys())

        if namesin is None:
            # Raise all pins
            for name in available_pinnames:
                if name in do_not_raise:
                    continue

                node = self.pin[name]

                # Skip if passing through and pin is not already passed through
                if pass_pins_through and "/" not in name and "|" not in name:
                    continue

                # Generate hierarchical name if needed
                if hierarchy_label:
                    separator = "/" if "|" in name else "|"
                    pin_name = self.name + separator + name
                else:
                    pin_name = name

                _raise_pin(node, pin_name, show=show)
        else:
            # Raise specific pins
            if namesout is None:
                namesout = []
                for name in namesin:
                    if hierarchy_label:
                        separator = "/" if "|" in name else "|"
                        namesout.append(self.name + separator + name)
                    else:
                        namesout.append(name)

            for namein, nameout in zip(namesin, namesout):
                if namein in available_pinnames:
                    node = self.pin[namein]
                    _raise_pin(node, nameout, show=show)
                else:
                    main_logger(f"'raise_pins': pin '{namein}' not defined.", "warning")

        return self


num = 0


class Cell:
    """Cell object, corresponding to a GDS cell when exported to GDS.

    A cell has default pins:
        'org': cell origin (non-chain)
        'a0' : input pin   (chain)
        'b0' : output pin  (chain)

    It is up to the user to place 'a0' and 'b0' at sensible positions in the cell.
    If not provided, they will be placed at the origin automatically.

    When starting a new cell: cp = C.pin['org']

    A cell typically contains one or more of the following objects:
        1. pins: A position w.r.t. the cell origin that can be used to connect to.
            method: Pin().put()

        2. cell instances: A reference to another cell
            method: Cell().put()

        3. polygons: A polygon assigned to a specific GDS layer.
            method: Polygon().put()

        4. polylines: A polyline/path assigned to a specific GDS layer.
            method: Polyline().put()

        5. annotations:
            method: Annotation().put()
    """
    id = 0  # cell counter/ID

    def __init__(
        self,
        name: str | None = None,
        celltype: str = "element",
        instantiate: bool = True,
        autobbox: bool = False,
        hull: bool | None = None,
        store_pins: bool | None = None,
        # hashme=False,
        cnt: bool = False,
        params: bool = False,
        show_hull: bool | None = None,
        hull_based_bbox: bool | None = None,
    ):
        # TODO: params unused?
        """Construct a Cell object.

        Cell definitions can be nested.

        If the cell is defined as the first cell inside a function that has
        a @hashme decorator, the cell obtains its (unique) name from hashme.

        Args:
            name (str): cell name (default=None). Name must be None to activate cellcache.
            celltype (str): type of cell, option 'element', 'mask' (default='element')
            instantiate (bool): flag if the cell is instantiated (default=True)
            autobbox (bool): create a cell bounding box (default=False)
            hull (bool): calculate bbox as a convex hull (may be slower)
            store_pins (bool): store cell pins in annotation inside GDSll.
            cnt (bool): append ordinal counter to the cellname (default=False)
            params (bool): add parameter annotation in the cell (default=False)
                Note that autobbox = True will already add parameter annotation.

        Returns:
            None

        Example:
            Create a cell with cell name 'mycell' and variable name C.
            Put the cell in the mask layout and export the layout::

                import nazca as nd

                with nd.Cell('mycell') as C:
                    nd.strt(length=40).put(0)
                    nd.bend(angle=15).put()

                C.put(0)

                nd.export_plt()
        """
        global num
        num += 1

        self.properties = {}

        if len(cfg.cellcachemodel) > 0 and name is None:
            self.hashme = True
            self.cellcache = cfg.cellcachemodel.pop()
        else:
            self.hashme = False
            self.cellcache = {}
        if self.hashme:
            name = self.cellcache["cellname_full"]
            basename = self.cellcache["cellname_base"]
            paramsname = self.cellcache["cellname_base_params"]
            self.func_id = self.cellcache["func_id"]
            self.parameters = self.cellcache["paramdict"]
            self.properties["parameters"] = self.parameters  # TODO: as part of cellcachemodel dict
            # self.properties["cellnameparameters"] = [key for key in cfg.hash_cellnameparams]  # TODO: remove? or used in manual?
        else:
            if name is None:
                name = f"noname_{num}"
            name = cfg.gds_cellname_cleanup(name)
            basename = cfg.gds_cellname_cleanup(name)
            paramsname = cfg.gds_cellname_cleanup(name)
            if cnt:
                name = "{}_{}".format(name, num)
            self.func_id = None
            self.parameters = None
            self.properties["parameters"] = None

        if cfg.validate_basename:
            validate_basename(basename)

        if name in cfg.cellnames:
            # TODO: what if new name also exists?
            name2 = f"{name}_{num}"
            # cfg.cellnames[name2] = self
            if instantiate is True:
                gdsmsg = ""
                if cfg.gdsload != "" and cfg.gdsload is not False:
                    gdsmsg = (
                        f" Occured during gds load of '{cfg.gdsload}'. Use load_gds(cellsreused=['{name}']) "
                        "to reuse existing cells instead."
                    )
                # main_logger(
                #     f"Duplicate cell name in nd.Cell(name='{name}') renamed to '{name2}'." + gdsmsg,
                #     "warning",
                # )
            name = name2

        cfg.cellnames[name] = self
        self.properties["cell_name"] = name

        # cell Node and netlist properties
        self.id = Cell.id
        Cell.id += 1
        cfg.cells.append(self)
        cfg.self = cfg.active_cell()
        self.closed = False
        self.pin2 = None  # store pinout for p2p interconnect cells
        self.cnode = Node("org")
        self.cnode.cnode = self.cnode
        self.cnode.cell = self
        self.cnode.pointer = Pointer(0, 0, 0)
        self.cnode.flip = False
        self.cnode.instance = None
        self.org = self.cnode
        self.parent_cnode = None

        # cell properties
        self.instantiate = instantiate
        self.auxiliary = False  # indicate if the cell is not real layout but mere visualization, e.g. pins, and stubs
        self.ranges = {}  # for storing parameter information like the allowed range of parameters
        self.bbinfo = dict()  # store metadata on the cell
        self.name_layer = None  # (str) custom layer for displaying BB name polygon. None defaults to 'bbox_name'.
        self.module = ""  # optional str value to store the module name the cells is defined in.
        self.version = None
        self.updk = {}
        self.void = False  # flag to allow pathfinder to go through empty tubes, e.g. length=0 guides.

        # layout elements
        self.polygons = []
        self.polylines = []
        self.gdsfiles = []
        self.annotations = []

        # cell naming
        self.name = self.id
        self.cell_basename = basename  # name: base
        self.cell_paramsname = paramsname  # name: base + params  # TODO: remove? part of cellcachemodel dict
        self.cell_name = name  # name: base + params + hash
        self.params = params  # TODO: remove? part of cellcachemodel dict
        self.group = ""  # (str) optional value for grouping/sorting cells

        # bbox handling:
        self.autobbox = autobbox
        self.bbox = None
        self.bboxbuf = 0
        self.userbbox = None
        self.add_bbox_flag = False  # store if bbox has been calculated already
        self.userbbox_include = True  # make userbbox part of the bbox if True
        self.protectbox = False  # copy the bbox to the userbbox if no userbbox is defined.
        self.bbox_polygon = np.array([])
        self.ibbox = {}  # {inode, ibbox} store instance bounding boxes for group_connect

        # hull handling:
        self.hull = None  # contain the actual hull data if any.
        self.hull_based_bbox = None  # hull based bbox if True
        self.show_hull = cfg.show_hull if show_hull is None else show_hull  # export the hull as layout
        # Note that if use_hull is True:
        # - calculate a hull for this cell
        # - AND use hulls of instances in this cell if available (otherwise the bbox)
        if hull is None:
            self.use_hull = cfg.use_hull
        elif hull is True:
            self.use_hull = True
        else:
            self.use_hull = False
        self.hull_based_bbox = cfg.hull_based_bbox if hull_based_bbox is None else hull_based_bbox
        if hull is True and hull_based_bbox:
            self.hull_based_bbox = True

        # pin connectivity handling:
        self.store_pins = cfg.store_pins if store_pins is None else store_pins
        self.oldcp = cfg.cp
        self.pin = {self.cnode.name: self.cnode}
        if celltype == "mask":
            self.default_in = self.cnode.name  # 'org'
            self.default_out = self.cnode.name  # 'org'
        else:  # 'element':
            self.default_in = "a0"
            self.default_out = "b0"
        cfg.cp = self.org

        # compact models related properties:
        self.pcell_data: dict[str, Any] = {}
        self.model_info = {"model": None}
        self.cm_id = None  # cell ID for compact model mapping

    @classmethod
    def json_init(cls, cell_dict: dict) -> Cell:
        """Reconstruct a Cell using the serialized cell tree dictionary.

        This initialization method avoids recalculating many steps, as these have already been calculated before.
        The cell tree dictionary should be bottom up, so that reconstruction happens bottom up. This ensures that Cells
        are first reconstructed before they are placed in the cell above.

        While deserializing, we keep track of regenerated Cells and Nodes. This way we can access the pointers to these
        objects where necessary (i.e. when placing an instance of a cell, we can retrieve the actual cell object of
        the new cell).

        Deserialization happens as follows:
        1. Deserialize Cells:
            - Initialize Cell.
            - Regenerate Cell pin objects.
            - Regenerate cnode connectivity.
            - Place any instances, polygons, polylines, annotations or GDS files in the cell.
            - Handle relevant steps of Cell closure.
        2. Add back in pin connections:
            - Connect geometrical connections from storage. Therefore group connect is not needed, to speed things up.
            - Add compact model connections from storage.

        Args:
            cell_dict (dict): Dictionary containing the serialized cell tree.

        Returns:
            nd.Cell: the top level cell of the cell tree.
        """
        global num
        num += 1

        oldcp = cfg.cp  # after placing all the cells in the cell tree, we need to reset cfg.cp back to the old value

        # keep track of newly generated objects, so that we can insert the relevant pointers where necessary
        cell_objects = {}
        node_objects = {}
        reused_connection_ids = set()

        def _add_id_mapping(objects, key, value):
            """Map serialized ids with both JSON string keys and native ids."""
            objects[key] = value
            objects[str(key)] = value
            try:
                objects[int(key)] = value
            except (TypeError, ValueError):
                pass

        # extract connections
        geo_connections = cell_dict.pop("geo_connections")
        cm_connections = cell_dict.pop("cm_connections")

        # turn off group connect to speed up. Connections will be inserted from storage
        with GroupConnect(onoff=False):

            # place all Cells. Cell initialization happens bottom up, to ensure cells are available when they are placed
            for cell_id, cell_info in cell_dict.items():
                # TODO: RB: Check immediately if the cell exists already and return that cell if it exists
                #     : this is best done top down first to not reconstruct existing branches bottom up.
                #     : this assumes that local and remote celltrees are the same for the same cell signatures.
                if cell_info["cell_name"] in cfg.cellnames:
                    cell = cfg.cellnames[cell_info["cell_name"]]
                    _add_id_mapping(cell_objects, cell_id, cell)
                    _add_id_mapping(cell_objects, cell_info["id"], cell)

                    for pin_id, info in cell_info["pins"].items():
                        if info["name"] in cell.pin:
                            node_objects[pin_id] = cell.pin[info["name"]]
                        reused_connection_ids.add(pin_id)

                    for instance_info in cell_info["instances"]:
                        for pinname in cell_objects[instance_info["cell_id"]].pin.keys():
                            reused_connection_ids.add(f"{pinname}_instance{instance_info['instance_id']}")
                    continue

                # create an empty cell to circumvent running __init__
                cell = super(Cell, cls).__new__(cls)

                # 'open' the cell
                cell.closed = False

                cfg.cells.append(cell)

                # extract information on objects that need to be placed in the Cell
                pininfo = cell_info.pop("pins")
                cnode_id = cell_info.pop("cnode")
                polygons = cell_info.pop("polygons")
                polylines = cell_info.pop("polylines")
                annotations = cell_info.pop("annotations")
                instances = cell_info.pop("instances")

                # deserialize remaining (simple, non-object) attributes:
                for attr, value in cell_info.items():
                    setattr(cell, attr, value)

                # convert cm_id back to tuple
                cell.cm_id = tuple(cell.cm_id)

                # initialize model_info attribute
                cell.model_info = {}

                # TODO could be that xs in model info is a tuple!
                if "xs" in cell.pcell_data:
                    if isinstance(cell.pcell_data["xs"], list):
                        cell.pcell_data["xs"] = tuple(cell.pcell_data["xs"])

                cell.bbox_polygon = np.asarray(cell.bbox_polygon)

                # TODO implement some sort of hashme functionality?
                # ensure no duplicate cellnames
                if cell.cell_name in cfg.cellnames:
                    old_name = cell.cell_name
                    name2 = f"{old_name}_{num}"
                    cfg.cellnames[name2] = cell
                    cell.cell_name = name2
                    cell.properties["cell_name"] = name2
                    if cell.instantiate is True:
                        main_logger(
                            f"Duplicate cell name in nd.Cell(name='{old_name}') renamed to '{name2}'.",
                            "warning",
                        )
                else:
                    cfg.cellnames[cell.cell_name] = cell

                # add pins to the cell
                pins = {}
                for pin_id, info in pininfo.items():
                    node = Node.json_init(info)
                    pins[info["name"]] = node
                    # make mapping to the newly generated node object
                    node_objects[pin_id] = node
                cell.pin = pins

                # set cnode and cnode information
                cell.cnode = node_objects[cnode_id]
                cell.cnode.cell = cell
                cell.cnode.instance = None
                cell.org = cell.cnode
                # We also have to point the pins to the new cnode object
                for pinname, node in cell.pin.items():
                    node.cnode = node_objects[cnode_id]

                # add instances to cell
                cell.ibbox = {}
                for instance_info in instances:
                    instance = cell_objects[instance_info["cell_id"]].put(
                        "org",
                        instance_info["x"],
                        instance_info["y"],
                        instance_info["a"],
                        flip=instance_info["flip"],
                        label=instance_info["label"],
                    )

                    # save reference to instance node objects so that we can access these when reconstructing connections
                    for name, pin in instance.pin.items():
                        node_objects[f"{pin.basename}_instance{instance_info['instance_id']}"] = pin

                # add polygons to cell
                cell.polygons = []
                for polygon_info in polygons:
                    p = Polygon(
                        layer=tuple(polygon_info["polygon"]["layer"]),
                        points=polygon_info["polygon"]["points"]
                    )
                    p.put(
                        polygon_info["x"],
                        polygon_info["y"],
                        polygon_info["a"],
                        flip=polygon_info["flip"],
                        flop=polygon_info["flop"],
                        scale=polygon_info["scale"],
                    )

                # add polylines to cell
                cell.polylines = []
                for polyline_info in polylines:
                    p = Polyline(
                        layer=tuple(polyline_info["polyline"]["layer"]),
                        points=polyline_info["polyline"]["points"],
                        width=polyline_info["polyline"]["width"],
                        pathtype=polyline_info["polyline"]["pathtype"],
                        miter=polyline_info["polyline"]["miter"],
                    )
                    p.put(
                        polyline_info["x"],
                        polyline_info["y"],
                        polyline_info["a"],
                        flip=polyline_info["flip"],
                        flop=polyline_info["flop"],
                        scale=polyline_info["scale"],
                    )

                # add annotations to cell
                cell.annotations = []
                for annotation_info in annotations:
                    a = Annotation(
                        layer=tuple(annotation_info["annotation"]["layer"]),
                        text=annotation_info["annotation"]["text"]
                    )
                    a.put(
                        annotation_info["x"],
                        annotation_info["y"],
                        annotation_info["a"],
                    )
                # add gds files to cell
                cell.gdsfiles = []
                # TODO implement gds file functionality?

                # Handle cell closure
                cm._fetch_compact_models(cell)  # fetch compact models on the client side
                cell.pin_in = cell.pin[cell.default_in]
                cell.pin_out = cell.pin[cell.default_out]
                _add_id_mapping(cell_objects, cell.id, cell)  # save cells so that it can be put when placing instances

                cell.id = Cell.id  # use local cell id to set the cell id of the new cell, instead of server id
                Cell.id += 1
                cfg.cells.pop()
                cell.closed = True

            # Reconstruct geo connections from storage
            for pin1_id, connections in geo_connections.items():  # geo connections append to nb_geo
                if pin1_id in reused_connection_ids:
                    continue
                pin1 = node_objects[pin1_id]  # deserialize pin1
                for connection in connections:
                    pin2_id = connection[0]
                    pin2 = node_objects[pin2_id]  # deserialize pin2
                    pin1.nb_geo.append((pin2, np.asarray(connection[1])))
            # Reconstruct compact model connections from storage
            for pin1_id, connections in cm_connections.items():  # cm connections append to nb_cm
                if pin1_id in reused_connection_ids:
                    continue
                pin1 = node_objects[pin1_id]  # deserialize pin1
                for connection in connections:
                    pin2_id = connection[0]
                    pin2 = node_objects[pin2_id]  # deserialize pin2
                    pin1.nb_cm.append((pin2, *connection[1:]))

        # reset cp
        cfg.cp = oldcp

        # return top level cell
        return cell

    @property
    def cm_id(self):
        """Identifier for compact model generation."""
        return self._cm_id

    @cm_id.setter
    def cm_id(self, value):
        """Identifier for compact model generation.

        Should not be altered after cell is closed, since the compact model will not be retrieved.
        """
        if self.closed:
            main_logger(f"Property 'cm_id' can not be set after cell '{self.cell_name}' is closed!", "error")
        else:
            self._cm_id = value

    def __repr__(self):
        return "<Cell(name='{}', instantiate={})>".format(self.cell_name, self.instantiate)

    def default_pins(self, pinin: Node | str | None = None, pinout: Node | str | None = None) -> None:
        """Set default input and output pins to connect the cell.

        If no default pins are provided they will be set to 'a0' and 'b0'.
        These pins are added to the cell in (0, 0) if they do not exist.

        Args:
            pinin (Node | str): pin to set as default cell input pin
            pinout (Node | str): pin to set as default cell output pin

        Returns:
            None
        """
        if pinin is None:
            pinin = self.default_in
        else:
            self.default_in = pinin

        if pinout is None:
            pinout = self.default_out
        else:
            self.default_out = pinout

    def add_property(self, item:dict):
        """Add item to the cell properties dictionary.

        item (dict): new property

        Returns:
            None
        """
        # TODO: what is this full function doing here? Implementation can move to utils.
        def merge_properties(D1:dict, D2:dict):
            """Merge dictionaries recursively.

            D1 (dict): existing properties
            D2 (dict): properties to add

            Returns:
                dict: merged level of the dictionary
            """
            update = {}
            if isinstance(D1, dict):
                D1keys = list(D1.keys())
            else:
                D1keys = []
            if isinstance(D2, dict):
                D2keys = list(D2.keys())
            else:
                D2keys = []

            if not D1keys or not D2keys:
                main_logger(
                    f"In cell '{self.cell_name}': Overwriting properties: {D1} to {D2}",
                    "warning",
                )
                return D2
            else:
                for e in set(D1keys + D2keys):
                    if e not in D1keys:
                        update[e] = D2[e]
                    elif e not in D2keys:
                        update[e] = D1[e]
                    else:
                        update[e] = merge_properties(D1[e], D2[e])
                # print("update", update)
                return update

        self.properties = merge_properties(self.properties, item)
        # print("\n", self.properties)

    def ic_pins(self):
        """Generator over interconnect pins, filter out org and bounding box.

        Yields:
            str, Pin: iterator over pins in cell
        """
        for name, p in self.pin.items():
            if (name != "org") and (name not in bbu.bbox_pinnames):
                yield name, p

    def iterpins(self, filters:dict|None=None, org:bool=False, bbox:bool=False):
        """Generator over interconnect pins, filter out org and bounding box.

        If no filters are specified then all pins will be returned,
        except for org and bbox pins

        Args:
            filters (dict): filter for pin attribute values when to yield pins.
               For multiple values to match against a list of values can be provided.
            org (bool): yield org pin. Default = False
            bbox (bool): yield bbox pins. Default = False

        Yields:
            str, Pin: iterator over pins in cell

        Example::

            Iterate only over pins having xsections names xs = "XS1" or "XS2":

            for name, pin in C.iterpins(filters={"xs": ["XS1", "XS2"]}):
                print(name)
        """
        if filters is None:
            filters = {}
        for name, p in self.pin.items():
            if not org:
                if name == "org":
                    continue
            if not bbox:
                if name in bbu.bbox_pinnames:
                    continue
            if filters == {}:
                yield p
            for attr, values in filters.items():
                if not isinstance(values, list):
                    values = [values]
                if getattr(p, attr) in values:
                    yield p

    def __enter__(self):
        return self

    def __exit__(self, type, value, traceback):
        if value is None:
            self.close()
        else:
            # Exception inside the cell context: do not run close(), but
            # unwind the active cell stack so subsequent code does not end up
            # in this half-built cell.
            if cfg.cells and cfg.cells[-1] is self:
                cfg.cells.pop()
            cfg.cp = self.oldcp
            if cfg.cells:
                cfg.self = cfg.active_cell()
        return False

    def parse_instance_connection(self, C1, C2, C3, C4, C5, /, instance:Instance|None=None):
        """Connect a (closed) cell as an Instance object into the active cell.

        Parse up to five connection arguments to extract: pin1, pin2 and (x,y,a):

        Args:
            C1 (float | Node | Instance): connection information
            C2 (float | Node | Instance): connection information
            C3 (float | Node | Instance): connection information
            C4 (float | Node | Instance): connection information
            C5 (float | Node | Instance): connection information
            instance (Instance): instance object to connect to

        Returns:
            Node, Node, (x, y, a): instance pin, cell pin, connection

        Notes:
            The connection has the following syntax:

            [pin_inst [, translation]]

            or

            [pin_inst, ] translation  [, pin_cell]

            * translation = x | x,y | x, y, a | (x) | (x, y) | (x, y, z), where
              translation is w.r.t. <pin_cell>
            * pin_inst: pinname of instance being placed (default='a0')
            * pin_cell: pinname of active cell (default='org')
            * pin_inst2: pinname of an existing instance in the active cell

            Options:

            * ()
            * (node)
            * (instance)
            * (0,)
            * (0, 0)
            * (0, 0, 0)
            * ((0))
            * ((0, 0))
            * ((0, 0, 0))
            * (0, pin)
            * (0, 0, pin_cell)
            * (0, 0, 0, pin_cell)
            * ((0), pin_cell)
            * ((0, 0), pin_cell)
            * ((0, 0, 0), pin_cell)

            * (pin_inst)
            * (pin_inst, 0)
            * (pin_inst, 0, 0)
            * (pin_inst, 0, 0, 0)
            * (pin_inst, (0))
            * (pin_inst, (0, 0))
            * (pin_inst, (0, 0, 0))

            * (pin_inst, pin_cell)
            * (pin_inst, 0, pin_cell)
            * (pin_inst, 0, 0, pin_cell)
            * (pin_inst, 0, 0, 0, pin_cell)
            * (pin_inst, (0), pin_cell)
            * (pin_inst, (0, 0), pin_cell)
            * (pin_inst, (0, 0, 0), pin_cell)

            * (pin_inst, pin_inst2)
            * (pin_inst, 0, pin_inst2)
            * (pin_inst, 0, 0, pin_inst2)
            * (pin_inst, 0, 0, 0, pin_inst2)
            * (pin_inst, (0), pin_inst2)
            * (pin_inst, (0, 0), pin_inst2)
            * (pin_inst, (0, 0, 0), pin_inst2)
        """
        if C1 is None:
            return instance.pin[self.default_in], cfg.cp, (0, 0, 0)
        elif isinstance(C1, Node):
            if C1.cnode.instance is None and C1.cnode.cell.closed and not cfg.patchcell:
                raise RuntimeError(
                    "You are trying to connect to a closed Cell object:\n"
                    "  The construction found is similar to\n"
                    "  $ foo.put(cell.pin['a0'])\n"
                    "  Connect not to the Cell but to an instance of the cell instead\n"
                    "  $ instance = cell.put()\n"
                    "  $ foo.put(instance.pin['a0'])\n"
                )
            return instance.pin[self.default_in], C1, (0, 0, 0)
        elif isinstance(C1, Instance):
            if C1.cnode.instance is None and C1.cnode.cell.closed and not cfg.patchcell:
                raise RuntimeError("Trying to connect to a closed cell. " "Try using an instance instead.")
            return (
                instance.pin[self.default_in],
                C1.pin[C1.cnode.cell.default_out],
                (0, 0, 0),
            )
        elif isinstance(C1, str):
            pin2, T = parse_pin(C2, C3, C4, C5, instance)
            p = instance.pin.get(C1)
            if p is None:
                main_logger(
                    f"Unknown pin name '{C1}' to connect to. Using pin 'org' instead. ",
                    "error",
                )
                p = instance.pin.get("org")
            return p, pin2, T
        else:
            pin2, T = parse_pin(C1, C2, C3, C4, instance)
            return instance.pin[self.default_in], pin2, T

    def parse_pin_connection(self, C1, C2, C3, C4, /):
        """Parse pin connection for polygon, polyline, annotation and gds methods.

        Args:
             C1, C2, C3, C4 (float | Node | instance): Parsing information

        Returns:
            Node, (x, y, a): pin, translation

        Example:
            Options:

            * ()
            * (node)
            * (0,)
            * (0, 0)
            * (0, 0 ,0)
            * ((0))
            * ((0, 0))
            * ((0, 0 ,0))
            * (0, 'b0')
            * (0, 0, 'b0')
            * (0, 0 ,0, 'b0')
            * ((0), 'b0')
            * ((0, 0), 'b0')
            * ((0, 0 ,0), 'b0')
        """
        # TODO: check if pin connection is in scope (parent or sibling)
        if C1 is None or (isinstance(C1, tuple) and len(C1) == 0):
            return cfg.cp, (0, 0, 0)
        elif isinstance(C1, Node):
            if C1.cnode.instance is None and C1.cnode.cell.closed and not cfg.patchcell:
                raise RuntimeError(
                    "It is not allowed to connect to a closed cell:"
                    " from cell '{2}'"
                    " to pin '{1}' of the already *closed* cell '{0}'."
                    " Solution: instantiate cell '{0}' first inside cell '{2}'"
                    " using put(),"
                    " and connect to a pin of the resulting instance instead.".format(
                        C1.cnode.cell.cell_name, C1.name, self.cell_name
                    )
                )
            return C1, (0, 0, 0)
        elif isinstance(C1, Instance):
            if C1.cnode.instance is None and C1.cnode.cell.closed and not cfg.patchcell:
                raise RuntimeError(
                    "It is not allowed to connect from cell '{2}'"
                    " to pin '{1}' of the already *closed* cell '{0}'."
                    " Solution: instantiate cell '{0}' first inside cell '{2}'"
                    " using put(),"
                    " and connect to a pin of the resulting instance instead.".format(
                        C1.cnode.cell.cell_name, C1.name, self.cell_name
                    )
                )
            return C1.pin[C1.cnode.cell.default_out], (0, 0, 0)

        xya = [0, 0, 0]
        if isinstance(C1, tuple):
            for i, elm in enumerate(C1):
                # isinstance(elm, int) may fail on numpy.int64 type
                try:
                    elm = 1.0 * elm
                except TypeError as E:
                    raise ValueError("Invalid value provided pin({}). {}".format(repr(elm), E))
                xya[i] = elm
            if isinstance(C2, str):
                return self.pin[C2], xya
            else:
                return self.org, xya
        else:
            P = C4
            for i, elm in enumerate([C1, C2, C3]):
                # isinstance(elm, int) may fail on numpy.int64 type
                if elm is None:
                    P = elm
                    break
                else:
                    try:
                        elm = 1.0 * elm
                    except TypeError as E:
                        raise ValueError(
                            "Invalid value provided: put({})."
                            "This may be caused by using a pin name string in a Polygon put().\n {}".format(
                                repr(elm), E
                            )
                        )
                    xya[i] = elm
            if isinstance(P, str):
                return self.pin[P], xya
            else:
                return self.org, xya

    def _put_pin(
        self,
        name=None,
        connect=None,
        xs=None,
        width=0,
        type=None,
        radius=None,
        io=None,
        chain=1,
        show=False,
        remark=None,
        drc=None,
    ):
        """Add new pin and connect it to an existing pin.

        Returns:
            Node: pin being put
        """
        node_new = Node(name)  # next(Pt)
        node_new.pointer = Pointer()
        node_new.pointer.chain = chain
        node_new.cnode = self.cnode
        node_new.xs = xs
        node_new.width = width
        node_new.radius = radius
        node_new.io = io
        node_new.type = type
        node_new.show = show
        node_new.remark = remark

        if name is not None:  # add a node
            self.pin[name] = node_new

        C = [None] * 4
        if isinstance(connect, tuple):
            for i, conn in enumerate(connect):
                C[i] = conn
        else:
            C[0] = connect

        node_exist, T = self.parse_pin_connection(*C)
        connect_geo(node_exist, node_new, t=T, chain_node=1, chain_connect=0, drc=drc)
        return node_new

    def get_pin(self, pinname: str | None = None, connect: tuple | Node | None = None) -> Node:
        """ "Parse pinname and connect for put_polygon and put_gds methods.

        Returns:
            Node: pin position, new if needed
        """
        if pinname is None:
            pinname = "org"
        if pinname not in cfg.active_cell().pin.keys():  # add new pin w.r.t. org
            if connect is None:  # org
                node = self._put_pin(pinname, cfg.active_cell().org)
            elif isinstance(connect, tuple):  # (x,y,a)
                node = self._put_pin(pinname, connect)
                # node = cfg.active_cell().org.move(*connect)
                # node.name = pinname
            elif isinstance(connect, Node):  # Node
                self._put_pin(pinname, connect)
                node = connect
            return node
        else:  # existing pin
            if connect is None:  # org
                node = cfg.active_cell().org
            elif isinstance(connect, tuple):  # (x,y,a)
                node = cfg.active_cell().pin[pinname].move(*connect)
            elif isinstance(connect, Node):  # Node
                node = connect  # maybe set parent node !!!!
            return node

    def _put_polygon(
        self,
        connect=None,
        polygon=None,
        flip=False,
        flop=False,
        scale=1.0,
    ):
        """Add a polygon to the cell.

        Args:
            connect (float, float, float): position (x, y, a) of polygon in cell.
            polygon (Polygon): polygon to put.
            flip (bool): flip the polygon if True (default = False).
            flop (bool): flop the polygon if True (default = False).
            polyline (Polyline): polyline to put.
            scale (float): scale factor. default = 1.0

        Returns:
            None
        """
        node = self._put_pin(None, connect)
        node.flip = flip
        node.flop = flop
        node.scale = scale
        if polygon is not None:
            self.polygons.append((node, polygon))

    def _put_polyline(self, connect=None, flip:bool=False, flop:bool=False, polyline=None, scale:float=1.0):
        """Add a polyline to the cell.

        Args:
            connect (float, float, float): position (x, y, a) of polygon in cell.
            flip (bool): flip the polyline if True (default = False).
            flop (bool): flop the polyline if True (default = False).
            polyline (Polyline): polyline to put.
            scale (float): scale factor. default = 1.0

        Returns:
            None"""
        node = self._put_pin(None, connect)
        node.flip = flip
        node.flop = flop
        node.scale = scale
        if polyline is not None:
            self.polylines.append((node, polyline))

    def _put_annotation(self, connect=None, annotation=None):
        """Add an annotation to the cell.

        Args:
            pinname (str): pinname to attach the annotation to.

        Returns:
            None
        """
        node = self._put_pin(None, connect)
        if annotation is not None:
            self.annotations.append((node, annotation))

    def _put_gds(
        self,
        connect=None,
        filename=None,
        cellname=None,
        newcellname=None,
        layermap=None,
        cellmap=None,
        scale:float=1.0,
        strm=None,
    ):
        """Add a GDS to the cell. Anchor it to a pin by the pinname (string).

        Example::

            cell_1.put_gds(filename='path_to_file.gds',
                cellname='name', newcellname='new')
        """
        node = self._put_pin(connect=connect)
        self.gdsfiles.append((node, (filename, cellname, newcellname, layermap, cellmap, scale, strm)))
        # print('put_gds node {}, pinname {} = '.format(node, pinname))

    def _copy_cell2instance(
        self,
        parent_cnode,
        flip,
        flop,
        array=None,
        scale=1.0,
        propattr=None,
        propvalue=None,
    ):
        """Copy all nodes from the Cell into its Instance.

        Args:
            parent_node (Node): main cell node of the cell to place the instance into.
            flip (bool): flip state of the instance.
            array (list): creates an array instance upon GDS output if not None.
                Format the array as [col#, [dx1, dy1], row#, [dx2, dy2]]
                dx1, dy1 is the column vector measured between adjacent elements.
                dx2, dy2 is the row vector measured between adjacent elements.
                (default=None)

        Returns:
            Instance: instance created from <parent_node>
        """
        instance = Instance(cell_name=self.cell_name)

        flipflop = flip != flop
        if array is not None:
            try:
                A = array
                array = [
                    A[0],
                    [A[1][0], A[1][1]],
                    A[2],
                    [A[3][0], A[3][1]],
                ]
                if not self.instantiate:
                    main_logger(
                        f"Trying to set a GDS array property on cell '{self.cell_name}' in "
                        f"parent cell '{parent_cnode.cell.cell_name}'. However, "
                        f"instantiate=False for cell '{self.cell_name}'. Therefore, only a "
                        f"single flattened instance will be visible. To fix this, set "
                        f"instantiate=True for cell '{self.cell_name}' to obtain the full "
                        f"array in GDS.",
                        "warning",
                    )
                    array = None
            except Exception as excp:
                logger.exception(
                    f"Error: incompatible array format {array} when placing "
                    f"cell '{self.cell_name}' in '{parent_cnode.cell.cell_name}'. "
                    f"Array will be ignored.\n{excp}",
                    "exception",
                )
                array = None

        # Create cnode of the instance (in this context it can be called inode):
        node = Node()
        # node.name = '{}_cnode_{}'.format(self.cell_name, Cell.I)
        node.name = f"{instance.id}_iorg"
        node.up = self.cnode
        node.instance = instance  # point to the instance object, only set for inodes.
        node.pointer = self.cnode.pointer.copy()
        node.cnode = node
        node.xs = self.cnode.xs
        node.width = self.cnode.width
        node.type = self.cnode.type
        node.cell = self
        node.flip = flipflop
        node.array = array
        node.scale = scale
        if cfg._linenumbers:
            # Preserve backwards compatibility when line numbers are activated
            node.propattr = propattr
            node.propvalue = propvalue
        else:
            # Otherwise, add Nazca instance IDs to Klayout instance user properties
            node.propattr = 1
            node.propvalue = "Instance id: " + str(instance.id)
        node.parent_cnode = parent_cnode
        # connect instance to node-tree:
        instance.cnode = node
        instance.cell = node.cell
        instance.pin["org"] = node
        instance.org = node
        instance.properties = self.properties
        instance.pcell_data = COPY.copy(self.pcell_data)  # TODO: make custom copy if pcell_data has structure.

        connect_cnode(parent_cnode, instance.cnode, None)
        # all other nodes:
        for key, pin in self.pin.items():
            if True:  # the name 'org' maybe outside the cnode. #key is not 'org':
                # TODO: do all properties have to be copied?
                #       maybe better to get them from the cell?
                node = Node()
                node.up = pin  # link to original node in cell
                node.xs = pin.xs
                node.io = pin.io
                node.width = pin.width
                node.radius = pin.radius
                node.type = pin.type
                node.show = pin.show
                node.remark = pin.remark
                node.name = f"{instance.id}_{key}"
                node.cnode = instance.cnode
                instance.pin[key] = node
                # reconstruct connectivity inside the instance scope:
                # 1. org-to-node connectivity
                #    no solving needed for xya, this will be done in put statement.
                x, y, a = pin.pointer.xya()
                if flipflop:
                    y, a = -y, -a
                connect_geo(instance.cnode, node, (x * scale, y * scale, a), solve=False)
                # 2. copy pointer properties (stored position xya is irrelevant)
                node.pointer = pin.pointer.copy()

        instance.pinin = instance.pin[self.default_in]
        instance.pinout = instance.pin[self.default_out]
        return instance

    def _should_connect_pins(
        self, npin: Node, opin: Node, x: float, y: float, a: float, rules: dict, len_options: int
    ) -> bool:
        """Determine if two pins should be connected based on configured rules.

        Args:
            npin (Node): New pin
            opin (Node): Existing pin to potentially connect to
            x, y, a (float): Connection parameters
            rules (dict): Rules configuration

        Returns:
            bool: True if pins should be connected
        """
        # Always check for occupied pins first if the filter is enabled
        if rules.get("filter_occupied", True):
            if self._is_pin_occupied(opin, npin):
                return False

        # Force all connections if enabled, early exit
        if rules.get("group_connect_all", False):
            return True

        # If there is only one connection available, connect it, early exit
        if rules.get("unique_connection", True) and len_options == 1:
            return True

        # Now apply remaining filters
        # Cross-section matching filter
        if rules.get("filter_xs", True):
            xs_opin = get_xsection(opin.xs)
            compatible_xs = xs_opin.drc_pin2pin
            if npin.xs not in compatible_xs:
                return False

        # Angle tolerance filter
        if rules.get("filter_angle", True):
            if not (abs(a - 180) < cfg.group_connect_acceptance_angle):
                return False

        # Only return True if all filters that we apply are passed.
        return True

    def _is_pin_occupied(self, opin: Node, npin: Node) -> bool:
        """Check if pin is already occupied with a matching connection.

        Args:
            opin (Node): Pin to check
            npin (Node): Pin that wants to connect

        Returns:
            bool: True if pin is occupied
        """
        xs_npin = get_xsection(npin.xs)
        compatible_xs = xs_npin.drc_pin2pin
        for data in opin.nb_geo:
            # check if pin isn't already connected and not allowed to split
            if data[0].xs in compatible_xs and data[0].cnode.instance is not None:
                return True
        return False

    def _apply_group_connections(
        self, connectionoptions: dict[Node, list[tuple[Node, tuple[float, float, float]]]], drc: bool = True
    ) -> None:
        """Apply group connection rules for proximity pins.

        Args:
            connectionoptions (defaultdict): Dictionary mapping pins to their connection options
            drc (bool): Whether to apply DRC checks

        Returns:
            None
        """
        rules = cfg.group_connect_rules

        for npin, options in connectionoptions.items():
            for opin, (x, y, a) in options:
                if self._should_connect_pins(npin, opin, x, y, a, rules, len(options)):
                    connect_geo(npin, opin, (x, y, a), solve=False, drc=drc)
                    if cfg.connections_logging:
                        cfg.connections_logfile_handle.write(
                            f"group-put  {npin.cnode.cell.cell_name}.{npin.name} "
                            f"onto  {opin.cnode.cell.cell_name}.{opin.name}\n"
                        )

    # TODO: add instantiate to put to flatten at put-time
    # TODO: Add description for param_mapping
    # TODO: handle "cp" explicitly?
    def put(
        self,
        *args,
        flip: bool = False,
        flop: bool = False,
        array=None,
        scale: float = 1.0,
        drc: bool | None = None,
        cp: str | None = None,
        param_mapping=None,  # TODO: describe
        propattr=None,
        propvalue=None,
        label: str | None = None,
        **kwargs,
    ) -> Instance:
        """Instantiate a Cell object and put it in the active cell.

        Args:
            *args (float | Node | Instance| str): a set of maximum 5 unnamed parameters
                interpreted as a connection between two pins, where
                put() connects to the current pin (cp).
                For more details see method 'parse_instance_connection'.
            flip (bool): mirror the instance in the vector line (default=False).
                The flip is performed after any translation and/or rotation
                and only applies to the instance that is put.
                Hint: for connecting waveguides you only need flip (not flop).
            flop (bool): mirror the instance in the line perpendicular to the vector
                (default=False).
                flop is performed after any translation and/or rotation.
                A flop is the same as 180 degree rotation + flip.
                Hint: for mask assembly or connecting bbox pins you may find both
                flip and flop useful.
            cp (str): Set current pin cp to a specific pin of the instance after putting
                (default='b0'). Example: put(..., cp='b1')
            array (list): creates an array instance upon GDS output if not None.
                Format the array as [cols, [dx1, dy1], rows, [dx2, dy2]], where
                dx1, dy1 is the column vector measured between adjacent elements.
                dx2, dy2 is the row vector measured between adjacent elements,
                and cols and rows the number of columns and rows.
                (default=None)
            scale (float): set scaling factor of the instance (default=1.0).
                In gds the scaling will be set as instance attribute. In case
                of flattening of the instance, the scaling factor will be applied
                to the instance content.
            drc (bool): Flag to switch off pin2pin DRC. default=None in which case
                it takes the global value of cfg.drc

        Returns:
            Instance: reference to the instance of the cell being put

        Examples:
            Below are different syntax examples for put.

            In the examples we use the following objects:
                * nd.example_cell: a pre-defined cell in Nazca
                * 'a0': default input pin name of "example"
                * 'b0': default output pin name of "example"


            1. connect the default pin of cell "example_cell()" to current pin (cp)::

                import nazca as nd
                nd.example_cell().put() # -> put('a0', cp)
                nd.export_plt()

            2. connect pin 'b0' of cell "example_cell()" to current pin (cp)::

                import nazca as nd
                nd.example_cell().put('b0') # -> put('b0', cp)
                nd.export_plt()

            3. connect default pin of cell "example_cell()" to its parent cell at org + (10, 20, 30)::

                import nazca as nd
                nd.example_cell().put(10, 20, 30) # -> put('a0', cp.move(10, 20, 30))
                nd.export_plt()

            4. connect default pin of cell "example_cell()" to instance C at pin 'b0'::

                import nazca as nd
                C = nd.example_cell().put(0)
                nd.example.put(C.pin['b0']) # -> put('a0', C.pin['b0'])
                nd.export_plt()

            5. connect pin 'b0' of cell "example_cell()" to instance C at pin 'b0'::

                import nazca as nd
                C = nd.example_cell().put(0)
                nd.example_cell().put('b0', C.pin['b0']) # -> put('b0', C.pin['b0'])
                nd.export_plt()

            6. connect pin 'b0' of cell "example_cell()" to instance C at its default out pin, i.e.
               referring to instance C only without pin attribute is interpreted as
               connecting to the default output pin of C::

                import nazca as nd
                C = nd.example_cell().put(0)
                nd.example.put('b0', C) # -> put('b0', C.pin['b0'])
                nd.export_plt()
        """
        if drc is None:
            drc = cfg.drc
        C = [None] * 5
        for i, arg in enumerate(args):
            C[i] = arg

        active_cell = cfg.active_cell()
        parent_cnode = active_cell.cnode
        nbs = len(parent_cnode.nb_cnode)
        if self.cnode is parent_cnode:
            main_logger(f"can not connect cell '{active_cell.cell_name}' to itself.", "error")

        if self.instantiate and cfg._linenumbers:
            codeinfo = ""
            limit = 5
            for frame in reversed(traceback.extract_stack(limit=limit + 1)):
                if nazca_dir not in frame.filename:
                    filename = os.path.basename(frame.filename)
                    codeinfo = f"file:{filename}/{frame.lineno}"
                    break
            if not codeinfo:
                main_logger(
                    f"No non-nazca line number found for cell '{active_cell.cell_name}'.",
                    "warning",
                )
                codeinfo = "file:-/-"
            propattr = 1
            propvalue = codeinfo

        instance = self._copy_cell2instance(parent_cnode, flip, flop, array, scale, propattr, propvalue)
        nodeI, nodeC, T = self.parse_instance_connection(*C, instance=instance)
        if flop:
            T = (T[0], T[1], T[2] + 180)
        # TODO; in case of groupconnect do not create this connection here, but as part of group connect?
        connect_geo(nodeC, nodeI, T, drc=drc)

        if cfg.connections_logging:
            cfg.connections_logfile_handle.write(
                f"dirct-put  {nodeI.cnode.cell.cell_name}.{nodeI.name} onto {nodeC.cnode.cell.cell_name}.{nodeC.name}\n"
            )

        # Update all the instance its pin pointers to reflect positions w.r.t. the parent cell.
        # 1. Solve position of cnodeI via 'mat' of solved node nodeI
        mat = nodeI.nb_geo[0][1]
        instance.cnode.pointer.set_mat(nodeI.pointer.trans(mat))
        # 2. Solve position of all instance nodes using cnodeI (pp[0])
        for pp in instance.cnode.nb_geo:
            pp[0].pointer.set_mat(instance.cnode.pointer.trans(pp[1]))

        # add the new instance bbox information to the parent:
        parent = parent_cnode.cell
        newi = parent_cnode.nb_cnode[nbs][0]  # new instance node
        # TODO: check here for auxiliary?
        self._calculate_instance_bbox(newi)
        ibboxloc = newi.instance.bbox

        # group connect
        if cfg.group_connect and not instance.cell.auxiliary:
            # create list of pins in the parent (self) that are available for connections:
            pnames = []
            for pname, pin in parent.pin.items():
                # parent pins:
                if pin.type in [0, 1]:
                    pnames.append(f"{pname} - {pin.type}")

            # filter pins in new instance available for connections:
            newipins = {}
            for pname, pin in newi.instance.pin.items():
                # TODO: pre-store eligible pins (types)
                # TODO: filter out "org"?
                if pin.type != "bbox":
                    newipins[pname] = pin

            # Note that adding DRC items to self may change parent.ibbox in the iteration
            # if not auxiliary cells, hence .copy().
            ibboxes = parent.ibbox.copy()
            ibboxbuf = 1.0  # scan a bit beyond the ibbox size if > 0.
            connectionoptions = defaultdict(list)  # {pin: list of pins it may connect to}
            for oldinode, oldibbox in ibboxes.items():
                # Loop over existing instances and skip all non-overlapping bboxes
                if oldinode.instance.cell.auxiliary:
                    continue
                if ibboxloc == [] or ibboxloc == [] or ibboxloc is None or oldibbox is None:
                    # print(f"SKIP: {parent_cnode.cell.cell_name:30}"
                    continue
                if ibboxloc[2] < oldibbox[0] - ibboxbuf:
                    continue
                if ibboxloc[0] > oldibbox[2] + ibboxbuf:
                    continue
                if ibboxloc[3] < oldibbox[1] - ibboxbuf:
                    continue
                if ibboxloc[1] > oldibbox[3] + ibboxbuf:
                    continue

                # instance pins:
                # create dict of existing instance pins available for connections
                # TODO: store this to not regenerate every time?
                opindict = {}
                for name, opin in oldinode.instance.pin.items():
                    if opin.type != "bbox":
                        opindict[name] = opin
                if len(pnames) >= 0:  # identify all possible connections based on colocation
                    for oname, opin in opindict.items():
                        if not (opin.xs is not None and opin.io >= 0):  # do not scan further for pins with xs = None
                            continue
                        for nname, npin in newipins.items():
                            if (
                                npin.xs is not None and npin.io >= 0
                            ):  # and npin.io >= 0:  # do not scan further for pins with xs = None
                                if npin is nodeI and opin is nodeC:
                                    # avoid double connection on already exlicitly put node at the start of this method.
                                    continue
                                if nname != "org" and oname != "org":  # TODO: perhaps check on chain connect?
                                    x, y, a = diff(npin, opin)
                                    d = hypot(x, y)
                                    if d <= cfg.autoconnectdistance:
                                        connectionoptions[npin].append((opin, (x, y, a)))

            # Apply connection rules for proximity pins other than the explicit put-connection
            self._apply_group_connections(connectionoptions, drc)

        parent.ibbox[newi] = ibboxloc

        # update cp:
        if cp is None:
            cfg.cp = instance.pin[self.default_out]
        else:
            cfg.cp = instance.pin[cp]

        if param_mapping is not None:
            instance.model_info["param_mapping"] = param_mapping

        if label is None:
            instance.label = instance.name
        else:
            instance.label = label
        cfg.label2instance_map[label] = instance

        return instance

    def put_stub(
        self,
        pinname=None,
        length=None,
        shape="box",
        pinshape=None,
        pinsize=None,
        pinlayer=None,
        pinshow=True,
        annotation_layer=None,
        pinstyle=None,
        cell=None,
    ):
        """Create corresponding cell method for nd.put_stub().

        Unlike other Cell methods this can be used on a closed cell,
        as stubs represent cell visualization elements only.

        Returns:
            None
        """
        bbu.put_stub(
            pinname=pinname,
            length=length,
            shape=shape,
            pinshape=pinshape,
            pinsize=pinsize,
            pinlayer=pinlayer,
            pinshow=pinshow,
            annotation_layer=annotation_layer,
            pinstyle=pinstyle,
            cell=self,
        )

    def hide_stubs(self, pinname=None):
        """Hide stubs in the list <pinname> from exports.

        Args:
            pinname (str | list str): pins for which to hide stubs.

        Returns:
            None
        """
        if not isinstance(pinname, list):
            pinname = [pinname]
        for name in pinname:
            self.pin[name].show = False

    def show_stubs(self, pinname=None):
        """Hide stubs that are not in the list <pinname> from exports.

        Args:
            pinname (str | list str): pins for which to hide stubs.

        Returns:
            None
        """
        pins = set([name for name, p in self.pin.items() if p.show])
        if not isinstance(pinname, list):
            pinname = [pinname]
        pins = pins - set(pinname)
        for name in pins:
            self.pin[name].show = False

    def __str__(self):
        """Print which structures are contained in the cell."""
        s = "cell info of '{}'".format(self.cell_name)
        s += "\n--pin     {:2}x              = {}".format(len(self.pin.keys()), self.pin.keys())
        s += "\n--polygon {:2}x (layer, N)   = ".format(len(self.polygons))

        L = []
        for g in self.polygons:
            L.append("({g[1]}, {N})".format(g=g, N=len(g[1].points)))
        s += ", ".join(L)
        s += "\n--gds     {:2}x (file, cell) = ".format(len(self.gdsfiles))

        L = []
        for pointer, g in self.gdsfiles:
            L.append("({g[1]}, {g[2]})".format(g=g))
        s += ", ".join(L)

        L = []
        # s += '\n--inst    {:2}x (x,y, cell)  = '.format(len(self.instances))
        # for i in self.instances:
        #    L.append('({}, {})'.format(i[0], i[1].cell_name))
        # s += ', '.join(L)
        return s + "\n"

    def _polyshape_iter(self, trans=Pointer(0), flip:bool=False, scale:float=1.0):
        """Generator to iterate over all polylines and polygons.

        Yields:
            Polygon | Polyline, list(float, float): poly object, transformed points
        """
        pgon_iter = Netlist().polygon_transflip_iter(
            self.cnode,
            trans,
            flip=flip,
            scale=scale,
            apply=True,
            hierarchy="apply",
            hull=True,
        )
        for pgon, xy, bbox in pgon_iter:
            if pgon.layer not in cfg.bbox_layers_ignore:
                yield pgon, xy

        pline_iter = Netlist().polyline_transflip_iter(
            self.cnode,
            trans,
            flip=flip,
            scale=scale,
            apply=True,
            hierarchy="apply",
            hull=True,
            polygon=True,
        )
        for pline, xy, bbox in pline_iter:
            if pline.layer not in cfg.bbox_layers_ignore:
                yield pline, xy

    def _calculate_instance_bbox(self, inode:Node)->list[float]:
        """Calculate bbox of the instance inode with respect to its parent.

        inode (Node): instance node of self

        Returns:
            (float, float, float, float): bbox (x1, y1, x2, y2) w.r.t. the parent's cnode
        """
        org = inode.pointer.copy()
        if inode.flip:
            s = -1
        else:
            s = 1
        x0, y0, a0 = org.xya()
        a = np.radians(a0)
        S = inode.scale

        # add hull_points
        bbhull = []
        basepoints = []
        hullarrs = []
        if self.hull_based_bbox:
            if self.hull is not None:
                basepoints = self.hull
        if len(basepoints) == 0:
            basepoints = self.bbox_polygon
            # this may validly be an empty bbox: []
            # if len(basepoints) == 0:
            #    print(f"Empty basepoints in {self.cell_name}'")

        for x, y in basepoints:
            bbhull.append(
                (
                    x0 + S * (cos(a) * x - s * sin(a) * y),
                    y0 + S * (sin(a) * x + s * cos(a) * y),
                )
            )

        # add points in case of array's
        if inode.array is not None:
            hullarrs = []
            Nx, (x1, y1), Ny, (x2, y2) = inode.array
            Dx1 = (Nx - 1) * x1
            Dy1 = (Nx - 1) * y1
            Dx2 = (Ny - 1) * x2
            Dy2 = (Ny - 1) * y2
            for x, y in bbhull:
                hullarrs.extend(
                    [
                        (x, y),
                        (Dx1 + x, Dy1 + y),
                        (Dx2 + x, Dy2 + y),
                        (Dx1 + Dx2 + x, Dy1 + Dy2 + y),
                    ]
                )
        else:
            hullarrs = bbhull

        if len(hullarrs) > 0:
            xy = list(zip(*hullarrs))
            inode.instance.bbox = (min(xy[0]), min(xy[1]), max(xy[0]), max(xy[1]))
        inode.instance.hullarrs = hullarrs
        return hullarrs

    def _calculate_bbox(self, instance:bool=True):
        """Calculate the bounding box, userbox and hull of a cell.

        Args:
            instance (bool): instantiation flag

        - The bounding box (bbox) is based on the cell content and rectangular.
        - The userbbox is a polygon and can have any number of points > 2.
        - The hull is the smallest convex polygon that encloses all points in the cell.

        The userbbox can by choice either be part of the bbox and hull calculation or
        stay separate and possible extend beyond the bbox.

        The bbox can be calculated based on the hull of its instances,
        if it exists, or based on the bbox of the instance.

        Returns:
            None
        """
        self.bbox_complete = True  # flag to indicate if all bbox info was availble
        limit = 1e8
        self.bbox = (limit, limit, -limit, -limit)

        elements = 0
        hullarrs = []
        if self.userbbox is not None and self.userbbox_include:
            elements += 1
            hullarrs.append(self.userbbox)

        # add polygon dimensions
        for polyobj, xy in self._polyshape_iter():
            elements += 1
            hullarrs.append(xy)

        # add instance its bbox dimensions to hullarrs:
        for inode in self.cnode.instance_iter(auxiliary=False):
            elements += 1
            ha = inode.instance.hullarrs
            if ha:
                hullarrs.append(ha)

        include_pins = True
        if not hullarrs and include_pins and not self.auxiliary:
            # Create a bounding box elements of an "empty" cell based on its pin.
            for name, pin in self.pin.items():
                pinposarr = []
                if name != "org":
                    pinposarr.append((pin.x, pin.y))
            if pinposarr:  # for non-native load_gds cell tha only have an 'org'.
                hullarrs.append(pinposarr)

        if not hullarrs:
            self.bbox = None
            self.bbox_polygon = np.array([])
            # logger.warning("Empty bounding box for cell '{}'".format(self.cell_name))
            return
        else:
            cat_hullarrs = np.concatenate(hullarrs)

        hull_created = False
        if self.use_hull:  # make a hull for this cell (self)
            try:  # ConvexHull may fail
                H = ConvexHull(cat_hullarrs)
                self.bbox = (
                    min(self.bbox[0], H.min_bound[0]),
                    min(self.bbox[1], H.min_bound[1]),
                    max(self.bbox[2], H.max_bound[0]),
                    max(self.bbox[3], H.max_bound[1]),
                )
                self.hull = np.take(H.points, H.vertices, axis=0)
                if self.show_hull:
                    Polygon(self.hull, layer=cfg.default_layers["hull"]).put(0)
                hull_created = True
            except Exception as excp:
                self.hull = None
                hull_created = False
                main_logger(
                    f"No hull resolved in cell '{self.cell_name}'. Using square bbox instead.\n{excp}",
                    "exception",
                )  # probably 1D polygons, like strt(length=0)
        if not hull_created:  # if no convex hull has been created, make a normal bbox
            xy = list(zip(*cat_hullarrs))
            self.bbox = (min(xy[0]), min(xy[1]), max(xy[0]), max(xy[1]))

        if elements == 0:
            self.bbox_complete = False
            self.bbox = None
            self.bbox_polygon = np.array([])
        else:
            self.bbox = (
                self.bbox[0] - self.bboxbuf,
                self.bbox[1] - self.bboxbuf,
                self.bbox[2] + self.bboxbuf,
                self.bbox[3] + self.bboxbuf,
            )
            # print("\n-- bbox: '{}': ({:.3f}, {:.3f}, {:.3f}, {:.3f})".\
            #    format(self.cell_name, *self.bbox ))
            self.bbox_polygon = np.array(
                [
                    [self.bbox[0], self.bbox[1]],
                    [self.bbox[0], self.bbox[3]],
                    [self.bbox[2], self.bbox[3]],
                    [self.bbox[2], self.bbox[1]],
                ]
            )

        area = None
        if self.bbox is not None:
            area = abs((self.bbox[2] - self.bbox[0]) * (self.bbox[3] - self.bbox[1]))

        self.add_property({"dimension": {"bbox": self.bbox, "bbox_area": area}})
        return

    def _add_bbox(self, draw_bbox:bool=True):
        """Add the bbox to the cell.

        Returns:
            None
        """
        self.add_bbox_flag = True
        self._calculate_bbox()

        if draw_bbox:
            if len(self.gdsfiles) > 0:
                if self.bbox is None:
                    main_logger(
                        f"Can not determine a bounding box for cell '{self.cell_name}',"
                        "  e.g. due to only non-native GDS subcell(s) and/or empty subcell(s)."
                        "  In case of gds loading causing this message:"
                        "  Try keyword native=True in  to get the complete bbox"
                        "  or set keyword bbox=False to get rid of this message.",
                        "warning",
                    )
                else:
                    logger.main(
                        f"Not all instances in cell '{self.cell_name}' have a known bbox,"
                        "  e.g. due to a non-native GDS subcell or an empty subcell."
                        "  Therefore, the bbox may be smaller than the actual structures."
                        "  Try option native=True in gds loading to get the complete bbox"
                        "  or set bbox=False to get rid of this message.",
                        "warning",
                    )
            if self.bbox is not None:
                length = self.bbox[2] - self.bbox[0]
                width = self.bbox[3] - self.bbox[1]
                bbu.put_boundingbox(
                    pinname="org",
                    length=length,
                    width=width,
                    move=(self.bbox[0], self.bbox[1] + 0.5 * width, 0),
                    params=True,
                    name_layer=self.name_layer,
                )
                self.length = length
                self.width = width

    def _store_pins(self):
        """Store pin information in a gds annotation.

        Returns:
            None
        """
        pintxt = "pins:\n"
        for name, node in sorted(self.pin.items()):
            if node.xs is None:
                xs = "None"
            else:
                xs = None
            if node.width is None:
                w = "None"
            else:
                w = "{:.3f}".format(float(node.width))
            pintxt += "{0}: {c[0]:.5f}, {c[1]:.5f}, {c[2]:.5f}, {xs}, {w}\n".format(name, xs=xs, w=w, c=node.xya())
        Annotation(text=pintxt, layer="pin_text").put(0)

    def pins2csv(
        self,
        pins: list[str] | None = None,
        filename: Path | str | None = None,
        has_xs: bool = False,
        has_width: bool = False,
        digits: int = 5,
    ) -> None:
        """Store pin information in a csv file for pin names contained in list <pins>.

        Some extra filter functionality is added to the pins2csv method to only store pins that have a xs and/or width.
        Default export with no parameters is to export all pins in the cell to a filename <cell_name> + '_pins.csv'.

        Args:
            pins (list): list of pin names to store in the csv file. Explicitly mentioned pins are always
                regardless has_xs and has_width settings.
            filename (str): filename to store the csv file. If None, the cell name is used.
            has_xs (bool): only store pins that have a xs (plus any pins explicitly mentioned under pins).
            has_width (bool): only store pins that have a width (plus any pins explicitly mentioned under pins).
            digits (int): number of digits to store for x, y, a, and width. default=5.

        Returns:
            None
        """
        if filename is None:
            filename = self.cell_name + "_pins.csv"

        select_pins = pins
        if pins is None:
            pins = []  # make iterable for later checks
            select_pins = self.pin.keys()
        if has_xs or has_width:
            select_pins = self.pin.keys()

        pintxt = "name,xs,width,x,y,a\n"
        for name in sorted(select_pins):
            node = self.pin[name]
            if node.xs is None:
                if has_xs and name not in pins:
                    continue
                xs = "None"
            else:
                xs = node.xs[0]
            _w = node.width
            if _w is None:
                w = "None"
                _w = 0
            else:
                w = f"{float(node.width):.{digits}f}"
            if has_width and _w == 0 and name not in pins:
                continue
            x, y, a = node.xya()
            pintxt += f"{name},{xs},{w},{x:.{digits}f},{y:.{digits}f},{a:.{digits}f}\n"
        with open(filename, "w") as f:
            f.write(pintxt)
        msg = f"Pin information of cell '{self.cell_name}' stored in '{filename}'"
        print(msg)
        logger.info(msg)

    def close(self):
        """Close the cell.

        This function will be called as closure of the "with nd.Cell() context."
        Set the cp back to the position before opening the cell.
        If default input and/or output pins have not been set yet they will be
        set on 'org', pointing in opposite directions. Depending on the Cell
        attributes it will add a bounding box, hulls, and PDK
        related annotations with cell info.

        Returns:
            Cell: self
        """
        if self.closed:
            main_logger(f"Cell '{self.cell_name}' already closed.", "warning")

        # add default ports if missing:
        if self.default_in not in self.pin:
            self._put_pin(self.default_in, (0, 0, 180))
            if self.default_in != "a0":
                main_logger(
                    f"Requested default pin '{self.default_in}' not available in "
                    f"'{self.cell_name}', setting it to 'a0'.",
                    "warning",
                )
        if self.default_out not in self.pin:
            self._put_pin(self.default_out, (0))
            # print("Warning: no default pin '{}' set in '{}', setting it to {}.".\
            #    format(self.default_out, self.cell_name, (0, 0, 0)))
            # self.put_pin(self.default_out, cfg.cp)

        self.pinin = self.pin[self.default_in]
        self.pinout = self.pin[self.default_out]

        if not self.add_bbox_flag:
            if self.autobbox:
                self._add_bbox(draw_bbox=True)
            else:
                self._add_bbox(draw_bbox=False)
            if self.params:
                bbu.put_parameters(parameters=self.parameters)

        if self.userbbox:
            Polygon(points=self.userbbox, layer="userbbox").put(0)
        elif self.protectbox:
            Polygon(points=self.bbox_polygon, layer="userbbox").put(0)

        if self.store_pins:
            self._store_pins()

        # Add version annotation to cell.
        if cfg.store_bbname and self.version is not None:
            # TODO: enforce verion as a dict before the copy?
            version = self.version.copy()
            if self.instantiate:
                if isinstance(self.version, dict):
                    if version.get("cellname", None) == "auto":
                        version["cellname"] = self.cell_basename
                    if cfg.force_pdk_version is not None:
                        version = cfg.force_pdk_version
                    bbtxt = yaml.dump(version)
                    Annotation(text=bbtxt, layer=get_layer("bb_name")).put(0)
                else:
                    main_logger(
                        f"In cell '{self.cell_name}' version is not of type dict: {self.version}",
                        "error",
                    )
                self.version = version
            else:
                raise RuntimeError(f"Cell must be instantiated to add a name and version to it, Cell: '{self.cell_name}'")

        # copy parameters from updk to pcell_data
        updkparams = self.updk.get("parameters", {})
        for param, value in updkparams.items():
            if param not in self.pcell_data.keys():
                self.pcell_data[param] = value['value']
            else:
                msg = f"Parameter '{param}': {value['value']} from updk already exists in pcell_data: '{param}': {self.pcell_data[param]}"
                compact_model_logger(msg, 'warning')

        # copy parameters from properties to pcell_data
        if self.properties["parameters"] is not None:
            for param, value in self.properties["parameters"].items():
                if param not in self.pcell_data.keys():
                    self.pcell_data[param] = value
                elif param not in updkparams.keys():
                    msg = f"Parameter '{param}': {value} from properties already exists in pcell_data: " \
                          f"'{param}': {self.pcell_data[param]}"
                    compact_model_logger(msg, 'warning')

        # generate cm_id based on cell version
        if self.cm_id is None:
            self.cm_id = (self.cell_basename, cfg.active_tech)

        # obtain models from registered model libraries
        if not self.auxiliary:
            cm._fetch_compact_models(cell=self)

        # call back to user defined function to validate the cell name.
        cfg.gds_cell_validate(self)
        self.closed = True

        cfg.cp = self.oldcp
        cfg.cells.pop()
        if cfg.cells:
            cfg.self = cfg.active_cell()
        return self


def diff0(node1: Node, node2: Node) -> tuple[float, float, float]:
    """Calculate the geometrical difference between two nodes.

    Legacy version with (slower) internal ptr calls and copy's.

    Args:
        node1 (Node): start node
        node2 (Node): end node

    Example:
        Obtain dx, dy, da from p1 to p2::

            import nazca as nd

            p1 = nd.Pin().put(10, 10, 0)
            p2 = nd.Pin().put(20, 30, 45)
            dx, dy, da = nd.diff(p1, p2)
            print(dx, dy, da)
            # (10.0, 20.0, 45.0)

    Returns:
        tuple: differential vector <node2> - <node1> in the form (dx, dy, da)
    """
    ptr1 = node1.pointer.copy()
    ptr2 = node2.pointer.copy()
    ptr2.multiply_ptr(ptr1.inv())
    # print('nd.diff:', ptr2.get_xya())
    dx, dy, da = ptr2.get_xya()
    if da == 360:
        da = 0
    return dx, dy, da


def diff(node1: Node, node2: Node) -> tuple[float, float, float]:
    """Calculate the geometrical difference between two nodes.

    Args:
        node1 (Node): start node
        node2 (Node): end node

    Example:
        Obtain dx, dy, da from p1 to p2::

            import nazca as nd

            p1 = nd.Pin().put(10, 10, 0)
            p2 = nd.Pin().put(20, 30, 45)
            dx, dy, da = nd.diff(p1, p2)
            print(dx, dy, da)
            # (10.0, 20.0, 45.0)

    Returns:
        (dx, dy, da): difference vector <node2> - <node1> between their pointers
    """
    mat1 = node1.pointer.mat
    mat2 = node2.pointer.mat
    c1, s1 = mat1[0, 0], mat1[0, 1]
    x1, y1 = mat1[2, 0], mat1[2, 1]
    c2, s2 = mat2[0, 0], mat2[0, 1]
    x2, y2 = mat2[2, 0], mat2[2, 1]
    x3 = x2 * c1 + y2 * s1 - x1 * c1 - y1 * s1
    y3 = -x2 * s1 + y2 * c1 + x1 * s1 - y1 * c1
    C = c1 * c2 + s1 * s2
    S = -s1 * c2 + s2 * c1
    a3 = degrees(atan2(S, C)) % 360.0
    return x3, y3, a3


def midpoint(node1: Node, node2: Node) -> tuple[float, float, float]:
    """Calculate the geometrical center between two nodes.

    See also function midpointer.

    Args:
        node1 (Node): start node
        node2 (Node): end node

    Returns:
        (x, y, a): mid-point between pointers of <node1> and <node2>

    Example::

        import nazca as nd

        p1 = nd.Pin().put(10, 20, 0)
        p2 = nd.Pin().put(20, 40, 90)

        x, y, a = nd.midpoint(p1, p2)
        print(x, y, a)
        # 15.0, 30.0, 45.0
    """
    x1, y1, a1 = node1.xya()
    x2, y2, a2 = node2.xya()
    da = a2 - a1
    if da > 180:
        da -= 360
    a = round(a1 + da / 2, 12)  # avoid small negative values
    if a < 0:
        a += 360
    return x1 + (x2 - x1) / 2, y1 + (y2 - y1) / 2, a


def midpointer(node1:Node, node2:Node)->Pointer:
    """Calculate the geometrical center between two nodes.

    See also midpoint.

    Args:
        node1 (Node): start node
        node2 (Node): end node

    Returns:
        Pointer: pointer in mid-point between pointers of <node1> and <node2>

    Example::

        import nazca as nd

        p1 = nd.Pin().put(10, 20, 0)
        p2 = nd.Pin().put(20, 40, 90)

        p3 = nd.midpointer(p1, p2)
        print(p3.xya())
        # (15.0, 30.0, 45.0)
    """
    x1, y1, a1 = node1.xya()
    x2, y2, a2 = node2.xya()
    da = a2 - a1
    if da > 180:
        da -= 360
    a = round(a1 + da / 2, 12)  # avoid small negative values
    if a < 0:
        a += 360
    return Pointer(x1 + (x2 - x1) / 2, y1 + (y2 - y1) / 2, a)


def bbinfo(item=None, data=None):
    """Attach metadata to the Active cell in dictionary bbinfo.'

    Args:
        item (hashable object): dictionary key
        data: The value of the metadata

    Returns:
        None
    """
    cfg.active_cell().bbinfo[item] = data


def get_transformation(start=None, end=None):
    """Return the transformation matrix that connects two pointers.

    Returns:
        float[:]: translation matrix
    """
    translate = dot(inverse(start.pointer.mat), end.pointer.rotate(180).mat)
    return translate


# ==============================================================================
# Class structures to represent mask structures that can be put.
# ==============================================================================
class Pin:
    """Pin class"""

    def __init__(
        self,
        name: str | None = None,
        xs: str = None,
        layer=None,
        width: float = None,
        radius: float = None,
        type: str = None,
        pin: Node | None = None,
        io: int = None,
        flip: bool = False,
        show=None,
        remark=None,
        chain: int = None,
    ):
        """Construct a Pin object.

        A Pin object (capital P to denote the class object) holds information
        to describe a Node object. Nodes are the objects that are connected in
        a graph to connect layout elements. The Node object is created inside
        the active cell via the put() method of the Pin.
        When a Node is created in the active cell it is stored in
        the pin attribute of the active cell (not to be confused with the Pin
        object). The pin attribute is a dictionary
        with the string name of the Pin object as key and the Node object as
        the value {pinname: Node}.

        Note that Pin represenation in a layout is defined by the pinstyle
        of the xsection of the pin. The pinstyle maps the xs to the
        visualisation layers.

        Args:
            name (str): name of the Pin to refer to it.
            xs (str): xsection name assigned to the pin.
            layer (str or number): optional layer to represent the pin.
                This will add an xs pinstyle. If no xs is provided it will use
                the default xs. Note that layer is not a pin property.
            width (float): width in um of the connection the pin represents
            radius (float): radius of curvature at the pin in um.
            type (str): extra property for the pin
            pin (Node):
            chain (int):indicate if pin is a chain or connector (1) or not (0)
                (default=1)
            remark (str): short optional documentation of the Pin (default=None)
            io (int): connectivity info in integer form
            flip (bool): symmetry state of the pin. This flip is *only* relevant
                for stub representation and DRC checks of assymmetric interconnects,
                default=False.

        Returns:
            None

        Example:
            Create a Pin object and put it in the active cell to create a Node.
            Subsequently, retrieve the Node by name 'a0' via cell pin attribute
            and print properties as set in the Pin object::

            import nazca as nd

            nd.Cell(name='test') as C:
                nd.Pin(name='a0', width=2.0).put()

            p = C.pin['a0']
            print(p.name)
            print(p.width)
            # 'a0'
            # 2.0
        """
        # TODO: Check if Pin attirbutes can be stored directly as a Node.
        # set defaults, see Node for attributes:
        self.xs = None
        self.width = None
        self.radius = None
        self.name = "noname"
        self.type = None
        self.chain = 1
        self.show = False
        self.remark = remark
        self.io = 0
        self.pin = pin  # pin to use as source for attributes

        # copy pin properties if a pin is provided:
        if pin is not None:
            if pin.cnode.instance is False:
                # check if not by mistake referencing to a cell
                if pin.cnode is not cfg.active_cell().cnode:
                    # allow a copy from pin in same call
                    interconnect_logger(
                        msg=f"Connecting to cell pin {cfg.active_cell().cell_name}.pin['{pin.name}'] "
                        "rather than an instance of this cell.",
                        level="warning",
                    )
            self.name = pin.name
            self.xs = pin.xs
            self.width = pin.width
            self.radius = pin.radius
            self.io = pin.io
            self.type = pin.type
            self.chain = pin.chain
            self.remark = pin.remark

        if name is not None:
            self.name = name

        # override pin properties if set explicitly:
        if xs is not None:
            # TODO: Make it possible to overrule the pin with a None value (for DRC)?
            XS = get_xsection(xs)
            self.xs = XS.ID
            if pin is None:
                # take default width setting from xsection
                if XS is not None:
                    self.width = XS.width
                    if layer is not None:  # add a new layer (only for new pinstyles)
                        layer = get_layer(layer)
                        presentstyle = cfg.pinstyles.get(self.xs, None)
                        if presentstyle is None:
                            style_id = bbu.parse_pinstyle(None)
                            newstyle = cfg.pinstyles[style_id].copy()
                            newstyle["layer"] = layer
                            bbu.add_pinstyle(self.xs, newstyle)
                            XS.pinstyle = self.xs
                        else:
                            main_logger(
                                f"In setting pin '{cfg.active_cell().cell_name}'.'{self.name}',"
                                f" can not add layer {layer} to existing pinstyle '{xs}'"
                                f" having already layer {presentstyle['layer']}."
                                f" Alternatively, set an explicit with bb_util.add_pinstyle() for xs '{xs}'.",
                                "error",
                            )
        if width is not None:
            self.width = width
        if type is not None:
            self.type = type
        if radius is not None:
            self.radius = radius
        if chain is not None:
            self.chain = chain
        if show is not None:
            self.show = show
        if remark is not None:
            self.remark = remark
        if flip:
            self.io = 1  # store flip in io.
        if io is not None:  # TODO: io = 0 and 1 settings need better sync with pin-flip
            self.io = io

    def __repr__(self):
        return "<Pin() object, name='{}', xs='{}', width={}, type={}, chain={}, show={}, io={}, remark={}>".format(
            self.name,
            self.xs,
            self.width,
            self.type,
            self.chain,
            self.show,
            self.io,
            self.remark,
        )

    def put(self, *args, **kwargs):
        """Put a Pin object in the layout."""
        if self.pin is not None:
            cfg.cp = self.pin
        drc = kwargs.pop("drc", None)
        return cfg.active_cell()._put_pin(
            self.name,
            connect=args,
            xs=self.xs,
            width=self.width,
            type=self.type,
            radius=self.radius,
            io=self.io,
            chain=self.chain,
            show=self.show,
            remark=self.remark,
            drc=drc,
        )


class Polygon:
    """Polygon class."""

    def __init__(self, points: list[tuple[float, float]] | None = None, layer=None):
        """Construct a Polygon object.

        Args:
            points (list): list of points [(x1, y1), (x2, y2), ...]
            layer (int | (int, int) | str): layer number, (layer, datatype) tuple or layer name to put the Polygon in.

        Returns:
            None
        """
        self.layer = get_layer(layer)
        if points is None:
            self.points = []
        else:
            self.points = points
        hull = False  # flag
        if cfg.use_hull:
            try:
                hull = True
                H = ConvexHull(points)
                self.hull = np.take(H.points, H.vertices, axis=0)
                self.bbox = [
                    H.min_bound[0],
                    H.min_bound[1],
                    H.max_bound[0],
                    H.max_bound[1],
                ]
            except Exception as excp:
                # less than 2D polygon, e.g. a zero length straight
                main_logger(f"CovexHull Error Polygon: {excp}\n{points}.", "error")
                hull = False
        if not hull:
            xy = list(zip(*points))
            self.bbox = (min(xy[0]), min(xy[1]), max(xy[0]), max(xy[1]))

    def __repr__(self):
        size = len(self.points)
        return "<Polygon() object, layer={}, points={}, bbox={}>".format(self.layer, size, self.bbox)

    def to_dict(self)->dict:
        """Serialize polygon object."""
        info = {}
        info["layer"] = self.layer.ID
        if type(self.points) == np.ndarray:
            points = self.points.tolist()
        else:
            points = self.points
        info["points"] = points

        return info

    def transform(
        self,
        center: tuple[float, float, float] = (0, 0, 0),
        scale: float = 1.0,
        flipx: bool = False,
        flipy: bool = False,
        move: tuple[float, float, float] = (0, 0, 0),
        layer=None,
    ):
        """Transform the points in the Polygon object.

        See nazca.geometries.transform().

        Returns:
            Polygon: new Polygon with transformed points.
        """
        if layer is None:
            layer = self.layer
        points = transform(
            points=self.points,
            center=center,
            scale=scale,
            flipx=flipx,
            flipy=flipy,
            move=move,
        )
        newPolygon = Polygon(points=points, layer=layer)
        return newPolygon

    def grow(self, grow:float=5, accuracy:float=0.1, jointype:str="square", layer=None)->Polygon:
        """Grow the polygon.

        Args:
           grow (float): size of growth in um.
           accuracy (float): accuracy [µm] of the location of the intermediate points.
               The accuracy determines the grid on which the grown path is drawn.
           jointype: specifies the type of growing that is used.
               The jointype is one of 'round' (default), 'square' or 'miter'.
           layer (layer): mask layer to send grow output to (default is the source layer)

        Returns:
            Polygon: new Polygon with growth applied.
        """
        if layer is None:
            layer = self.layer
        points = grow_polygons(paths=[self.points], grow=grow, accuracy=accuracy, jointype=jointype)
        newPolygon = Polygon(points=points[0], layer=layer)
        return newPolygon

    def put(self, *args, flip:bool=False, flop:bool=False, scale:float=1.0):
        """Put a Polygon object in the layout.

        Args:
            flip (bool): flip state of the polygon put
            flop (bool): flop state of the polygon put
            scale (float): scaling factor of the Polygon. This scaling looks
                as if the whole cell the polygon would have scaled.
                Note that it may be more appropiate to use
                the 'transform' method to scale a Polygon.

        Returns:

        """
        return cfg.active_cell()._put_polygon(connect=args, flip=flip, flop=flop, scale=scale, polygon=self)


class Polyline:
    """Polyline (path) class."""

    def __init__(
        self, points=None, layer=None, width: float | None = None, pathtype: int = 0, miter: float = 0.5
    ):
        """Construct a Polyline object.

        Args:
            pinname (str): name of the pin (obsolete)
            layer (int | (int, int) | str): layer number, (layer, datatype) tuple or layer name to put the Polygon in.
            width (float): width of the polyline
            pathtype (int): gds type of path: 0 (flush), 1 (round), 2, 3
            points (list): list of points [(x1, y1), (x2, y2), ...]
            miter (float): length at joint of two straight sections (default=0.5)

        Returns:
            None
        """
        self.layer = get_layer(layer)
        if points is None:
            self.points = []
        else:
            self.points = points
        if width is not None:
            self.width = float(width)
        else:
            self.width = 0.20
        self.pathtype = pathtype
        self.points = points
        self.miter = miter
        self.polygon = util.polyline2polygon(
            self.points,
            width=self.width,
            miter=self.miter,
        )
        hull = False
        if cfg.use_hull:
            try:
                hull = True
                H = ConvexHull(self.polygon)
                self.hull = np.take(H.points, H.vertices, axis=0)
                self.bbox = [
                    H.min_bound[0],
                    H.min_bound[1],
                    H.max_bound[0],
                    H.max_bound[1],
                ]
            except Exception as excp:
                # less than 2D polyline, e.g. a zero length straight
                main_logger(f"CovexHull Error Polygon: {excp}\n{points}.", "error")
                hull = False
        if not hull:
            xy = list(zip(*self.polygon))
            self.bbox = (min(xy[0]), min(xy[1]), max(xy[0]), max(xy[1]))

    def __repr__(self):
        size = len(self.points)
        return "<Polyline() object, layer={}, width={}, pathtype={}, " "points={}, bbox={}>".format(
            self.layer, self.width, self.pathtype, size, self.bbox
        )

    def to_dict(self):
        """Serialize polyline object."""
        info = {}
        info["layer"] = self.layer.ID
        info["points"] = self.points
        info["width"] = self.width
        info["pathtype"] = self.pathtype
        info["miter"] = self.miter

        return info

    def transform(
        self,
        center: tuple[float, float, float] = (0, 0, 0),
        scale: float = 1.0,
        flipx: bool = False,
        flipy: bool = False,
        move: tuple[float, float, float] = (0, 0, 0),
        width: float | None = None,
        pathtype: int | None = None,
        layer=None,
    ):
        """Transform the points in the Polyline object.

        See nazca.geometries.transform() for usage

        Returns:
            Polyline: new Polyline with transformed points.
        """
        if layer is None:
            layer = self.layer
        if width is None:
            width = self.width
        if pathtype is None:
            pathtype = self.pathtype
        points = transform(
            points=self.points,
            center=center,
            scale=scale,
            flipx=flipx,
            flipy=flipy,
            move=move,
        )
        newPolyline = Polyline(points=points, width=width, pathtype=pathtype, layer=layer)
        return newPolyline

    def grow(self, grow:float=5, accuracy:float=0.1, jointype:str="square", width=None, layer=None):
        """Grow the polyline.

        Args:
           grow (float): size of growth in um.
           accuracy (float): accuracy [µm] of the location of the intermediate points.
               The accuracy determines the grid on which the grown path is drawn.
           jointype: specifies the type of growing that is used.
               The jointype is one of 'round' (default), 'square' or 'miter'.
           layer (layer): mask layer to send grow output to (default is the source layer)


        Returns:
            Polyline: new Polyline with growth applied.
        """
        if layer is None:
            layer = self.layer
        points = grow_polygons(paths=[self.points], grow=grow, accuracy=accuracy, jointype=jointype)
        newPolyline = Polyline(points=points[0], layer=layer)
        return newPolyline

    def put(self, *args, flip:bool=False, flop:bool=False, scale:float=1.0):
        """Put a Polyline object in the layout.

        Args:
            flip (bool): flip state of the polygon put
            flop (bool): flop state of the polygon put
        scale (float): scaling factor of the Polygon. This scaling looks
                as if the whole cell the polygon would have scaled.
                Note that it may be more appropiate to use
                the 'transform' method to scale a Polygon.

        Returns:

        """
        return cfg.active_cell()._put_polyline(connect=args, flip=flip, flop=flop, scale=scale, polyline=self)


class Annotation:
    """Annotation class."""

    def __init__(self, layer=None, text:str=""):
        """Construct an annotation object.

        Args:
            layer (int | (int, int) | str): layer number, (layer, datatype) tuple or layer name to put the Polygon in.
            text (str): annotation text (default = '')

        Returns:
            None
        """
        self.layer = get_layer(layer)
        self.text = text

    def __repr__(self):
        if len(self.text) >= 10:
            text = self.text[:7] + "..."
        else:
            text = self.text
        return "<Annotation() object, layer={}, text='{}'>".format(self.layer, text)

    def to_dict(self)->dict:
        """Serialize annotation object."""
        info = {}
        info["layer"] = self.layer.ID
        info["text"] = self.text

        return info

    def put(self, *args):
        """Put an Annotation object in the layout."""
        return cfg.active_cell()._put_annotation(connect=args, annotation=self)


def _scan_branch(strm, cellname, celllist=None, level:int=0):
    """Generator for cell names in a branch. Bottom-up, deep first.

    Args:

    Yields:

    """

    cell_rec = strm.cells[cellname]
    snames = cell_rec.snames
    # print("cell:{}, snames:{}".format(cellname, snames))
    if snames is not None:
        level += 1
        for sname in snames:
            yield from _scan_branch(strm, sname, level=level)
        level -= 1
    yield (cellname)


def _string_to_pins(string:str)->OrderedDict:
    """Convert a pin annotation string to a pin dictionary.

    Expected format of <string>:

    "pins:
    <name>: <x, y, a xs, w>
    <name>: <x, y, a xs, w>
    ..."

    Header 'pins:' is case incensitive and spaces will be stripped.

    Returns:
        ordered dict: {<parameter_name>: <parameter_value>}
    """
    pins = None
    lines = string.split("\n")
    pins = OrderedDict()
    if lines[0].lower() == "pins:":
        for line in lines[1:]:
            if line == "":
                continue
            name, prop = line.split(":", 1)
            x, y, a, xs, w = prop.replace(" ", "").split(",")
            x = float(x)
            y = float(y)
            a = float(a)
            if w.lower() != "none":
                w = float(w)
            pins[name.strip()] = (x, y, a, xs, w)
    return pins


def _gds2native(
    strm,
    topcellname=None,
    cellmap=None,
    bbox=False,
    bboxbuf=0,
    hull=None,
    show_hull=False,
    hull_based_bbox=None,
    scale=None,
    flat=False,
    instantiate=True,
    asdict=False,
    topcellsonly=True,
    select="",
    reuse=False,
    cellsnotreused=None,
    cellsreused=None,
):
    """Translate a GDS stream into a native Nazca cell structure.

    If no cellname is provided it will select the topcell, if there is one topcell only.

    Args:
        strm (bytestr): gds layout
        topcellname (str): name of topcell to process
        cellmap (dict): cellname (and under) to process
        bbox (bool): Add bounding box if True (default=False)
        bboxbuf (float): extra buffer space added to the bbox (default=0)
        scale (float): scaling of the cells (default=1.0)
        flat (bool): set instantiation off all subcells (default=False)
        instantiate (bool): instantiation setting of the topcell (default=True)
        reuse (bool): default is False. If True, load gds assumes cells with the
            same name are the same cell and it resolves conficts by using
            only the first cell occurrence. Setting reuse=True is dangerous.
        cellsnotreused (list of str): list of cellnames to ignore for
            reuse if reuse=True
        cellsreused (list of str): list of cellnames to reuse. If set all other cells will
            not be reused and reuse and cellsnotreused will be ignored.

    Returns:
        list of str: list of cellnames in <filename> under cell name <cellname>
    """
    annotated_cells = []
    um0 = 1e-6 / gb.gds_db_unit
    um = um0 / scale  # scale factor between gds integers and micro-meters.
    gds_elements_unknown = set()

    NC = {}
    rename_map = {}

    if cellsnotreused is None:
        cellsnotreused = []
    if cellsreused is None:
        cellsreused = []
    if cellsreused:
        reuse = True
    if reuse:
        if cellsreused:
            cells_forreuse = set(cellsreused) - set(
                cellsnotreused
            )  # only reuse explicit cells from the list for reuse and cells in this load call
        else:
            cells_forreuse = set(cfg.cellnames.keys()) - set(cellsnotreused)  # reuse all cells in memory
    else:
        cells_forreuse = []

    cells_visited = set()

    if asdict:
        topcells = strm.topcell()
    else:
        topcells = [topcellname]

    for topcellname in topcells:
        branch_iter = _scan_branch(strm, topcellname)
        C = None  # stays None if only resued cells are encountered.
        for cellname in branch_iter:  # bottom up
            if cellname in cells_visited:
                continue
            if reuse:
                if cellname in set(cfg.cellnames):
                    if cellname in cells_forreuse:  # cells visited during program execution
                        main_logger(
                            f"reusing cell '{cellname}' when loading file '{cfg.gdsload}'",
                            "info",
                        )
                        continue

            cells_visited.add(cellname)
            cellrecord = strm.cells[cellname]

            if cellname == topcellname:
                _instantiate = instantiate
            else:
                if flat:
                    _instantiate = False
                else:
                    _instantiate = True
            # print(cellname)
            with Cell(
                cellname,
                instantiate=_instantiate,
                hull=hull,
                show_hull=show_hull,
                hull_based_bbox=hull_based_bbox,
            ) as C:
                C.default_pins("org", "org")
                for elem in cellrecord.elements:

                    if elem.etype == gb.GDS_record.BOUNDARY:
                        LD, XY = elem.polygon
                        XY = [(x / um, y / um) for x, y, in zip(*[iter(XY)] * 2)]
                        Polygon(points=XY, layer=LD).put(0)

                    elif elem.etype == gb.GDS_record.PATH:
                        LD, XY, pathtype, width = elem.polyline
                        if width is not None:
                            width = width / um
                        if pathtype is None:
                            # TODO: add debug?
                            pathtype = 0
                        XY = [(x / um, y / um) for x, y, in zip(*[iter(XY)] * 2)]
                        Polyline(points=XY, layer=LD, pathtype=pathtype, width=width).put(0)

                    elif elem.etype == gb.GDS_record.TEXT:
                        LD, XY, TEXT = elem.annotation
                        XY = (XY[0] / um, XY[1] / um)
                        Annotation(layer=LD, text=TEXT).put(XY)
                        # TODO: also check for the layer
                        if TEXT[:4].lower() == "pins":
                            pins = _string_to_pins(TEXT)
                            for name, (x, y, a, xs, w) in pins.items():
                                if name == "org":
                                    continue
                                if isinstance(xs, str):
                                    if xs.lower() == "none":
                                        xs = None
                                if isinstance(w, str):
                                    if w.lower() == "none":
                                        w = None
                                if cellname == topcellname:
                                    x, y = x * scale, y * scale
                                Pin(name=name, xs=xs, width=w).put(x, y, a)
                                # print(name, x, y, a, xs, w)
                        if LD == cfg.default_layers[cfg.bb_version_layer]:
                            Annotation(layer=LD, text=TEXT).put(XY)
                            annotated_cells.append(C)
                            try:
                                bbname, bbversion = TEXT.split("\n")
                                C.annotated_name = bbname  # store cell name
                                C.annotated_version = bbversion  # store version
                                # print('BB ID found:\n{}'.format(TEXT))
                            except ValueError as e:
                                if not isinstance(e, ValueError):
                                    logger.exception("e")
                                # print("ERROR: (netist): No valid black box"\
                                #    " annotation in layer {}: {}".format(LD, e))

                    elif elem.etype == gb.GDS_record.BOX:
                        gds_elements_unknown.add("BOX")

                    elif elem.etype == gb.GDS_record.SREF:
                        name, trans, mag, angle, XY, propattr, propvalue = elem.instance
                        if trans == 1:
                            flip = True
                        else:
                            flip = False
                        name = rename_map.get(name, name)
                        cell = NC.get(name, cfg.cellnames[name])
                        cell.put(
                            "org",
                            XY[0] / um,
                            XY[1] / um,
                            angle,
                            flip=flip,
                            scale=mag,
                            propattr=propattr,
                            propvalue=propvalue,
                        )

                    elif elem.etype == gb.GDS_record.AREF:
                        name, trans, mag, angle, col, row, XY = elem.array
                        if trans == 1:
                            flip = True
                        else:
                            flip = False
                        x, y = XY[0] / um, XY[1] / um
                        x1, y1 = XY[2] / um, XY[3] / um
                        x2, y2 = XY[4] / um, XY[5] / um
                        dx1, dy1 = (x1 - x) / col, (y1 - y) / col
                        dx2, dy2 = (x2 - x) / row, (y2 - y) / row
                        name = rename_map.get(name, name)
                        cell = NC.get(name, cfg.cellnames[name])
                        cell.put(
                            "org",
                            x,
                            y,
                            angle,
                            array=(col, (dx1, dy1), row, (dx2, dy2)),
                            flip=flip,
                            scale=mag,
                        )
                    else:
                        gds_elements_unknown.add(elem.etype)
                if cellname == topcellname:
                    # only apply bbox and/or hull to topcell
                    if bbox:
                        C.autobbox = True
                        C.bboxbuf = bboxbuf
                    if hull:
                        C.hull_based_bbox = True

            rename_map[cellname] = C.cell_name
            NC[C.cell_name] = C  # 'cellname' after cell generation

    if gds_elements_unknown and cfg.show_unknown_GDS_records:
        elist = ["{}({})".format(gb.GDS_record.name[e], e) for e in gds_elements_unknown]
        strlist = ", ".join(elist)
        main_logger(
            f"gds2nazca: Ignoring elements in cell (branch) '{cellname}': {strlist}",
            "warning",
        )
    cfg.annotated_cells = annotated_cells
    if C is None:
        # print(f"Only reused cells found when loading {topcells}")
        C = cfg.cellnames[topcellname]
    if not asdict:
        return C
    else:
        NCfilter = dict()
        if topcellsonly:
            renamed_topcells = {name: rename_map[name] for name in topcells}
            for cellname, cell in NC.items():
                if cellname in renamed_topcells.values():
                    NCfilter[cellname] = cell
        else:
            NCfilter = NC
        return NCfilter


def gds_filter(filename:str, cellmap=None, layermap=None):
    """Filter layers and cells from gds and export a copy to file."""
    # TODO filter out cellnames by pattern.
    print("Filtering '{}'...".format(filename))
    strm = gdsimp.GDSII_stream(filename=filename, cellmap=cellmap, layermap=layermap)
    newfilename = "{}_filtered.gds".format(filename[:-4])
    strm.GDSII_write(newfilename)
    print("...Wrote '{}'".format(newfilename))


def print_structure(filename:str, cellname:str, level:int=0):
    """Print gds structure in ascii art.

    Returns:
        None
    """
    strm = gdsimp.GDSII_stream(filename)
    strm.print_structure(cellname, level)


def load_gds(
    filename: str | bytes,
    cellname: str | None = None,
    newcellname: str | None = None,
    asdict: bool = False,
    topcellsonly: bool = True,
    select: str = "top",
    layermap: dict | None = None,
    cellmap: dict | None = None,
    scale: float | None = None,
    prefix: str = "",
    instantiate: bool = True,
    native: bool = True,
    bbox: bool = False,
    bboxbuf: float = 0,
    hull=None,
    show_hull: bool = False,
    hull_based_bbox=None,
    connect=None,
    flat: bool = False,
    reuse: bool = False,
    cellsnotreused: list[str] | None = None,
    cellsreused: list[str] | None = None,
    layermapmode: str = "all",
) -> Cell:
    """Load one or more GDS cells (and its instances) from <filename> into a Nazca cell.

    By default, load_gds returns a single cell in the specified gds file in
    <filename>, as specified in cellname, or the topcell, if only one exists.

    Alternatively, when using a gds file as a library it is more
    efficient and convenient to call, load the GDS file only once. In that case
    use asdict=True in load_gds, which returns a dictionary with the keys referencing
    each cell by cellname, while keeping a distinction between topcells and subcells:

    {'topcells': {<cellname>: Cell}, 'subcells': {<cellname>: Cell}}

    load_gds checks for cellname clashes, because a cell(tree)
    loaded into the layout can not contain any cell name that already exists
    in the layout. There are three ways to avoid name clashes in case they occur:

    1. Set a <newcellname>: changes only the name of the top cell;
    Note <newcellname> is ignored if a <cellmap> is provided as cellmap is then
    supposed to contain the renaming.

    2. Provide a <cellmap>: maps original cell names one-by-one to new cell
    names. Cells names omitted will not be renamed.

    3. Provide a cell name <prefix>: applies to all cells in a branch,
    except those in <newcellname> or <cellmap>.

    Note, if you need to create a building block from GDS with pins and stubs,
    and you have the pin and xsection info available already (for example in a
    file) then you may prefer to use method 'load_gdsBB' instead.

    Args:
        filename (str|bytes): filename of gds to load or bytes object that
            contains the gds byte stream.
        cellname (str): cellname in filename to load
        newcellname (str): new name for <cellname>
        asdict (bool): return a dict of cells if True (default=False).
            If True, the cellname keyword will be ignored.
        select (str): set the structure of the dictionary returned by this function.
            Only used when asdict is True.
        layermap (dict): layer mapping {old_layernumber: new_layernumber}
        layermapmode (str): 'all' | 'none'
            'all': copy all layers,
            'none': copy only explicitly mapped layers, remove others.
            Default='all'.
        cellmap (dict): cellname mapping {old_cellname: new_cellname}
        scale (float): scaling factor of the cell (default=1.0).
            Scaling in this function will be applied directly to the polygon
            structures, not as a modifier attribute like scaling/magnification
            on a gds instance. For the latter use the scale keyword in 'put()'.
            Warning, use scaling with care and basically only on structures
            like logos and text. Avoid (do not) use on library building
            blocks and/or optical components as their functionality may be
            compromised by scaling.
        prefix (str): optional string to avoid name clashes (default='')
        instantiate (bool): instantiate the GDS (default=False)
        native (bool): create native Nazca cells from GDS (default=True).
            Native cells provide full access to all elements in the gds.
        bbox (bool): add bounding box if True (default=False)
        bboxbuf (float): add a buffer to the bounding box (default=0)
        connect ((float, float, float)): Only for native=False,
            move GDS origin by (x, y, a) when putting it into the layout.
        moveorg ((float, float, float)): alternative name for connect
        reuse (bool): default is False. If True, load gds assumes cells with the
            same name are the same cell and it resolves conficts by using
            only the first cell occurance. Setting reuse=True is dangerous.
        cellsnotreused (list of str): list of cellnames to ignore for
            reuse if reuse=True
        cellsreused (list of str): list of cellnames to reuse. If set all other cells will
            not be reused and reuse and cellsnotreused will be ignored.
        topcellsonly (bool): default=True

    Returns:
        Cell | {cellname: Cell}: Nazca Cell containing the loaded gds cell(tree).
            If asdict is True return a dictionary.

    Example::

        cell1 = load_gds(filename='path_to_file.gds', cellname='name')
        cell1.put()

        # using asdict = True:
        cellAll = load_gds(filename='path_to_file.gds', asdict=True)
        cellAll[<cellname>].put()

    """
    # TODO: The load_GDS method loads the gds in a stream object to check the cellnames
    #    After that, the stream is discarded. Only the filename, cell reference
    #    are stored. At mask export time the GDS is loaded again. For large GDS
    #    it may be wiser to store the stream in memory for reuse at export time.
    # print('load_gds: {} -- {}'.format(filename, cellname))
    global num
    num += 1
    cfg.gdsload = filename

    # =============================================================================
    # Load gds and select topcell(s) to return
    # =============================================================================
    if cfg.layermap not in ({}, None):
        layermap = cfg.layermap
        layermapmode = cfg.layermapmode

    strm = gdsimp.GDSII_stream(filename, layermap=layermap, layermapmode=layermapmode)
    if scale is None:
        scale = round(strm.gds_db_unit / gb.gds_db_unit, 8)
        # print(f"scale: {os.path.basename(filename)}, {strm.gds_db_unit}, {gb.gds_db_unit}, {scale}")
        if abs(scale - 1) > 1e-12:
            main_logger(
                f"Imported gds '{filename}' will be scale corrected by factor {scale}.",
                "info",
            )

    if isinstance(filename, str):
        fln_or_buf = filename
    else:
        fln_or_buf = "<buffer>"

    if cellname is not None:
        topcellname = cellname
        topcells = [topcellname]
    else:  # find cellname if not provided
        topcells = strm.topcell()
        topcellname = None
        if len(topcells) == 1 and topcells is not None:
            topcellname = next(iter(topcells))
        elif not asdict:  # and not native:
            asdict = True
            allcells = set(list(strm.cells.keys()))
            othercells = allcells - topcells
            raise ValueError(
                "load_gds: No cellname provided to load from file '{}'."
                " Tried to find a single topcell, but multiple topcells exist."
                " To solve this: specify an explicit cellname to load,"
                " or set asdict=True."
                " to return a cell dictionary instead of a single cell."
                " Available topcells:\n{}"
                " \nAvailable non-topcells:\n{}".format(filename, topcells, othercells)
            )  # '\n'.join(list(strm.cells))))

            # print("Error: Could not determine the topcell.")
            # topcellname = None

    # =============================================================================
    # Build cellmap to avoid name clashes and reload GDS:
    # =============================================================================
    if cellmap is None:
        cellmap = dict()
        if newcellname is not None:
            cellmap[topcellname] = newcellname

    # Check for cellname clashes:
    for topcell in topcells:
        names = strm.cell_branch(topcell)
        for name in sorted(names):
            if name not in cellmap:
                cellmap[name] = f"{prefix}{name}"
            if (cellmap[name] in cfg.cellnames.keys()) and not native:  # native solves the conflicts itself
                if cellmap[name] is not name:
                    rename = f"is renamed to '{cellmap[name]}' which "
                else:
                    rename = ""
                if reuse:
                    main_logger(f"use_first=True in load_gds:" f" from file '{name}'", "warning")
                else:
                    raise ValueError(
                        f"""
Error in load_gds: cell name overlap: '{cellmap[name]}'.

Cell name '{name}' in file '{fln_or_buf}' {rename} is already in use in the design.

  Five suggestions to solve this issue by giving a <uniquename>:
    In 'load_gds':
    1. Rename the cell (topcell only): load_gds(..., newcellname=<uniquename>)
    2. Apply a cellmap (0 or more cells in a branch): load_gds(...,
       cellmap=<cellmap_dict>)
    3. Apply a prefix (to all cells in a branch): load_gds(..., prefix='new').
       Present prefix is '{prefix}'
    Other:
    4. Rename cell '{name}' in gds file '{fln_or_buf}'
    5. Rename existing cell name '{cellmap[name]}' in the design
"""
                    )

        if not native:  # or Cell will see it as existing.
            cfg.cellnames[cellmap[name]] = "loaded_gds_cell"
    # Reload gds applying cellmaps and layer maps.
    # TODO: change in memory i.o. reload.
    strm = gdsimp.GDSII_stream(
        filename,
        layermap=layermap,
        layermapmode=layermapmode,
        cellmap=cellmap,
    )

    # =============================================================================
    # Create nazca cell to return:
    # =============================================================================
    if topcellname is None:
        maptopcellname = None
    else:
        maptopcellname = cellmap[topcellname]

    if native:
        maskcell = _gds2native(
            strm=strm,
            topcellname=maptopcellname,
            cellmap=cellmap,
            bbox=bbox,
            bboxbuf=bboxbuf,
            hull=hull,
            show_hull=show_hull,
            hull_based_bbox=hull_based_bbox,
            scale=scale,
            flat=flat,
            instantiate=instantiate,
            asdict=asdict,
            topcellsonly=topcellsonly,
            select=select,
            reuse=reuse,
            cellsreused=cellsreused,
            cellsnotreused=cellsnotreused,
        )
    else:  # non-native
        with Cell("load_gds", celltype="mask", instantiate=instantiate) as maskcell:
            maskcell._put_gds(
                connect=connect,
                filename=fln_or_buf,
                cellname=topcellname,
                newcellname=maptopcellname,
                layermap=layermap,
                cellmap=cellmap,
                scale=scale,
                strm=strm,
            )
            maskcell.autobbox = bbox
            maskcell.bboxbuf = bboxbuf
            maskcell.hull_based_bbox = hull

    cfg.gdsload = False
    cfg.gdsloadstore = ""  # clear for generating new warnings in a next gds file.
    return maskcell


def load_gds_raw(
    filename,
    cellname=None,
    newcellname=None,
    layermap=None,
    cellmap=None,
    scale=1.0,
    prefix="",
    instantiate=False,
    bbox=False,
    hull=None,
    hull_based_bbox=None,
    connect=None,
    use_first=False,
    layermapmode="all",
    **kwargs,
):
    """Load GDS and always force native=False.

    load_gds_raw(...) is the same as load_gds(..., native=False).
    See load_gds() for a detailed method description.

    Returns:
        Cell: Nazca Cell containing the loaded gds cell(tree)
    """
    return load_gds(
        filename=filename,
        cellname=cellname,
        newcellname=newcellname,
        layermap=layermap,
        cellmap=cellmap,
        scale=scale,
        prefix=prefix,
        instantiate=instantiate,
        native=False,
        bbox=bbox,
        hull=hull,
        hull_based_bbox=hull_based_bbox,
        connect=connect,
        use_first=use_first,
        layermapmode=layermapmode,
    )


def show_pin(pin=None, radius:float=10, width:float=1, layer="dump"):
    """Draw a ring in the layout to indicate/visualize the pin position.

    Args:
        pin (node | str | (x, a)): pin reference as accepted by Pin.put()
        radius (float): radius of the ring shaped pin inidcator in um
        width (float): width of the ring-shaped pin indicator in um

    If no pin is provided (None), cp will be use to apply the "show".

    Returns:
        None
    """
    if pin is None:
        pin = cfg.cp
    Polygon(layer=layer, points=ring(radius=radius, width=width)).put(pin)
    # TODO: add direction


def show_cp(radius:float=10, width:float=1, layer="dump"):
    """Draw a ring in the layout to indicate/visualize the cp position.

    Args:
        radius (float): radius of the ring shaped pin inidcator in um
        width (float): width of the ring-shaped pin indicator in um

    Returns:
        None
    """
    if isinstance(radius, Node):
        raise TypeError(f"To show pin '{radius.name}' use method show_pin() instead of show_cp().")
    show_pin(pin=None, radius=radius, width=width, layer=layer)


def log_pin(pin=None, label:str="", show:bool=True, layer="dump"):
    """Generate log string where a pin is (cell + location) and lable it.

    Optionally visualize the location of the pin with the label in the layout.

    Args:
        pin (Node): pin to log. default=cp
        label (str): label to identify the log
        show (bool): show the pin in the layout
        layer (str | int | (int, int)): layer identifier for visualization. default='dump'

    Returns:
        str: message to put in a logfile, e.g. via nd.logging.info(...)
    """
    height = 5
    if pin is None:
        pin = cfg.cp
    try:
        pinname = pin.up.name
    except AttributeError:
        pinname = pin.name
    logstr = (
        f"log_pin with label '{label}' in cell '{cfg.active_cell().cell_name}' = {pin.fxya()} "
        f"for pin.name = '{pinname}', pin.id = {pin.id}"
    )
    if show:
        show_pin(pin=pin, layer=layer)
        cp = cfg.cp
        font.text(text=label, height=height, align="cc", layer=layer).put(pin)
        cfg.cp = cp
    try:
        logger.info(logstr)
    except AttributeError:
        return logstr


# See also show_pin()
wherecnt = count(1)


def whereami(text:str="here", size:float=100, pin=None):
    """Show current pointer position as arrow in the layout.

    Args:
        text (str): annotation text
        size (float): size of the annotation

    Returns:
        None
    """
    layer = 500
    cp_store = cfg.cp
    if pin is None:
        pin = cfg.cp
    points = [
        (0, 0),
        (-0.5, 0.5),
        (-0.4, 0.25),
        (-1, 0.3),
        (-1, -0.3),
        (-0.4, -0.25),
        (-0.5, -0.5),
    ]
    points = [(x * size, y * size) for x, y in points]
    with Cell(f"I am {next(wherecnt)}") as crisis:
        Polygon(layer=layer, points=points).put(0)
        font.text(text + " ", height=size / 4, align="rc", layer=layer).put(0)

    crisis.put(pin)
    cfg.cp = cp_store


class Netlist:
    """Class for building the netlist."""

    def __init__(self):
        """Construct a Netlist object. Singleton."""
        self.nodes_visited = set()
        self.cnodes_visited = set()

    def solvecell_core(self, node:Node, _cnode0:Node|None=None)->None:
        """Calculate the geometrical position of nodes in a cell via the netlist.

        Include all nodes in the cell (level 0) and all nodes in instantiated
        cells (level 1). Hence, a node in scope adheres to one of the following
        conditions:

        - the node resides in same cell as the starting node (parent <cnode0>).
        - the node resides in an instance of the cell of the starting node.

        A starting <node> has to be provided from where to solve.
        A good starting point in each cell is the cnode with its pointer
        position set at (x, y, a) = (0, 0, 0).

        Args:
            node (Node): node from where to start solving the cell
            _cnode0 (Node): Internal parameter containing the cnode of the cell
                to solve. It is automatically obtained from <node> in theh
                first pass.

        Returns:
            None
        """

        if _cnode0 is None:
            _cnode0 = node.cnode
        self.nodes_visited.add(node)

        neighbours = node.geo_nb_iter()
        for nextnode, mat in neighbours:
            if nextnode not in self.nodes_visited:
                # print(node)
                # node in main cell or in instance
                if nextnode.cnode is _cnode0:
                    nextnode.pointer.set_mat(node.pointer.trans(mat))
                    self.solvecell_core(nextnode, _cnode0)
                elif nextnode.cnode.parent_cnode is _cnode0:
                    nextnode.pointer.set_mat(node.pointer.trans(mat))
                    self.solvecell_core(nextnode, _cnode0)
                else:
                    logger.warning(
                        f"Skipping node {nextnode} in cell '{nextnode.cnode.cell.cell_name}': "
                        f"The node is not in scope of cell '{_cnode0.cell.cell_name}'.",
                        "warning",
                    )
            # TODO: else: check geo consistency, e.g. floating point delta's.

    # =============================================================================
    # Cell-element iterators that return Node and a cell-element object
    # =============================================================================
    def polygon_iter(self, cnode:Node, level:int, infolevel:int=0):
        """Generator to iterate over all polygons in a cell (cnode).

        Yields:
            (Pointer, Polygom): Next Polygon object and its position
        """
        for node, pgon in cnode.cell.polygons:
            if infolevel > 1:
                print(
                    "{}polygon: ML={}, xya={}, bbox={}".format("  " * level, pgon.layer, node.pointer.xya(), pgon.bbox)
                )
            yield node.pointer.copy(), pgon

    def polyline_iter(self, cnode:Node, level:int, infolevel:int=0):
        """Generator to iterate over all polylines (paths) in a cell (cnode).

        Yields:
            (Pointer, Polyline): Next Polyline object and its position
        """
        for node, pline in cnode.cell.polylines:
            if infolevel > 1:
                print(
                    "{}polyline: ML={}, xya={}, bbox={}".format(
                        "  " * level, pline.layer, node.pointer.xya(), pline.bbox
                    )
                )
            yield node.pointer.copy(), pline

    def annotation_iter(self, cnode:Node, level:int, infolevel:int=0):
        """Generator to iterate over all annotations in a cell (cnode).

        Yields:
            (Pointer, annotation): Next Annotation and its position
        """
        for node, anno in cnode.cell.annotations:
            if infolevel > 1:
                print("{}annotation: ML={}, xya={}".format("  " * level, anno.layer, node.pointer.xya()))
            yield node.pointer.copy(), anno

    def instance_iter(self, cnode:Node):
        """Generator to iterate over all instances in cell (cnode) one level deep.

        Yields:
            Node: cnode of instance
        """
        for nn in cnode.nb_cnode:
            if nn[2] == 1:
                yield nn[0]

    def gdsfile_iter(self, cnode:Node, level:int, infolevel:int=0):
        """Generator to iterate over all GDS files instantiated in a cell (cnode).

        Yields:
            (Pointer, gdsinfo): Next gds file and info to generate it.
                gdsinfo = (filename, cell, newcell, layermap, cellmap, scale)
        """
        gdsfiles = cnode.cell.gdsfiles
        for node, gdsinfo in gdsfiles:
            if infolevel > 1:
                print("{}gds-cell: cell={}, xya={}".format("  " * level, gdsinfo.newcell, cnode.pointer.xya()))
            yield node.pointer.copy(), gdsinfo

    # =============================================================================
    # Cell-element iterators WITH translation and flipping performed
    # =============================================================================
    def polygon_transflip_iter(
        self,
        cnode: Node,
        trans,
        flip: bool,
        scale: float,
        level: int = 0,
        apply: bool = True,
        hierarchy: str = "self",
        infolevel: int = 0,
        hull: bool = False,
    ):
        """Generator to iterate over all polygons in a cell (cnode).

        Args:
            cnode (Node): cnode
            trans (tuple): translation state w.r.t. to (new) parent
            flip (bool): flip state w.r.t. to (new) parent
            scale (float): scale state w.r.t. to (new) parent
            apply (bool): apply translation and flipping (default=True)
            infolevel (int): debug info level to stdout

        Yields:
            (Polygon, list((float, float)), tuple(4*float)) |
            (Polygon, tuple(3*float), tuple(4*float)):

            if apply is True (default)::

                Polygon object, and the polygon points & the bbox w.r.t.
                the (possibly new) parent cell.

            if apply is False::

                Polygon object, its position (x, y, a), 'a' in radians,
                the flip state of the polygon
        """
        # TODO: how to deal with  hierarchy == 'self' and apply
        # if hierarchy == 'self':
        #    apply = False
        for node, pgon in cnode.cell.polygons:
            if infolevel > 1:
                print(
                    "{0}polygon: ML='{ld}', "
                    "xya=({p[0]:.3f}, {p[1]:.3f}, {p[2]:.3f}), "
                    "bbox_wxh=({bx:.3f}, {by:.3f}), "
                    "N={1}".format(
                        TAB_ELM * (level + 2),
                        len(pgon.points),
                        ld=pgon.layer,
                        p=node.pointer.xya(),
                        bx=pgon.bbox[2] - pgon.bbox[0],
                        by=pgon.bbox[3] - pgon.bbox[1],
                    )
                )
            org = node.pointer.copy()
            org.scale_position(scale)
            nflip, nflop = 1, 1
            if node.flip:
                nflip = -1
            if node.flop:
                nflop = -1
            s = 1
            if flip:
                s = -1
                org = org.copy()
                org.flip()
            [x, y, a] = org.multiply_ptr(trans).xya()
            a = s * np.radians(a)
            scale_tot = scale * node.scale
            if hull and hasattr(pgon, "hull"):
                points = pgon.hull
            else:
                points = pgon.points
            if apply:
                if [x, y, a] != [0, 0, 0] or nflip == -1 or nflop == -1 or scale_tot != 1.0 or s == -1:
                    xy = [
                        (
                            x + scale_tot * (cos(a) * nflip * u - sin(a) * nflop * v),
                            y + scale_tot * s * (sin(a) * nflip * u + cos(a) * nflop * v),
                        )
                        for u, v in points
                    ]
                else:
                    xy = points
                xyT = list(zip(*xy))
                bbox = (min(xyT[0]), min(xyT[1]), max(xyT[0]), max(xyT[1]))
                yield pgon, xy, bbox
            else:
                yield pgon, pgon.points, pgon.bbox
            # TODO: can this realy be removed?:
            # else:
            #    print(f"other-xya: {x, y, a}")
            #    yield pgon, [x, y, a], s

    def polyline_transflip_iter(
        self,
        cnode: Node,
        trans,
        flip: bool,
        scale: float,
        level: int = 0,
        apply: bool = True,
        hierarchy: str = "self",
        infolevel: int = 0,
        hull: bool = False,
        polygon: bool = False,
    ):
        """Generator to iterate over all polylines in a cell (cnode).

        Args:
            cnode (Node): cnode
            trans (tuple): translation state w.r.t. to (new) parent
            flip (bool): flip state w.r.t. to (new) parent
            scale (float): scale state w.r.t. to (new) parent
            apply (bool): apply translation and flipping (default=True)
            hull (bool): if True work with hull points
            polygon (bool): if True work with the polygon rather then polyline points
            infolevel (int): debug info level to stdout

        Yields:
            (Polyline, list((float, float)), tuple(4*float)) |
            (Polyline, tuple(3*float), tuple(4*float)):

            if apply is True (default):

                Polyline object, and the polyline points & the bbox w.r.t.
                the (possibly new) parent cell.

            if apply is False:

                Polyline object, its position (x, y, a), 'a' in radians,
                the flip state of the polyline
        """
        # if hierarchy == 'self':
        #    apply = False
        if cfg.export_polyline_as_polygon:
            polygon = True
            hull = False
        for node, pline in cnode.cell.polylines:
            if infolevel > 1:
                print(
                    "{0}polyline: ML='{ld}', "
                    "xya=({p[0]:.3f}, {p[1]:.3f}, {p[2]:.3f}), "
                    "bbox_wxh=({bx:.3f}, {by:.3f}), "
                    "N={1}".format(
                        TAB_ELM * (level + 2),
                        len(pline.points),
                        ld=pline.layer,
                        p=node.pointer.xya(),
                        bx=pline.bbox[2] - pline.bbox[0],
                        by=pline.bbox[3] - pline.bbox[1],
                    )
                )
            org = node.pointer.copy()
            org.scale_position(scale)
            nflip, nflop = 1, 1
            if node.flip:
                nflip = -1
            if node.flop:
                nflop = -1
            s = 1
            if flip:
                s = -1
                org = org.copy()
                org.flip()
            [x, y, a] = org.multiply_ptr(trans).xya()
            a = s * np.radians(a)
            scale_tot = scale * node.scale
            if hull and hasattr(pline, "hull"):
                points = pline.hull
            elif polygon:
                points = pline.polygon
            else:
                points = pline.points
            if apply:
                if [x, y, a] != [0, 0, 0] or nflip == -1 or nflop == -1 or scale_tot != 1.0 or s == -1:
                    xy = [
                        (
                            x + scale_tot * (cos(a) * nflip * u - sin(a) * nflop * v),
                            y + scale_tot * s * (sin(a) * nflip * u + cos(a) * nflop * v),
                        )
                        for u, v in points
                    ]
                else:
                    xy = points
                xyT = list(zip(*xy))
                bbox = (min(xyT[0]), min(xyT[1]), max(xyT[0]), max(xyT[1]))
                yield pline, xy, bbox
            else:
                yield pline, pline.points, pline.bbox
            # else:
            #    yield pline, [x, y, a], s

    def annotation_transflip_iter(
        self,
        cnode,
        trans,
        flip,
        scale,
        level=0,
        apply=True,
        hierarchy="self",
        infolevel=0,
    ):
        """Generator to iterate over all annotations in a cell (cnode).

        Args:
            cnode (Node): cnode to iterate
            trans (tuple): translation state of instance
            flip (bool): flip state of instance
            apply (bool): default=True: Apply translation and flipping
            infolevel (int): amount of debug info to display in stdout

        Includes translation and flipping.

        Yields:
            (Annotation, (float, float), int):
                Next Annotation and its position as (x, y),
                and a flip multiplyer -1 (flip) or 1
        """
        for node, anno in cnode.cell.annotations:
            if infolevel > 1:
                print(
                    "{0}annotation: ML='{ld}', "
                    "xy=({p[0]:.3f}, {p[1]:.3f}), "
                    "text='{t}'".format(
                        TAB_ELM * (level + 2),
                        ld=anno.layer,
                        p=node.pointer.xya(),
                        t=anno.text[:5],
                    )
                )
            org = node.pointer.copy()
            org.scale_position(scale)
            if flip:
                org = org.copy()
                org.flip()
            xy = org.multiply_ptr(trans).xy()
            yield anno, xy

    def instance_transflip_iter(
        self,
        cnode,
        trans,
        flip,
        scale,
        level=0,
        apply=True,
        hierarchy="self",
        infolevel=0,
    ):
        """Generator to iterate over all instances one level deep.

        Includes translation and flipping.

        Args:
            cnode (Node): cnode to iterate.
            trans (tuple): translation state of instance.
            flip (bool): flip state of instance.
            scale (float): scaling factor.
            apply (bool): default=True: Apply translation and flipping.
            infolevel (int): amount of debug info to display in stdout.
            hierarchy (str): setting on how to process the hierarchy.

        Yields:
            cnode, (float, float, float), bool: cnode of instance (inode),
                position (x, y, a), 'a' in degrees, flip state
        """
        if hierarchy == "flat":
            return None
        for nn in cnode.nb_cnode:
            if nn[2] == 1:  # cell link is down stream
                # if not nn[0].cell.instantiate and hierarchy != 'full':
                #    return None
                org = nn[0].pointer.copy()
                if flip:
                    org = org.copy()
                    org.flip()
                [x, y, a] = org.multiply_ptr(trans).xya()
                # print(f"|instance: {nn[0].cell.cell_name}, instantiate:{nn[0].cell.instantiate}")
                yield nn[0], [x, y, a], flip

    def gdsfile_transflip_iter(
        self,
        cnode,
        trans,
        flip,
        scale,
        apply,
        level=0,
        hierarchy="self",
        infolevel=0,
    ):
        """Generator to iterate over all GDS files instantiated in a cell (cnode).

        Args:
            cnode (Node): cnode to iterate
            trans (tuple): translation state of instance
            flip (bool): flip state of instance
            apply (bool): ignored: always True
            infolevel (int): amount of debug info to display in stdout

        Yields:
             (Polyline, (float, float, float), bool):
                Next gdsfile and its position (x, y, a), 'a' in degrees,
                and the flip state
        """
        gdsfiles = cnode.cell.gdsfiles
        for node, gdsinfo in gdsfiles:
            if infolevel > 1:
                print("{}gds-cell: cell={}, xya={}".format(TAB_ELM * (level + 2), gdsinfo.newcell, cnode.pointer.xya()))
            org = node.pointer.copy()
            [x, y, a] = org.multiply_ptr(trans).xya()
            yield gdsinfo, [x, y, a], flip

    # =============================================================================
    # Cell iteration
    # =============================================================================
    def celltree_iter_base(
        self,
        icnode,
        hierarchy="full",  # ['flat', 'self', 'full', 'apply']
        position=None,
        level=0,
        infolevel=0,
    ):
        """Generator to iterate over cell of <cnode>, top-down, go deep first.

        The tree descents from the provided cnode into instantiated cnode(s)
        until no deeper instances are available.
        For decending into an instance, the inode:
        - look up the cell object the instance represents,
        - take that cell's cnode and use it to seed the next level.

        Args:
            icnode (Node): cnode of cell or inode of instance to iterate into
            level (int): depth in cell tree, (default=0)
            position (Pointer): icnode (org) position. default = Pointer(0, 0, 0)
            flat (bool): flatten array instances if True (default=False)
            infolevel (int): amount of runtime info to stdout (default=0)

        Yields:
            (Node, int, Pointer, bool, scale): (cnode, level, position, flip scale).
                Yields next cell, its level in the hierarchy and its position.
        """
        # Get the cnode of the cell cnode or inode
        #   Hence, always start the tree with a cell.
        if position is None:
            position = Pointer(0, 0, 0)
        cnode = icnode.cell.cnode
        if infolevel > 3:
            print("{}: cnode={}, name={}, level={}".format("  " * infolevel, cnode, cnode.cell.cell_name, level))

        # stack of cnode-tree:
        path = []
        nodes = [(cnode, level, position, False, 1.0, cnode)]
        while nodes:
            level_old = level
            cnode, level, position, flip, scale, next_node = nodes[-1]
            if level > 0 and level <= level_old:
                for _ in range(level_old - level + 1):
                    del path[-1]
            path.append(next_node)
            # P = '/'.join([a.cnode.cell.cell_name for a in path])
            # print(level, len(nodes), P)
            yield cnode, level, position, flip, scale, path
            self.cnodes_visited.add(cnode)
            del nodes[-1]
            next_nodes = list(cnode.instance_iter())
            for next_node in next_nodes:  # append nodes list with all next_nodes (instances)
                if hasattr(next_node.instance, "sourcepin"):
                    if not next_node.instance.sourcepin.show:
                        continue
                cnode = next_node.cell.cnode
                flip = next_node.flip
                scale = next_node.scale
                array = next_node.array
                if array is not None and (not next_node.cell.instantiate or hierarchy == "flat"):
                    nx, (dx1, dy1), ny, (dx2, dy2) = array
                    x0, y0, a0 = next_node.pointer.xya()
                    for xi in range(nx):
                        for yi in range(ny):
                            orgnew = Pointer(x0 + xi * dx1 + yi * dx2, y0 + xi * dy1 + yi * dy2, a0)
                            nodes.append((cnode, level + 1, orgnew, flip, scale, next_node))
                else:
                    nodes.append((cnode, level + 1, next_node.pointer, flip, scale, next_node))

    def celltree_iter(
        self,
        cell: Cell,
        position: tuple[float, float, float] | None = None,
        hierarchy: str = "self",
        cells_visited: set | None = None,
        infolevel: int = 0,
        cellmap: dict | None = None,
        revisit: bool = False,
    ):
        """Generator to iterate top-down or bottom-up (default) over the celltree in <cell>.

        Translation, flipping and flattening are applied.
        Go deep first. If a instantiation is found of a cell that already has
        been iterated over (cells_visited), then this cell will not be
        scanned again but reused.

        Iteration over this Generator with infolevel = 1 will print the Nazca
        hierarchy, cell-levels to stdout.

        Local coordinates that are returned will be relative to the first instantiated
        parent, as determined by the cell instantiation and hierarchy setting.

        Args:
            cell (Cell): topcell to iterate in(to
            position ((float, float float)): (x, y, a) starting postition of the topcell.
                default=None, which translates into (0, 0, 0)
            hierarchy (str): None, 'flat', 'self' (default), 'full' or 'apply'.
                Determines the handling of the instatiate cell attribute:

                    None: follow the cells instantiate setting to flatten Nazca cells or not.

                    'flat': collapses the hierarcy into a single level corresponding
                            to setting instantiate=False in all Nazca cells.

                    'self' (default): reproduces all Nazca cells explicitly while maintaining their instantiate setting.

                    'full': instantiates all Nazca cells.

                    'apply': Flatten all non-instantiated levels

            cells_visited (set): list of cells_visited. The iterator will skip
                cells in this set and not iterate into them.
            infolevel (int): amount of info printed when iterating
            cellmap (dict): Optional dict to rename cells {oldname: newname}.
                default=None
            revisit (bool): go into each instance of each cell (default=False)

        Yields:
            named_tuple: Info to (re)build cells in a netlist branch.
        """
        hierarchy_allowed = ["flat", "apply", "self", "full"]
        if hierarchy not in hierarchy_allowed:
            raise ValueError(f"Unkown hierarchy setting '{hierarchy}', not in {hierarchy_allowed}")

        def up(depth, stop):
            """Move upwards in the celltree.

            Args:
                depth (int): depth is the present level to move up from.
                stop (int): last level to move to.

            Yields:
                named_tuple: Info to (re)build cells in a netlist branch.
            """
            while depth >= stop:
                cellparams = stack_params[depth]

                if translist_loc:  # not []: go level up in location lists
                    translist_loc.pop()
                    fliplist_loc.pop()
                    translist_glob.pop()
                    fliplist_glob.pop()

                if infolevel > 0:
                    print(
                        "{}closed cell: '{}', inst={}".format(
                            TAB_CLOSE * (cellparams.level + 1),
                            cellparams.cell.cell_name,
                            cellparams.instantiate,
                            # export_flag,
                        )
                    )

                if depth in export_levels:
                    # if an export level yields a cell closure
                    export_levels.pop()
                    CLOSE = CLOSECELL
                else:
                    # no export_level
                    scalelist.pop()
                    CLOSE = not CLOSECELL
                yield cellinfo_close(
                    cell_start=False,
                    cell_instantiate=None,
                    cell_close=CLOSE,
                    cell_end=True,
                    cell=cellparams.cell,
                    level=depth,
                    cell_create=False,
                    cell_open=False,
                    iters=iters_close,
                    new_cell_name="",
                    hierarchy=hierarchy,
                    branch=cellparams.branch,
                )
                depth -= 1
            return depth

        cellinfo_open = namedtuple(
            "cellinfo_open",
            [
                "cell_start",  # Old name for cell_instantiate
                "cell_instantiate",  # True for a new nazca cell, instantiated or not
                "cell_create",  # True for a new instantiated cell
                "cell_open",  # = cell_create
                "cell",  # cell object
                "new_cell_name",  # name of the cell
                "level",  # depth od the cell in the hierarchy (top=0)
                "parent_level",  # parent level, taken into account flattend levels
                "transflip_loc",  # position and flip state w.r.t. the parent cell
                "transflip_glob",  # position and flip state w.r.t. the top cell
                "scale",  # scaling factor of the parent cell after export
                "iters",  # list of iterators of the elements in the cell
                "cell_close",  # for compatibility with cellinfo_close tuple only
                "cell_end",  # for compatibility with cellinfo_close tuple only
                "instantiate",  # bool based on hierarchy setting: 'flat', 'self' or 'full'
                "hierarchy",  # how to deal with instantiation
                "branch",
            ],
        )
        cellinfo_close = namedtuple(
            "cellinfo_close",
            [
                "cell_close",  # True for a cell closure of an instantiated cell
                "cell_end",  # cell ending, instantiated or not
                "level",  # level of the cell in the hierarchy (top=0)
                "cell",  # cell object
                "iters",  # for compatibility with cellinfo_open tuple only
                "cell_start",  # for compatibility with cellinfo_open tuple only
                "cell_instantiate",  # for compatibility with cellinfo_open tuple only
                "cell_create",  # for compatibility with cellinfo_open tuple only
                "cell_open",  # for compatibility with cellinfo_open tuple only
                "new_cell_name",  # for compatibility with cellinfo_open tuple only
                "hierarchy",  # how to deal with instantiation
                "branch",
            ],
        )

        if infolevel > 0:
            print(
                f"Start Netlist (infolevel={infolevel})\n"
                f"{TAB_OPEN} -> open an instantiated cell\n"
                f"{TAB_CLOSE} -> close a cell\n"
                f"{TAB_REUSE} -> reused instantiated cell\n"
                f"{TAB_FLAT} -> non-instantiated cell\n"
                f"{TAB_INST} -> (export) add instance to cell\n"
                f"{TAB_ELM} -> (export) elements (polygons, etc.)\n"
                "-------------------------------"
            )

        stack_params = {}  # {level: params} store all parameters per instantiated cell level.
        # stack_noninstant = []  # stack for storing all params for non-instantiated cell levels
        if cellmap is None:
            cellmap = {}
        NEWCELL = True
        CLOSECELL = True
        iters_close = {  # iterators data for cell closures
            "polyline": [],
            "polygon": [],
            "annotation": [],
            "instance": [],
            "gdsfile": [],
        }
        export_levels = []  # stack for exported netlist levels.
        translist_loc = []  # stack for local translation
        fliplist_loc = []  # stack for local flip state
        translist_glob = []  # stack for global translation
        fliplist_glob = []  # stack for global flip state
        scalelist = [1.0]  # stack for scaling of flattened instances
        level_last = 0  # keep track of level in previous iteration, start at top level is 0
        level_limit = 100  # reset level (high number) to retreat to for non-reused levels.
        level_reuse = level_limit  # track if level is still in a reused branch and bypass it.

        if cells_visited is None:
            self.cells_visited = set()
        else:
            self.cells_visited = cells_visited

        cell_iter = self.celltree_iter_base(
            icnode=cell.cnode,
            level=0,
            position=position,
            hierarchy=hierarchy,
            infolevel=infolevel,
        )

        for cnode, level, org, flip, scale, branch in cell_iter:
            if level > level_reuse:
                # skip cells that are part of a reused cell (if level_reuse is set).
                continue
            else:
                # reset to high value to inactivate reuse.
                level_reuse = level_limit

            # Close cells from last processed level level_last (-> depth)
            #   and stop at the just obtained new level for this iteration step:
            depth, stop = level_last, max(1, level)
            depth = yield from up(depth, stop)

            cellname = cnode.cell.cell_name
            if infolevel > 0:
                info = "opened cell: '{}' @ ({:.3f}, {:.3f}, {:.3f}), flip={}, inst={}".format(
                    cellname, org.x, org.y, org.a, flip, cnode.cell.instantiate
                )

            # Define "inst", "makecell" and "reusecell" settings:
            #   inst:      instantiate setting of the cell being processed based on the hierarchy.
            #   makecell:  if the cell is exported explicitly
            #   reusecell: control parameter to force re-creation of the cell
            #                if the cell was created before, e.g. for 'flat' output.
            if hierarchy == "self":
                inst = cnode.cell.instantiate
                makecell = True
                reusecell = True
            elif hierarchy == "apply":
                inst = cnode.cell.instantiate
                makecell = cnode.cell.instantiate
                reusecell = cnode.cell.instantiate
            elif hierarchy == "flat":
                if level == 0:
                    inst = True
                    makecell = True
                    reusecell = True  # reusecell setting does not matter in this case
                else:
                    inst = False
                    makecell = False
                    reusecell = False
            elif hierarchy == "full":
                inst = True
                makecell = True
                reusecell = True
            else:
                raise ValueError(f"hierarchy value '{hierarchy}' unknown")

            visited = cellname in self.cells_visited

            if not reusecell or not visited or revisit:
                # create new cell or recreate the cell.
                if infolevel > 0:
                    if inst:
                        print("{}{}".format(TAB_OPEN * (level + 1), info))
                    elif infolevel > 0:
                        print("{}{}".format(TAB_FLAT * (level + 1), info))

                self.cells_visited.add(cellname)

                # global transflipping:
                if level == 0:
                    translist_glob.append(Pointer(0, 0, 0))
                    fliplist_glob.append(False)
                else:
                    translate = translist_glob[-1].copy()
                    orgtrans = org.copy()
                    if fliplist_glob[-1]:
                        orgtrans.flip()
                    fliplast = fliplist_glob[-1] ^ flip
                    fliplist_glob.append(fliplast)
                    translate.move_ptr(orgtrans)
                    translist_glob.append(translate)

                # local transflipping:
                if makecell or level == 0:
                    # create new export level
                    createcell = True
                    export_levels.append(level)
                    fliplast = flip
                    translist_loc.append(Pointer(0, 0, 0))
                    fliplist_loc.append(False)
                else:
                    # flattened cell -> content translates into a parent cell.
                    createcell = False
                    translate = translist_loc[-1].copy()
                    orgtrans = org.copy()
                    # The parent scales this placement; the child scales its own content.
                    orgtrans.scale_position(scalelist[-1])
                    scalelist.append(scalelist[-1] * scale)
                    if fliplist_loc[-1]:
                        orgtrans.flip()
                    fliplast = fliplist_loc[-1] ^ flip
                    fliplist_loc.append(fliplast)
                    translate.move_ptr(orgtrans)
                    translist_loc.append(translate)

                transflip_loc = translist_loc[-1], fliplist_loc[-1]
                transflip_glob = translist_glob[-1], fliplist_glob[-1]
                apply_transflip = True  # TODO: connect apply to hierarchy?
                internal_params = (
                    cnode,
                    translist_loc[-1],
                    fliplist_loc[-1],
                    scalelist[-1],
                    level,
                    apply_transflip,
                    hierarchy,
                    infolevel,
                )
                element_iters = {
                    "polyline": self.polyline_transflip_iter(*internal_params),
                    "polygon": self.polygon_transflip_iter(*internal_params),
                    "annotation": self.annotation_transflip_iter(*internal_params),
                    "instance": self.instance_transflip_iter(*internal_params),
                    "gdsfile": self.gdsfile_transflip_iter(*internal_params),
                }
                parent_level = export_levels[-1]
                new_cell_name = cellmap.get(cellname, None)

                iterparams = cellinfo_open(
                    cell_start=NEWCELL,
                    cell_instantiate=NEWCELL,
                    cell=cnode.cell,
                    cell_create=createcell,
                    cell_open=createcell,
                    cell_close=False,
                    cell_end=False,
                    new_cell_name=new_cell_name,
                    level=level,
                    parent_level=parent_level,
                    transflip_loc=transflip_loc,
                    transflip_glob=transflip_glob,
                    scale=scalelist[-1],
                    iters=element_iters,
                    instantiate=inst,
                    hierarchy=hierarchy,
                    branch=branch.copy(),
                )

                stack_params[level] = iterparams
                yield iterparams
                level_last = level

            elif reusecell:  # reuse previously processed cell:
                if infolevel > 0:
                    print("{}{}".format(TAB_REUSE * (level + 1), info))
                level_reuse = level
                level_last = level - 1
        # end cell_iter

        yield from up(level_last, 0)
        if infolevel > 0:
            print("End celltree iteration")


# TODO: issue warning when patching a cell that already has been instantiated.
class PatchCell:
    """Context manager to patch a closed cell.

    Use with care and never patch a cell after using it.
    Patching of cells is rarely needed and may lead to
    an inconsistent/changing bounding box, among others.

    A use case for PatchCell is when loading a hierarchical gds
    where a subcell(s) could be patched.

    Example::

        with Patchell(cell=cellvar):
            # add stuff to the cell
    """

    def __init__(self, cell: Cell) -> None:
        """Initialize PatchCell object.

        Args:
            cell (Cell): Cell object to path
        """
        if isinstance(cell, Cell):
            self.cell = cell
            self.cell.closed = False
            return
        else:
            raise ValueError(f"Must provide a type cell to PatchCell context manager, not a {type(cell)}.")


    def __enter__(self):
        self.cp = cfg.cp
        cfg.cp = self.cell.pin[self.cell.default_out]
        cfg.cells.append(self.cell)
        cfg.patchcell = True
        return self

    def __exit__(self, type, value, traceback):
        self.cell.closed = True
        if value is None:
            cfg.cp = self.cp
            cfg.cells.pop()
            cfg.patchcell = False
        return False


# Define a Global layermap that will be added to gds loads if not {}.
# This can be used to e.g. solve non-unique layer mapping at a level higher up in the code
# and it reach inside loaded ip-blocks remove non-unique mapping warnings without adding
# a layermap inside ip-blocks. Make sure to set layermap = {} after usage to switch it off.
# Default = {} or None: do not use any global layer mapping.
cfg.layermap = {}

# Global layermapmode for nd.cfg.layermap
cfg.layermapmode = "all"


class LayerMap:
    """Context manager to force a layermap on all gds loads.

    Example::

        with LayerMapping():
            # do stuff that calls one or more gds load function(s) directly or in sub-functions.
    """

    def __init__(self, layermap:dict, layermapmode:str="all"):
        """Initialize LayerMapping object.

        Args:
            layermap (dict): layermap dict {old_layer: new_layer}
            layermapmode (str): layermapmode: 'all' (default) or 'none'

        Returns:
            None
        """
        self.old_layermap = cfg.layermap
        self.layermap = layermap

        layermapmodeoptions = ["all", "none"]
        if layermapmode in layermapmodeoptions:
            self.layermapmode = layermapmode
        else:
            main_logger(
                f"Wrong layermapmode given '{layermapmode}', valid option are {layermapmodeoptions}",
                "error",
            )
            self.layermapmode = "all"

    def __enter__(self):
        cfg.layermap = self.layermap
        cfg.layermapmode = self.layermapmode
        return self

    def __exit__(self, type, value, traceback):
        if value is None:
            cfg.layermap = self.old_layermap
            cfg.layermapmode = "all"
        return False


class SuspendRangeCheck:
    """Context manager to suspend range checking.

    Example::

        with SuspendRangeCheck():
            # calls cells but do not range check.
    """

    def __init__(self, onoff:bool=True):
        """Initialize SuspendRangeCheck object.

        Args:
            onoff (bool): default True. Can be set to False to stop suspending rangecheck.

        Returns:
            None
        """
        self.rangecheck = cfg.rangecheck
        self.onoff = onoff

    def __enter__(self):
        cfg.rangecheck = self.onoff
        return self

    def __exit__(self, type, value, traceback):
        if value is None:
            cfg.rangecheck = self.rangecheck
        return False


class GroupConnect:
    """Context manager to force group connect on or off.

    Group_connect can slow down mask creation and it maby be convenient to
    switch it on or off in a workflow.

    Example::

        with GroupConnect(False):
            # Create layout, but do not group_connect.

    """

    def __init__(self, onoff:bool=True):
        """Initialize GroupConnect object.

        Args:
            onoff (bool): default True.

        Returns:
            None
        """
        self.group_connect = cfg.group_connect
        self.onoff = onoff

    def __enter__(self):
        cfg.group_connect = self.onoff
        return self

    def __exit__(self, type, value, traceback):
        if value is None:
            cfg.group_connect = self.group_connect
        return False


def cell_iter(
    topcell: Cell,
    cellmap: dict | None = None,
    flat: bool = False,
    hierarchy: str = "self",
    infolevel: int = 0,
    revisit: bool = False,
):
    """Get a cell iterator for rebuilding cells.

    Args:
        topcell (Cell): cell to iterate into.
        cellmap (dict): Optional dict to rename cells {oldname: newname}.
            default=None.
        flat (bool): for backward compatibility, same as hierarchy='flat' if True
            and hierarchy not provided, but ignored if hierarchy is provided explicitly.
        hierarchy (str): 'flat', 'self' (default), 'full', or 'apply'.
        revisit (bool): go into each instance of each cell (default=False)

    Returns:
        Iterator: top-down celltree_iter()
    """
    if flat:
        hierarchy = "flat"

    return Netlist().celltree_iter(
        cell=topcell,
        hierarchy=hierarchy,
        cellmap=cellmap,
        infolevel=infolevel,
        revisit=revisit,
    )


def cell_iter_bottom_up(
    topcell: Cell,
    cellmap: dict | None = None,
    flat: bool = False,
    hierarchy: str = "self",
    revisit: bool = False,
    infolevel: int = 0,
):
    """Get a cell iterator for yielding cells bottom up.

    For each cell the cell_open parameters and cell_close parameters are yielded sequentially
    in the order of cell_close occurences as extracted from the more generic top-down cell_iter() function.

    Args:
        cell (Cell): topcell to iterate into.
        cellmap (dict): Optional dict to rename cells {oldname: newname}.
            default=None.
        flat (bool): for backward compatibility, same as hierarchy='flat' if True
            and hierarchy not provided, but ignored if hierarchy is provided explicitly.
            default=False
        hierarchy (str): 'flat', 'self' (default), 'full', or 'apply'.
        revisit (bool): go into each instance of each cell (default=False)
        infolevel (int): indicate level of debugging information to stdout.
            default=0 is no output.

    Returns:
        Iterator: bottom-up celltree_iter()
    """
    if flat:
        hierarchy = "flat"

    iter = cell_iter(
        topcell,
        hierarchy=hierarchy,
        cellmap=cellmap,
        infolevel=infolevel,
        revisit=revisit
    )
    bottom_up_tree = []
    opened_cells = {}
    for params in iter:
        if params.cell_open:
            opened_cells[params.cell] = params
        elif params.cell_close:
            params_open = opened_cells.pop(params.cell)
            bottom_up_tree.append(params_open)
            bottom_up_tree.append(params)

    for params in bottom_up_tree:
        yield params


def cell_tree_modelcell_iter(
    topcell: Cell, hierarchical: bool = True, modeltype: str = "cml", bottom_up: bool = False
):
    """Filters the cell tree to only return the information of cells that have a model of type modeltype.
    If hierarchical=True, Cells that have a Cell with a model at any lower level are also considered to have a model).

    Args:
        topcell (nd.Cell): Cell for which the celltree iter will iterate
        hierarchical (bool): if True, Cells that have a Cell with a model at any lower level are also considered
            to have a model
        modeltype (List or str): modeltype(s) to check for.

    Yields:
        filtered params

    """
    if not isinstance(modeltype, list):
        modeltype = [modeltype]

    model_cells = []
    for params in cell_iter(topcell, revisit=True):
        if params.cell_open:
            cm._fetch_compact_models(params.cell)
            for type in modeltype:
                if type in params.cell.model_info.keys():
                    if hierarchical:
                        for node in params.branch:
                            cell = node.cnode.cell
                            if cell not in model_cells:
                                model_cells.append(cell)
                    else:
                        cell = params.cell
                        model_cells.append(cell)

    model2params = {}
    for params in cell_iter(topcell):
        if params.cell_open:
            if params.cell in model_cells:
                if bottom_up:
                    model2params[params.cell.cell_name] = params
                else:
                    yield params
        if params.cell_close:
            if params.cell.cell_name in model2params:
                if bottom_up:
                    # bottom up iteration: yield open + close on cell_close
                    yield model2params[params.cell.cell_name]
                yield params


# information of the cell that is copied when serializing
# TODO not everything here is relevant, need to investigate which attributes are relevant for the deserialization
cell_properties_to_copy = [
    "cellcache",
    "id",
    "bbinfo",
    "name",
    "properties",
    "parameters",
    "func_id",
    "cell_basename",
    "cell_paramsname",
    "cell_name",
    "instantiate",
    "group",
    "name_layer",
    "module",
    "ranges",
    "bbox",
    "params",
    "version",
    "auxiliary",
    "updk",
    "pcell_data",
    "void",
    "default_in",
    "default_out",
    "cm_id",
    "autobbox",
    "bboxbuf",
    "hull",
    "userbbox",
    "add_bbox_flag",
    "userbbox_include",
    "protectbox",
    "hull_based_bbox",
    "store_pins",
    "show_hull",
    "use_hull",
    "hull_based_bbox",
]

def cell_tree_serialize(cell:Cell)->dict:
    """Serialization of a Cell object.

    Args:
        cell (nd.Cell): Top level cell of the cell tree

    Returns:
        dict: Dictionary containing the serialized cell tree
    """
    celltree = {}
    geo_connections = {}
    cm_connections = {}

    for params in cell_iter_bottom_up(topcell=cell):
        if params.cell_close:
            continue
        cell = params.cell
        cell_info = {}
        model_info_dump = {}

        # store 'simple' attributes that do not need to be serialized
        for attr in cell_properties_to_copy:
            cell_info[attr] = getattr(cell, attr)
        # serialize bbox polygon, in case it is a numpy array
        try:
            cell_info["bbox_polygon"] = cell.bbox_polygon.tolist()
        except AttributeError:
            main_logger(f"bbox_polygon of cell {cell.cell_name} is not a numpy array", "warning")
            cell_info["bbox_polygon"] = cell.bbox_polygon

        # TODO this is a bit ugly, but it appears that these attributes can be set when a bbox is generated
        #  Not sure if every cell is garantueed to have these attributes, so that's why it's a separate statement.
        #  Ideally, we make this generic, and ensure that a Cell always has these attributes (default to None?)
        if hasattr(cell, "length"):
            cell_info["length"] = cell.length
        if hasattr(cell, "width"):
            cell_info["width"] = cell.width

        # serialize pin objects
        pins = {}
        for name, node in cell.pin.items():
            pin_id = f"{name}_cell{cell.id}"  # serialize pin to unique reference string
            pins[pin_id] = node.to_dict()
        cell_info["pins"] = pins
        # also serialize cnode information
        cell_info["cnode"] = f"{cell.cnode.name}_cell{cell.id}"

        # store cell pin connections (can be both cm connection and geo connection for the cell)
        for pinname, pin in cell.pin.items():
            pin1_id = f"{pin.name}_cell{cell.id}"  # serialize pin1 to unique reference string

            # cm connections
            connections = []
            for connection in pin.nb_cm:
                pin2_id = f"{connection[0].name}_cell{cell.id}"  # serialize pin2 to unique reference string
                if isinstance(connection[1], cm.ModelInfo):
                    model_new = connection[1].model_dump()
                else:
                    model_new = connection[1]
                connection = (pin2_id, model_new, *connection[2:])
                connections.append(connection)
            cm_connections[pin1_id] = connections

            # geometrical connections
            connections = []
            for connection in pin.nb_geo:
                if connection[0].cnode.instance is not None:  # transform connection pin to unique reference
                    if connection[0].basename not in connection[0].cnode.instance.pin:
                        # this is an auxiliary pin that is used to help placement. Not relevant for connectivity.
                        continue
                    pin2_id = f"{connection[0].basename}_instance{connection[0].cnode.instance.id}"
                else:
                    if connection[0].name not in connection[0].cnode.cell.pin:
                        # this is an auxiliary pin that is used to help placement. Not relevant for connectivity.
                        continue
                    pin2_id = f"{connection[0].name}_cell{connection[0].cnode.cell.id}"

                connection = (pin2_id, connection[1].tolist())
                connections.append(connection)

            geo_connections[pin1_id] = connections

        # serialize and save instances in Cell
        instances = []
        for inode, xya, flip in params.iters["instance"]:
            instances.append(
                {
                    "instance_id": inode.instance.id,  # necessary for references to instance nodes after deserialization
                    "cell_id": inode.instance.cell.id,  # reference to cell that is to be put in the deserialization
                    "x": xya[0],
                    "y": xya[1],
                    "a": xya[2],
                    "flip": inode.flip,
                    "label": inode.instance.label,
                }
            )

            # store instance pin2pin connections
            for name, pin in inode.instance.pin.items():
                pin1_id = f"{pin.basename}_instance{inode.instance.id}"
                connections = []
                for connection in pin.nb_geo:
                    if connection[0].cnode.instance is not None:  # instance pin
                        if connection[0].basename not in connection[0].cnode.instance.pin:
                            # this is an auxiliary pin that is used to help placement. Not relevant for connectivity.
                            continue
                        # transform connection pin to unique reference
                        pin2_id = f"{connection[0].basename}_instance{connection[0].cnode.instance.id}"
                    else:  # cell pins
                        if connection[0].name not in connection[0].cnode.cell.pin:
                            # this is an auxiliary pin that is used to help placement. Not relevant for connectivity.
                            continue
                        pin2_id = f"{connection[0].name}_cell{connection[0].cnode.cell.id}"

                    connection = (pin2_id, connection[1].tolist())
                    connections.append(connection)

                geo_connections[pin1_id] = connections

        cell_info["instances"] = instances

        # serialize and save polygons in the cell
        polygons = []
        for node, polygon in cell.polygons:
            polygons.append(
                {
                    "polygon": polygon.to_dict(),
                    "x": node.x,
                    "y": node.y,
                    "a": node.a,
                    "flip": node.flip,
                    "flop": node.flop,
                    "scale": node.scale,
                }
            )
        cell_info["polygons"] = polygons

        polylines = []
        for node, polyline in cell.polylines:
            polylines.append(
                {
                    "polyline": polyline.to_dict(),
                    "x": node.x,
                    "y": node.y,
                    "a": node.a,
                    "flip": node.flip,
                    "flop": node.flop,
                    "scale": node.scale,
                }
            )
        cell_info["polylines"] = polylines

        annotations = []
        for node, annotation in cell.annotations:
            annotations.append(
                {
                    "annotation": annotation.to_dict(),
                    "x": node.x,
                    "y": node.y,
                    "a": node.a,
                }
            )
        cell_info["annotations"] = annotations

        # TODO serialize and save gds files in the cell

        # save serialized cell to serialized cell tree
        celltree[cell.id] = cell_info

    # store all connections to the serialized celltree
    celltree["geo_connections"] = geo_connections
    celltree["cm_connections"] = cm_connections

    return celltree


interconnect_properties_to_copy = [
    "radius",
    "width",
    "angle",
    "xs",
    "layer",
    "adapt_width",
    "adapt_xs",
    "instantiate",
    "pinstyle",
    "PCB",
    "pitch",
    "N",
    "sectionangle",
    "mambalayer",
    "varname",
    "doc",
    "euler_scale"
]

def interconnect_serialize(ic):
    """Serialization function for Interconnect objects.

    Args:
        ic (nd.Interconnect): interconnect object to serialize

    Returns:
        dict: serialized interconnect information
    """
    ic_info = {}
    for attr in interconnect_properties_to_copy:
        ic_info[attr] = getattr(ic, attr)
        if  isinstance(ic_info[attr], list):
            ic_info[attr] = tuple(ic_info[attr])
    ic_info["arrow"] = cell_tree_serialize(ic.arrow)
    return ic_info


# -----------------------------------------------------------------------------
if __name__ == "__main__":
    pass
