# -----------------------------------------------------------------------
# This file is part of Nazca.
#
# Nazca is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or (at
# your option) any later version.
#
# Nazca is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with Nazca.  If not, see <http://www.gnu.org/licenses/>.
# -----------------------------------------------------------------------
#
# @Authors: Katarzyna Lawniczuk, Ronald Broeke 2017(c)
# @email: nazca@brightphotonics.eu

"""
**Demofab PDK icon definition.**
"""

import nazca as nd
import nazca.cfg as cfg
import nazca.icons as icons

# =============================================================================
# initialize icons
# =============================================================================
icon_d2s = nd.icons.Tp_xsection_transition(layer1="DeepLogic", layer2="ShallowLogic")
icon_s2d = nd.icons.Tp_xsection_transition(layer1="ShallowLogic", layer2="DeepLogic")
icon_a2s = nd.icons.Tp_xsection_transition(layer1="ActiveLogic", layer2="ShallowLogic")
icon_s2a = nd.icons.Tp_xsection_transition(layer1="ShallowLogic", layer2="ActiveLogic")

icon_modefilter_sh = nd.icons.Tp_icon_mmi(Nin=1, Nout=1, layer="ShallowLogic")
icon_mmi1x2_sh = nd.icons.Tp_icon_mmi(Nin=1, Nout=2, layer="ShallowLogic")
icon_mmi2x2_sh = nd.icons.Tp_icon_mmi(Nin=2, Nout=2, layer="ShallowLogic")

icon_mmi1x2_dp = nd.icons.Tp_icon_mmi(Nin=1, Nout=2, layer="DeepLogic")
icon_mmi2x2_dp = nd.icons.Tp_icon_mmi(Nin=2, Nout=2, layer="DeepLogic")

icon_strt = icons.icon_strt

icon_grating = icons.Tp_icon_grating(layer="ActiveLogic")

icon_pad_dc = icons.Tp_icon_rounded_pad(bufx=20, bufy=20, layer="MetalDCLogic")