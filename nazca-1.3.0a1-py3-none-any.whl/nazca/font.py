# -----------------------------------------------------------------------
# This file is part of Nazca.
#
# Nazca is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or (at
# your option) any later version.
#
# Nazca is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with Nazca.  If not, see <http://www.gnu.org/licenses/>.
# -----------------------------------------------------------------------
#
# Polygon font output
#
# (c) 2017-2020 Xaveer Leijtens
# (c) 2017-2019 Ronald Broeke

"""
Module to add text to a layout.

Example:
    A simple way to put text in the layout using default settings::

        import nazca as nd

        nd.text(text='Hello world').put(0)
        nd.export_plt()
"""
from __future__ import annotations
from pathlib import Path
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from .netlist import Cell

import pickle
import warnings
import numpy as np
from math import atan2

from . import netlist as net

from .util import md5
from .cfg import default_font as default_fnt  # prevent name clash with function


# Path to this file
_font_path = Path(__file__).parent / "fonts"


class Font:
    """Class to define text object in various fonts.

    Nazca font files have the following structure:
    version: font file version number
    height: total height of the font
    space: interword space (can be 0 for fixed fonts)

    tfont: dictionary of characters:
        key: character
        value: tuple[w, p]
        w: (float) width of that character
        p: list of polygons, of which each is a list of (x,y) coordinate points
    """

    def __init__(self, fontfile: str | Path = default_fnt, box_layer: str = None, box_buf: float = 0):
        """Initialize a font object.

        Args:
            fontfile (str): name of the fontfile (.nft)
            box_layer (str | int | tuple): layer reference to generate a square
                box in behind the text, e.g. for NOFILL (default = None)
            box_buf (float): extra buffer for the box_layer in um

        Returns:
            None
        """
        self.fontfile = fontfile
        self.box_layer = box_layer
        self.box_buf = box_buf

        # Convert to Path and add .nft extension if missing
        ff = Path(fontfile)
        if ff.suffix != ".nft":
            ff = ff.with_suffix(".nft")

        # Check if file exists, otherwise check in fonts subdirectory
        if not ff.exists():
            ff = _font_path / ff.name
            if not ff.exists():
                print(f"Can't open font '{fontfile}'. Using '{default_fnt}'.")
                ff = _font_path / f"{default_fnt}.nft"

        # Store short name without extension
        self.ff = ff.stem

        with open(ff, "rb") as f:
            self.version, self.lh, self.spc, self.tfont = pickle.load(f)
        # Line spacing scale: same as intercharacter space or fixed ratio if the
        # intercharacter space is zero.
        self.lss = 1.10 if self.spc == 0 else 1 + self.spc / self.lh

        self.els = self.lss  # Exclusion layer scale
        cwidth = self.tfont["O"][0]  # width of "O"
        self.empty_char = (  # Stub for unknown character
            cwidth,  # Character width
            (
                (
                    (0, 22.5),  # Thin rectangle with left-side opening
                    (0, 42.5),
                    (5, 42.5),
                    (5, 27.5),
                    (30, 27.5),
                    (30, 72.5),
                    (5, 72.5),
                    (5, 57.5),
                    (0, 57.5),
                    (0, 77.5),
                    (35, 77.5),
                    (35, 22.5),
                ),
            ),
        )

    def textheight(self, text: str, height: float = 50) -> float:
        """Returns:
        float: total textheight of line(s) in text
        """
        return (text.count("\n") * self.lss + 1) * height

    def linelength(self, text: str, height: float = 50) -> float:
        """Returns:
        float: total linelength of longest line in (multiline) text
        """
        scale = height / self.lh
        maxsize = 0
        for line in text.split("\n"):
            # return width of line
            size = sum(self.tfont.get(char, self.empty_char)[0] for char in line) * scale
            size += (len(line) - 1) * self.spc * scale
            maxsize = max(maxsize, size)

        return size

    def text(
        self,
        text: str = "Text",
        height: float = 0,
        strokewidth: float = 0,
        layer: Any = 1,
        align: str = "lb",
        box_layer: Any = None,
        box_buf: float = 0,
        tight_box_layer=None,
        instantiate: bool = False,
        cellname: str = "",
    ) -> Cell:
        """Output a cell with text of specified dimensions and alignment.

        In case of an exclusion (NOFILL) box_layer, e.g. for tiling protection,
        the box will be scaled with the text height unless a box_buf value
        is provided. The box_buf represents an absolute
        buffer between the text field and the box edge in um.

        Args:
            text (str): text to display
            height (float): height of the text in um (default=50)
            strokewidth (float): approximate font stroke width in um (height
                takes precedence if both are specified) (default=0, resembling not specified)
            layer (int | string): layer number or name to place text in
            align (str): relative placement: regex: [lcr][bct] (default = 'lb')
                examples: 'lc', 'cc', 'tr'
            box_layer (str | int | tuple): layer reference to generate a square
                box in behind the text, e.g. for NOFILL (default = None)
            box_buf (float): extra buffer for the box_layer in um
            tight_box_layer (str | int | tuple): layer reference to generate a tight box in
                behind the text (convex hull around the text polygons), e.g. for NOFILL (default = None)
            instantiate (bool): instantiate cell (default=False)
            cellname (str): overrule the standard hash text cell naming (default=None)
                Set instantiate=True to get the text as a cell in the gds export.
            xs (str): not yet implemented. optional xsection to place text in. Useful to
                copy text to multiple layers, e.g. a logical layer.

        Returns:
            Cell: cell with text as provided in <text>

        Example::

            import nazca as nd

            message = nd.text(text='Hello world', align='cc')
            message.put(0)
            nd.export_plt()
        """
        if height <= 0 and strokewidth <= 0:
            height = 50
        elif height == 0:
            # Scale font according to the width of the "|" character.
            polygon = self.tfont["|"][1][0]  # Just the first polygon
            _x = [x for x, y in polygon]
            height = self.lh * strokewidth / (max(_x) - min(_x))
            print(strokewidth, self.lh, height)
        if not box_layer:
            box_layer = self.box_layer

        if box_buf is None:
            box_buf = 0
        if box_buf == 0:
            if self.box_buf > 0:
                box_buf = self.box_buf
            else:
                box_buf = height * (self.els - 1)

        if not isinstance(layer, (list, tuple)):
            layers = [layer]
        else:
            layers = layer

        halign, valign = align.lower()
        if halign not in "lcr":
            warnings.warn("text halign parameter not one of lcr, default to 'l'.")
            halign = "l"
        if valign not in "bct":
            warnings.warn("text valign parameter not one of bct, default to 'b'.")
            valign = "b"

        # Character parameters
        scale = height / self.lh
        ls = self.lss * height  # line spacing

        id5 = md5(text + align.lower() + "{}{}{}".format(self.ff, height, layer))
        if cellname is None or cellname == "":
            cellname = "text_{}_{}".format(self.ff, id5)
        with net.Cell(cellname, instantiate=instantiate) as txt:
            txt.auxiliary = True
            bby = self.textheight(text, height)
            if valign == "c":
                ypos = bby / 2 - height
            elif valign == "t":
                ypos = -height
            else:
                ypos = bby - height

            cat_hullarrs = None
            for line in text.split("\n"):
                bbx = self.linelength(line, height)
                if halign == "c":
                    xpos = -bbx / 2
                elif halign == "r":
                    xpos = -bbx
                else:
                    xpos = 0
                xpos0 = xpos

                for char in line:
                    # w, polys = self.tfont[char]
                    w, polys = self.tfont.get(char, self.empty_char)
                    for poly in polys:
                        XY = [(x * scale, y * scale) for x, y in poly]
                        if len(XY) > 3:
                            for lay in layers:
                                net.Polygon(points=XY, layer=lay).put(xpos, ypos, 0),
                        if len(poly) > 0:
                            if cat_hullarrs is None:
                                cat_hullarrs = np.array(XY) + np.array([xpos, ypos])
                            else:
                                cat_hullarrs = np.concatenate(
                                    [cat_hullarrs, np.array(XY) + np.array([xpos, ypos])]
                                )
                    xpos = xpos + (w + self.spc) * scale
                if box_layer is not None:
                    net.Polygon(
                        layer=box_layer,
                        points=[
                            (0, 0),
                            (0, height + 2 * box_buf),
                            (bbx + 2 * box_buf, height + 2 * box_buf),
                            (bbx + 2 * box_buf, 0),
                        ],
                    ).put(xpos0 - box_buf, ypos - box_buf, 0)
                ypos -= ls

            if tight_box_layer is not None:
                H = convex_hull(cat_hullarrs.tolist())
                net.Polygon(points=H, layer=tight_box_layer).put(0)

            net.Pin(name="b0", xs=None).put(xpos, ypos + ls, 0)
        return txt

    def sample(self, height: float = 50, layer: int | str = 1, instantiate: bool = False) -> Cell:
        """Return a cell with all characters present in a font.

        Args:
            height (float): height off the text in um
            layer (int | string): layer number or name to place text in
            instantiate (bool): instantiate cell (default False)

        Returns:
            Cell: cell with a sample of all characters in the font.

        Example::

            cousine = nd.Font("cousine")
            sample = cousine.sample()
            sample.put()
            nd.export_plt()
        """
        id5 = md5("{}_{}_{}".format(self.ff, height, layer))
        with net.Cell("sample_{}_{}".format(self.ff, id5), instantiate=instantiate) as S:
            s = self.characters()
            n = 15
            lines = "\n".join([s[i : i + n] for i in range(0, len(s), n)])
            self.text(lines, height=height, align="cc", layer=layer, instantiate=False).put()
        return S

    def characters(self) -> str:
        """Get all font characters.

        Returns:
            str: string with all characters present in a font
        """
        return "".join(sorted(list(self.tfont.keys())))


# Implement default font callable via nazca.text()
fdef = Font()


def default_font(f: str = default_fnt):
    global fdef
    fdef = Font(f)


# =============================================================================
# Functions to calculate the convex hull of a collection of points
# =============================================================================
def is_counter_clockwise(a: tuple, b: tuple, c: tuple) -> bool:
    """Determines if three points are in clockwise order.

    Args:
        a (tuple): first point
        b (tuple): second point
        c (tuple): third point

    Returns:
        bool
    """
    prod = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
    return True if prod > 0 else False


def polar_angle(point: tuple, start_point: tuple) -> float:
    """Calculate the angle of a vector between two points with respect to the x axis.

    Args:
        point (tuple): second point
        start_point (tuple): starting point

    Returns:
        float: angle in radians
    """
    dx = point[0] - start_point[0]
    dy = point[1] - start_point[1]
    return atan2(dy, dx)


def convex_hull(points: list[tuple]) -> list[tuple]:
    """Calculate the convex hull of a collection of points.

    Args:
        points (list[tuple]): list of points

    Returns:
        list[tuple]: convex hull as a new list of points
    """
    start_point = min(points, key=lambda p: p[1])
    pre_sort = sorted(
        points, key=lambda p: p[0]
    )  # to prevent problems with points at the same y coordinate as start_point
    sorted_points = sorted(pre_sort, key=lambda p: polar_angle(p, start_point))  # sort by angle
    result = [sorted_points[0], sorted_points[1]]
    # loop over points and keep the ones resulting in a convex shape
    for i in range(2, len(sorted_points)):
        while len(result) >= 2:
            if is_counter_clockwise(result[-2], result[-1], sorted_points[i]):
                break
            result.pop()
        result.append(sorted_points[i])
    result.append(sorted_points[0])
    return result


def text(
    text="Text",
    height: float = 0,
    strokewidth: float = 0,
    layer=1,
    stretch=1,
    align: str = "lb",
    linewidth=1,
    instantiate: bool = False,
    box_layer: Any = None,
    box_buf=None,
    tight_box_layer=None,
    cellname: str = None,
):
    return fdef.text(
        text=text,
        height=height,
        strokewidth=strokewidth,
        layer=layer,
        align=align,
        box_layer=box_layer,
        tight_box_layer=tight_box_layer,
        instantiate=instantiate,
        cellname=cellname,
    )


def linelength(text: str, height: float = 50) -> float:
    return fdef.linelength(text, height)
